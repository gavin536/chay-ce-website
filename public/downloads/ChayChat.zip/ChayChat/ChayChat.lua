local ADDON_NAME = ...
local addon = {}

local DEFAULTS = {
    point = "CENTER",
    relativePoint = "CENTER",
    x = 0,
    y = 0,
    width = 520,
    height = 420,
    locked = false,
    openIncoming = true,
    openOutgoing = true,
    hideDefaultWhispers = false,
    hideWhispersInMainChat = false,
    fontSize = 13,
    historyLimit = 250,
    minimapAngle = 225,
    customBackground = "",
}

local COLORS = {
    bg = {0.015, 0.012, 0.014, 1},
    bg2 = {0.055, 0.014, 0.018, 1},
    border = {0.62, 0.04, 0.05, 1},
    borderDark = {0.20, 0.02, 0.03, 1},
    text = {0.92, 0.88, 0.82, 1},
    dim = {0.60, 0.56, 0.54, 1},
    red = {0.85, 0.08, 0.08, 1},
    gold = {1.00, 0.72, 0.20, 1},
    bnet = {0.18, 0.58, 1.00, 1},
    player = {0.90, 0.90, 0.90, 1},
    incoming = {0.97, 0.90, 0.80, 1},
    outgoing = {0.72, 0.88, 1.00, 1},
}

local state = {
    db = nil,
    conversations = {},
    order = {},
    currentKey = nil,
    unread = {},
    copyMode = false,
    lastOutgoingToken = nil,
    filterInstalled = false,
}

local root = CreateFrame("Frame", "ChayChatCoreFrame")
root:RegisterEvent("ADDON_LOADED")
root:RegisterEvent("PLAYER_LOGIN")
root:RegisterEvent("CHAT_MSG_WHISPER")
root:RegisterEvent("CHAT_MSG_WHISPER_INFORM")
root:RegisterEvent("CHAT_MSG_BN_WHISPER")
root:RegisterEvent("CHAT_MSG_BN_WHISPER_INFORM")

local mainFrame
local messageFrame
local copyScroll
local copyEditBox
local replyBox
local titleText
local subtitleText
local tabBar
local menuFrame
local optionsFrame
local minimapButton
local customBackgroundTexture

local function CopyDefaults(src)
    local dst = {}
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = CopyDefaults(v)
        else
            dst[k] = v
        end
    end
    return dst
end

local function EnsureDB()
    if type(ChayChatDB) ~= "table" then
        ChayChatDB = CopyDefaults(DEFAULTS)
    end
    for k, v in pairs(DEFAULTS) do
        if ChayChatDB[k] == nil then
            if type(v) == "table" then
                ChayChatDB[k] = CopyDefaults(v)
            else
                ChayChatDB[k] = v
            end
        end
    end
    state.db = ChayChatDB
    state.db.width = math.max(420, tonumber(state.db.width) or DEFAULTS.width)
    state.db.height = math.max(300, tonumber(state.db.height) or DEFAULTS.height)
    state.db.fontSize = math.max(10, math.min(22, tonumber(state.db.fontSize) or DEFAULTS.fontSize))
    state.db.historyLimit = math.max(50, math.min(1000, tonumber(state.db.historyLimit) or DEFAULTS.historyLimit))
end

local function Clamp(value, minValue, maxValue)
    value = tonumber(value) or minValue
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function GetHideWhispersInMainChat()
    local db = state.db or ChayChatDB
    if type(db) == "table" and type(db.settings) == "table" and db.settings.hideWhispersInMainChat ~= nil then
        return db.settings.hideWhispersInMainChat and true or false
    end
    if type(db) == "table" and db.hideWhispersInMainChat ~= nil then
        return db.hideWhispersInMainChat and true or false
    end
    return false
end


local function HexByte(value)
    return math.floor(Clamp((tonumber(value) or 0) * 255, 0, 255) + 0.5)
end

local function ColorText(text, r, g, b)
    return string.format("|cff%02x%02x%02x%s|r", HexByte(r), HexByte(g), HexByte(b), tostring(text or ""))
end

local function StripServer(name)
    if not name or name == "" then return "Unknown" end
    local plain = tostring(name)
    plain = plain:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    plain = plain:gsub("|K.-|k", "Battle.net")
    return plain
end

local function PlainForCopy(text)
    if not text then return "" end
    local plain = tostring(text)
    plain = plain:gsub("|c%x%x%x%x%x%x%x%x", "")
    plain = plain:gsub("|r", "")
    plain = plain:gsub("|H.-|h%[(.-)%]|h", "[%1]")
    plain = plain:gsub("|T.-|t", "")
    plain = plain:gsub("|K.-|k", "Battle.net")
    return plain
end

local function ClassColorFromGUID(guid)
    if guid and GetPlayerInfoByGUID then
        local _, classFile = GetPlayerInfoByGUID(guid)
        if classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile] then
            local c = RAID_CLASS_COLORS[classFile]
            return c.r, c.g, c.b
        end
    end
    return COLORS.player[1], COLORS.player[2], COLORS.player[3]
end

local function CurrentRealmNormalized()
    local realm = GetNormalizedRealmName and GetNormalizedRealmName() or GetRealmName()
    realm = realm or ""
    realm = realm:gsub("%s+", "")
    return realm
end

local function NormalizePlayerName(name)
    if not name or name == "" then return "Unknown" end
    local clean = tostring(name)
    if Ambiguate then
        clean = Ambiguate(clean, "none") or clean
    end
    return clean
end

local function GetBNetDisplayName(bnID, fallback)
    if bnID and C_BattleNet and C_BattleNet.GetAccountInfoByID then
        local info = C_BattleNet.GetAccountInfoByID(bnID)
        if info then
            if info.accountName and info.accountName ~= "" then
                return info.accountName
            end
            if info.battleTag and info.battleTag ~= "" then
                return info.battleTag
            end
        end
    end
    return fallback and fallback ~= "" and fallback or "Battle.net"
end

local function GetBNetInviteName(bnID)
    if not (bnID and C_BattleNet and C_BattleNet.GetAccountInfoByID) then return nil end
    local info = C_BattleNet.GetAccountInfoByID(bnID)
    local game = info and info.gameAccountInfo
    if not game or game.clientProgram ~= BNET_CLIENT_WOW then return nil end
    if not game.characterName or game.characterName == "" then return nil end
    local name = game.characterName
    local realm = game.realmName or game.realmDisplayName
    if realm and realm ~= "" then
        realm = realm:gsub("%s+", "")
        if realm ~= "" and realm ~= CurrentRealmNormalized() then
            name = name .. "-" .. realm
        end
    end
    return name
end

local function ConversationKey(kind, name, bnID)
    if kind == "BN" and bnID then
        return "BN:" .. tostring(bnID)
    end
    return kind .. ":" .. string.lower(tostring(name or "unknown"))
end

local function EnsureConversation(kind, name, bnID, guid)
    local displayName = kind == "BN" and GetBNetDisplayName(bnID, name) or NormalizePlayerName(name)
    local key = ConversationKey(kind, displayName, bnID)
    local convo = state.conversations[key]
    if not convo then
        convo = {
            key = key,
            kind = kind,
            displayName = displayName,
            whisperName = kind == "BN" and GetBNetInviteName(bnID) or NormalizePlayerName(name),
            bnID = bnID,
            guid = guid,
            lines = {},
            lastTime = time(),
        }
        state.conversations[key] = convo
        table.insert(state.order, 1, key)
    else
        convo.displayName = displayName or convo.displayName
        convo.bnID = bnID or convo.bnID
        convo.guid = guid or convo.guid
        if kind == "BN" then
            convo.whisperName = GetBNetInviteName(convo.bnID) or convo.whisperName
        elseif name and name ~= "" then
            convo.whisperName = NormalizePlayerName(name)
        end
        convo.lastTime = time()
        for i, existingKey in ipairs(state.order) do
            if existingKey == key then
                table.remove(state.order, i)
                break
            end
        end
        table.insert(state.order, 1, key)
    end
    return convo
end

local function SaveFramePosition()
    if not mainFrame or not state.db then return end
    local point, _, relativePoint, x, y = mainFrame:GetPoint(1)
    state.db.point = point or DEFAULTS.point
    state.db.relativePoint = relativePoint or DEFAULTS.relativePoint
    state.db.x = x or 0
    state.db.y = y or 0
    state.db.width = mainFrame:GetWidth()
    state.db.height = mainFrame:GetHeight()
end

local function SafeCall(fn, ...)
    if type(fn) ~= "function" then return false end
    local ok = pcall(fn, ...)
    return ok
end

local function ApplyBackdrop(frame, bg, border)
    frame:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    frame:SetBackdropColor(bg[1], bg[2], bg[3], bg[4])
    frame:SetBackdropBorderColor(border[1], border[2], border[3], border[4])
end

local function CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
    button:SetSize(width or 78, height or 24)
    ApplyBackdrop(button, COLORS.bg2, COLORS.borderDark)
    button.text = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    button.text:SetPoint("CENTER")
    button.text:SetText(text or "")
    button.text:SetTextColor(COLORS.text[1], COLORS.text[2], COLORS.text[3], COLORS.text[4])
    button:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(COLORS.red[1], COLORS.red[2], COLORS.red[3], 1)
    end)
    button:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(COLORS.borderDark[1], COLORS.borderDark[2], COLORS.borderDark[3], 1)
    end)
    return button
end

local function CreateEditBox(parent, multiline)
    local box = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    ApplyBackdrop(box, {0.02, 0.018, 0.020, 1}, COLORS.borderDark)
    box:SetAutoFocus(false)
    box:SetFontObject(ChatFontNormal)
    box:SetTextColor(COLORS.text[1], COLORS.text[2], COLORS.text[3], 1)
    box:SetTextInsets(8, 8, 4, 4)
    box:SetMultiLine(multiline and true or false)
    box:SetMaxLetters(0)
    box:EnableMouse(true)
    return box
end

local function RefreshCopyBox()
    if not copyEditBox then return end
    local convo = state.currentKey and state.conversations[state.currentKey]
    if not convo then
        copyEditBox:SetText("")
        return
    end
    local lines = {}
    for _, entry in ipairs(convo.lines) do
        table.insert(lines, entry.copy)
    end
    copyEditBox:SetText(table.concat(lines, "\n"))
    if copyScroll and copyScroll.GetWidth then
        copyEditBox:SetWidth(math.max(320, copyScroll:GetWidth() - 12))
    end
    copyEditBox:SetHeight(math.max(800, (#lines * 18) + 60))
    copyEditBox:HighlightText(0, 0)
end

local function RefreshTabs()
    if not tabBar then return end
    for _, child in ipairs({tabBar:GetChildren()}) do
        child:Hide()
    end
    tabBar.buttons = tabBar.buttons or {}
    local x = 0
    local maxTabs = math.min(#state.order, 8)
    for i = 1, maxTabs do
        local key = state.order[i]
        local convo = state.conversations[key]
        if convo then
            local button = tabBar.buttons[i]
            if not button then
                button = CreateButton(tabBar, "", 88, 24)
                tabBar.buttons[i] = button
            end
            button:ClearAllPoints()
            button:SetPoint("LEFT", tabBar, "LEFT", x, 0)
            button:SetSize(92, 24)
            button.key = key
            local label = StripServer(convo.displayName)
            if #label > 12 then label = label:sub(1, 11) .. "…" end
            if state.unread[key] then label = "* " .. label end
            button.text:SetText(label)
            if state.currentKey == key then
                button:SetBackdropColor(0.14, 0.02, 0.025, 1)
                button:SetBackdropBorderColor(COLORS.red[1], COLORS.red[2], COLORS.red[3], 1)
            else
                button:SetBackdropColor(COLORS.bg2[1], COLORS.bg2[2], COLORS.bg2[3], 1)
                button:SetBackdropBorderColor(COLORS.borderDark[1], COLORS.borderDark[2], COLORS.borderDark[3], 1)
            end
            button:SetScript("OnClick", function(self)
                addon:OpenConversation(self.key, true)
            end)
            button:Show()
            x = x + 96
        end
    end
end

local function AddDisplayMessage(entry)
    if not messageFrame then return end
    messageFrame:AddMessage(entry.display)
    if messageFrame.ScrollToBottom then
        messageFrame:ScrollToBottom()
    end
end

function addon:RefreshConversation()
    if not mainFrame or not messageFrame then return end
    messageFrame:Clear()
    local convo = state.currentKey and state.conversations[state.currentKey]
    if not convo then
        titleText:SetText("ChayChat")
        subtitleText:SetText("No whispers this session")
        if replyBox then replyBox:SetText("") end
        RefreshCopyBox()
        RefreshTabs()
        return
    end

    titleText:SetText(convo.kind == "BN" and ColorText(convo.displayName, COLORS.bnet[1], COLORS.bnet[2], COLORS.bnet[3]) or convo.displayName)
    local sub = convo.kind == "BN" and "Battle.net whisper"
        or (convo.whisperName and ("WoW whisper: " .. convo.whisperName) or "WoW whisper")
    subtitleText:SetText(sub)

    for _, entry in ipairs(convo.lines) do
        AddDisplayMessage(entry)
    end
    RefreshCopyBox()
    RefreshTabs()
end

function addon:OpenConversation(key, showWindow)
    if not key or not state.conversations[key] then return end
    state.currentKey = key
    state.unread[key] = nil
    if mainFrame and showWindow then
        mainFrame:Show()
    end
    self:RefreshConversation()
end

local function BuildCopyLine(timestamp, directionLabel, senderPlain, text)
    return string.format("[%s] %s %s: %s", timestamp, directionLabel, senderPlain, PlainForCopy(text))
end

local function BuildDisplayLine(timestamp, direction, senderText, text, kind, guid)
    local prefixColor = direction == "OUT" and COLORS.outgoing or COLORS.incoming
    local nameR, nameG, nameB = COLORS.player[1], COLORS.player[2], COLORS.player[3]
    if kind == "BN" then
        nameR, nameG, nameB = COLORS.bnet[1], COLORS.bnet[2], COLORS.bnet[3]
    else
        nameR, nameG, nameB = ClassColorFromGUID(guid)
    end
    local label = direction == "OUT" and "To" or "From"
    local directionText = ColorText("[" .. timestamp .. "]", COLORS.dim[1], COLORS.dim[2], COLORS.dim[3])
    local labelText = ColorText(label, prefixColor[1], prefixColor[2], prefixColor[3])
    local sender = ColorText(senderText, nameR, nameG, nameB)
    return string.format("%s %s %s: %s", directionText, labelText, sender, tostring(text or ""))
end

function addon:AddLine(convo, direction, text, senderName, guid)
    if not convo then return end
    local timestamp = date("%H:%M")
    local senderPlain = StripServer(senderName or convo.displayName)
    local entry = {
        direction = direction,
        text = text or "",
        time = time(),
        display = BuildDisplayLine(timestamp, direction, senderName or convo.displayName, text, convo.kind, guid or convo.guid),
        copy = BuildCopyLine(timestamp, direction == "OUT" and "To" or "From", senderPlain, text),
    }
    table.insert(convo.lines, entry)
    while #convo.lines > state.db.historyLimit do
        table.remove(convo.lines, 1)
    end

    if state.currentKey == convo.key then
        if messageFrame then AddDisplayMessage(entry) end
        if state.copyMode then RefreshCopyBox() end
    else
        state.unread[convo.key] = true
    end
    RefreshTabs()
end

local function ToggleCopyMode(enabled)
    state.copyMode = enabled and true or false
    if messageFrame then messageFrame:SetShown(not state.copyMode) end
    if copyScroll then copyScroll:SetShown(state.copyMode) end
    if state.copyMode then RefreshCopyBox() end
end

local function ShowMenuForCurrent(anchor)
    if not menuFrame then return end
    local convo = state.currentKey and state.conversations[state.currentKey]
    if not convo then return end
    for _, child in ipairs({menuFrame:GetChildren()}) do
        child:Hide()
    end
    if menuFrame.actionButtons then
        for _, button in ipairs(menuFrame.actionButtons) do
            button:Show()
        end
    end
    menuFrame:SetSize(160, 142)
    menuFrame.convo = convo
    menuFrame:ClearAllPoints()
    menuFrame:SetPoint("TOPLEFT", anchor or mainFrame, "BOTTOMLEFT", 0, -4)
    menuFrame:Show()
    menuFrame:Raise()
end

local function SendReply()
    local convo = state.currentKey and state.conversations[state.currentKey]
    if not convo or not replyBox then return end
    local msg = replyBox:GetText() or ""
    msg = msg:gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "" then return end

    if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then
        print("|cffff3030ChayChat:|r Chat messaging is locked down right now.")
        return
    end

    if convo.kind == "BN" then
        if convo.bnID and C_BattleNet and C_BattleNet.SendWhisper then
            local ok = C_BattleNet.SendWhisper(convo.bnID, msg)
            if not ok then
                print("|cffff3030ChayChat:|r Battle.net whisper failed.")
                return
            end
        else
            print("|cffff3030ChayChat:|r Missing Battle.net account ID for this whisper.")
            return
        end
    else
        if not convo.whisperName or convo.whisperName == "" then
            print("|cffff3030ChayChat:|r Missing player name for this whisper.")
            return
        end
        SendChatMessage(msg, "WHISPER", nil, convo.whisperName)
    end
    state.lastOutgoingToken = (convo.key or "") .. ":" .. msg .. ":" .. tostring(GetTime())
    replyBox:SetText("")
end

local function ApplyCustomBackground()
    if not customBackgroundTexture or not state.db then return end
    local path = state.db.customBackground or ""
    path = path:gsub("^%s+", ""):gsub("%s+$", "")
    if path == "" then
        customBackgroundTexture:Hide()
        return
    end
    customBackgroundTexture:SetTexture(path)
    customBackgroundTexture:SetAlpha(0.22)
    customBackgroundTexture:Show()
end

local function ApplyMainFrameStyle()
    if not mainFrame then return end
    mainFrame:SetAlpha(1)
    ApplyBackdrop(mainFrame, COLORS.bg, COLORS.border)
    if mainFrame.inner then
        mainFrame.inner:SetAlpha(1)
        ApplyBackdrop(mainFrame.inner, {0.02, 0.015, 0.018, 1}, COLORS.borderDark)
    end
    ApplyCustomBackground()
end

local function CreateMenuFrame()
    if menuFrame then return end
    menuFrame = CreateFrame("Frame", "ChayChatActionMenu", UIParent, "BackdropTemplate")
    menuFrame:SetSize(160, 142)
    menuFrame:SetFrameStrata("DIALOG")
    ApplyBackdrop(menuFrame, {0.015, 0.012, 0.014, 1}, COLORS.border)
    menuFrame:Hide()

    menuFrame.actionButtons = {}

    local function makeRow(label, y, handler)
        local b = CreateButton(menuFrame, label, 138, 24)
        b:SetPoint("TOP", menuFrame, "TOP", 0, y)
        b:SetScript("OnClick", function()
            local convo = menuFrame.convo
            menuFrame:Hide()
            if convo then handler(convo) end
        end)
        table.insert(menuFrame.actionButtons, b)
        return b
    end

    makeRow("Invite Group", -12, function(convo)
        local name = convo.kind == "BN" and GetBNetInviteName(convo.bnID) or convo.whisperName
        if name and name ~= "" and C_PartyInfo and C_PartyInfo.InviteUnit then
            C_PartyInfo.InviteUnit(name)
        else
            print("|cffff3030ChayChat:|r No WoW character available to invite.")
        end
    end)

    makeRow("Invite Guild", -40, function(convo)
        local name = convo.kind == "BN" and GetBNetInviteName(convo.bnID) or convo.whisperName
        if name and name ~= "" and C_GuildInfo and C_GuildInfo.Invite then
            C_GuildInfo.Invite(name)
        else
            print("|cffff3030ChayChat:|r No WoW character available for guild invite.")
        end
    end)

    makeRow("Copy Mode", -68, function()
        ToggleCopyMode(true)
    end)

    makeRow("Close Menu", -96, function() end)
end

local function CreateOptionsFrame()
    if optionsFrame then return end
    optionsFrame = CreateFrame("Frame", "ChayChatOptions", UIParent, "BackdropTemplate")
    optionsFrame:SetSize(380, 290)
    optionsFrame:SetPoint("CENTER")
    optionsFrame:SetFrameStrata("DIALOG")
    optionsFrame:SetMovable(true)
    optionsFrame:EnableMouse(true)
    optionsFrame:RegisterForDrag("LeftButton")
    optionsFrame:SetScript("OnDragStart", optionsFrame.StartMoving)
    optionsFrame:SetScript("OnDragStop", optionsFrame.StopMovingOrSizing)
    ApplyBackdrop(optionsFrame, COLORS.bg, COLORS.border)
    optionsFrame:Hide()

    local title = optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -14)
    title:SetText("ChayChat Options")
    title:SetTextColor(COLORS.gold[1], COLORS.gold[2], COLORS.gold[3], 1)

    local close = CreateButton(optionsFrame, "X", 24, 22)
    close:SetPoint("TOPRIGHT", -12, -12)
    close:SetScript("OnClick", function() optionsFrame:Hide() end)

    local function makeCheck(label, key, y)
        local cb = CreateFrame("CheckButton", nil, optionsFrame, "UICheckButtonTemplate")
        cb:SetPoint("TOPLEFT", 18, y)
        cb.Text:SetText(label)
        cb.Text:SetTextColor(COLORS.text[1], COLORS.text[2], COLORS.text[3], 1)
        cb:SetChecked(state.db[key] and true or false)
        cb:SetScript("OnClick", function(self)
            state.db[key] = self:GetChecked() and true or false
            if key == "locked" and mainFrame then
                mainFrame:EnableMouse(not state.db.locked)
            end
        end)
        return cb
    end

    makeCheck("Open window on incoming whispers", "openIncoming", -48)
    makeCheck("Open window when I send a whisper", "openOutgoing", -76)
    makeCheck("Lock main window position", "locked", -104)
    makeCheck("Hide whispers from default chat frames", "hideDefaultWhispers", -132)

    local fs = optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    fs:SetPoint("TOPLEFT", 22, -166)
    fs:SetText("Custom background path")
    fs:SetTextColor(COLORS.dim[1], COLORS.dim[2], COLORS.dim[3], 1)

    local pathBox = CreateEditBox(optionsFrame, false)
    pathBox:SetSize(250, 24)
    pathBox:SetPoint("TOPLEFT", 20, -184)
    pathBox:SetText(state.db.customBackground or "")
    pathBox:SetScript("OnEnterPressed", function(self)
        state.db.customBackground = self:GetText() or ""
        self:ClearFocus()
        ApplyCustomBackground()
    end)
    pathBox:SetScript("OnEditFocusLost", function(self)
        state.db.customBackground = self:GetText() or ""
        ApplyCustomBackground()
    end)

    local apply = CreateButton(optionsFrame, "Apply", 74, 24)
    apply:SetPoint("LEFT", pathBox, "RIGHT", 8, 0)
    apply:SetScript("OnClick", function()
        state.db.customBackground = pathBox:GetText() or ""
        ApplyCustomBackground()
    end)

    local note = optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    note:SetPoint("TOPLEFT", 22, -220)
    note:SetWidth(330)
    note:SetJustifyH("LEFT")
    note:SetTextColor(COLORS.dim[1], COLORS.dim[2], COLORS.dim[3], 1)
    note:SetText("Window background is forced solid. Custom image is drawn under the chat panel and cannot make the window transparent.")
end

local function CreateMainFrame()
    if mainFrame then return end

    mainFrame = CreateFrame("Frame", "ChayChatWindow", UIParent, "BackdropTemplate")
    mainFrame:SetSize(state.db.width, state.db.height)
    mainFrame:SetPoint(state.db.point or "CENTER", UIParent, state.db.relativePoint or "CENTER", state.db.x or 0, state.db.y or 0)
    mainFrame:SetFrameStrata("DIALOG")
    mainFrame:SetClampedToScreen(true)
    mainFrame:SetMovable(true)
    mainFrame:SetResizable(true)
    mainFrame:SetMinResize(420, 300)
    mainFrame:EnableMouse(not state.db.locked)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", function(self)
        if not state.db.locked then self:StartMoving() end
    end)
    mainFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SaveFramePosition()
    end)
    mainFrame:SetScript("OnSizeChanged", function()
        SaveFramePosition()
    end)
    mainFrame:Hide()

    customBackgroundTexture = mainFrame:CreateTexture(nil, "BORDER")
    customBackgroundTexture:SetPoint("TOPLEFT", 6, -6)
    customBackgroundTexture:SetPoint("BOTTOMRIGHT", -6, 6)
    customBackgroundTexture:SetTexCoord(0.05, 0.95, 0.05, 0.95)
    customBackgroundTexture:Hide()

    local header = CreateFrame("Button", nil, mainFrame)
    header:SetPoint("TOPLEFT", 12, -10)
    header:SetPoint("TOPRIGHT", -118, -10)
    header:SetHeight(34)
    header:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    header:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            ShowMenuForCurrent(header)
        end
    end)

    titleText = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    titleText:SetPoint("TOPLEFT", 0, 0)
    titleText:SetPoint("TOPRIGHT", 0, 0)
    titleText:SetJustifyH("LEFT")
    titleText:SetTextColor(COLORS.gold[1], COLORS.gold[2], COLORS.gold[3], 1)
    titleText:SetText("ChayChat")

    subtitleText = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    subtitleText:SetPoint("TOPLEFT", titleText, "BOTTOMLEFT", 0, -2)
    subtitleText:SetPoint("TOPRIGHT", titleText, "BOTTOMRIGHT", 0, -2)
    subtitleText:SetJustifyH("LEFT")
    subtitleText:SetTextColor(COLORS.dim[1], COLORS.dim[2], COLORS.dim[3], 1)
    subtitleText:SetText("No whispers this session")

    local close = CreateButton(mainFrame, "X", 26, 24)
    close:SetPoint("TOPRIGHT", -10, -10)
    close:SetScript("OnClick", function() mainFrame:Hide() end)

    local opts = CreateButton(mainFrame, "Opt", 34, 24)
    opts:SetPoint("RIGHT", close, "LEFT", -4, 0)
    opts:SetScript("OnClick", function()
        CreateOptionsFrame()
        optionsFrame:SetShown(not optionsFrame:IsShown())
    end)

    local actions = CreateButton(mainFrame, "Actions", 66, 24)
    actions:SetPoint("RIGHT", opts, "LEFT", -4, 0)
    actions:SetScript("OnClick", function(self) ShowMenuForCurrent(self) end)

    tabBar = CreateFrame("Frame", nil, mainFrame)
    tabBar:SetPoint("TOPLEFT", 12, -50)
    tabBar:SetPoint("TOPRIGHT", -12, -50)
    tabBar:SetHeight(26)

    mainFrame.inner = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    mainFrame.inner:SetPoint("TOPLEFT", 12, -80)
    mainFrame.inner:SetPoint("BOTTOMRIGHT", -12, 56)

    messageFrame = CreateFrame("ScrollingMessageFrame", nil, mainFrame.inner)
    messageFrame:SetPoint("TOPLEFT", 10, -10)
    messageFrame:SetPoint("BOTTOMRIGHT", -10, 10)
    messageFrame:SetFont("Fonts\\FRIZQT__.TTF", state.db.fontSize, "OUTLINE")
    messageFrame:SetJustifyH("LEFT")
    messageFrame:SetMaxLines(500)
    messageFrame:SetFading(false)
    messageFrame:SetIndentedWordWrap(true)
    messageFrame:EnableMouse(true)
    messageFrame:EnableMouseWheel(true)
    if messageFrame.SetHyperlinksEnabled then
        messageFrame:SetHyperlinksEnabled(true)
    end
    messageFrame:SetScript("OnHyperlinkClick", function(self, link, text, button)
        if ChatFrame_OnHyperlinkShow then
            ChatFrame_OnHyperlinkShow(DEFAULT_CHAT_FRAME, link, text, button)
        end
    end)
    messageFrame:SetScript("OnHyperlinkEnter", function(self, link)
        if GameTooltip and GameTooltip.SetHyperlink then
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:SetHyperlink(link)
            GameTooltip:Show()
        end
    end)
    messageFrame:SetScript("OnHyperlinkLeave", function()
        if GameTooltip then GameTooltip:Hide() end
    end)
    messageFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then
            if IsShiftKeyDown() and self.PageUp then self:PageUp() elseif self.ScrollUp then self:ScrollUp() end
        else
            if IsShiftKeyDown() and self.PageDown then self:PageDown() elseif self.ScrollDown then self:ScrollDown() end
        end
    end)

    copyScroll = CreateFrame("ScrollFrame", nil, mainFrame.inner, "UIPanelScrollFrameTemplate")
    copyScroll:SetPoint("TOPLEFT", 10, -10)
    copyScroll:SetPoint("BOTTOMRIGHT", -28, 10)
    copyScroll:Hide()

    copyEditBox = CreateEditBox(copyScroll, true)
    copyEditBox:SetWidth(440)
    copyEditBox:SetHeight(800)
    copyEditBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        ToggleCopyMode(false)
    end)
    copyScroll:SetScrollChild(copyEditBox)

    local copyMode = CreateButton(mainFrame, "Copy Mode", 86, 26)
    copyMode:SetPoint("BOTTOMLEFT", 12, 18)
    copyMode:SetScript("OnClick", function()
        ToggleCopyMode(not state.copyMode)
    end)

    local toBottom = CreateButton(mainFrame, "Bottom", 60, 26)
    toBottom:SetPoint("LEFT", copyMode, "RIGHT", 6, 0)
    toBottom:SetScript("OnClick", function()
        ToggleCopyMode(false)
        if messageFrame and messageFrame.ScrollToBottom then messageFrame:ScrollToBottom() end
    end)

    replyBox = CreateEditBox(mainFrame, false)
    replyBox:SetPoint("LEFT", toBottom, "RIGHT", 8, 0)
    replyBox:SetPoint("RIGHT", mainFrame, "RIGHT", -82, 0)
    replyBox:SetHeight(28)
    replyBox:SetScript("OnEnterPressed", SendReply)
    replyBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

    local send = CreateButton(mainFrame, "Send", 60, 28)
    send:SetPoint("LEFT", replyBox, "RIGHT", 8, 0)
    send:SetScript("OnClick", SendReply)

    local resize = CreateFrame("Button", nil, mainFrame)
    resize:SetSize(18, 18)
    resize:SetPoint("BOTTOMRIGHT", -2, 2)
    resize:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resize:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resize:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resize:SetScript("OnMouseDown", function()
        if not state.db.locked then mainFrame:StartSizing("BOTTOMRIGHT") end
    end)
    resize:SetScript("OnMouseUp", function()
        mainFrame:StopMovingOrSizing()
        SaveFramePosition()
    end)

    ApplyMainFrameStyle()
    CreateMenuFrame()
end

local function MinimapButtonSetPosition()
    if not minimapButton or not state.db then return end
    local angle = math.rad(state.db.minimapAngle or DEFAULTS.minimapAngle)
    local radius = 80
    local x = math.cos(angle) * radius
    local y = math.sin(angle) * radius
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function CreateMinimapButton()
    -- ChayChat whisper popout owns the visible minimap launcher now.
    -- It registers through LibDataBroker/LibDBIcon so ElvUI, ProjectAzilroka,
    -- and other minimap-button collectors can place it in their button bars.
    local broker = _G.ChayChat
    if broker and broker.RefreshMinimapButton then
        broker.RefreshMinimapButton()
    elseif C_Timer and C_Timer.After then
        C_Timer.After(0.5, function()
            local delayedBroker = _G.ChayChat
            if delayedBroker and delayedBroker.RefreshMinimapButton then
                delayedBroker.RefreshMinimapButton()
            end
        end)
    end
end

function addon:ShowHistoryMenu(anchor)
    if not menuFrame then CreateMenuFrame() end
    if not menuFrame.historyButtons then menuFrame.historyButtons = {} end
    menuFrame.convo = nil
    menuFrame:SetSize(190, math.max(60, math.min(260, (#state.order * 26) + 18)))
    menuFrame:ClearAllPoints()
    menuFrame:SetPoint("TOPRIGHT", anchor or minimapButton, "BOTTOMLEFT", -4, -4)
    for _, child in ipairs({menuFrame:GetChildren()}) do
        child:Hide()
    end
    local maxRows = math.min(#state.order, 9)
    if maxRows == 0 then
        local b = menuFrame.historyButtons[1] or CreateButton(menuFrame, "No whispers", 166, 24)
        menuFrame.historyButtons[1] = b
        b:SetPoint("TOP", 0, -12)
        b.text:SetText("No whispers")
        b:SetScript("OnClick", function() menuFrame:Hide() end)
        b:Show()
    else
        for i = 1, maxRows do
            local key = state.order[i]
            local convo = state.conversations[key]
            local b = menuFrame.historyButtons[i] or CreateButton(menuFrame, "", 166, 24)
            menuFrame.historyButtons[i] = b
            b:ClearAllPoints()
            b:SetPoint("TOP", 0, -10 - ((i - 1) * 26))
            local label = convo and StripServer(convo.displayName) or "Unknown"
            if state.unread[key] then label = "* " .. label end
            b.text:SetText(label)
            b.key = key
            b:SetScript("OnClick", function(self)
                menuFrame:Hide()
                addon:OpenConversation(self.key, true)
            end)
            b:Show()
        end
    end
    menuFrame:Show()
    menuFrame:Raise()
end

local function InstallFilters()
    if state.filterInstalled then return end
    local function whisperFilter()
        return (state.db and state.db.hideDefaultWhispers and true or false) or GetHideWhispersInMainChat()
    end
    if ChatFrame_AddMessageEventFilter then
        ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", whisperFilter)
        ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER_INFORM", whisperFilter)
        ChatFrame_AddMessageEventFilter("CHAT_MSG_BN_WHISPER", whisperFilter)
        ChatFrame_AddMessageEventFilter("CHAT_MSG_BN_WHISPER_INFORM", whisperFilter)
        state.filterInstalled = true
    end
end

local function HandleWhisper(event, ...)
    local text, playerName, _, _, _, _, _, _, _, _, _, guid, bnSenderID = ...
    local isBN = event == "CHAT_MSG_BN_WHISPER" or event == "CHAT_MSG_BN_WHISPER_INFORM"
    local isOutgoing = event == "CHAT_MSG_WHISPER_INFORM" or event == "CHAT_MSG_BN_WHISPER_INFORM"
    local kind = isBN and "BN" or "WOW"
    local convo = EnsureConversation(kind, playerName, isBN and bnSenderID or nil, guid)

    if not state.currentKey then
        state.currentKey = convo.key
    end

    if GetHideWhispersInMainChat() then
        return
    end

    local displaySender = isOutgoing and convo.displayName or (isBN and GetBNetDisplayName(bnSenderID, playerName) or NormalizePlayerName(playerName))
    addon:AddLine(convo, isOutgoing and "OUT" or "IN", text, displaySender, guid)

    local shouldOpen = (isOutgoing and state.db.openOutgoing) or ((not isOutgoing) and state.db.openIncoming)
    if shouldOpen then
        CreateMainFrame()
        addon:OpenConversation(convo.key, true)
    else
        RefreshTabs()
    end
end

local function SlashCommand(msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    CreateMainFrame()
    if msg == "reset" then
        state.db.point = DEFAULTS.point
        state.db.relativePoint = DEFAULTS.relativePoint
        state.db.x = 0
        state.db.y = 0
        state.db.width = DEFAULTS.width
        state.db.height = DEFAULTS.height
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint("CENTER")
        mainFrame:SetSize(DEFAULTS.width, DEFAULTS.height)
        mainFrame:Show()
        SaveFramePosition()
    elseif msg == "options" or msg == "config" then
        CreateOptionsFrame()
        optionsFrame:SetShown(not optionsFrame:IsShown())
    elseif msg == "copy" then
        mainFrame:Show()
        ToggleCopyMode(true)
    else
        if state.currentKey then
            addon:OpenConversation(state.currentKey, true)
        else
            mainFrame:SetShown(not mainFrame:IsShown())
        end
    end
end

root:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        local loadedName = ...
        if loadedName == ADDON_NAME then
            EnsureDB()
        end
        return
    end

    if event == "PLAYER_LOGIN" then
        EnsureDB()
        CreateMinimapButton()
        InstallFilters()
        SLASH_CHAYCHAT1 = "/chaychat"
        SLASH_CHAYCHAT2 = "/ccchat"
        SlashCmdList.CHAYCHAT = SlashCommand
        print("|cffffb020ChayChat:|r loaded. /chaychat to toggle, /chaychat options for settings.")
        return
    end

    if event == "CHAT_MSG_WHISPER" or event == "CHAT_MSG_WHISPER_INFORM" or event == "CHAT_MSG_BN_WHISPER" or event == "CHAT_MSG_BN_WHISPER_INFORM" then
        if not state.db then EnsureDB() end
        HandleWhisper(event, ...)
    end
end)
