---@class addonTableChayChat
local addonTable = select(2, ...)

addonTable.CustomiseDialog = addonTable.CustomiseDialog or {}

local function OpenUnifiedOptions()
  if addonTable.ChayWhisperPopout and addonTable.ChayWhisperPopout.ShowOptions then
    addonTable.ChayWhisperPopout.ShowOptions()
  else
    print("|cffb592ffChayChat:|r Options are still loading. Try again after /reload finishes.")
  end
end

function addonTable.CustomiseDialog.Toggle()
  OpenUnifiedOptions()
end

function addonTable.CustomiseDialog.ToggleTabFilters()
  OpenUnifiedOptions()
end

function addonTable.CustomiseDialog.Initialize()
  local optionsFrame = CreateFrame("Frame")

  local header = optionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalHuge3")
  header:SetPoint("CENTER", optionsFrame, 0, 34)
  header:SetText(LINK_FONT_COLOR:WrapTextInColorCode(addonTable.Locales.CHAYCHAT or "ChayChat"))

  local version = C_AddOns.GetAddOnMetadata("ChayChat", "Version") or ""
  local versionText = optionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  versionText:SetPoint("CENTER", optionsFrame, 0, 6)
  versionText:SetText(WHITE_FONT_COLOR:WrapTextInColorCode((addonTable.Locales.VERSION_COLON_X or "Version: %s"):format(version)))

  local template = "SharedButtonLargeTemplate"
  if not C_XMLUtil.GetTemplateInfo(template) then
    template = "UIPanelDynamicResizeButtonTemplate"
  end
  local button = CreateFrame("Button", nil, optionsFrame, template)
  button:SetText(addonTable.Locales.OPEN_OPTIONS or "Open Options")
  DynamicResizeButton_Resize(button)
  button:SetPoint("CENTER", optionsFrame, 0, -34)
  button:SetScript("OnClick", OpenUnifiedOptions)

  optionsFrame.OnCommit = function() end
  optionsFrame.OnDefault = function() end
  optionsFrame.OnRefresh = function() end

  local category = Settings.RegisterCanvasLayoutCategory(optionsFrame, addonTable.Locales.CHAYCHAT or "ChayChat")
  category.ID = addonTable.Locales.CHAYCHAT or "ChayChat"
  Settings.RegisterAddOnCategory(category)
end
