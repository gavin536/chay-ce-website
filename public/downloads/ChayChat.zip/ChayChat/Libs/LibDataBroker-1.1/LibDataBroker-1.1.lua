assert(LibStub, "LibDataBroker-1.1 requires LibStub")
assert(LibStub:GetLibrary("CallbackHandler-1.0", true), "LibDataBroker-1.1 requires CallbackHandler-1.0")

local lib = LibStub:NewLibrary("LibDataBroker-1.1", 4)
if not lib then return end

lib.callbacks = lib.callbacks or LibStub:GetLibrary("CallbackHandler-1.0"):New(lib)
lib.attributestorage = lib.attributestorage or {}
lib.namestorage = lib.namestorage or {}
lib.proxystorage = lib.proxystorage or {}

local attributestorage = lib.attributestorage
local namestorage = lib.namestorage
local proxystorage = lib.proxystorage
local callbacks = lib.callbacks

lib.domt = lib.domt or {
  __metatable = "access denied",
  __index = function(self, key)
    return attributestorage[self] and attributestorage[self][key]
  end,
}

lib.domt.__newindex = function(self, key, value)
  if not attributestorage[self] then
    attributestorage[self] = {}
  end
  local oldValue = attributestorage[self][key]
  if oldValue == value then
    return
  end
  attributestorage[self][key] = value
  local name = namestorage[self]
  callbacks:Fire("LibDataBroker_AttributeChanged", name, key, value, self)
  callbacks:Fire("LibDataBroker_AttributeChanged_" .. name, name, key, value, self)
  callbacks:Fire("LibDataBroker_AttributeChanged_" .. name .. "_" .. key, name, key, value, self)
  callbacks:Fire("LibDataBroker_AttributeChanged__" .. key, name, key, value, self)
end

function lib:NewDataObject(name, dataobj)
  if proxystorage[name] then
    return nil
  end
  dataobj = dataobj or {}
  local proxy = setmetatable({}, self.domt)
  proxystorage[name] = proxy
  namestorage[proxy] = name
  attributestorage[proxy] = {}

  for key, value in pairs(dataobj) do
    proxy[key] = value
  end

  callbacks:Fire("LibDataBroker_DataObjectCreated", name, proxy)
  return proxy
end

function lib:DataObjectIterator()
  return pairs(proxystorage)
end

function lib:GetDataObjectByName(dataobjectname)
  return proxystorage[dataobjectname]
end

function lib:GetNameByDataObject(dataobject)
  return namestorage[dataobject]
end
