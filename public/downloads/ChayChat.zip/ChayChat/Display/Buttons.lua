---@class addonTableChayChat
local addonTable = select(2, ...)

---@class ButtonsBarMixin: Frame
addonTable.Display.ButtonsBarMixin = {}

function addonTable.Display.ButtonsBarMixin:OnLoad()
  self.buttons = {}

  self.socialAnchor1 = {"TOPRIGHT", self:GetParent().ScrollingMessages, "TOPLEFT", -5, 20}

  addonTable.CallbackRegistry:RegisterCallback("SkinLoaded", self.Update, self)

  self:GetParent().ScrollingMessages:SetOnScrollChangedCallback(function()
    if self.ScrollToBottomButton then
      self.ScrollToBottomButton:SetShown(not self:GetParent().ScrollingMessages:AtBottom())
    end
  end)

  self.hookedButtons = false
  self.active = false

  self.fadeInterpolator = CreateInterpolator(InterpolatorUtil.InterpolateEaseIn)
end

function addonTable.Display.ButtonsBarMixin:AddBlizzardButtons()
  if addonTable.Data.BlizzardButtonsAssigned then
    return
  end

  addonTable.Data.BlizzardButtonsAssigned = true

  local hidden = addonTable.hiddenFrame or UIParent
  local function HideBlizzardButton(button)
    if not button then
      return
    end
    button:ClearAllPoints()
    button:SetParent(hidden)
    button:Hide()
  end

  HideBlizzardButton(QuickJoinToastButton)
  HideBlizzardButton(FriendsMicroButton)
  HideBlizzardButton(ChatFrameChannelButton)
  HideBlizzardButton(ChatFrameToggleVoiceDeafenButton)
  HideBlizzardButton(ChatFrameToggleVoiceMuteButton)
  HideBlizzardButton(ChatFrameMenuButton)
end

local searchMarkup = CreateTextureMarkup("Interface/AddOns/ChayChat/Assets/Search.png", 64, 64, 12, 12, 0, 1, 0, 1)
local function RunSearch(windowIndex, tabIndex, text, isPattern)
  local window = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[windowIndex]
  local tab = window.tabs[tabIndex]

  local newTab = CopyTable(tab)
  text = text:lower()
  if isPattern then
    table.insert(newTab.filters, function(data)
      return data.text:lower():match(text) ~= nil
    end)
  else
    table.insert(newTab.filters, function(data)
      return data.text:lower():find(text, nil, true) ~= nil
    end)
  end
  newTab.name = searchMarkup
  newTab.isTemporary = true

  local newIndex = tabIndex + 1

  for index, otherTab in ipairs(window.tabs) do
    if otherTab.name == newTab.name and otherTab.isTemporary then
      table.remove(window.tabs, index)
      if index < newIndex then
        newIndex = newIndex - 1
      end
      break
    end
  end

  table.insert(window.tabs, newIndex, newTab)
  addonTable.allChatFrames[windowIndex].tabIndex = newIndex
  addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
end

function addonTable.Display.ButtonsBarMixin:AddButtons()
  if self.madeButtons then
    return
  end

  self.madeButtons = true

  local function MakeButton(tooltipText)
    local button = CreateFrame("Button", nil, self)
    button:SetScript("OnEnter", function()
      GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
      GameTooltip:SetText(WHITE_FONT_COLOR:WrapTextInColorCode(tooltipText))
      GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function()
      GameTooltip:Hide()
    end)

    return button
  end

  self.SettingsButton = MakeButton("ChayChat Options")
  self.SettingsButton:SetScript("OnClick", function()
    if addonTable.ChayWhisperPopout and addonTable.ChayWhisperPopout.ShowOptions then
      addonTable.ChayWhisperPopout.ShowOptions()
    end
  end)
  table.insert(self.buttons, self.SettingsButton)
  addonTable.Skins.AddFrame("ChatButton", self.SettingsButton, {"settings"})

  self.HistoryButton = MakeButton("Old session whispers")
  self.HistoryButton:SetScript("OnClick", function()
    if addonTable.ChayWhisperPopout and addonTable.ChayWhisperPopout.ShowSessionWhispers then
      addonTable.ChayWhisperPopout.ShowSessionWhispers(self.HistoryButton)
    end
  end)
  table.insert(self.buttons, self.HistoryButton)
  addonTable.Skins.AddFrame("ChatButton", self.HistoryButton, {"search"})

  self.ScrollToBottomButton = nil
end

function addonTable.Display.ButtonsBarMixin:OnEnter()
  for _, b in ipairs(self.buttons) do
    b:SetShown(b.fitsSize)
    b:SetFrameStrata("HIGH")
  end
  if self.hideTimer then
    self.hideTimer:Cancel()
  end
  self.active = true
  self.fadeInterpolator:Interpolate(self.buttons[1]:GetAlpha(), 1, 0.15, function(value)
    for _, b in ipairs(self.buttons) do
      b:SetAlpha(value)
    end
  end)
end

function addonTable.Display.ButtonsBarMixin:OnLeave()
  if self:IsMouseOver() then
    return
  end
  if self.hideTimer then
    self.hideTimer:Cancel()
  end
  local function Hide()
    self.hideTimer = C_Timer.NewTimer(2, function()
      if Menu.GetManager():IsAnyMenuOpen() and (InCombatLockdown() or tIndexOf(Menu.GetOpenMenuTags(), "MENU_CHAT_SHORTCUTS") ~= nil) then
        Hide()
        return
      end

      self.fadeInterpolator:Interpolate(self.buttons[1]:GetAlpha(), 0, 0.15, function(value)
        for _, b in ipairs(self.buttons) do
          b:SetAlpha(value)
        end
      end, function()
        for _, b in ipairs(self.buttons) do
          b:Hide()
        end
      end)
      self.active = false
    end)
  end
  Hide()
end

function addonTable.Display.ButtonsBarMixin:Update()
  if not self.SettingsButton then
    return
  end

  self.active = true
  self.lockActive = true
  self:SetScript("OnEnter", nil)
  self:SetScript("OnLeave", nil)
  if self.hideTimer then
    self.hideTimer:Cancel()
    self.hideTimer = nil
  end

  self:ClearAllPoints()
  self:SetPoint("TOPRIGHT", self:GetParent(), "TOPRIGHT", -8, -4)
  self:SetSize(132, 26)

  self.SettingsButton:ClearAllPoints()
  self.SettingsButton:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, 0)
  self.SettingsButton:SetSize(82, 24)
  self.SettingsButton:SetAlpha(1)
  self.SettingsButton.fitsSize = true
  self.SettingsButton:Show()
  self.SettingsButton:SetFrameStrata("HIGH")

  if not self.SettingsButton.ChayLabel then
    self.SettingsButton.ChayLabel = self.SettingsButton:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    self.SettingsButton.ChayLabel:SetPoint("CENTER")
  end
  self.SettingsButton.ChayLabel:SetText("Options")
  self.SettingsButton.ChayLabel:SetTextColor(1, 0.95, 0.75, 1)
  if self.SettingsButton.Icon then
    self.SettingsButton.Icon:Hide()
  end

  if self.HistoryButton then
    self.HistoryButton:ClearAllPoints()
    self.HistoryButton:SetPoint("TOPRIGHT", self.SettingsButton, "TOPLEFT", -4, 0)
    self.HistoryButton:SetSize(42, 24)
    self.HistoryButton:SetAlpha(1)
    self.HistoryButton.fitsSize = true
    self.HistoryButton:Show()
    self.HistoryButton:SetFrameStrata("HIGH")

    if not self.HistoryButton.ChayLabel then
      self.HistoryButton.ChayLabel = self.HistoryButton:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
      self.HistoryButton.ChayLabel:SetPoint("CENTER")
    end
    self.HistoryButton.ChayLabel:SetText("Old")
    self.HistoryButton.ChayLabel:SetTextColor(1, 0.95, 0.75, 1)
    if self.HistoryButton.Icon then
      self.HistoryButton.Icon:Hide()
    end
  end
end
