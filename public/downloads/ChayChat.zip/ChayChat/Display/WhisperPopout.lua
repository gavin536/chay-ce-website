local ADDON_NAME = ...
local addonTable = select(2, ...)
local PREFIX = "|cffb592ffChayChat:|r "

local MEDIA_PATH = "Interface\\AddOns\\ChayChat\\Media\\"
local DRAGON_BACKGROUND = MEDIA_PATH .. "DragonBackground.tga"
local ASSETS_PATH = "Interface\\AddOns\\ChayChat\\Assets\\"
local BASE_BACKGROUND_PATHS = {
  [DRAGON_BACKGROUND] = true,
  [ASSETS_PATH .. "Logo.png"] = true,
  [ASSETS_PATH .. "ChatBackground.tga"] = true,
  [ASSETS_PATH .. "ChatButton.png"] = true,
  [ASSETS_PATH .. "SettingsCog.png"] = true,
  [ASSETS_PATH .. "ChatMenu.png"] = true,
  [ASSETS_PATH .. "Copy.png"] = true,
  [ASSETS_PATH .. "Search.png"] = true,
  [ASSETS_PATH .. "ScrollToBottom.png"] = true,
}
local FIXED_OPTIONS_IMAGE_ALPHA = 0.78
local FIXED_OPTIONS_DARK_OVERLAY = 0.38
local BNET_BLUE_R, BNET_BLUE_G, BNET_BLUE_B = 0.20, 0.55, 1.00
local DEFAULT_WIDTH = 500
local DEFAULT_HEIGHT = 330
local MIN_WIDTH = 330
local MIN_HEIGHT = 210
local MAX_WIDTH = 980
local MAX_HEIGHT = 760
local MAX_WINDOWS = 8
local DEFAULT_FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"

local DEFAULTS = {
  windowWidth = DEFAULT_WIDTH,
  windowHeight = DEFAULT_HEIGHT,
  posX = false,
  posY = false,
  messageFontSize = 15,
  inputFontSize = 13,
  headerFontSize = 20,
  headerHeight = 40,
  lineCap = 60,
  messageFontPath = false,
  inputFontPath = false,
  headerFontPath = false,
  windowAlpha = 0.82,
  backgroundLevel = 0.080,
  backgroundImagePath = DRAGON_BACKGROUND,
  popoutImageAlpha = 0.36,
  popoutDarkOverlay = 0.30,
  optionsImageAlpha = FIXED_OPTIONS_IMAGE_ALPHA,
  optionsDarkOverlay = FIXED_OPTIONS_DARK_OVERLAY,
  useClassAccent = true,
  accentR = 0.72,
  accentG = 0.08,
  accentB = 0.08,
  textR = 0.98,
  textG = 0.96,
  textB = 0.88,
  timestamps = false,
  textOutline = true,
  popoutBorder = true,
  popoutBorderSize = 2,
  optionsBorder = true,
  optionsBorderSize = 2,
  noFade = true,
  showMinimapButton = true,
  minimapAngle = 225,
  showMockWindow = false,
  soundEnabled = true,
  soundChoice = "Chay Ping",
  soundChannel = "Master",
  showChatFrameButton = false,
  optionsWidth = 650,
  optionsHeight = 700,
  optionsPosX = false,
  optionsPosY = false,
}

local windows = {}
local windowOrder = {}
local localEcho = {}
local lastKey
local optionsFrame
local copyFrame
local optionControls = {}
local refreshingOptions = false
local minimapButton
local conversationMenu
local chatFrameButton
local ldbObject
local ldbIcon
local usingBrokerButton = false
local initialized = false

local LayoutWindow
local ApplyWindowStyle
local RefreshOptionsFrame
local RefreshMinimapButton
local RefreshChatFrameButton
local UpdateMockPreview
local ApplyOptionsFrameStyle
local OpenMockWindow
local ShowConversationMenu
local UpdateInviteButton
local OpenCopyFrame
local EnterInlineCopyMode
local ExitInlineCopyMode
local RefreshInlineCopyText

local function Clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue
  if value < minValue then
    return minValue
  end
  if value > maxValue then
    return maxValue
  end
  return value
end

local function Clamp01(value)
  return Clamp(value, 0, 1)
end

local function Round(value)
  return math.floor((tonumber(value) or 0) + 0.5)
end

local function Now()
  if GetTime then
    return GetTime()
  end
  return time()
end

local function EnsureDB()
  if type(ChayChatDB) ~= "table" then
    ChayChatDB = {}
  end
  if type(ChayChatDB.settings) ~= "table" then
    ChayChatDB.settings = {}
  end
  return ChayChatDB.settings
end

local function GetSetting(key)
  local db = EnsureDB()
  if db[key] == nil then
    return DEFAULTS[key]
  end
  return db[key]
end

local function SetSetting(key, value)
  EnsureDB()[key] = value
end

local function ResetSettings()
  ChayChatDB = {settings = {}}
end

local function IsSecretValue(value)
  return type(issecretvalue) == "function" and issecretvalue(value)
end

local function SafeText(value)
  if IsSecretValue(value) then
    return nil
  end
  if type(value) ~= "string" or value == "" then
    return nil
  end
  return value
end

local function SafeNumber(value)
  if IsSecretValue(value) then
    return nil
  end
  if type(value) == "number" then
    return value
  end
  return nil
end

local function Trim(text)
  text = tostring(text or "")
  return (text:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function NormalizeTexturePath(path)
  if type(path) ~= "string" then
    return DRAGON_BACKGROUND
  end

  path = Trim(path)
  if path == "" then
    return DRAGON_BACKGROUND
  end

  path = path:gsub("/", "\\")

  -- WoW cannot load arbitrary OS paths. If the user pasted an absolute path,
  -- use only the file name and look for it inside ChayChat\Media.
  if path:find(":", 1, true) then
    local fileName = path:match("([^\\]+)$")
    if fileName and fileName ~= "" then
      return MEDIA_PATH .. fileName
    end
    return DRAGON_BACKGROUND
  end

  if path:find("^Interface\\") then
    return path
  end

  if path:find("^AddOns\\") then
    return "Interface\\" .. path
  end

  if path:find("^ChayChat\\") then
    return "Interface\\AddOns\\" .. path
  end

  if path:find("^Media\\") or path:find("^Assets\\") then
    return "Interface\\AddOns\\ChayChat\\" .. path
  end

  -- Plain file names and relative subfolders are treated as custom media files.
  -- WoW cannot enumerate user-added files, so custom backgrounds must live under
  -- Interface\AddOns\ChayChat\Media and be typed/added once in options.
  return MEDIA_PATH .. path
end

local function GetBackgroundTexturePath()
  return NormalizeTexturePath(GetSetting("backgroundImagePath"))
end

local function BackgroundFileName(path)
  path = NormalizeTexturePath(path)
  local fileName = tostring(path or ""):match("([^\\]+)$") or tostring(path or "")
  if fileName == "" then
    return "Custom Background"
  end
  return fileName
end

local function IsBaseBackgroundPath(path)
  path = NormalizeTexturePath(path)
  return BASE_BACKGROUND_PATHS[path] and true or false
end

local function IsSupportedBackgroundFile(path)
  if type(path) ~= "string" or path == "" then
    return false
  end
  local lower = path:lower()
  return lower:find("%.png$") or lower:find("%.tga$") or lower:find("%.blp$")
end

local function AddCustomBackgroundPath(path)
  path = NormalizeTexturePath(path)
  if path == "" or IsBaseBackgroundPath(path) or not IsSupportedBackgroundFile(path) then
    return nil
  end

  local db = EnsureDB()
  if type(db.customBackgroundFiles) ~= "table" then
    db.customBackgroundFiles = {}
  end

  for _, existing in ipairs(db.customBackgroundFiles) do
    if NormalizeTexturePath(existing) == path then
      return path
    end
  end

  table.insert(db.customBackgroundFiles, 1, path)
  while #db.customBackgroundFiles > 25 do
    table.remove(db.customBackgroundFiles)
  end
  return path
end

local function BackgroundChoiceName(path)
  path = NormalizeTexturePath(path)
  if IsBaseBackgroundPath(path) then
    return "No custom background selected"
  end
  return BackgroundFileName(path)
end

local function GetBackgroundChoices(current)
  local choices = {}
  local seen = {}
  local db = EnsureDB()

  if type(db.customBackgroundFiles) == "table" then
    for _, path in ipairs(db.customBackgroundFiles) do
      local normalized = NormalizeTexturePath(path)
      if normalized ~= "" and not IsBaseBackgroundPath(normalized) and IsSupportedBackgroundFile(normalized) and not seen[normalized] then
        seen[normalized] = true
        table.insert(choices, {name = BackgroundFileName(normalized), path = normalized})
      end
    end
  end

  current = NormalizeTexturePath(current or GetSetting("backgroundImagePath"))
  if current ~= "" and not IsBaseBackgroundPath(current) and IsSupportedBackgroundFile(current) and not seen[current] then
    seen[current] = true
    table.insert(choices, {name = BackgroundFileName(current), path = current})
  end

  if #choices == 0 then
    table.insert(choices, {name = "Add a custom image below first", path = false, disabled = true})
  end

  return choices
end

local function GetBackgroundChoiceIndex(current)
  local choices = GetBackgroundChoices(current)
  current = NormalizeTexturePath(current or GetSetting("backgroundImagePath"))
  for index, choice in ipairs(choices) do
    if choice.path and NormalizeTexturePath(choice.path) == current then
      return index, choices
    end
  end
  return 1, choices
end

local function GetBackgroundChoiceName(path)
  path = NormalizeTexturePath(path)
  if IsBaseBackgroundPath(path) or not IsSupportedBackgroundFile(path) then
    return "No custom background selected"
  end
  return BackgroundChoiceName(path)
end

local function PruneCustomBackgroundFiles()
  local db = EnsureDB()
  if type(db.customBackgroundFiles) ~= "table" then
    db.customBackgroundFiles = {}
    return
  end

  local cleaned = {}
  local seen = {}
  for _, path in ipairs(db.customBackgroundFiles) do
    local normalized = NormalizeTexturePath(path)
    if normalized ~= "" and not IsBaseBackgroundPath(normalized) and IsSupportedBackgroundFile(normalized) and not seen[normalized] then
      seen[normalized] = true
      table.insert(cleaned, normalized)
    end
  end
  db.customBackgroundFiles = cleaned
end

local function DisplayName(name)
  if not name or name == "" then
    return UNKNOWN or "Unknown"
  end
  if Ambiguate then
    local ok, result = pcall(Ambiguate, name, "short")
    if ok and result and result ~= "" then
      return result
    end
  end
  return name
end

local function StripBattleTagSuffix(name)
  if type(name) ~= "string" or name == "" then
    return nil
  end
  local stripped = name:gsub("#%d+$", "")
  if stripped == "" then
    return name
  end
  return stripped
end

local function IsGenericBattleNetName(name)
  if type(name) ~= "string" then
    return true
  end
  local trimmed = Trim(name)
  if trimmed == "" then
    return true
  end
  if trimmed:find("|K", 1, true) and trimmed:find("|k", 1, true) then
    return false
  end
  local lowered = trimmed:lower()
  if lowered == "battle.net" or lowered == "battlenet" or lowered == "bnet" then
    return true
  end
  return false
end

local function UseBattleNetCandidate(candidate)
  if type(candidate) ~= "string" then
    return nil
  end
  candidate = Trim(candidate)
  if candidate == "" or IsGenericBattleNetName(candidate) then
    return nil
  end

  -- Preserve protected |K...|k names exactly. Changing case or stripping these breaks
  -- the client-side protected-name renderer and exposes raw |K tokens.
  if candidate:find("|K", 1, true) and candidate:find("|k", 1, true) then
    return candidate
  end

  local stripped = StripBattleTagSuffix(candidate)
  if stripped and stripped ~= "" and not IsGenericBattleNetName(stripped) then
    return DisplayName(stripped)
  end
  return DisplayName(candidate)
end

local function TryBattleNetAccountInfo(accountID)
  if not accountID or not C_BattleNet or not C_BattleNet.GetAccountInfoByID then
    return nil, nil
  end
  local ok, accountInfo = pcall(C_BattleNet.GetAccountInfoByID, accountID)
  if not ok or type(accountInfo) ~= "table" then
    return nil, nil
  end

  local gameInfo = accountInfo.gameAccountInfo
  if type(gameInfo) == "table" then
    local characterName = UseBattleNetCandidate(gameInfo.characterName)
    if characterName then
      return characterName, gameInfo
    end
  end

  local accountName = UseBattleNetCandidate(accountInfo.accountName)
  if accountName then
    return accountName, gameInfo
  end

  local battleTag = UseBattleNetCandidate(accountInfo.battleTag)
  if battleTag then
    return battleTag, gameInfo
  end

  return nil, gameInfo
end

local function TryBattleNetAccountGUID(guid)
  guid = SafeText(guid)
  if not guid or not C_BattleNet then
    return nil, nil
  end

  if C_BattleNet.GetGameAccountInfoByGUID then
    local ok, gameInfo = pcall(C_BattleNet.GetGameAccountInfoByGUID, guid)
    if ok and type(gameInfo) == "table" then
      local characterName = UseBattleNetCandidate(gameInfo.characterName)
      if characterName then
        return characterName, gameInfo
      end
    end
  end

  if C_BattleNet.GetAccountInfoByGUID then
    local ok, accountInfo = pcall(C_BattleNet.GetAccountInfoByGUID, guid)
    if ok and type(accountInfo) == "table" then
      local gameInfo = accountInfo.gameAccountInfo
      if type(gameInfo) == "table" then
        local characterName = UseBattleNetCandidate(gameInfo.characterName)
        if characterName then
          return characterName, gameInfo
        end
      end
      local accountName = UseBattleNetCandidate(accountInfo.accountName)
      if accountName then
        return accountName, gameInfo
      end
      local battleTag = UseBattleNetCandidate(accountInfo.battleTag)
      if battleTag then
        return battleTag, gameInfo
      end
    end
  end

  return nil, nil
end

local function TryBattleNetGameAccountID(gameAccountID)
  if not gameAccountID or not C_BattleNet or not C_BattleNet.GetGameAccountInfoByID then
    return nil, nil
  end
  local ok, gameInfo = pcall(C_BattleNet.GetGameAccountInfoByID, gameAccountID)
  if ok and type(gameInfo) == "table" then
    local characterName = UseBattleNetCandidate(gameInfo.characterName)
    if characterName then
      return characterName, gameInfo
    end
  end
  return nil, nil
end

local function TryLegacyBattleNetInfo(accountID)
  if not accountID then
    return nil, nil
  end

  -- BNGetFriendInfoByID accepts the Battle.net account ID. It can return the
  -- active game-account ID, which BNGetGameAccountInfo can translate to the
  -- current WoW character name.
  if BNGetFriendInfoByID then
    local result = {pcall(BNGetFriendInfoByID, accountID)}
    if result[1] then
      local directToon = UseBattleNetCandidate(result[6])
      if directToon then
        return directToon, nil
      end

      local accountName = UseBattleNetCandidate(result[3])
      if accountName then
        return accountName, nil
      end

      local battleTag = UseBattleNetCandidate(result[4])
      if battleTag then
        return battleTag, nil
      end

      local gameAccountID = SafeNumber(result[7])
      if gameAccountID and BNGetGameAccountInfo then
        local game = {pcall(BNGetGameAccountInfo, gameAccountID)}
        if game[1] then
          local characterName = UseBattleNetCandidate(game[3])
          if characterName then
            return characterName, nil
          end
        end
      end
    end
  end

  return nil, nil
end

local function ResolveBattleNetDisplayName(sender, accountID, guid, secondaryName)
  local candidate = UseBattleNetCandidate(secondaryName)
  if candidate then
    return candidate, nil
  end

  candidate = UseBattleNetCandidate(sender)
  if candidate then
    return candidate, nil
  end

  local gameInfo
  candidate, gameInfo = TryBattleNetAccountGUID(guid)
  if candidate then
    return candidate, gameInfo
  end

  candidate, gameInfo = TryBattleNetAccountInfo(accountID)
  if candidate then
    return candidate, gameInfo
  end

  candidate, gameInfo = TryBattleNetGameAccountID(accountID)
  if candidate then
    return candidate, gameInfo
  end

  candidate, gameInfo = TryLegacyBattleNetInfo(accountID)
  if candidate then
    return candidate, gameInfo
  end

  if accountID then
    return "BNet Friend " .. tostring(accountID), gameInfo
  end
  return BATTLE_NET or "Battle.net", gameInfo
end

local function CleanInviteName(name)
  if type(name) ~= "string" then
    return nil
  end
  name = Trim(name)
  if name == "" or IsGenericBattleNetName(name) then
    return nil
  end
  if name:find("|K", 1, true) or name:find("|k", 1, true) then
    return nil
  end
  name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  name = name:gsub("%s+%-", "-"):gsub("%-%s+", "-")
  return Trim(name)
end

local function CleanRealmName(realm)
  if type(realm) ~= "string" then
    return nil
  end
  realm = Trim(realm)
  if realm == "" then
    return nil
  end
  realm = realm:gsub("%s+", "")
  return realm ~= "" and realm or nil
end

local function BuildInviteName(characterName, realmName)
  characterName = CleanInviteName(characterName)
  if not characterName then
    return nil
  end
  if characterName:find("-", 1, true) then
    return characterName
  end
  realmName = CleanRealmName(realmName)
  if realmName then
    return characterName .. "-" .. realmName
  end
  return characterName
end

local function GetInviteNameFromGameInfo(gameInfo)
  if type(gameInfo) ~= "table" then
    return nil
  end

  local characterName = SafeText(gameInfo.characterName) or SafeText(gameInfo.characterNameWithoutRealm)
  local realmName = SafeText(gameInfo.realmName) or SafeText(gameInfo.realmDisplayName) or SafeText(gameInfo.realm)
  local inviteName = BuildInviteName(characterName, realmName)
  if inviteName then
    return inviteName
  end

  return CleanInviteName(characterName)
end

local function TryLegacyBattleNetGameInfo(accountID)
  if not accountID or not BNGetFriendInfoByID or not BNGetGameAccountInfo then
    return nil
  end

  local friend = {pcall(BNGetFriendInfoByID, accountID)}
  if not friend[1] then
    return nil
  end

  local gameAccountID = SafeNumber(friend[7])
  if not gameAccountID then
    return nil
  end

  local game = {pcall(BNGetGameAccountInfo, gameAccountID)}
  if not game[1] then
    return nil
  end

  -- Legacy BNGetGameAccountInfo return positions have changed over the years,
  -- so collect only values that look like usable player/realm strings.
  local info = {}
  for index = 2, #game do
    local value = SafeText(game[index])
    if value and not IsGenericBattleNetName(value) then
      local cleaned = CleanInviteName(value)
      if cleaned and not info.characterName then
        info.characterName = cleaned
      elseif cleaned and not info.realmName and not cleaned:find("-", 1, true) and cleaned ~= info.characterName then
        info.realmName = cleaned
      end
    end
  end

  if info.characterName then
    return info
  end
  return nil
end

local function ResolveBattleNetGameInfo(accountID, guid)
  local _, gameInfo = TryBattleNetAccountGUID(guid)
  if type(gameInfo) == "table" then
    return gameInfo
  end

  _, gameInfo = TryBattleNetAccountInfo(accountID)
  if type(gameInfo) == "table" then
    return gameInfo
  end

  _, gameInfo = TryBattleNetGameAccountID(accountID)
  if type(gameInfo) == "table" then
    return gameInfo
  end

  return TryLegacyBattleNetGameInfo(accountID)
end

local function ResolveBattleNetInviteName(accountID, guid, displayName, existingInviteName)
  local gameInfo = ResolveBattleNetGameInfo(accountID, guid)
  local inviteName = GetInviteNameFromGameInfo(gameInfo)
  if inviteName then
    return inviteName
  end

  inviteName = CleanInviteName(existingInviteName)
  if inviteName then
    return inviteName
  end

  -- Last safe fallback: if the displayed name is already a normal WoW name,
  -- allow the user to click Invite instead of leaving the button grey.
  -- Protected Battle.net names and generic account labels are still rejected.
  return CleanInviteName(displayName)
end

local function RefreshBattleNetInviteName(frame)
  if not frame or frame.kind ~= "BN" then
    return frame and CleanInviteName(frame.inviteName or frame.target) or nil
  end

  local inviteName = ResolveBattleNetInviteName(frame.accountID, frame.senderGUID, frame.displayName, frame.inviteName)
  if inviteName then
    frame.inviteName = inviteName
  end
  return inviteName
end
local function MakeKey(kind, target, accountID)
  if kind == "BN" then
    return "BN:" .. tostring(accountID or target or "unknown")
  end
  if kind == "MOCK" then
    return "MOCK:preview"
  end
  return "PLAYER:" .. tostring(target or "unknown")
end

local function RemoveFromOrder(key)
  for index, value in ipairs(windowOrder) do
    if value == key then
      table.remove(windowOrder, index)
      return
    end
  end
end

local function TouchWindow(key)
  RemoveFromOrder(key)
  table.insert(windowOrder, key)
end

local function HideOldestWindows()
  while #windowOrder > MAX_WINDOWS do
    local key = table.remove(windowOrder, 1)
    local frame = windows[key]
    if frame then
      if frame.messages then
        frame.messages:Clear()
      end
      frame.copyLines = {}
      frame:Hide()
      windows[key] = nil
    end
  end
end

local function GetChatFont()
  if ChatFontNormal and ChatFontNormal.GetFont then
    local font = select(1, ChatFontNormal:GetFont())
    if type(font) == "string" and font ~= "" then
      return font
    end
  end
  return DEFAULT_FONT
end

local function GetNormalFont()
  if GameFontNormal and GameFontNormal.GetFont then
    local font = select(1, GameFontNormal:GetFont())
    if type(font) == "string" and font ~= "" then
      return font
    end
  end
  return DEFAULT_FONT
end

local function AddFontChoice(choices, seen, name, path, lsmKey)
  if type(path) ~= "string" or path == "" or seen[path] then
    return
  end
  seen[path] = true
  table.insert(choices, {name = name, path = path, lsmKey = lsmKey})
end

local function GetFontChoices()
  local choices = {}
  local seen = {}

  AddFontChoice(choices, seen, "Default Chat", GetChatFont(), "default")
  AddFontChoice(choices, seen, "Default UI", GetNormalFont(), "default")
  AddFontChoice(choices, seen, "Standard", STANDARD_TEXT_FONT)
  AddFontChoice(choices, seen, "Unit Name", UNIT_NAME_FONT)
  AddFontChoice(choices, seen, "Damage", DAMAGE_TEXT_FONT)
  AddFontChoice(choices, seen, "Nameplate", NAMEPLATE_FONT)
  AddFontChoice(choices, seen, "Morpheus", "Fonts\\MORPHEUS.TTF")
  AddFontChoice(choices, seen, "Skurri", "Fonts\\SKURRI.TTF")

  if LibStub then
    local ok, media = pcall(LibStub, "LibSharedMedia-3.0", true)
    if ok and media and media.List and media.Fetch then
      local list = media:List("font")
      if type(list) == "table" then
        for _, fontName in ipairs(list) do
          local okFetch, path = pcall(media.Fetch, media, "font", fontName)
          if okFetch then
            AddFontChoice(choices, seen, tostring(fontName), path, tostring(fontName))
          end
        end
      end
    end
  end

  if #choices == 0 then
    AddFontChoice(choices, seen, "Fallback", DEFAULT_FONT)
  end

  return choices
end

local function GetFontChoiceIndex(path)
  local choices = GetFontChoices()
  if type(path) == "string" and path ~= "" then
    for index, choice in ipairs(choices) do
      if choice.path == path then
        return index, choices
      end
    end
  end
  return 1, choices
end

local function GetFontChoiceName(path)
  local index, choices = GetFontChoiceIndex(path)
  return choices[index] and choices[index].name or "Default"
end
local function GetMainChatFontChoices()
  local choices = {{name = DEFAULT or "Default", lsmKey = "default"}}
  local seen = {default = true}
  if LibStub then
    local ok, media = pcall(LibStub, "LibSharedMedia-3.0", true)
    if ok and media and media.List then
      local list = media:List("font")
      if type(list) == "table" then
        for _, fontName in ipairs(list) do
          fontName = tostring(fontName)
          if not seen[fontName] then
            seen[fontName] = true
            table.insert(choices, {name = fontName, lsmKey = fontName})
          end
        end
      end
    end
  end
  return choices
end

local function GetMainChatFontChoiceIndex(current)
  local choices = GetMainChatFontChoices()
  current = current or "default"
  for index, choice in ipairs(choices) do
    if choice.lsmKey == current then
      return index, choices
    end
  end
  return 1, choices
end

local function GetMainChatFontChoiceName(current)
  local index, choices = GetMainChatFontChoiceIndex(current)
  return choices[index] and choices[index].name or (DEFAULT or "Default")
end

local function SetMainChatOption(option, value)
  if addonTable and addonTable.Config and addonTable.Config.Set then
    addonTable.Config.Set(option, value)
  end
end

local function GetMainChatOption(option, fallback)
  if addonTable and addonTable.Config and addonTable.Config.Get then
    local value = addonTable.Config.Get(option)
    if value ~= nil then
      return value
    end
  end
  return fallback
end

local function ApplyNoFadeSetting()
  local noFade = GetSetting("noFade") and true or false
  if addonTable and addonTable.Config and addonTable.Config.Options then
    if addonTable.Config.Options.ENABLE_MESSAGE_FADE then
      SetMainChatOption(addonTable.Config.Options.ENABLE_MESSAGE_FADE, not noFade)
    end
    -- These are skin-specific options in the original Chattynator code. Guarded string keys are safe if unused.
    SetMainChatOption("skins.gw2_ui.fade_chat", false)
  end
end

local function ForceMainChatRender()
  if addonTable and addonTable.CallbackRegistry and addonTable.Constants and addonTable.Constants.RefreshReason then
    addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {
      [addonTable.Constants.RefreshReason.MessageFont] = true,
      [addonTable.Constants.RefreshReason.MessageWidget] = true,
      [addonTable.Constants.RefreshReason.Tabs] = true,
      [addonTable.Constants.RefreshReason.Locked] = true,
    })
    addonTable.CallbackRegistry:TriggerEvent("Render")
  end
end


local function GetConfiguredFont(key, fallback)
  local saved = GetSetting(key)
  if type(saved) == "string" and saved ~= "" then
    return saved
  end
  if fallback == "ui" then
    return GetNormalFont()
  end
  return GetChatFont()
end

local function AddFileSound(choices, seen, name, filename)
  if seen[name] then
    return
  end
  seen[name] = true
  table.insert(choices, {name = name, file = MEDIA_PATH .. filename})
end

local function AddSoundKit(choices, seen, name, key)
  if seen[name] or not SOUNDKIT or not key or not SOUNDKIT[key] then
    return
  end
  seen[name] = true
  table.insert(choices, {name = name, soundID = SOUNDKIT[key]})
end

local function GetSoundChoices()
  local choices = {}
  local seen = {}
  AddFileSound(choices, seen, "Chay Ping - Loud", "WhisperPing.ogg")
  AddFileSound(choices, seen, "Chay Chime - Loud", "WhisperChime.ogg")
  AddFileSound(choices, seen, "Chay Soft - Loud", "WhisperSoft.ogg")
  AddFileSound(choices, seen, "Chay Alert - Loud", "WhisperAlert.ogg")
  AddFileSound(choices, seen, "Chay Double - Loud", "WhisperDouble.ogg")
  AddFileSound(choices, seen, "Chay Cascade - Loud", "WhisperCascade.ogg")
  AddSoundKit(choices, seen, "Tell Message", "TELL_MESSAGE")
  AddSoundKit(choices, seen, "Raid Warning", "RAID_WARNING")
  AddSoundKit(choices, seen, "Ready Check", "READY_CHECK")
  AddSoundKit(choices, seen, "GM Warning", "GM_CHAT_WARNING")
  AddSoundKit(choices, seen, "Friend Online", "FRIEND_JOIN_GAME")
  AddSoundKit(choices, seen, "Invite Alert", "IG_PLAYER_INVITE")
  AddSoundKit(choices, seen, "Loot Toast", "UI_EPICLOOT_TOAST")
  AddSoundKit(choices, seen, "Quest Open", "IG_QUEST_LIST_OPEN")
  AddSoundKit(choices, seen, "Map Ping", "MAP_PING")
  AddSoundKit(choices, seen, "UI Check", "IG_MAINMENU_OPTION_CHECKBOX_ON")
  AddSoundKit(choices, seen, "UI Open", "IG_CHARACTER_INFO_OPEN")
  table.insert(choices, {name = "None"})
  return choices
end

local function GetSoundChoiceIndex(name)
  local choices = GetSoundChoices()
  local aliases = {
    ["Chay Ping"] = "Chay Ping - Loud",
    ["Chay Chime"] = "Chay Chime - Loud",
    ["Chay Soft"] = "Chay Soft - Loud",
  }
  name = aliases[name] or name
  for index, choice in ipairs(choices) do
    if choice.name == name then
      return index, choices
    end
  end
  return 1, choices
end

local function PlaySelectedSound()
  if not GetSetting("soundEnabled") then
    return
  end
  local index, choices = GetSoundChoiceIndex(GetSetting("soundChoice"))
  local choice = choices[index]
  if not choice or choice.name == "None" then
    return
  end

  local function PlayOnce()
    if choice.file and PlaySoundFile then
      pcall(PlaySoundFile, choice.file, "Master")
    elseif choice.soundID and PlaySound then
      pcall(PlaySound, choice.soundID, "Master")
    end
  end

  PlayOnce()
  if C_Timer and C_Timer.After then
    C_Timer.After(0.045, PlayOnce)
    C_Timer.After(0.090, PlayOnce)
  else
    PlayOnce()
    PlayOnce()
  end
end

local function GetAccentColor()
  do
    local classFile = select(2, UnitClass("player"))
    local colors = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
    local color = colors and classFile and colors[classFile]
    if color then
      return Clamp01(color.r), Clamp01(color.g), Clamp01(color.b)
    end
  end
  return Clamp01(GetSetting("accentR")), Clamp01(GetSetting("accentG")), Clamp01(GetSetting("accentB"))
end

local function Lighten(r, g, b, amount)
  amount = Clamp01(amount or 0.25)
  return Clamp01(r + ((1 - r) * amount)), Clamp01(g + ((1 - g) * amount)), Clamp01(b + ((1 - b) * amount))
end

local function HexPart(value)
  return string.format("%02x", Clamp(Round(Clamp01(value) * 255), 0, 255))
end

local function ColorCode(r, g, b)
  return "|cff" .. HexPart(r) .. HexPart(g) .. HexPart(b)
end

local function GetClassRGB(classFile)
  if type(classFile) ~= "string" or classFile == "" then
    return nil
  end
  local colors = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
  local color = colors and colors[classFile]
  if color then
    return Clamp01(color.r), Clamp01(color.g), Clamp01(color.b)
  end
  if GetClassColor then
    local ok, r, g, b = pcall(GetClassColor, classFile)
    if ok and type(r) == "number" and type(g) == "number" and type(b) == "number" then
      return Clamp01(r), Clamp01(g), Clamp01(b)
    end
  end
  if C_ClassColor and C_ClassColor.GetClassColor then
    local ok, classColor = pcall(C_ClassColor.GetClassColor, classFile)
    if ok and classColor then
      local r = classColor.r or (classColor.GetRGB and select(1, classColor:GetRGB()))
      local g = classColor.g or (classColor.GetRGB and select(2, classColor:GetRGB()))
      local b = classColor.b or (classColor.GetRGB and select(3, classColor:GetRGB()))
      if type(r) == "number" and type(g) == "number" and type(b) == "number" then
        return Clamp01(r), Clamp01(g), Clamp01(b)
      end
    end
  end
  return nil
end

local function GetPlayerClassRGB()
  local classFile = select(2, UnitClass("player"))
  local r, g, b = GetClassRGB(classFile)
  if r then
    return r, g, b
  end
  return 0.50, 0.75, 1.00
end

local CLASS_NAME_TO_FILE = {
  WARRIOR = "WARRIOR",
  PALADIN = "PALADIN",
  HUNTER = "HUNTER",
  ROGUE = "ROGUE",
  PRIEST = "PRIEST",
  DEATHKNIGHT = "DEATHKNIGHT",
  DEATH_KNIGHT = "DEATHKNIGHT",
  ["DEATH KNIGHT"] = "DEATHKNIGHT",
  SHAMAN = "SHAMAN",
  MAGE = "MAGE",
  WARLOCK = "WARLOCK",
  MONK = "MONK",
  DRUID = "DRUID",
  DEMONHUNTER = "DEMONHUNTER",
  DEMON_HUNTER = "DEMONHUNTER",
  ["DEMON HUNTER"] = "DEMONHUNTER",
  EVOKER = "EVOKER",
}

local function NormalizeClassFile(className)
  className = SafeText(className)
  if not className then
    return nil
  end

  className = Trim(className)
  if className == "" then
    return nil
  end

  local direct = CLASS_NAME_TO_FILE[className] or CLASS_NAME_TO_FILE[className:upper():gsub("%s+", "_")] or CLASS_NAME_TO_FILE[className:upper():gsub("[%s_]+", "")]
  if direct then
    return direct
  end

  if LOCALIZED_CLASS_NAMES_MALE then
    for fileName, localizedName in pairs(LOCALIZED_CLASS_NAMES_MALE) do
      if localizedName == className then
        return fileName
      end
    end
  end

  if LOCALIZED_CLASS_NAMES_FEMALE then
    for fileName, localizedName in pairs(LOCALIZED_CLASS_NAMES_FEMALE) do
      if localizedName == className then
        return fileName
      end
    end
  end

  return nil
end

local function GetClassRGBFromGUID(guid)
  guid = SafeText(guid)
  if not guid or not GetPlayerInfoByGUID then
    return nil
  end
  local ok, _, englishClass = pcall(GetPlayerInfoByGUID, guid)
  if ok and englishClass then
    return GetClassRGB(englishClass)
  end
  return nil
end

local function GetClassRGBFromGameInfo(gameInfo)
  if type(gameInfo) ~= "table" then
    return nil
  end

  local classFile = SafeText(gameInfo.classFilename)
    or SafeText(gameInfo.classFileName)
    or NormalizeClassFile(gameInfo.className)

  if classFile then
    return GetClassRGB(classFile)
  end

  return nil
end

local function GetClassRGBFromBattleNetAccount(accountID, guid)
  local _, gameInfo = TryBattleNetAccountGUID(guid)
  local r, g, b = GetClassRGBFromGameInfo(gameInfo)
  if r then
    return r, g, b
  end

  _, gameInfo = TryBattleNetAccountInfo(accountID)
  r, g, b = GetClassRGBFromGameInfo(gameInfo)
  if r then
    return r, g, b
  end

  _, gameInfo = TryBattleNetGameAccountID(accountID)
  r, g, b = GetClassRGBFromGameInfo(gameInfo)
  if r then
    return r, g, b
  end

  return nil
end
local function StoreNameColor(frame, r, g, b)
  if frame and type(r) == "number" and type(g) == "number" and type(b) == "number" then
    frame.nameR, frame.nameG, frame.nameB = Clamp01(r), Clamp01(g), Clamp01(b)
  end
end

local function GetFrameNameColor(frame)
  if frame and type(frame.nameR) == "number" and type(frame.nameG) == "number" and type(frame.nameB) == "number" then
    return frame.nameR, frame.nameG, frame.nameB
  end
  if frame and frame.kind == "BN" then
    return BNET_BLUE_R, BNET_BLUE_G, BNET_BLUE_B
  end
  return GetAccentColor()
end

local function ClassColorName(name, r, g, b)
  return ColorCode(r or 1, g or 1, b or 1) .. tostring(name or UNKNOWN or "Unknown") .. "|r"
end

local function ApplyBackdrop(frame, r, g, b, a, br, bg, bb, ba, edgeSize)
  if not frame or not frame.SetBackdrop then
    return
  end
  edgeSize = Clamp(Round(edgeSize or 1), 1, 8)
  frame:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Buttons\\WHITE8X8",
    edgeSize = edgeSize,
    insets = {left = edgeSize, right = edgeSize, top = edgeSize, bottom = edgeSize},
  })
  frame:SetBackdropColor(r or 0.02, g or 0.02, b or 0.025, a or 0.94)
  frame:SetBackdropBorderColor(br or 0.5, bg or 0.1, bb or 0.1, ba or 1)
end

local function CreateFont(parent, text, size, justify, layer, subLevel)
  local font = parent:CreateFontString(nil, layer or "OVERLAY", nil, subLevel or 0)
  font:SetFont(GetNormalFont(), size or 12, "")
  font:SetJustifyH(justify or "LEFT")
  font:SetText(text or "")
  return font
end

local function SetFontObject(fontString, fontPath, size, flags)
  if not fontString or not fontString.SetFont then
    return
  end
  fontString:SetFont(fontPath or DEFAULT_FONT, size or 12, flags or "")
end

local function GetTitleText(displayName, frame)
  local r, g, b = GetFrameNameColor(frame)
  local name = tostring(displayName or UNKNOWN or "Unknown")

  -- Do not uppercase Battle.net protected strings. Uppercasing changes the closing |k token
  -- into |K, which makes the protected name render as raw |K...|K text in the header.
  return "|cffffffffWHISPER:|r " .. ColorCode(r, g, b) .. name .. "|r"
end

local function SaveGeometry(frame)
  if not frame then
    return
  end
  SetSetting("windowWidth", Clamp(Round(frame:GetWidth() or DEFAULT_WIDTH), MIN_WIDTH, MAX_WIDTH))
  SetSetting("windowHeight", Clamp(Round(frame:GetHeight() or DEFAULT_HEIGHT), MIN_HEIGHT, MAX_HEIGHT))

  local centerX, centerY = frame:GetCenter()
  local parentX, parentY = UIParent:GetCenter()
  if centerX and centerY and parentX and parentY then
    SetSetting("posX", Round(centerX - parentX))
    SetSetting("posY", Round(centerY - parentY))
  end
end

local function PositionWindow(frame)
  local width = Clamp(GetSetting("windowWidth"), MIN_WIDTH, MAX_WIDTH)
  local height = Clamp(GetSetting("windowHeight"), MIN_HEIGHT, MAX_HEIGHT)
  frame:SetSize(width, height)
  frame:ClearAllPoints()
  local posX = GetSetting("posX")
  local posY = GetSetting("posY")
  if type(posX) == "number" and type(posY) == "number" then
    frame:SetPoint("CENTER", UIParent, "CENTER", posX, posY)
  else
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  end
end

local function SaveOptionsGeometry(frame)
  if not frame then
    return
  end
  SetSetting("optionsWidth", Clamp(Round(frame:GetWidth() or 650), 620, 1000))
  SetSetting("optionsHeight", Clamp(Round(frame:GetHeight() or 700), 420, 900))

  local centerX, centerY = frame:GetCenter()
  local parentX, parentY = UIParent:GetCenter()
  if centerX and centerY and parentX and parentY then
    SetSetting("optionsPosX", Round(centerX - parentX))
    SetSetting("optionsPosY", Round(centerY - parentY))
  end
end

local function PositionOptionsFrame(frame)
  if not frame then
    return
  end
  frame:SetSize(Clamp(GetSetting("optionsWidth"), 620, 1000), Clamp(GetSetting("optionsHeight"), 420, 900))
  frame:ClearAllPoints()
  local posX = GetSetting("optionsPosX")
  local posY = GetSetting("optionsPosY")
  if type(posX) == "number" and type(posY) == "number" then
    frame:SetPoint("CENTER", UIParent, "CENTER", posX, posY)
  else
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  end
end

local function SnapWindowToBottom(frame)
  if not frame then
    return
  end
  frame:ClearAllPoints()
  frame:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 36)
  SaveGeometry(frame)
end


local function StripChatCodes(text)
  text = tostring(text or "")
  text = text:gsub("|T.-|t", "")
  text = text:gsub("|A.-|a", "")
  text = text:gsub("|H.-|h(.-)|h", "%1")
  text = text:gsub("|c%x%x%x%x%x%x%x%x", "")
  text = text:gsub("|r", "")
  text = text:gsub("|K.-|k", "Battle.net")
  text = text:gsub("|W(.-)|w", "[%1]")
  text = text:gsub("%s+", " ")
  return Trim(text)
end

local function SafeScrollCall(messageFrame, primary, fallbackOffset)
  if not messageFrame then
    return
  end
  if primary and messageFrame[primary] then
    local ok = pcall(messageFrame[primary], messageFrame)
    if ok then
      return
    end
  end
  if messageFrame.GetScrollOffset and messageFrame.SetScrollOffset then
    local offset = tonumber(messageFrame:GetScrollOffset()) or 0
    offset = math.max(0, offset + (fallbackOffset or 0))
    pcall(messageFrame.SetScrollOffset, messageFrame, offset)
  end
end

local function ScrollPopoutMessages(messageFrame, delta)
  if not messageFrame then
    return
  end

  if delta > 0 then
    if IsShiftKeyDown and IsShiftKeyDown() then
      SafeScrollCall(messageFrame, "ScrollToTop", 1000)
    elseif IsControlKeyDown and IsControlKeyDown() then
      SafeScrollCall(messageFrame, "PageUp", 6)
    else
      SafeScrollCall(messageFrame, "ScrollUp", 3)
    end
  else
    if IsShiftKeyDown and IsShiftKeyDown() then
      SafeScrollCall(messageFrame, "ScrollToBottom", -1000)
    elseif IsControlKeyDown and IsControlKeyDown() then
      SafeScrollCall(messageFrame, "PageDown", -6)
    else
      SafeScrollCall(messageFrame, "ScrollDown", -3)
    end
  end
end

OpenCopyFrame = function(sourceFrame)
  if not sourceFrame then
    return
  end

  if not copyFrame then
    copyFrame = CreateFrame("Frame", "ChayChatWhisperCopyFrame", UIParent, "BackdropTemplate")
    copyFrame:SetFrameStrata("DIALOG")
    copyFrame:SetToplevel(true)
    copyFrame:SetSize(680, 460)
    copyFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    copyFrame:SetMovable(true)
    copyFrame:SetResizable(true)
    copyFrame:EnableMouse(true)
    copyFrame:RegisterForDrag("LeftButton")
    if copyFrame.SetResizeBounds then
      copyFrame:SetResizeBounds(420, 260, 1000, 800)
    end
    copyFrame:SetScript("OnDragStart", function(self)
      self:StartMoving()
    end)
    copyFrame:SetScript("OnDragStop", function(self)
      self:StopMovingOrSizing()
    end)

    copyFrame.title = CreateFont(copyFrame, "Copy Whisper Conversation", 16, "LEFT", "OVERLAY", 5)
    copyFrame.title:SetPoint("TOPLEFT", copyFrame, "TOPLEFT", 14, -10)
    copyFrame.title:SetPoint("RIGHT", copyFrame, "RIGHT", -92, 0)
    copyFrame.title:SetShadowColor(0, 0, 0, 1)
    copyFrame.title:SetShadowOffset(2, -2)

    copyFrame.close = CreateFrame("Button", nil, copyFrame, "BackdropTemplate")
    copyFrame.close:SetPoint("TOPRIGHT", copyFrame, "TOPRIGHT", -10, -8)
    copyFrame.close:SetSize(28, 26)
    copyFrame.close.text = CreateFont(copyFrame.close, "×", 21, "CENTER", "OVERLAY", 6)
    copyFrame.close.text:SetAllPoints(copyFrame.close)
    copyFrame.close:SetScript("OnClick", function()
      copyFrame:Hide()
    end)

    copyFrame.textBox = CreateFrame("Frame", nil, copyFrame, "ScrollingEditBoxTemplate")
    copyFrame.textBox:SetPoint("TOPLEFT", copyFrame, "TOPLEFT", 14, -46)
    copyFrame.textBox:SetPoint("BOTTOMRIGHT", copyFrame, "BOTTOMRIGHT", -14, 14)
    copyFrame.editBox = copyFrame.textBox:GetEditBox()
    copyFrame.editBox:SetAutoFocus(false)
    copyFrame.editBox:SetMultiLine(true)
    copyFrame.editBox:SetScript("OnEscapePressed", function()
      copyFrame:Hide()
    end)

    copyFrame.resizeGrip = CreateFrame("Button", nil, copyFrame)
    copyFrame.resizeGrip:SetPoint("BOTTOMRIGHT", copyFrame, "BOTTOMRIGHT", -4, 4)
    copyFrame.resizeGrip:SetSize(24, 24)
    copyFrame.resizeGrip:EnableMouse(true)
    copyFrame.resizeGrip:SetScript("OnMouseDown", function(_, button)
      if button == "LeftButton" then
        copyFrame:StartSizing("BOTTOMRIGHT")
      end
    end)
    copyFrame.resizeGrip:SetScript("OnMouseUp", function()
      copyFrame:StopMovingOrSizing()
    end)
    copyFrame.resizeGrip.text = CreateFont(copyFrame.resizeGrip, "///", 20, "CENTER", "OVERLAY", 7)
    copyFrame.resizeGrip.text:SetAllPoints(copyFrame.resizeGrip)
  end

  local ar, ag, ab = GetAccentColor()
  local lr, lg, lb = Lighten(ar, ag, ab, 0.35)
  ApplyBackdrop(copyFrame, 0.012, 0.012, 0.018, 0.96, ar, ag, ab, 1, 2)
  if copyFrame.close then
    ApplyBackdrop(copyFrame.close, ar * 0.20, ag * 0.20, ab * 0.20, 0.96, ar, ag, ab, 1, 1)
    copyFrame.close.text:SetTextColor(1, 0.20, 0.20, 1)
  end
  if copyFrame.title then
    copyFrame.title:SetTextColor(lr, lg, lb, 1)
  end
  if copyFrame.resizeGrip and copyFrame.resizeGrip.text then
    copyFrame.resizeGrip.text:SetTextColor(lr, lg, lb, 1)
  end
  if copyFrame.editBox then
    copyFrame.editBox:SetFont(GetConfiguredFont("messageFontPath", "chat"), Clamp(GetSetting("messageFontSize"), 10, 34), "")
    copyFrame.editBox:SetTextColor(1, 1, 1, 1)
  end

  local lines = sourceFrame.copyLines or {}
  local text = table.concat(lines, "\n")
  if text == "" then
    text = "No session messages are available to copy yet."
  end

  copyFrame.textBox:SetText(text)
  copyFrame:Show()
  copyFrame.editBox:SetFocus()
  copyFrame.editBox:HighlightText(0, #copyFrame.editBox:GetText())
end

local function BuildInlineCopyText(sourceFrame)
  if not sourceFrame then
    return ""
  end

  local lines = sourceFrame.copyLines or {}
  local text = table.concat(lines, "\n")
  if text == "" then
    text = "No session messages are available to copy yet."
  end
  return text
end

RefreshInlineCopyText = function(sourceFrame, keepSelection)
  if not sourceFrame or not sourceFrame.inlineCopyBox or not sourceFrame.inlineCopyEdit then
    return
  end

  local text = BuildInlineCopyText(sourceFrame)
  sourceFrame.inlineCopyEdit:SetText(text)
  if sourceFrame.inlineCopyActive and not keepSelection then
    sourceFrame.inlineCopyEdit:SetFocus()
    sourceFrame.inlineCopyEdit:HighlightText(0, #text)
  end
end

ExitInlineCopyMode = function(sourceFrame)
  if not sourceFrame then
    return
  end

  sourceFrame.inlineCopyActive = false
  if sourceFrame.inlineCopyEdit then
    sourceFrame.inlineCopyEdit:ClearFocus()
  end
  if sourceFrame.inlineCopyBox then
    sourceFrame.inlineCopyBox:Hide()
  end
  if sourceFrame.messages then
    sourceFrame.messages:Show()
    if sourceFrame.messages.ScrollToBottom then
      sourceFrame.messages:ScrollToBottom()
    end
  end
  if sourceFrame.copyButton and sourceFrame.copyButton.text then
    sourceFrame.copyButton.text:SetText("Copy")
  end
end

EnterInlineCopyMode = function(sourceFrame)
  if not sourceFrame or not sourceFrame.inlineCopyBox or not sourceFrame.inlineCopyEdit then
    return
  end

  sourceFrame.inlineCopyActive = true
  RefreshInlineCopyText(sourceFrame)
  if sourceFrame.messages then
    sourceFrame.messages:Hide()
  end
  sourceFrame.inlineCopyBox:Show()
  sourceFrame.inlineCopyEdit:SetFocus()
  sourceFrame.inlineCopyEdit:HighlightText(0, #(sourceFrame.inlineCopyEdit:GetText() or ""))
  if sourceFrame.copyButton and sourceFrame.copyButton.text then
    sourceFrame.copyButton.text:SetText("Chat")
  end
end

local function ToggleInlineCopyMode(sourceFrame)
  if not sourceFrame then
    return
  end
  if sourceFrame.inlineCopyActive then
    ExitInlineCopyMode(sourceFrame)
  else
    EnterInlineCopyMode(sourceFrame)
  end
end

local function AddHyperlinkScripts(messageFrame)
  if not messageFrame then
    return
  end

  if messageFrame.EnableMouse then
    messageFrame:EnableMouse(true)
  end
  if messageFrame.SetMouseClickEnabled then
    messageFrame:SetMouseClickEnabled(true)
  end
  if messageFrame.SetMouseMotionEnabled then
    messageFrame:SetMouseMotionEnabled(true)
  end
  if messageFrame.SetHyperlinksEnabled then
    messageFrame:SetHyperlinksEnabled(true)
  end
  if messageFrame.EnableMouseWheel then
    messageFrame:EnableMouseWheel(true)
  end
  messageFrame:SetScript("OnMouseWheel", ScrollPopoutMessages)
  messageFrame:SetScript("OnMouseUp", function(self, button)
    if button == "RightButton" and self.ownerFrame then
      EnterInlineCopyMode(self.ownerFrame)
    end
  end)

  messageFrame:SetScript("OnHyperlinkClick", function(self, link, text, button)
    if not link or link == "" then
      return
    end

    -- Retail chat censor links use Blizzard chat hyperlink handling. Using the
    -- clicked ScrollingMessageFrame plus the original line ID keeps special
    -- |W[Show Message]|w regions clickable inside the popout.
    if SetItemRef then
      local ok = pcall(SetItemRef, link, text or link, button or "LeftButton", self)
      if ok then
        return
      end
      ok = pcall(SetItemRef, link, text or link, button or "LeftButton")
      if ok then
        return
      end
    end

    if ChatFrame_OnHyperlinkShow then
      pcall(ChatFrame_OnHyperlinkShow, self, link, text or link, button or "LeftButton")
    end
  end)

  messageFrame:SetScript("OnHyperlinkEnter", function(self, link)
    if not link or link == "" or not GameTooltip then
      return
    end
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    if GameTooltip.SetHyperlink then
      pcall(GameTooltip.SetHyperlink, GameTooltip, link)
    end
    GameTooltip:Show()
  end)

  messageFrame:SetScript("OnHyperlinkLeave", function()
    if GameTooltip then
      GameTooltip:Hide()
    end
  end)
end

local function EchoKey(key, text)
  return tostring(key or "") .. "||" .. tostring(text or "")
end

local function MarkLocalEcho(key, text)
  localEcho[EchoKey(key, text)] = Now()
end

local function SkipLocalEcho(key, text)
  local now = Now()
  local echoKey = EchoKey(key, text)
  local stamp = localEcho[echoKey]
  if stamp and now - stamp <= 3 then
    localEcho[echoKey] = nil
    return true
  end
  for token, tokenStamp in pairs(localEcho) do
    if now - tokenStamp > 10 then
      localEcho[token] = nil
    end
  end
  return false
end

local function SendPlayerWhisper(target, text)
  if C_ChatInfo and C_ChatInfo.SendChatMessage then
    local ok, result = pcall(C_ChatInfo.SendChatMessage, text, "WHISPER", nil, target)
    if ok and result ~= false then
      return true
    end
  end
  print(PREFIX .. "Unable to send whisper to " .. tostring(target) .. ".")
  return false
end

local function SendBNWhisper(accountID, text)
  if accountID and C_BattleNet and C_BattleNet.SendWhisper then
    local ok, result = pcall(C_BattleNet.SendWhisper, accountID, text)
    if ok and result ~= false then
      return true
    end
  end
  if accountID and BNSendWhisper then
    local ok, result = pcall(BNSendWhisper, accountID, text)
    if ok and result ~= false then
      return true
    end
  end
  print(PREFIX .. "Unable to send Battle.net whisper.")
  return false
end

local function InviteTarget(frame)
  if not frame or frame.kind == "MOCK" then
    return
  end

  local inviteName
  if frame.kind == "BN" then
    inviteName = RefreshBattleNetInviteName(frame)
  else
    inviteName = CleanInviteName(frame.inviteName) or CleanInviteName(frame.target)
  end

  if not inviteName then
    print(PREFIX .. "No inviteable WoW character name is available for this Battle.net conversation yet. They may need to be logged into WoW, visible on Battle.net, and on an inviteable character.")
    return
  end

  if InCombatLockdown and InCombatLockdown() then
    print(PREFIX .. "Cannot invite while in combat lockdown. Try again after combat.")
    return
  end

  if C_PartyInfo and C_PartyInfo.InviteUnit then
    pcall(C_PartyInfo.InviteUnit, inviteName)
    return
  end

  print(PREFIX .. "Group invite API is unavailable on this client build.")
end

local function AddLine(frame, direction, text, lineID)
  if not frame or not frame.messages or not text then
    return
  end

  local ar, ag, ab = GetAccentColor()
  local nr, ng, nb = Lighten(ar, ag, ab, 0.50)
  local tr = Clamp01(GetSetting("textR"))
  local tg = Clamp01(GetSetting("textG"))
  local tb = Clamp01(GetSetting("textB"))
  local prefix = ""

  -- ChayChat: no timestamps in whisper popouts.

  local namePrefix
  if direction == "out" then
    local pr, pg, pb = GetPlayerClassRGB()
    namePrefix = ClassColorName("You", pr, pg, pb) .. ": "
  else
    local cr, cg, cb = GetFrameNameColor(frame)
    namePrefix = ClassColorName(frame.displayName or "Whisper", cr, cg, cb) .. ": "
  end

  if type(frame.copyLines) ~= "table" then
    frame.copyLines = {}
  end
  local plainName = direction == "out" and "You" or StripChatCodes(frame.displayName or "Whisper")
  table.insert(frame.copyLines, plainName .. ": " .. StripChatCodes(text))
  local maxCopyLines = Clamp(Round(GetSetting("lineCap")), 20, 250)
  while #frame.copyLines > maxCopyLines do
    table.remove(frame.copyLines, 1)
  end
  if frame.inlineCopyActive then
    RefreshInlineCopyText(frame, true)
  end

  lineID = SafeNumber(lineID)
  if lineID then
    frame.messages:AddMessage(prefix .. namePrefix .. tostring(text), tr, tg, tb, lineID)
  else
    frame.messages:AddMessage(prefix .. namePrefix .. tostring(text), tr, tg, tb)
  end
  if frame.messages.ScrollToBottom then
    frame.messages:ScrollToBottom()
  end
end

local function CreateButton(parent, label, width, height, onClick)
  local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
  button:SetSize(width or 70, height or 24)
  button.text = CreateFont(button, label, 12, "CENTER", "OVERLAY", 3)
  button.text:SetAllPoints(button)
  button:SetScript("OnClick", onClick)
  ApplyBackdrop(button, 0.06, 0.06, 0.075, 0.94, 0.38, 0.32, 0.48, 1)
  return button
end

ApplyWindowStyle = function(frame)
  if not frame then
    return
  end

  local ar, ag, ab = GetAccentColor()
  local br, bg, bb = Lighten(ar, ag, ab, 0.35)
  local background = Clamp(GetSetting("backgroundLevel"), 0, 0.15)
  local alpha = Clamp(GetSetting("windowAlpha"), 0.35, 1)
  local outline = GetSetting("textOutline") and "OUTLINE" or ""
  local headerSize = Clamp(GetSetting("headerFontSize"), 12, 36)
  local borderAlpha = GetSetting("popoutBorder") and 1 or 0
  local borderSize = Clamp(Round(GetSetting("popoutBorderSize")), 1, 8)

  ApplyBackdrop(frame, background, background, background + 0.005, alpha, ar, ag, ab, borderAlpha, borderSize)
  if frame.bgTexture then
    frame.bgTexture:SetTexture(GetBackgroundTexturePath())
    frame.bgTexture:SetTexCoord(0, 1, 0, 1)
    frame.bgTexture:SetAlpha(Clamp(GetSetting("popoutImageAlpha"), 0, 1))
    frame.bgTexture:SetVertexColor(1, 1, 1, 1)
  end
  if frame.bgShade then
    frame.bgShade:SetColorTexture(0, 0, 0, Clamp(GetSetting("popoutDarkOverlay"), 0, 0.90))
  end
  if frame.header then
    ApplyBackdrop(frame.header, 0.012 + (ar * 0.10), 0.012 + (ag * 0.10), 0.016 + (ab * 0.10), 1, ar, ag, ab, 1)
  end
  if frame.headerGlow then
    frame.headerGlow:SetColorTexture(br, bg, bb, 0.20)
  end
  if frame.headerLine then
    frame.headerLine:SetColorTexture(br, bg, bb, 0.82)
  end
  if frame.title then
    SetFontObject(frame.title, GetConfiguredFont("headerFontPath", "ui"), headerSize, "THICKOUTLINE")
    frame.title:SetText(GetTitleText(frame.displayName, frame))
    frame.title:SetTextColor(1, 1, 1, 1)
    frame.title:SetAlpha(1)
  end
  if frame.messages then
    frame.messages:SetFont(GetConfiguredFont("messageFontPath", "chat"), Clamp(GetSetting("messageFontSize"), 10, 34), outline)
    frame.messages:SetMaxLines(Clamp(Round(GetSetting("lineCap")), 20, 250))
  end
  if frame.inlineCopyEdit then
    frame.inlineCopyEdit:SetFont(GetConfiguredFont("messageFontPath", "chat"), Clamp(GetSetting("messageFontSize"), 10, 34), outline)
    frame.inlineCopyEdit:SetTextColor(1, 1, 1, 1)
  end
  if frame.inlineCopyBox and frame.inlineCopyBox.SetBackdrop then
    ApplyBackdrop(frame.inlineCopyBox, 0.010 + (ar * 0.04), 0.010 + (ag * 0.04), 0.014 + (ab * 0.04), 0.92, br, bg, bb, 0.95, 1)
  end
  if frame.input then
    frame.input:SetFont(GetConfiguredFont("inputFontPath", "chat"), Clamp(GetSetting("inputFontSize"), 10, 30), outline)
    frame.input:SetTextColor(1, 1, 1, 1)
    frame.input:SetAlpha(1)
    ApplyBackdrop(frame.input, 0.010 + (ar * 0.05), 0.010 + (ag * 0.05), 0.014 + (ab * 0.05), 1, br, bg, bb, 1)
    if frame.inputHint then
      local hasText = frame.input:GetText() and frame.input:GetText() ~= ""
      frame.inputHint:SetShown(not hasText and not frame.input:HasFocus())
      frame.inputHint:SetTextColor(br, bg, bb, 0.82)
      frame.inputHint:SetFont(GetConfiguredFont("inputFontPath", "chat"), Clamp(GetSetting("inputFontSize"), 10, 30), "OUTLINE")
    end
  end
  if frame.optionsButton then
    ApplyBackdrop(frame.optionsButton, ar * 0.22, ag * 0.22, ab * 0.22, 0.95, ar, ag, ab, 1)
    frame.optionsButton.text:SetTextColor(1, 0.95, 0.75, 1)
  end
  if frame.bottomButton then
    ApplyBackdrop(frame.bottomButton, ar * 0.22, ag * 0.22, ab * 0.22, 0.95, ar, ag, ab, 1)
    frame.bottomButton.text:SetTextColor(1, 0.95, 0.75, 1)
  end
  if frame.sendButton then
    ApplyBackdrop(frame.sendButton, ar * 0.30, ag * 0.30, ab * 0.30, 0.96, ar, ag, ab, 1)
    frame.sendButton.text:SetTextColor(1, 0.95, 0.75, 1)
  end
  if frame.copyButton then
    ApplyBackdrop(frame.copyButton, ar * 0.25, ag * 0.25, ab * 0.25, 0.96, ar, ag, ab, 1)
    frame.copyButton.text:SetTextColor(1, 0.95, 0.75, 1)
  end
  if frame.inviteButton then
    if frame.kind == "BN" then
      RefreshBattleNetInviteName(frame)
    end
    local enabled = frame.kind ~= "MOCK"
    frame.inviteButton:SetShown(frame.kind ~= "MOCK")
    if enabled then
      ApplyBackdrop(frame.inviteButton, ar * 0.28, ag * 0.28, ab * 0.28, 0.96, ar, ag, ab, 1)
      frame.inviteButton.text:SetTextColor(1, 0.95, 0.75, 1)
      frame.inviteButton:Enable()
    else
      ApplyBackdrop(frame.inviteButton, 0.05, 0.05, 0.055, 0.88, 0.25, 0.25, 0.28, 0.75)
      frame.inviteButton.text:SetTextColor(0.55, 0.55, 0.55, 1)
      frame.inviteButton:Disable()
    end
  end
  if frame.closeButton and frame.closeButton.text then
    ApplyBackdrop(frame.closeButton, ar * 0.20, ag * 0.20, ab * 0.20, 0.96, ar, ag, ab, 1, 1)
    frame.closeButton.text:SetTextColor(1, 0.20, 0.20, 1)
  end
  if frame.gripText then
    frame.gripText:SetFont(GetNormalFont(), 20, "OUTLINE")
    frame.gripText:SetTextColor(br, bg, bb, 1)
  end
end

LayoutWindow = function(frame)
  if not frame then
    return
  end

  local headerHeight = Clamp(Round(GetSetting("headerHeight")), 28, 80)
  local buttonHeight = Clamp(headerHeight - 12, 20, 32)
  local topButtonY = -math.floor((headerHeight - buttonHeight) / 2) - 1

  frame.header:ClearAllPoints()
  frame.header:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -1)
  frame.header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -1, -1)
  frame.header:SetHeight(headerHeight)

  frame.closeButton:ClearAllPoints()
  frame.closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, topButtonY)
  frame.closeButton:SetSize(buttonHeight, buttonHeight)

  if frame.copyButton then
    frame.copyButton:ClearAllPoints()
    frame.copyButton:SetPoint("RIGHT", frame.closeButton, "LEFT", -7, 0)
    frame.copyButton:SetSize(56, buttonHeight)
  end

  if frame.inviteButton then
    frame.inviteButton:ClearAllPoints()
    if frame.copyButton then
      frame.inviteButton:SetPoint("RIGHT", frame.copyButton, "LEFT", -7, 0)
    else
      frame.inviteButton:SetPoint("RIGHT", frame.closeButton, "LEFT", -7, 0)
    end
    frame.inviteButton:SetSize(62, buttonHeight)
  end

  if frame.bottomButton then
    frame.bottomButton:Hide()
  end
  if frame.optionsButton then
    frame.optionsButton:Hide()
  end

  frame.title:ClearAllPoints()
  frame.title:SetPoint("LEFT", frame.header, "LEFT", 14, 0)
  if frame.inviteButton and frame.inviteButton:IsShown() then
    frame.title:SetPoint("RIGHT", frame.inviteButton, "LEFT", -10, 0)
  elseif frame.copyButton then
    frame.title:SetPoint("RIGHT", frame.copyButton, "LEFT", -10, 0)
  else
    frame.title:SetPoint("RIGHT", frame.closeButton, "LEFT", -10, 0)
  end
  frame.title:SetHeight(headerHeight)

  frame.dragBar:ClearAllPoints()
  frame.dragBar:SetPoint("TOPLEFT", frame.header, "TOPLEFT", 0, 0)
  if frame.inviteButton and frame.inviteButton:IsShown() then
    frame.dragBar:SetPoint("BOTTOMRIGHT", frame.inviteButton, "LEFT", -3, 0)
  elseif frame.copyButton then
    frame.dragBar:SetPoint("BOTTOMRIGHT", frame.copyButton, "LEFT", -3, 0)
  else
    frame.dragBar:SetPoint("BOTTOMRIGHT", frame.closeButton, "LEFT", -3, 0)
  end

  frame.input:ClearAllPoints()
  frame.input:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 10, 10)
  frame.input:SetPoint("BOTTOMRIGHT", frame.sendButton, "BOTTOMLEFT", -8, 0)
  frame.input:SetHeight(34)

  frame.sendButton:ClearAllPoints()
  frame.sendButton:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -32, 10)
  frame.sendButton:SetSize(72, 34)

  frame.messages:ClearAllPoints()
  frame.messages:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -headerHeight - 10)
  frame.messages:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -10, 56)

  if frame.inlineCopyBox then
    frame.inlineCopyBox:ClearAllPoints()
    frame.inlineCopyBox:SetPoint("TOPLEFT", frame.messages, "TOPLEFT", 0, 0)
    frame.inlineCopyBox:SetPoint("BOTTOMRIGHT", frame.messages, "BOTTOMRIGHT", 0, 0)
  end

  frame.grip:ClearAllPoints()
  frame.grip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5)
  frame.grip:SetSize(22, 22)
end

local function ApplyAllWindows()
  for _, frame in pairs(windows) do
    LayoutWindow(frame)
    ApplyWindowStyle(frame)
  end
end

ApplyOptionsFrameStyle = function()
  if not optionsFrame then
    return
  end

  local ar, ag, ab = GetAccentColor()
  local lr, lg, lb = Lighten(ar, ag, ab, 0.35)

  if optionsFrame.dragon then
    optionsFrame.dragon:SetTexture(GetBackgroundTexturePath())
    optionsFrame.dragon:SetAlpha(FIXED_OPTIONS_IMAGE_ALPHA)
  end
  if optionsFrame.overlay then
    optionsFrame.overlay:SetColorTexture(0, 0, 0, FIXED_OPTIONS_DARK_OVERLAY)
  end

  local optionsBorderAlpha = GetSetting("optionsBorder") and 1 or 0
  local optionsBorderSize = Clamp(Round(GetSetting("optionsBorderSize")), 1, 10)
  ApplyBackdrop(optionsFrame, 0.006, 0.006, 0.010, 0.08, ar, ag, ab, optionsBorderAlpha, optionsBorderSize)
  if optionsFrame.title then
    optionsFrame.title:SetTextColor(lr, lg, lb, 1)
  end
  if optionsFrame.close then
    ApplyBackdrop(optionsFrame.close, ar * 0.20, ag * 0.20, ab * 0.20, 0.96, ar, ag, ab, 1, 1)
  end
  if optionsFrame.resizeGrip and optionsFrame.resizeGrip.text then
    optionsFrame.resizeGrip.text:SetTextColor(lr, lg, lb, 1)
  end
end

local function ShowOptionsFrame()
  if not optionsFrame then
    optionControls = {}

    optionsFrame = CreateFrame("Frame", "ChayChatOptionsFrame", UIParent, "BackdropTemplate")
    PositionOptionsFrame(optionsFrame)
    optionsFrame:SetFrameStrata("DIALOG")
    optionsFrame:SetClampedToScreen(true)
    optionsFrame:EnableMouse(true)
    optionsFrame:SetMovable(true)
    optionsFrame:SetResizable(true)
    optionsFrame:RegisterForDrag("LeftButton")
    if optionsFrame.SetResizeBounds then
      optionsFrame:SetResizeBounds(620, 420, 1000, 900)
    end
    optionsFrame:SetScript("OnDragStart", function(self)
      self:StartMoving()
    end)
    optionsFrame:SetScript("OnDragStop", function(self)
      self:StopMovingOrSizing()
      SaveOptionsGeometry(self)
    end)

    optionsFrame.dragon = optionsFrame:CreateTexture(nil, "BACKGROUND")
    optionsFrame.dragon:SetAllPoints(optionsFrame)
    optionsFrame.dragon:SetTexture(GetBackgroundTexturePath())
    optionsFrame.dragon:SetTexCoord(0, 1, 0, 1)
    optionsFrame.dragon:SetAlpha(FIXED_OPTIONS_IMAGE_ALPHA)

    optionsFrame.overlay = optionsFrame:CreateTexture(nil, "BORDER")
    optionsFrame.overlay:SetAllPoints(optionsFrame)
    optionsFrame.overlay:SetColorTexture(0, 0, 0, FIXED_OPTIONS_DARK_OVERLAY)

    optionsFrame.title = CreateFont(optionsFrame, "ChayChat Options", 16, "LEFT", "OVERLAY", 4)
    optionsFrame.title:SetPoint("TOPLEFT", optionsFrame, "TOPLEFT", 16, -12)
    optionsFrame.title:SetPoint("RIGHT", optionsFrame, "RIGHT", -46, 0)
    optionsFrame.title:SetTextColor(1, 0.88, 0.35, 1)
    optionsFrame.title:SetShadowColor(0, 0, 0, 1)
    optionsFrame.title:SetShadowOffset(2, -2)

    optionsFrame.close = CreateFrame("Button", nil, optionsFrame, "BackdropTemplate")
    optionsFrame.close:SetPoint("TOPRIGHT", optionsFrame, "TOPRIGHT", -10, -8)
    optionsFrame.close:SetSize(26, 24)
    optionsFrame.close.text = CreateFont(optionsFrame.close, "×", 21, "CENTER", "OVERLAY", 5)
    optionsFrame.close.text:SetAllPoints(optionsFrame.close)
    optionsFrame.close.text:SetTextColor(1, 0.20, 0.20, 1)
    optionsFrame.close:SetScript("OnClick", function()
      optionsFrame:Hide()
    end)

    optionsFrame.mockTab = CreateButton(optionsFrame, "Mock Window", 112, 24, function()
      if OpenMockWindow then
        OpenMockWindow()
      end
    end)
    optionsFrame.mockTab:SetPoint("TOPRIGHT", optionsFrame.close, "TOPLEFT", -8, -1)

    local scroll = CreateFrame("ScrollFrame", "ChayChatOptionsScrollFrame", optionsFrame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", optionsFrame, "TOPLEFT", 28, -52)
    scroll:SetPoint("BOTTOMRIGHT", optionsFrame, "BOTTOMRIGHT", -34, 34)

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(560, 1)
    scroll:SetScrollChild(content)

    local rows = {}
    local function AddRow(row)
      table.insert(rows, row)
    end

    local function CreateSection(text)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, 24)
      local label = CreateFont(row, text, 14, "LEFT", "OVERLAY", 2)
      label:SetPoint("LEFT", row, "LEFT", 0, 0)
      label:SetTextColor(0.85, 0.72, 1.0, 1)
      return row
    end

    local function CreateCheck(labelText, key)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, 30)
      local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
      check:SetPoint("LEFT", row, "LEFT", -4, 0)
      check:SetSize(28, 28)
      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("LEFT", check, "RIGHT", 3, 0)
      label:SetTextColor(1, 0.95, 0.25, 1)
      check:SetScript("OnClick", function(self)
        if refreshingOptions then
          return
        end
        SetSetting(key, self:GetChecked() and true or false)
        if key == "noFade" then
          ApplyNoFadeSetting()
          ForceMainChatRender()
        end
        ApplyAllWindows()
        RefreshMinimapButton()
        RefreshChatFrameButton()
        RefreshOptionsFrame()
      end)
      table.insert(optionControls, {kind = "check", key = key, check = check})
      return row
    end

    local function CreateEditInput(labelText, key, helpText)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, helpText and 64 or 42)

      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
      label:SetTextColor(1, 0.95, 0.25, 1)

      local edit = CreateFrame("EditBox", nil, row, "BackdropTemplate")
      edit:SetPoint("TOPLEFT", row, "TOPLEFT", 170, 0)
      edit:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, 0)
      edit:SetHeight(26)
      edit:SetAutoFocus(false)
      edit:SetFont(GetNormalFont(), 12, "")
      edit:SetTextInsets(8, 8, 0, 0)
      edit:SetTextColor(1, 1, 1, 1)
      edit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
      end)

      local function SaveValue(self)
        if refreshingOptions then
          return
        end
        local value = Trim(self:GetText() or "")
        if value == "" then
          value = DRAGON_BACKGROUND
        elseif key == "backgroundImagePath" then
          value = AddCustomBackgroundPath(value)
        end
        SetSetting(key, value)
        ApplyAllWindows()
        ApplyOptionsFrameStyle()
        RefreshMinimapButton()
        RefreshOptionsFrame()
      end

      edit:SetScript("OnEnterPressed", function(self)
        SaveValue(self)
        self:ClearFocus()
      end)
      edit:SetScript("OnEditFocusLost", SaveValue)

      local ar, ag, ab = GetAccentColor()
      ApplyBackdrop(edit, 0.015, 0.015, 0.020, 0.96, ar, ag, ab, 1, 1)

      if helpText then
        local help = CreateFont(row, helpText, 11, "LEFT", "OVERLAY", 2)
        help:SetPoint("TOPLEFT", row, "TOPLEFT", 170, -30)
        help:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, -30)
        help:SetTextColor(0.82, 0.78, 0.90, 1)
        help:SetJustifyH("LEFT")
      end

      table.insert(optionControls, {kind = "edit", key = key, edit = edit})
      return row
    end

    local function CreateBackgroundAddInput(labelText, helpText)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, helpText and 64 or 42)

      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
      label:SetTextColor(1, 0.95, 0.25, 1)

      local edit = CreateFrame("EditBox", nil, row, "BackdropTemplate")
      edit:SetPoint("TOPLEFT", row, "TOPLEFT", 170, 0)
      edit:SetPoint("TOPRIGHT", row, "TOPRIGHT", -64, 0)
      edit:SetHeight(26)
      edit:SetAutoFocus(false)
      edit:SetFont(GetNormalFont(), 12, "")
      edit:SetTextInsets(8, 8, 0, 0)
      edit:SetTextColor(1, 1, 1, 1)
      edit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
      end)

      local addButton = CreateButton(row, "Add", 54, 26, nil)
      addButton:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, 0)

      local function AddTypedBackground()
        if refreshingOptions then
          return
        end
        local raw = Trim(edit:GetText() or "")
        if raw == "" then
          print(PREFIX .. "Type a .png, .tga, or .blp file name from ChayChat\\Media first.")
          return
        end
        local path = AddCustomBackgroundPath(raw)
        if not path then
          print(PREFIX .. "Backgrounds must be custom .png, .tga, or .blp files inside Interface\\AddOns\\ChayChat\\Media.")
          return
        end
        SetSetting("backgroundImagePath", path)
        edit:SetText("")
        edit:ClearFocus()
        ApplyAllWindows()
        ApplyOptionsFrameStyle()
        RefreshMinimapButton()
        RefreshOptionsFrame()
      end

      edit:SetScript("OnEnterPressed", AddTypedBackground)
      addButton:SetScript("OnClick", AddTypedBackground)

      local ar, ag, ab = GetAccentColor()
      ApplyBackdrop(edit, 0.015, 0.015, 0.020, 0.96, ar, ag, ab, 1, 1)

      if helpText then
        local help = CreateFont(row, helpText, 11, "LEFT", "OVERLAY", 2)
        help:SetPoint("TOPLEFT", row, "TOPLEFT", 170, -30)
        help:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, -30)
        help:SetTextColor(0.82, 0.78, 0.90, 1)
        help:SetJustifyH("LEFT")
      end

      table.insert(optionControls, {kind = "backgroundAdd", edit = edit})
      return row
    end

    local function CreateSlider(labelText, key, minValue, maxValue, step, formatter)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, 42)
      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
      label:SetTextColor(1, 0.95, 0.25, 1)
      local valueLabel = CreateFont(row, "", 12, "RIGHT", "OVERLAY", 2)
      valueLabel:SetPoint("TOPRIGHT", row, "TOPRIGHT", -6, -1)
      valueLabel:SetSize(80, 18)
      valueLabel:SetTextColor(1, 0.95, 0.25, 1)

      local sliderName = "ChayChatOptionSlider" .. tostring(#optionControls + 1)
      local slider = CreateFrame("Slider", sliderName, row, "OptionsSliderTemplate")
      slider:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -23)
      slider:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, -23)
      slider:SetMinMaxValues(minValue, maxValue)
      slider:SetValueStep(step or 1)
      if slider.SetObeyStepOnDrag then
        slider:SetObeyStepOnDrag(true)
      end
      if _G[sliderName .. "Low"] then
        _G[sliderName .. "Low"]:SetText("")
      end
      if _G[sliderName .. "High"] then
        _G[sliderName .. "High"]:SetText("")
      end
      if _G[sliderName .. "Text"] then
        _G[sliderName .. "Text"]:SetText("")
      end
      formatter = formatter or function(value) return tostring(value) end
      slider:SetScript("OnValueChanged", function(_, value)
        if refreshingOptions then
          return
        end
        value = Clamp(value, minValue, maxValue)
        if step and step >= 1 then
          value = Round(value)
        end
        valueLabel:SetText(formatter(value))
        SetSetting(key, value)
        ApplyAllWindows()
        ApplyOptionsFrameStyle()
        RefreshMinimapButton()
        RefreshChatFrameButton()
        RefreshOptionsFrame()
      end)
      table.insert(optionControls, {kind = "slider", key = key, slider = slider, value = valueLabel, formatter = formatter})
      return row
    end

    local activeDropdown

    local function HideActiveDropdown()
      if activeDropdown then
        activeDropdown:Hide()
        activeDropdown = nil
      end
    end

    optionsFrame:SetScript("OnHide", HideActiveDropdown)

    local function CreateDropdownSelector(labelText, key, kind, getIndexAndChoices, applyChoice, playOnSelect, getter)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, 36)

      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("LEFT", row, "LEFT", 0, 0)
      label:SetWidth(142)
      label:SetTextColor(1, 0.95, 0.25, 1)

      local button = CreateFrame("Button", nil, row, "BackdropTemplate")
      button:SetPoint("LEFT", label, "RIGHT", 6, 0)
      button:SetSize(368, 26)
      ApplyBackdrop(button, 0.03, 0.03, 0.04, 0.96, 0.38, 0.32, 0.48, 1)

      local value = CreateFont(button, "", 12, "LEFT", "OVERLAY", 2)
      value:SetPoint("LEFT", button, "LEFT", 9, 0)
      value:SetPoint("RIGHT", button, "RIGHT", -28, 0)
      value:SetJustifyH("LEFT")
      value:SetTextColor(0.86, 0.74, 1.0, 1)

      local arrow = CreateFont(button, "▾", 14, "CENTER", "OVERLAY", 2)
      arrow:SetPoint("RIGHT", button, "RIGHT", -9, 0)
      arrow:SetTextColor(1, 0.94, 0.55, 1)

      local function RecolorButton(open)
        local ar, ag, ab = GetAccentColor()
        local lr, lg, lb = Lighten(ar, ag, ab, 0.38)
        ApplyBackdrop(button, 0.03, 0.03, 0.04, 0.96, open and lr or ar, open and lg or ag, open and lb or ab, 1)
        arrow:SetText(open and "▴" or "▾")
      end

      local function OpenDropdown()
        local selectedIndex, choices = getIndexAndChoices(getter and getter(key) or GetSetting(key))
        if type(choices) ~= "table" or #choices == 0 then
          return
        end

        HideActiveDropdown()

        local menu = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        activeDropdown = menu
        menu:SetFrameStrata("TOOLTIP")
        menu:SetFrameLevel((optionsFrame:GetFrameLevel() or 1) + 80)
        menu:SetSize(368, Clamp((#choices * 24) + 8, 48, 260))
        menu:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -2)
        menu:EnableMouse(true)
        ApplyBackdrop(menu, 0.008, 0.008, 0.012, 0.98, 0.55, 0.44, 0.75, 1)

        local scroll = CreateFrame("ScrollFrame", nil, menu, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", menu, "TOPLEFT", 4, -4)
        scroll:SetPoint("BOTTOMRIGHT", menu, "BOTTOMRIGHT", -26, 4)
        scroll:EnableMouseWheel(true)
        scroll:SetScript("OnMouseWheel", function(self, delta)
          local current = self:GetVerticalScroll() or 0
          local maxScroll = self:GetVerticalScrollRange() or 0
          self:SetVerticalScroll(Clamp(current - (delta * 30), 0, maxScroll))
        end)

        local holder = CreateFrame("Frame", nil, scroll)
        holder:SetSize(332, (#choices * 24) + 2)
        scroll:SetScrollChild(holder)

        local ar, ag, ab = GetAccentColor()
        local lr, lg, lb = Lighten(ar, ag, ab, 0.40)

        for index, choice in ipairs(choices) do
          local item = CreateFrame("Button", nil, holder, "BackdropTemplate")
          item:SetPoint("TOPLEFT", holder, "TOPLEFT", 0, -((index - 1) * 24))
          item:SetSize(332, 23)
          if index == selectedIndex then
            ApplyBackdrop(item, ar * 0.22, ag * 0.22, ab * 0.22, 0.96, lr, lg, lb, 1)
          else
            ApplyBackdrop(item, 0.015, 0.015, 0.020, 0.88, 0.18, 0.18, 0.22, 1)
          end

          local itemText = CreateFont(item, tostring(choice.name or "Unknown"), 12, "LEFT", "OVERLAY", 2)
          itemText:SetPoint("LEFT", item, "LEFT", 8, 0)
          itemText:SetPoint("RIGHT", item, "RIGHT", -8, 0)
          itemText:SetJustifyH("LEFT")
          if choice.disabled then
            itemText:SetTextColor(0.58, 0.55, 0.64, 1)
          elseif index == selectedIndex then
            itemText:SetTextColor(1, 0.96, 0.72, 1)
          else
            itemText:SetTextColor(0.86, 0.74, 1.0, 1)
          end

          item:SetScript("OnEnter", function(self)
            ApplyBackdrop(self, ar * 0.28, ag * 0.28, ab * 0.28, 0.98, lr, lg, lb, 1)
          end)
          item:SetScript("OnLeave", function(self)
            if index == selectedIndex then
              ApplyBackdrop(self, ar * 0.22, ag * 0.22, ab * 0.22, 0.96, lr, lg, lb, 1)
            else
              ApplyBackdrop(self, 0.015, 0.015, 0.020, 0.88, 0.18, 0.18, 0.22, 1)
            end
          end)
          item:SetScript("OnClick", function()
            if choice.disabled then
              HideActiveDropdown()
              RecolorButton(false)
              return
            end
            applyChoice(choice)
            if playOnSelect then
              PlaySelectedSound()
            end
            HideActiveDropdown()
            RecolorButton(false)
            ApplyAllWindows()
            ForceMainChatRender()
            RefreshMinimapButton()
            RefreshChatFrameButton()
            RefreshOptionsFrame()
          end)
        end

        RecolorButton(true)
        menu:SetScript("OnHide", function()
          if activeDropdown == menu then
            activeDropdown = nil
          end
          RecolorButton(false)
        end)
        menu:Show()
      end

      button:SetScript("OnClick", function()
        if activeDropdown and activeDropdown:IsShown() then
          HideActiveDropdown()
          RecolorButton(false)
        else
          OpenDropdown()
        end
      end)

      button:SetScript("OnEnter", function()
        local ar, ag, ab = GetAccentColor()
        local lr, lg, lb = Lighten(ar, ag, ab, 0.38)
        ApplyBackdrop(button, 0.03, 0.03, 0.04, 0.96, lr, lg, lb, 1)
      end)
      button:SetScript("OnLeave", function()
        if not activeDropdown then
          RecolorButton(false)
        end
      end)

      table.insert(optionControls, {kind = kind, key = key, value = value, dropdown = button, getIndexAndChoices = getIndexAndChoices, getter = getter})
      return row
    end

    local function CreateFontSelector(labelText, key)
      return CreateDropdownSelector(labelText, key, "font", GetFontChoiceIndex, function(choice)
        SetSetting(key, choice and choice.path or false)
      end, false)
    end

    local function CreateSoundSelector(labelText, key)
      return CreateDropdownSelector(labelText, key, "sound", GetSoundChoiceIndex, function(choice)
        SetSetting(key, choice and choice.name or "None")
      end, true)
    end

    local function CreateBackgroundSelector(labelText, key)
      return CreateDropdownSelector(labelText, key, "background", GetBackgroundChoiceIndex, function(choice)
        if choice and choice.path then
          SetSetting(key, AddCustomBackgroundPath(choice.path))
          ApplyOptionsFrameStyle()
        end
      end, false)
    end

    local function CreateMainChatSlider(labelText, option, minValue, maxValue, step, formatter)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, 42)
      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
      label:SetTextColor(1, 0.95, 0.25, 1)
      local valueLabel = CreateFont(row, "", 12, "RIGHT", "OVERLAY", 2)
      valueLabel:SetPoint("TOPRIGHT", row, "TOPRIGHT", -6, -1)
      valueLabel:SetSize(80, 18)
      valueLabel:SetTextColor(1, 0.95, 0.25, 1)

      local sliderName = "ChayChatMainOptionSlider" .. tostring(#optionControls + 1)
      local slider = CreateFrame("Slider", sliderName, row, "OptionsSliderTemplate")
      slider:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -23)
      slider:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, -23)
      slider:SetMinMaxValues(minValue, maxValue)
      slider:SetValueStep(step or 1)
      if slider.SetObeyStepOnDrag then
        slider:SetObeyStepOnDrag(true)
      end
      if _G[sliderName .. "Low"] then _G[sliderName .. "Low"]:SetText("") end
      if _G[sliderName .. "High"] then _G[sliderName .. "High"]:SetText("") end
      if _G[sliderName .. "Text"] then _G[sliderName .. "Text"]:SetText("") end

      formatter = formatter or function(value) return tostring(value) end
      slider:SetScript("OnValueChanged", function(_, value)
        if refreshingOptions then
          return
        end
        value = Clamp(value, minValue, maxValue)
        if step and step >= 1 then
          value = Round(value)
        end
        valueLabel:SetText(formatter(value))
        SetMainChatOption(option, value)
        ForceMainChatRender()
      end)
      table.insert(optionControls, {kind = "mainSlider", option = option, slider = slider, value = valueLabel, formatter = formatter})
      return row
    end

    local function CreateMainChatCheck(labelText, option)
      local row = CreateFrame("Frame", nil, content)
      row:SetSize(560, 30)
      local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
      check:SetPoint("LEFT", row, "LEFT", -4, 0)
      check:SetSize(28, 28)
      local label = CreateFont(row, labelText, 12, "LEFT", "OVERLAY", 2)
      label:SetPoint("LEFT", check, "RIGHT", 3, 0)
      label:SetTextColor(1, 0.95, 0.25, 1)
      check:SetScript("OnClick", function(self)
        if refreshingOptions then
          return
        end
        SetMainChatOption(option, self:GetChecked() and true or false)
        ForceMainChatRender()
        RefreshOptionsFrame()
      end)
      table.insert(optionControls, {kind = "mainCheck", option = option, check = check})
      return row
    end

    local function CreateStaticMainChatDropdown(labelText, option, choices)
      local function GetStaticIndex(current)
        for index, choice in ipairs(choices) do
          if choice.value == current then
            return index, choices
          end
        end
        return 1, choices
      end
      return CreateDropdownSelector(labelText, option, "mainDropdown", GetStaticIndex, function(choice)
        SetMainChatOption(option, choice and choice.value or choices[1].value)
      end, false, function(configOption)
        return GetMainChatOption(configOption, choices[1].value)
      end)
    end

    local function CreateMainChatFontSelector(labelText, option)
      return CreateDropdownSelector(labelText, option, "mainFont", GetMainChatFontChoiceIndex, function(choice)
        SetMainChatOption(option, choice and choice.lsmKey or "default")
      end, false, function(configOption)
        return GetMainChatOption(configOption, "default")
      end)
    end

    AddRow(CreateSection("Window"))
    AddRow(CreateBackgroundSelector("Added custom backgrounds", "backgroundImagePath"))
    AddRow(CreateBackgroundAddInput("Add custom background", "Put your PNG/TGA/BLP in ChayChat\\Media, type the file name, then press Add or Enter."))
    AddRow(CreateCheck("No fade / keep main chat text visible", "noFade"))
    AddRow(CreateSlider("Window opacity", "windowAlpha", 0.25, 1, 0.01, function(value) return tostring(Round(value * 100)) .. "%" end))
    AddRow(CreateSlider("Popout image visibility", "popoutImageAlpha", 0, 1, 0.01, function(value) return tostring(Round(value * 100)) .. "%" end))
    AddRow(CreateSlider("Popout dark overlay", "popoutDarkOverlay", 0, 0.90, 0.01, function(value) return tostring(Round(value * 100)) .. "%" end))
    AddRow(CreateSlider("Popout background brightness", "backgroundLevel", 0, 0.20, 0.005, function(value) return tostring(Round(value * 100)) .. "%" end))
    AddRow(CreateCheck("Show popout border", "popoutBorder"))
    AddRow(CreateSlider("Popout border size", "popoutBorderSize", 1, 8, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateCheck("Show options border", "optionsBorder"))
    AddRow(CreateSlider("Options border size", "optionsBorderSize", 1, 10, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateCheck("Show minimap button", "showMinimapButton"))

    AddRow(CreateSection("Main Chat"))
    AddRow(CreateMainChatFontSelector("Main chat font", addonTable.Config.Options.MESSAGE_FONT))
    AddRow(CreateMainChatSlider("Main chat font size", addonTable.Config.Options.MESSAGE_FONT_SIZE, 8, 34, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateMainChatSlider("Main chat message spacing", addonTable.Config.Options.MESSAGE_SPACING, 0, 60, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateMainChatSlider("Main chat line spacing", addonTable.Config.Options.LINE_SPACING, 0, 30, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateMainChatSlider("Main chat background transparency", "skins.dark.chat_transparency", 0, 0.95, 0.01, function(value) return tostring(Round(value * 100)) .. "%" end))
    AddRow(CreateStaticMainChatDropdown("Edit box position", addonTable.Config.Options.EDIT_BOX_POSITION, {
      {name = "Bottom", value = "bottom"},
      {name = "Top", value = "top"},
    }))
    AddRow(CreateMainChatCheck("Keep edit box visible", addonTable.Config.Options.KEEP_EDIT_BOX_VISIBLE))
    AddRow(CreateMainChatCheck("Lock main chat movement/resizing", addonTable.Config.Options.LOCKED))

    AddRow(CreateSection("Whisper Popout Text and Header"))
    AddRow(CreateSlider("Popout message font size", "messageFontSize", 10, 34, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateSlider("Popout input font size", "inputFontSize", 10, 30, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateSlider("Whisper name font size", "headerFontSize", 12, 36, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateSlider("Whisper header height", "headerHeight", 28, 80, 1, function(value) return tostring(Round(value)) end))
    AddRow(CreateFontSelector("Popout message font", "messageFontPath"))
    AddRow(CreateFontSelector("Popout input font", "inputFontPath"))
    AddRow(CreateFontSelector("Whisper name font", "headerFontPath"))
    AddRow(CreateSlider("Session line cap", "lineCap", 20, 250, 5, function(value) return tostring(Round(value)) end))
    AddRow(CreateSection("Incoming Whisper Alert"))
    AddRow(CreateCheck("Play sound on incoming whispers", "soundEnabled"))
    AddRow(CreateSoundSelector("Incoming sound", "soundChoice"))


    local y = 0
    for _, row in ipairs(rows) do
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -y)
      row:SetPoint("TOPRIGHT", content, "TOPRIGHT", 0, -y)
      y = y + (row:GetHeight() or 32) + 4
    end
    content:SetHeight(y + 12)

    -- Bottom utility buttons removed. Mock preview is opened from the top Mock Window tab.

    optionsFrame.resizeGrip = CreateFrame("Button", nil, optionsFrame)
    optionsFrame.resizeGrip:SetPoint("BOTTOMRIGHT", optionsFrame, "BOTTOMRIGHT", -5, 5)
    optionsFrame.resizeGrip:SetSize(24, 24)
    optionsFrame.resizeGrip:EnableMouse(true)
    optionsFrame.resizeGrip:SetFrameLevel(optionsFrame:GetFrameLevel() + 8)
    optionsFrame.resizeGrip:SetScript("OnMouseDown", function(_, button)
      if button == "LeftButton" then
        optionsFrame:StartSizing("BOTTOMRIGHT")
      end
    end)
    optionsFrame.resizeGrip:SetScript("OnMouseUp", function()
      optionsFrame:StopMovingOrSizing()
      SaveOptionsGeometry(optionsFrame)
    end)
    optionsFrame.resizeGrip.text = CreateFont(optionsFrame.resizeGrip, "///", 20, "CENTER", "OVERLAY", 9)
    optionsFrame.resizeGrip.text:SetAllPoints(optionsFrame.resizeGrip)
    optionsFrame.resizeGrip.text:SetJustifyH("CENTER")
  end

  PositionOptionsFrame(optionsFrame)
  ApplyOptionsFrameStyle()
  RefreshOptionsFrame()
  optionsFrame:Show()
  if optionsFrame.Raise then
    optionsFrame:Raise()
  else
    optionsFrame:SetFrameLevel((optionsFrame:GetFrameLevel() or 0) + 1)
  end
end

RefreshOptionsFrame = function()
  if not optionsFrame or refreshingOptions then
    return
  end
  refreshingOptions = true
  for _, control in ipairs(optionControls) do
    if control.kind == "check" then
      control.check:SetChecked(GetSetting(control.key) and true or false)
    elseif control.kind == "slider" then
      local value = GetSetting(control.key)
      control.slider:SetValue(value)
      control.value:SetText(control.formatter(value))
    elseif control.kind == "edit" then
      if control.key == "backgroundImagePath" then
        local backgroundPath = NormalizeTexturePath(GetSetting(control.key))
        control.edit:SetText(IsBaseBackgroundPath(backgroundPath) and "" or BackgroundFileName(backgroundPath))
      else
        control.edit:SetText(tostring(GetSetting(control.key) or ""))
      end
    elseif control.kind == "font" then
      control.value:SetText(GetFontChoiceName(GetSetting(control.key)))
    elseif control.kind == "sound" then
      local index, choices = GetSoundChoiceIndex(GetSetting(control.key))
      control.value:SetText(choices[index] and choices[index].name or "None")
    elseif control.kind == "background" then
      control.value:SetText(GetBackgroundChoiceName(GetSetting(control.key)))
    elseif control.kind == "backgroundAdd" then
      control.edit:SetText("")
    elseif control.kind == "mainSlider" then
      local value = GetMainChatOption(control.option, 0)
      control.slider:SetValue(value)
      control.value:SetText(control.formatter(value))
    elseif control.kind == "mainCheck" then
      control.check:SetChecked(GetMainChatOption(control.option, false) and true or false)
    elseif control.kind == "mainDropdown" then
      local current = control.getter and control.getter(control.key) or GetMainChatOption(control.key, "")
      local index, choices = control.getIndexAndChoices(current)
      control.value:SetText(choices[index] and choices[index].name or tostring(current))
    elseif control.kind == "mainFont" then
      control.value:SetText(GetMainChatFontChoiceName(GetMainChatOption(control.key, "default")))
    end
  end
  refreshingOptions = false
end

local function CreateWhisperWindow(key, kind, target, displayName, accountID, nameR, nameG, nameB, showWindow)
  local frame = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
  frame:SetFrameStrata("DIALOG")
  frame:SetClampedToScreen(false)
  frame:SetMovable(true)
  frame:SetResizable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  if frame.SetToplevel then
    frame:SetToplevel(true)
  end
  if frame.SetResizeBounds then
    frame:SetResizeBounds(MIN_WIDTH, MIN_HEIGHT, MAX_WIDTH, MAX_HEIGHT)
  end
  PositionWindow(frame)

  frame.windowKey = key
  frame.kind = kind
  frame.target = target
  frame.accountID = accountID
  frame.displayName = displayName or target or UNKNOWN or "Unknown"
  frame.inviteName = CleanInviteName(target)
  StoreNameColor(frame, nameR, nameG, nameB)

  frame.bgTexture = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
  frame.bgTexture:SetPoint("TOPLEFT", frame, "TOPLEFT", 3, -3)
  frame.bgTexture:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -3, 3)
  frame.bgTexture:SetTexture(GetBackgroundTexturePath())
  frame.bgTexture:SetTexCoord(0, 1, 0, 1)

  frame.bgShade = frame:CreateTexture(nil, "BACKGROUND", nil, -7)
  frame.bgShade:SetPoint("TOPLEFT", frame, "TOPLEFT", 3, -3)
  frame.bgShade:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -3, 3)

  local function StartMove()
    if not frame.isMoving and not frame.isSizing then
      frame.isMoving = true
      frame:StartMoving()
      TouchWindow(key)
    end
  end

  local function StopMove()
    if frame.isMoving then
      frame:StopMovingOrSizing()
      frame.isMoving = false
      SaveGeometry(frame)
    end
  end

  frame:SetScript("OnDragStart", StartMove)
  frame:SetScript("OnDragStop", StopMove)

  frame.header = CreateFrame("Frame", nil, frame, "BackdropTemplate")
  frame.header:SetFrameLevel(frame:GetFrameLevel() + 2)

  frame.headerGlow = frame.header:CreateTexture(nil, "ARTWORK", nil, 1)
  frame.headerGlow:SetPoint("TOPLEFT", frame.header, "TOPLEFT", 1, -1)
  frame.headerGlow:SetPoint("BOTTOMRIGHT", frame.header, "BOTTOMRIGHT", -1, 1)

  frame.headerLine = frame.header:CreateTexture(nil, "OVERLAY", nil, 3)
  frame.headerLine:SetPoint("BOTTOMLEFT", frame.header, "BOTTOMLEFT", 0, 0)
  frame.headerLine:SetPoint("BOTTOMRIGHT", frame.header, "BOTTOMRIGHT", 0, 0)
  frame.headerLine:SetHeight(2)

  frame.dragBar = CreateFrame("Button", nil, frame)
  frame.dragBar:SetFrameLevel(frame:GetFrameLevel() + 3)
  frame.dragBar:EnableMouse(true)
  frame.dragBar:RegisterForDrag("LeftButton")
  frame.dragBar:SetScript("OnDragStart", StartMove)
  frame.dragBar:SetScript("OnDragStop", StopMove)
  frame.dragBar:SetScript("OnMouseDown", function(_, button)
    if button == "LeftButton" then
      StartMove()
    end
  end)
  frame.dragBar:SetScript("OnMouseUp", StopMove)

  frame.title = CreateFont(frame.header, "", 20, "LEFT", "OVERLAY", 8)
  frame.title:SetJustifyV("MIDDLE")
  frame.title:SetShadowColor(0, 0, 0, 1)
  frame.title:SetShadowOffset(2, -2)
  if frame.title.SetWordWrap then
    frame.title:SetWordWrap(false)
  end

  -- Popout header utility buttons were removed; use the main Options button or minimap button instead.
  frame.optionsButton = nil
  frame.bottomButton = nil

  frame.inviteButton = CreateButton(frame, "Invite", 62, 28, function()
    InviteTarget(frame)
  end)
  frame.inviteButton:SetFrameLevel(frame:GetFrameLevel() + 7)

  frame.closeButton = CreateFrame("Button", nil, frame, "BackdropTemplate")
  frame.closeButton:SetFrameLevel(frame:GetFrameLevel() + 7)
  frame.closeButton.text = CreateFont(frame.closeButton, "×", 20, "CENTER", "OVERLAY", 8)
  frame.closeButton.text:SetAllPoints(frame.closeButton)
  frame.closeButton:SetScript("OnClick", function()
    frame:Hide()
  end)

  frame.copyLines = {}

  frame.copyButton = CreateButton(frame, "Copy", 56, 28, function()
    ToggleInlineCopyMode(frame)
  end)
  frame.copyButton:SetFrameLevel(frame:GetFrameLevel() + 7)

  frame.messages = CreateFrame("ScrollingMessageFrame", nil, frame)
  frame.messages:SetFontObject(ChatFontNormal)
  frame.messages:SetJustifyH("LEFT")
  frame.messages:SetFading(false)
  frame.messages:SetShadowColor(0, 0, 0, 1)
  frame.messages:SetShadowOffset(1.5, -1.5)
  if frame.messages.SetIndentedWordWrap then
    frame.messages:SetIndentedWordWrap(false)
  end
  frame.messages.ownerFrame = frame
  AddHyperlinkScripts(frame.messages)

  frame.inlineCopyBox = CreateFrame("Frame", nil, frame, "ScrollingEditBoxTemplate,BackdropTemplate")
  frame.inlineCopyBox:SetFrameLevel(frame:GetFrameLevel() + 5)
  frame.inlineCopyBox:Hide()
  frame.inlineCopyEdit = frame.inlineCopyBox:GetEditBox()
  frame.inlineCopyEdit:SetAutoFocus(false)
  frame.inlineCopyEdit:SetMultiLine(true)
  frame.inlineCopyEdit:SetTextInsets(8, 8, 8, 8)
  frame.inlineCopyEdit:SetScript("OnEscapePressed", function()
    ExitInlineCopyMode(frame)
  end)
  frame.inlineCopyEdit:SetScript("OnEditFocusGained", function(self)
    self:HighlightText(0, #(self:GetText() or ""))
  end)

  frame.input = CreateFrame("EditBox", nil, frame, "BackdropTemplate")
  frame.input:SetAutoFocus(false)
  frame.input:SetFontObject(ChatFontNormal)
  frame.input:SetTextInsets(8, 8, 0, 0)
  frame.input:SetMaxLetters(255)
  frame.input:SetScript("OnEscapePressed", function(self)
    self:ClearFocus()
  end)
  frame.input:SetScript("OnEditFocusGained", function(self)
    if frame.inputHint then
      frame.inputHint:Hide()
    end
  end)
  frame.input:SetScript("OnEditFocusLost", function(self)
    if frame.inputHint then
      frame.inputHint:SetShown((self:GetText() or "") == "")
    end
  end)
  frame.input:SetScript("OnTextChanged", function(self)
    if frame.inputHint then
      frame.inputHint:SetShown((self:GetText() or "") == "" and not self:HasFocus())
    end
  end)
  frame.inputHint = CreateFont(frame.input, "Type reply here...", 13, "LEFT", "OVERLAY", 4)
  frame.inputHint:SetPoint("LEFT", frame.input, "LEFT", 10, 0)
  frame.inputHint:SetPoint("RIGHT", frame.input, "RIGHT", -10, 0)
  frame.inputHint:SetJustifyH("LEFT")

  frame.sendButton = CreateButton(frame, "Send", 72, 34, nil)
  frame.sendButton:SetFrameLevel(frame:GetFrameLevel() + 4)

  local function Submit()
    local text = Trim(frame.input:GetText() or "")
    if text == "" then
      return
    end
    if frame.kind == "MOCK" then
      frame.input:SetText("")
      if frame.inputHint then frame.inputHint:SetShown(not frame.input:HasFocus()) end
      AddLine(frame, "out", text)
      return
    end

    local sent
    if frame.kind == "BN" then
      sent = SendBNWhisper(frame.accountID, text)
    else
      sent = SendPlayerWhisper(frame.target, text)
    end
    if sent then
      frame.input:SetText("")
      if frame.inputHint then frame.inputHint:SetShown(not frame.input:HasFocus()) end
      MarkLocalEcho(frame.windowKey, text)
      AddLine(frame, "out", text)
    end
  end

  frame.input:SetScript("OnEnterPressed", Submit)
  frame.sendButton:SetScript("OnClick", Submit)

  frame.grip = CreateFrame("Button", nil, frame)
  frame.grip:SetFrameLevel(frame:GetFrameLevel() + 8)
  frame.grip:EnableMouse(true)
  frame.grip:SetScript("OnMouseDown", function(_, button)
    if button == "LeftButton" and not frame.isSizing then
      frame.isSizing = true
      frame:StartSizing("BOTTOMRIGHT")
      TouchWindow(key)
    end
  end)
  frame.grip:SetScript("OnMouseUp", function()
    if frame.isSizing then
      frame:StopMovingOrSizing()
      frame.isSizing = false
      SaveGeometry(frame)
    end
  end)
  frame.gripText = CreateFont(frame.grip, "///", 20, "CENTER", "OVERLAY", 9)
  frame.gripText:SetAllPoints(frame.grip)
  frame.gripText:SetJustifyH("CENTER")

  LayoutWindow(frame)
  ApplyWindowStyle(frame)
  if showWindow == false then
    frame:Hide()
  else
    frame:Show()
  end
  return frame
end

local function GetWindow(kind, target, displayName, accountID, nameR, nameG, nameB, inviteName, senderGUID, showWindow)
  local key = MakeKey(kind, target, accountID)
  local frame = windows[key]
  if not frame then
    frame = CreateWhisperWindow(key, kind, target, displayName, accountID, nameR, nameG, nameB, showWindow)
    frame.senderGUID = senderGUID
    windows[key] = frame
  else
    frame.kind = kind
    frame.target = target or frame.target
    frame.accountID = accountID or frame.accountID
    frame.senderGUID = senderGUID or frame.senderGUID
    frame.displayName = displayName or frame.displayName
    StoreNameColor(frame, nameR, nameG, nameB)
  end
  if inviteName then
    frame.inviteName = inviteName
  elseif kind == "PLAYER" then
    frame.inviteName = CleanInviteName(target or frame.target)
  end
  LayoutWindow(frame)
  ApplyWindowStyle(frame)

  if showWindow == false then
    frame:Hide()
  else
    frame:Show()
    if frame.Raise then
      frame:Raise()
    else
      frame:SetFrameLevel((frame:GetFrameLevel() or 0) + 1)
    end
  end
  TouchWindow(key)
  lastKey = key
  HideOldestWindows()
  return frame
end

OpenMockWindow = function()
  local frame = GetWindow("MOCK", "preview", "Mock Whisper Preview")
  if not frame.mockSeeded then
    frame.messages:Clear()
    frame.copyLines = {}
    AddLine(frame, "in", "This is a mock incoming whisper preview.")
    AddLine(frame, "out", "Use this to test the name header, fonts, colors, sounds, and size.")
    AddLine(frame, "in", "Drag the header, resize the corner, or snap it to the bottom.")
    frame.mockSeeded = true
  end
  return frame
end

UpdateMockPreview = function()
  local key = MakeKey("MOCK", "preview")
  if windows[key] and not GetSetting("showMockWindow") then
    windows[key]:Hide()
  end
end

local function RaiseWindowByKey(key, focusInput)
  local frame = key and windows[key]
  if not frame then
    return false
  end

  LayoutWindow(frame)
  ApplyWindowStyle(frame)
  frame:Show()
  if frame.Raise then
    frame:Raise()
  else
    frame:SetFrameLevel((frame:GetFrameLevel() or 0) + 1)
  end
  TouchWindow(key)
  lastKey = key
  if focusInput and frame.input then
    frame.input:SetFocus()
  end
  return true
end

local function OpenLastOrMock()
  if lastKey and RaiseWindowByKey(lastKey, true) then
    return
  end
  OpenMockWindow()
end

local function GetSessionConversationKeys()
  local keys = {}
  local seen = {}

  for index = #windowOrder, 1, -1 do
    local key = windowOrder[index]
    local frame = windows[key]
    if frame and frame.kind ~= "MOCK" and not seen[key] then
      seen[key] = true
      table.insert(keys, key)
    end
  end

  for key, frame in pairs(windows) do
    if frame and frame.kind ~= "MOCK" and not seen[key] then
      seen[key] = true
      table.insert(keys, key)
    end
  end

  return keys
end

local function HideConversationMenu()
  if conversationMenu then
    conversationMenu:Hide()
  end
end

local function PositionConversationMenu(menu, owner)
  menu:ClearAllPoints()
  if owner and owner.GetCenter then
    menu:SetPoint("TOPRIGHT", owner, "BOTTOMLEFT", -4, -4)
    return
  end

  if GetCursorPosition then
    local scale = UIParent:GetEffectiveScale() or 1
    local cursorX, cursorY = GetCursorPosition()
    if cursorX and cursorY then
      menu:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", cursorX / scale, cursorY / scale)
      return
    end
  end

  menu:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
end

local function GetConversationMenuRow(menu, index)
  if not menu.rows then
    menu.rows = {}
  end

  if menu.rows[index] then
    return menu.rows[index]
  end

  local row = CreateFrame("Button", nil, menu, "BackdropTemplate")
  row:SetHeight(24)
  row:EnableMouse(true)
  row:RegisterForClicks("LeftButtonUp")
  row.text = CreateFont(row, "", 12, "LEFT", "OVERLAY", 4)
  row.text:SetPoint("LEFT", row, "LEFT", 9, 0)
  row.text:SetPoint("RIGHT", row, "RIGHT", -9, 0)
  row.text:SetTextColor(1, 1, 1, 1)
  row.text:SetWordWrap(false)
  row:SetScript("OnEnter", function(self)
    local ar, ag, ab = GetAccentColor()
    ApplyBackdrop(self, ar * 0.18, ag * 0.18, ab * 0.18, 0.96, ar, ag, ab, 1, 1)
  end)
  row:SetScript("OnLeave", function(self)
    ApplyBackdrop(self, 0.018, 0.018, 0.024, 0.96, 0.30, 0.25, 0.38, 1, 1)
  end)

  menu.rows[index] = row
  return row
end

local function CreateConversationMenu()
  if conversationMenu then
    return conversationMenu
  end

  conversationMenu = CreateFrame("Frame", "ChayChatConversationMenu", UIParent, "BackdropTemplate")
  conversationMenu:SetFrameStrata("TOOLTIP")
  conversationMenu:SetFrameLevel(1000)
  conversationMenu:EnableMouse(true)
  conversationMenu:SetClampedToScreen(true)
  conversationMenu.rows = {}

  conversationMenu.title = CreateFont(conversationMenu, "Session Whispers", 14, "LEFT", "OVERLAY", 5)
  conversationMenu.title:SetPoint("TOPLEFT", conversationMenu, "TOPLEFT", 10, -9)
  conversationMenu.title:SetPoint("RIGHT", conversationMenu, "RIGHT", -34, 0)
  conversationMenu.title:SetTextColor(1, 1, 1, 1)
  conversationMenu.title:SetFont(GetNormalFont(), 14, "OUTLINE")

  conversationMenu.close = CreateFrame("Button", nil, conversationMenu, "BackdropTemplate")
  conversationMenu.close:SetPoint("TOPRIGHT", conversationMenu, "TOPRIGHT", -6, -6)
  conversationMenu.close:SetSize(24, 22)
  conversationMenu.close.text = CreateFont(conversationMenu.close, "×", 18, "CENTER", "OVERLAY", 6)
  conversationMenu.close.text:SetAllPoints(conversationMenu.close)
  conversationMenu.close.text:SetTextColor(1, 0.22, 0.22, 1)
  conversationMenu.close:SetScript("OnClick", HideConversationMenu)

  conversationMenu:Hide()
  return conversationMenu
end

ShowConversationMenu = function(owner)
  local menu = CreateConversationMenu()
  if menu:IsShown() then
    menu:Hide()
    return
  end

  local ar, ag, ab = GetAccentColor()
  ApplyBackdrop(menu, 0.010, 0.010, 0.015, 0.98, ar, ag, ab, 1, 2)
  ApplyBackdrop(menu.close, ar * 0.18, ag * 0.18, ab * 0.18, 0.96, ar, ag, ab, 1, 1)

  local keys = GetSessionConversationKeys()
  local rowIndex = 0

  for _, row in ipairs(menu.rows) do
    row:Hide()
  end

  if #keys == 0 then
    rowIndex = rowIndex + 1
    local row = GetConversationMenuRow(menu, rowIndex)
    row:SetPoint("TOPLEFT", menu, "TOPLEFT", 8, -38)
    row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -8, -38)
    row.text:SetText("No session whispers yet")
    row.text:SetTextColor(0.78, 0.78, 0.78, 1)
    row:SetScript("OnClick", nil)
    row:EnableMouse(false)
    ApplyBackdrop(row, 0.018, 0.018, 0.024, 0.80, 0.30, 0.25, 0.38, 0.65, 1)
    row:Show()
  else
    for _, key in ipairs(keys) do
      local frame = windows[key]
      if frame then
        rowIndex = rowIndex + 1
        local row = GetConversationMenuRow(menu, rowIndex)
        row:SetPoint("TOPLEFT", menu, "TOPLEFT", 8, -38 - ((rowIndex - 1) * 27))
        row:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -8, -38 - ((rowIndex - 1) * 27))
        row:EnableMouse(true)
        local cr, cg, cb = GetFrameNameColor(frame)
        row.text:SetText(tostring(frame.displayName or frame.target or "Whisper"))
        row.text:SetTextColor(cr, cg, cb, 1)
        row:SetScript("OnClick", function()
          HideConversationMenu()
          RaiseWindowByKey(key, true)
        end)
        ApplyBackdrop(row, 0.018, 0.018, 0.024, 0.96, 0.30, 0.25, 0.38, 1, 1)
        row:Show()
      end
    end
  end

  local mockRow = GetConversationMenuRow(menu, rowIndex + 1)
  mockRow:SetPoint("TOPLEFT", menu, "TOPLEFT", 8, -38 - (rowIndex * 27) - 6)
  mockRow:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -8, -38 - (rowIndex * 27) - 6)
  mockRow:EnableMouse(true)
  mockRow.text:SetText("Mock preview")
  mockRow.text:SetTextColor(0.83, 0.73, 1, 1)
  mockRow:SetScript("OnClick", function()
    HideConversationMenu()
    OpenMockWindow()
  end)
  ApplyBackdrop(mockRow, 0.018, 0.018, 0.024, 0.96, 0.30, 0.25, 0.38, 1, 1)
  mockRow:Show()

  local optionsRow = GetConversationMenuRow(menu, rowIndex + 2)
  optionsRow:SetPoint("TOPLEFT", menu, "TOPLEFT", 8, -38 - ((rowIndex + 1) * 27) - 6)
  optionsRow:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -8, -38 - ((rowIndex + 1) * 27) - 6)
  optionsRow:EnableMouse(true)
  optionsRow.text:SetText("Options")
  optionsRow.text:SetTextColor(0.83, 0.73, 1, 1)
  optionsRow:SetScript("OnClick", function()
    HideConversationMenu()
    ShowOptionsFrame()
  end)
  ApplyBackdrop(optionsRow, 0.018, 0.018, 0.024, 0.96, 0.30, 0.25, 0.38, 1, 1)
  optionsRow:Show()

  local menuHeight = 52 + ((rowIndex + 2) * 27) + 8
  menu:SetSize(250, Clamp(menuHeight, 112, 340))
  PositionConversationMenu(menu, owner)
  menu:Show()
end

local function EnsureBrokerDB()
  local db = EnsureDB()
  if type(db.minimap) ~= "table" then
    db.minimap = {}
  end
  db.minimap.hide = not GetSetting("showMinimapButton")
  if type(db.minimap.minimapPos) ~= "number" then
    db.minimap.minimapPos = tonumber(GetSetting("minimapAngle")) or 225
  end
  return db.minimap
end

local function CreateBrokerLauncher()
  if not LibStub then
    return nil
  end
  local okLDB, LDB = pcall(LibStub, "LibDataBroker-1.1", true)
  if not okLDB or not LDB or not LDB.NewDataObject then
    return nil
  end
  if not ldbObject then
    ldbObject = LDB:NewDataObject("ChayChat", {
      type = "launcher",
      text = "ChayChat",
      label = "ChayChat",
      icon = "Interface\\AddOns\\ChayChat\\Assets\\Logo.png",
      OnClick = function(_, button)
        if button == "RightButton" then
          ShowConversationMenu()
        else
          ShowOptionsFrame()
        end
      end,
      OnTooltipShow = function(tooltip)
        if tooltip and tooltip.AddLine then
          tooltip:AddLine("ChayChat")
          tooltip:AddLine("Left-click: Options", 0.8, 0.8, 0.8)
          tooltip:AddLine("Right-click: Session whispers", 0.8, 0.8, 0.8)
        end
      end,
    })
  end

  local okIcon, icon = pcall(LibStub, "LibDBIcon-1.0", true)
  if okIcon and icon and icon.Register then
    local brokerDB = EnsureBrokerDB()
    if not usingBrokerButton then
      pcall(icon.Register, icon, "ChayChat", ldbObject, brokerDB)
      usingBrokerButton = true
    elseif icon.Refresh then
      pcall(icon.Refresh, icon, "ChayChat", brokerDB)
    end
    ldbIcon = icon
    return true
  end
  return false
end

local function GetMinimapAngleFromCursor()
  if not Minimap or not GetCursorPosition then
    return tonumber(GetSetting("minimapAngle")) or 225
  end
  local scale = Minimap:GetEffectiveScale() or 1
  local cursorX, cursorY = GetCursorPosition()
  local centerX, centerY = Minimap:GetCenter()
  if not cursorX or not cursorY or not centerX or not centerY then
    return tonumber(GetSetting("minimapAngle")) or 225
  end
  cursorX = cursorX / scale
  cursorY = cursorY / scale
  local x = cursorX - centerX
  local y = cursorY - centerY
  local angle = math.deg(math.atan2 and math.atan2(y, x) or math.atan(y / (x == 0 and 0.0001 or x)))
  if x < 0 and not math.atan2 then
    angle = angle + 180
  elseif y < 0 and not math.atan2 then
    angle = angle + 360
  end
  return angle
end

local function PositionMinimapButton()
  if not minimapButton then
    return
  end
  if not GetSetting("showMinimapButton") or not Minimap then
    minimapButton:Hide()
    return
  end

  -- If ElvUI/ProjectAzilroka/MBB has collected the button into its own holder,
  -- do not fight that bar by re-anchoring back to the Minimap.
  if minimapButton:GetParent() ~= Minimap then
    minimapButton:Show()
    return
  end

  local angle = math.rad(tonumber(GetSetting("minimapAngle")) or 225)
  local radius = 82
  local x = math.cos(angle) * radius
  local y = math.sin(angle) * radius
  minimapButton:ClearAllPoints()
  minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
  minimapButton:Show()
end

local function UpdateMinimapButtonStyle()
  if not minimapButton then
    return
  end
  local ar, ag, ab = GetAccentColor()
  local lr, lg, lb = Lighten(ar, ag, ab, 0.40)
  ApplyBackdrop(minimapButton, 0.01, 0.01, 0.014, 0.96, ar, ag, ab, 1)
  if minimapButton.icon then
    minimapButton.icon:SetAlpha(1)
  end
  minimapButton.text:SetTextColor(lr, lg, lb, 1)
end

local function CreateMinimapButton()
  if minimapButton or not Minimap then
    return
  end
  minimapButton = CreateFrame("Button", "LibDBIcon10_ChayChat", Minimap, "BackdropTemplate")
  _G.ChayChatMinimapButton = minimapButton
  minimapButton.isLibDBIcon = true
  minimapButton.db = EnsureDB().minimap or {}
  minimapButton:SetSize(32, 32)
  minimapButton:SetFrameStrata("MEDIUM")
  minimapButton:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 10)
  minimapButton:EnableMouse(true)
  minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  minimapButton:RegisterForDrag("LeftButton")
  minimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  minimapButton.icon = minimapButton:CreateTexture(nil, "ARTWORK")
  minimapButton.icon:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 3, -3)
  minimapButton.icon:SetPoint("BOTTOMRIGHT", minimapButton, "BOTTOMRIGHT", -3, 3)
  minimapButton.icon:SetTexture(DRAGON_BACKGROUND)
  minimapButton.icon:SetTexCoord(0.34, 0.66, 0.18, 0.50)

  minimapButton.text = CreateFont(minimapButton, "", 15, "CENTER", "OVERLAY", 3)
  minimapButton.text:SetAllPoints(minimapButton)
  minimapButton.text:SetFont(GetNormalFont(), 15, "OUTLINE")

  minimapButton:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine("ChayChat")
      GameTooltip:AddLine("Left-click: Options", 0.8, 0.8, 0.8)
      GameTooltip:AddLine("Right-click: Session whispers", 0.8, 0.8, 0.8)
      GameTooltip:AddLine("Drag: Move button", 0.8, 0.8, 0.8)
      GameTooltip:Show()
    end
  end)
  minimapButton:SetScript("OnLeave", function()
    if GameTooltip then
      GameTooltip:Hide()
    end
  end)
  minimapButton:SetScript("OnDragStart", function(self)
    if self:GetParent() ~= Minimap then
      return
    end
    self.dragSuppressUntil = Now() + 0.25
    self:SetScript("OnUpdate", function(inner)
      SetSetting("minimapAngle", GetMinimapAngleFromCursor())
      PositionMinimapButton()
      inner.dragSuppressUntil = Now() + 0.25
    end)
  end)
  minimapButton:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
    if self:GetParent() == Minimap then
      SetSetting("minimapAngle", GetMinimapAngleFromCursor())
      PositionMinimapButton()
    end
    self.dragSuppressUntil = Now() + 0.25
  end)
  minimapButton:SetScript("OnClick", function(self, button)
    if self.dragSuppressUntil and Now() <= self.dragSuppressUntil then
      return
    end
    if button == "RightButton" then
      ShowConversationMenu(self)
    else
      ShowOptionsFrame()
    end
  end)
  UpdateMinimapButtonStyle()
  PositionMinimapButton()
end

RefreshMinimapButton = function()
  local hasBroker = CreateBrokerLauncher()
  if hasBroker and ldbIcon then
    local brokerDB = EnsureBrokerDB()
    if GetSetting("showMinimapButton") then
      brokerDB.hide = false
      if ldbIcon.Show then pcall(ldbIcon.Show, ldbIcon, "ChayChat") end
    else
      brokerDB.hide = true
      if ldbIcon.Hide then pcall(ldbIcon.Hide, ldbIcon, "ChayChat") end
    end
    if minimapButton and minimapButton:GetName() ~= "LibDBIcon10_ChayChat" then
      minimapButton:Hide()
    end
    return
  end

  if not minimapButton then
    CreateMinimapButton()
  end
  UpdateMinimapButtonStyle()
  PositionMinimapButton()
end

local function PositionChatFrameButton()
  if not chatFrameButton then
    return
  end
  local chatFrame = DEFAULT_CHAT_FRAME or _G.ChatFrame1
  if not GetSetting("showChatFrameButton") or not chatFrame then
    chatFrameButton:Hide()
    return
  end
  chatFrameButton:ClearAllPoints()
  chatFrameButton:SetPoint("BOTTOMLEFT", chatFrame, "TOPLEFT", 4, 4)
  chatFrameButton:Show()
end

local function UpdateChatFrameButtonStyle()
  if not chatFrameButton then
    return
  end
  local ar, ag, ab = GetAccentColor()
  local lr, lg, lb = Lighten(ar, ag, ab, 0.45)
  ApplyBackdrop(chatFrameButton, 0.01, 0.01, 0.014, 0.96, ar, ag, ab, 1)
  chatFrameButton.text:SetTextColor(lr, lg, lb, 1)
end

local function CreateChatFrameButton()
  if chatFrameButton then
    return
  end
  local chatFrame = DEFAULT_CHAT_FRAME or _G.ChatFrame1
  if not chatFrame then
    return
  end

  chatFrameButton = CreateFrame("Button", "ChayChatMainChatButton", UIParent, "BackdropTemplate")
  chatFrameButton:SetSize(34, 24)
  chatFrameButton:SetFrameStrata("DIALOG")
  chatFrameButton:SetFrameLevel((chatFrame:GetFrameLevel() or 0) + 20)
  chatFrameButton:EnableMouse(true)
  chatFrameButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  chatFrameButton.text = CreateFont(chatFrameButton, "C", 14, "CENTER", "OVERLAY", 3)
  chatFrameButton.text:SetAllPoints(chatFrameButton)
  chatFrameButton.text:SetFont(GetNormalFont(), 14, "OUTLINE")

  chatFrameButton:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_TOP")
      GameTooltip:AddLine("ChayChat")
      GameTooltip:AddLine("Left-click: Options", 0.8, 0.8, 0.8)
      GameTooltip:AddLine("Right-click: Mock preview", 0.8, 0.8, 0.8)
      GameTooltip:Show()
    end
  end)
  chatFrameButton:SetScript("OnLeave", function()
    if GameTooltip then
      GameTooltip:Hide()
    end
  end)
  chatFrameButton:SetScript("OnClick", function()
    ShowOptionsFrame()
  end)

  UpdateChatFrameButtonStyle()
  PositionChatFrameButton()
end

RefreshChatFrameButton = function()
  if chatFrameButton then
    chatFrameButton:Hide()
  end
end


local function FindBattleNetAccountID(...)
  if not C_BattleNet or not C_BattleNet.GetAccountInfoByID then
    return nil
  end
  for index = 1, select("#", ...) do
    local value = SafeNumber(select(index, ...))
    if value then
      local ok, accountInfo = pcall(C_BattleNet.GetAccountInfoByID, value)
      if ok and type(accountInfo) == "table" then
        return value
      end
    end
  end
  return nil
end

local function HandleWhisper(event, ...)
  local message = SafeText(select(1, ...))
  if not message then
    return
  end

  local sender = SafeText(select(2, ...))
  local secondaryName = SafeText(select(5, ...))
  local senderGUID = SafeText(select(12, ...))
  local lineID = SafeNumber(select(11, ...))
  local accountID = SafeNumber(select(13, ...))
  if (event == "CHAT_MSG_BN_WHISPER" or event == "CHAT_MSG_BN_WHISPER_INFORM") and not accountID then
    accountID = FindBattleNetAccountID(...)
  end

  if event == "CHAT_MSG_WHISPER" then
    if not sender then
      return
    end
    local cr, cg, cb = GetClassRGBFromGUID(senderGUID)
    local frame = GetWindow("PLAYER", sender, DisplayName(sender), nil, cr, cg, cb, CleanInviteName(sender))
    AddLine(frame, "in", message, lineID)
    PlaySelectedSound()
  elseif event == "CHAT_MSG_WHISPER_INFORM" then
    if not sender then
      return
    end
    local key = MakeKey("PLAYER", sender)
    if SkipLocalEcho(key, message) then
      return
    end
    local cr, cg, cb = GetClassRGBFromGUID(senderGUID)
    local frame = windows[key] or GetWindow("PLAYER", sender, DisplayName(sender), nil, cr, cg, cb, CleanInviteName(sender), senderGUID, false)
    if frame then
      StoreNameColor(frame, cr, cg, cb)
      ApplyWindowStyle(frame)
      AddLine(frame, "out", message, lineID)
    end
  elseif event == "CHAT_MSG_BN_WHISPER" then
    if not sender and not accountID then
      return
    end
    local display, gameInfo = ResolveBattleNetDisplayName(sender, accountID, senderGUID, secondaryName)
    local cr, cg, cb = GetClassRGBFromBattleNetAccount(accountID, senderGUID)
    local inviteName = GetInviteNameFromGameInfo(gameInfo) or ResolveBattleNetInviteName(accountID, senderGUID, display, nil)
    local frame = GetWindow("BN", sender, display, accountID, cr, cg, cb, inviteName, senderGUID)
    AddLine(frame, "in", message, lineID)
    if C_Timer and C_Timer.After and (IsGenericBattleNetName(display) or tostring(display or ""):match("^BNet Friend")) then
      C_Timer.After(0.5, function()
        if frame and frame:IsShown() then
          local newDisplay, newGameInfo = ResolveBattleNetDisplayName(sender, accountID, senderGUID, secondaryName)
          frame.displayName = newDisplay
          frame.senderGUID = senderGUID or frame.senderGUID
          frame.inviteName = GetInviteNameFromGameInfo(newGameInfo) or ResolveBattleNetInviteName(accountID, senderGUID, newDisplay, frame.inviteName) or frame.inviteName
          StoreNameColor(frame, GetClassRGBFromBattleNetAccount(accountID, senderGUID))
          LayoutWindow(frame)
          ApplyWindowStyle(frame)
        end
      end)
    end
    PlaySelectedSound()
  elseif event == "CHAT_MSG_BN_WHISPER_INFORM" then
    if not sender and not accountID then
      return
    end
    local key = MakeKey("BN", sender, accountID)
    if SkipLocalEcho(key, message) then
      return
    end
    local newDisplay, newGameInfo = ResolveBattleNetDisplayName(sender, accountID, senderGUID, secondaryName)
    local cr, cg, cb = GetClassRGBFromBattleNetAccount(accountID, senderGUID)
    local inviteName = GetInviteNameFromGameInfo(newGameInfo) or ResolveBattleNetInviteName(accountID, senderGUID, newDisplay, nil)
    local frame = windows[key] or GetWindow("BN", sender, newDisplay, accountID, cr, cg, cb, inviteName, senderGUID, false)
    if frame then
      frame.displayName = newDisplay
      frame.senderGUID = senderGUID or frame.senderGUID
      frame.inviteName = GetInviteNameFromGameInfo(newGameInfo) or ResolveBattleNetInviteName(accountID, senderGUID, newDisplay, frame.inviteName) or frame.inviteName
      StoreNameColor(frame, cr, cg, cb)
      LayoutWindow(frame)
      ApplyWindowStyle(frame)
      AddLine(frame, "out", message, lineID)
    end
  end
end

local function ClearSessionMessages()
  for _, frame in pairs(windows) do
    if frame.messages then
      frame.messages:Clear()
    end
    frame.copyLines = {}
  end
  collectgarbage("collect")
end

local function Initialize()
  EnsureDB()
  SetSetting("showMockWindow", false)
  SetSetting("showChatFrameButton", false)
  SetSetting("useClassAccent", true)
  SetSetting("timestamps", false)
  ApplyNoFadeSetting()
  SetSetting("textR", 0.98)
  SetSetting("textG", 0.96)
  SetSetting("textB", 0.88)
  SetSetting("soundChannel", "Master")
  if GetSetting("soundChoice") == "Chay Ping" or GetSetting("soundChoice") == nil then
    SetSetting("soundChoice", "Chay Ping - Loud")
  elseif GetSetting("soundChoice") == "Chay Chime" then
    SetSetting("soundChoice", "Chay Chime - Loud")
  elseif GetSetting("soundChoice") == "Chay Soft" then
    SetSetting("soundChoice", "Chay Soft - Loud")
  end
  SetSetting("optionsImageAlpha", FIXED_OPTIONS_IMAGE_ALPHA)
  SetSetting("optionsDarkOverlay", FIXED_OPTIONS_DARK_OVERLAY)
  PruneCustomBackgroundFiles()
  local currentBackground = NormalizeTexturePath(GetSetting("backgroundImagePath"))
  if IsBaseBackgroundPath(currentBackground) and currentBackground ~= DRAGON_BACKGROUND then
    SetSetting("backgroundImagePath", DRAGON_BACKGROUND)
  elseif IsSupportedBackgroundFile(currentBackground) then
    AddCustomBackgroundPath(currentBackground)
  else
    SetSetting("backgroundImagePath", DRAGON_BACKGROUND)
  end
  if (tonumber(GetSetting("backgroundLevel")) or 0) < 0.08 then
    SetSetting("backgroundLevel", 0.110)
  end
  if (tonumber(GetSetting("windowAlpha")) or 1) > 0.90 then
    SetSetting("windowAlpha", 0.82)
  end
  if initialized then
    RefreshMinimapButton()
    RefreshChatFrameButton()
    return
  end
  initialized = true
  RefreshMinimapButton()
  RefreshChatFrameButton()
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("CHAT_MSG_WHISPER")
eventFrame:RegisterEvent("CHAT_MSG_WHISPER_INFORM")
eventFrame:RegisterEvent("CHAT_MSG_BN_WHISPER")
eventFrame:RegisterEvent("CHAT_MSG_BN_WHISPER_INFORM")
eventFrame:SetScript("OnEvent", function(_, event, ...)
  if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
    Initialize()
    return
  end
  HandleWhisper(event, ...)
end)

if C_Timer and C_Timer.After then
  C_Timer.After(1, Initialize)
end

_G.ChayChat = _G.ChayChat or {}
_G.ChayChat.ShowWhisperOptions = ShowOptionsFrame
_G.ChayChat.ShowWhisperOptions = ShowOptionsFrame
_G.ChayChat.OpenMockWindow = OpenMockWindow
_G.ChayChat.ShowSessionWhispers = ShowConversationMenu
_G.ChayChat.ClearSessionMessages = ClearSessionMessages
_G.ChayChat.RefreshMinimapButton = RefreshMinimapButton
_G.ChayChat.RefreshChatFrameButton = RefreshChatFrameButton

-- Bridge for the full ChayChat main chat button row.
if type(addonTable) == "table" then
  addonTable.ChayWhisperPopout = addonTable.ChayWhisperPopout or {}
  addonTable.ChayWhisperPopout.ShowOptions = ShowOptionsFrame
  addonTable.ChayWhisperPopout.OpenMockWindow = OpenMockWindow
  addonTable.ChayWhisperPopout.ShowSessionWhispers = ShowConversationMenu
  addonTable.ChayWhisperPopout.ClearSessionMessages = ClearSessionMessages
end

SLASH_CHAYCHATPOPOUT1 = "/chaypop"
SLASH_CHAYCHATPOPOUT2 = "/cpop"
SlashCmdList.CHAYCHATPOPOUT = function(input)
  input = Trim(input or "")
  local lower = string.lower(input)

  if input == "" or lower == "options" or lower == "option" or lower == "config" then
    ShowOptionsFrame()
    return
  end

  if lower == "test" then
    local frame = GetWindow("PLAYER", UnitName("player") or "Chay", "Test Whisper")
    AddLine(frame, "in", "ChayChat test message. Incoming whispers will open here.")
    AddLine(frame, "out", "Use /chaypop options, /chaypop mock, or the minimap button.")
    frame.input:SetFocus()
    return
  end

  if lower == "mock" or lower == "preview" then
    OpenMockWindow()
    return
  end

  if lower == "mock off" or lower == "preview off" then
    SetSetting("showMockWindow", false)
    local key = MakeKey("MOCK", "preview")
    if windows[key] then windows[key]:Hide() end
    RefreshOptionsFrame()
    return
  end

  if lower == "bottom" then
    if lastKey and windows[lastKey] then
      SnapWindowToBottom(windows[lastKey])
    else
      print(PREFIX .. "No whisper popout is open yet.")
    end
    return
  end


  if lower == "conversations" or lower == "conversation" or lower == "whispers" or lower == "sessions" or lower == "session" then
    ShowConversationMenu()
    return
  end

  if lower == "minimap" then
    SetSetting("showMinimapButton", not GetSetting("showMinimapButton"))
    RefreshMinimapButton()
    print(PREFIX .. "Minimap button " .. (GetSetting("showMinimapButton") and "shown." or "hidden."))
    return
  end

  if lower == "minimap reset" then
    SetSetting("showMinimapButton", true)
    SetSetting("minimapAngle", 225)
    RefreshMinimapButton()
    print(PREFIX .. "Minimap button reset.")
    return
  end

  if lower == "chatbutton" or lower == "mainbutton" then
    SetSetting("showChatFrameButton", false)
    RefreshChatFrameButton()
    print(PREFIX .. "The separate C button above chat is removed. Use the normal top settings button or minimap button.")
    return
  end

  if lower == "clear" then
    ClearSessionMessages()
    print(PREFIX .. "Session popout messages cleared.")
    return
  end

  if lower == "sound" then
    PlaySelectedSound()
    return
  end

  if lower == "reset" then
    ResetSettings()
    SetSetting("showChatFrameButton", false)
    SetSetting("showMockWindow", false)
    SetSetting("useClassAccent", true)
    for _, frame in pairs(windows) do
      frame:SetSize(DEFAULT_WIDTH, DEFAULT_HEIGHT)
      frame:ClearAllPoints()
      frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
    ApplyAllWindows()
    RefreshMinimapButton()
    RefreshOptionsFrame()
    print(PREFIX .. "Settings reset.")
    return
  end

  local frame = GetWindow("PLAYER", input, DisplayName(input))
  frame.input:SetFocus()
end
