---@class addonTableChayChat
local addonTable = select(2, ...)

local function DisableCombatLog(chatFrame)
  ChatFrame2:SetParent(addonTable.hiddenFrame)
  chatFrame.ScrollingMessages:Show()
end

local function RenameTab(windowIndex, tabIndex, newName)
  local windowData = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[windowIndex]
  if not windowData then
    return
  end
  local tabData = windowData.tabs[tabIndex]
  if not tabData then
    return
  end

  tabData.name = newName
  addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
end

addonTable.Display.TabsBarMixin = {}

function addonTable.Display.TabsBarMixin:OnLoad()
  self.chatFrame = self:GetParent()
  self:SetupPool()
  self.customHolders = {}

  self:SetScript("OnEvent", self.OnEvent)

  addonTable.CallbackRegistry:RegisterCallback("SkinLoaded", function()
    self:PositionTabs()
  end)

  self.active = false

  self.fadeInterpolator = CreateInterpolator(InterpolatorUtil.InterpolateEaseIn)

  self.dropdownTabs = {}
end

function addonTable.Display.TabsBarMixin:Reset()
  self.Tabs = {}
end

function addonTable.Display.TabsBarMixin:PositionTabs()
  self.dropdownTabs = {}
  local xOffset = 0
  for _, tab in ipairs(self.Tabs or {}) do
    if tab ~= self.dropdownTabButton then
      tab:SetPoint("BOTTOMLEFT", self, "TOPLEFT", xOffset, -22)
      xOffset = xOffset + tab:GetWidth() + addonTable.Constants.TabSpacing
    end
  end
  if not addonTable.Config.Get(addonTable.Config.Options.FORCE_TAB_OVERFLOW) and xOffset - addonTable.Constants.TabSpacing > self.chatFrame:GetWidth() then
    local index = #self.Tabs - 1
    while index >= 1 and xOffset + self.dropdownTabButton:GetWidth() > self.chatFrame:GetWidth() do
      local tab = self.Tabs[index]
      if not tab then
        break
      end
      xOffset = xOffset - tab:GetWidth() - addonTable.Constants.TabSpacing
      tab:Hide()
      table.insert(self.dropdownTabs, 1, tab)
      index = index - 1
    end
    self.tabsEnd = math.max(1, #self.Tabs - 1)
    self.dropdownTabButton:SetPoint("BOTTOMLEFT", self, "TOPLEFT", math.max(0, xOffset), -22)
    self.dropdownTabButton:SetShown(#self.dropdownTabs > 0)
  else
    self.dropdownTabButton:Hide()
    self.tabsEnd = #self.Tabs - 1
  end
end

function addonTable.Display.TabsBarMixin:StartDragging(index)
  local origin = GetCursorPosition() / UIParent:GetEffectiveScale()
  local prevLeft = self.Tabs[index]:GetLeft()
  self.dragIndex = index
  self:RegisterEvent("GLOBAL_MOUSE_UP")
  local rightLimit = self.Tabs[self.tabsEnd]:GetRight() + 1
  local leftLimit = self.Tabs[1]:GetLeft()

  self:SetScript("OnUpdate", function()
    local dragButton = self.Tabs[index]
    dragButton:SetFrameStrata("HIGH") -- Ensure dragged tab renders above all other tabs, avoids weird overlap artifacts

    local newOrigin = GetCursorPosition() / UIParent:GetEffectiveScale()
    local goingLeft = newOrigin < origin
    local goingRight = newOrigin > origin
    dragButton:AdjustPointsOffset(newOrigin - origin, 0)
    if dragButton:GetLeft() < leftLimit then
      dragButton:AdjustPointsOffset(leftLimit - dragButton:GetLeft(), 0)
    elseif dragButton:GetRight() > rightLimit then
      dragButton:AdjustPointsOffset(rightLimit - dragButton:GetRight(), 0)
    else
      origin = newOrigin
    end

    prevLeft = dragButton:GetLeft()

    local allTabsData = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[self.chatFrame:GetID()].tabs
    -- Check if the tab overlaps the tab to the left, and is at least 40% overlapping, and has been recently dragged left
    if index > 1 and dragButton:GetLeft() < self.Tabs[index - 1]:GetLeft() + self.Tabs[index - 1]:GetWidth() - dragButton:GetWidth() * 0.4 and goingLeft then
      dragButton:SetFrameStrata("MEDIUM") -- Revert strata change
      local old = allTabsData[index]
      allTabsData[index] = allTabsData[index - 1]
      allTabsData[index - 1] = old
      if self.chatFrame.tabIndex == index then
        self.chatFrame.tabIndex = index - 1
      elseif self.chatFrame.tabIndex == index - 1 then
        self.chatFrame.tabIndex = index
      end
      index = index - 1
      addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
    -- Check if the tab overlaps the tab to the right, and is at least 40% overlapping, and has been recently dragged right
    elseif index < #self.Tabs and self.Tabs[index + 1].isDraggable and self.Tabs[index + 1]:GetLeft() + dragButton:GetWidth() * 0.4 < dragButton:GetLeft() + dragButton:GetWidth() and goingRight then
      dragButton:SetFrameStrata("MEDIUM") -- Revert strata change
      local old = allTabsData[index]
      allTabsData[index] = allTabsData[index + 1]
      allTabsData[index + 1] = old
      if self.chatFrame.tabIndex == index then
        self.chatFrame.tabIndex = index + 1
      elseif self.chatFrame.tabIndex == index + 1 then
        self.chatFrame.tabIndex = index
      end
      index = index + 1
      addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
    end

    self.dragIndex = index

    local dragButton = self.Tabs[index]
    if math.abs(dragButton:GetLeft() - prevLeft) > 0.05 then
      dragButton:AdjustPointsOffset(prevLeft - dragButton:GetLeft(), 0)
    end

    dragButton:SetFrameStrata("HIGH")
  end)
end

function addonTable.Display.TabsBarMixin:EndDragging(index)
  self.Tabs[self.dragIndex]:SetFrameStrata("MEDIUM")
  self:UnregisterEvent("GLOBAL_MOUSE_UP")
  self:SetScript("OnUpdate", nil)
  self:PositionTabs()
end

function addonTable.Display.TabsBarMixin:OnEvent()
  self:EndDragging()
end

function addonTable.Display.TabsBarMixin:SetupPool()
  self.tabsPool = CreateFramePool("Button", self, nil, nil, false,
    function(tabButton)
      tabButton:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
      tabButton:RegisterForDrag("LeftButton", "RightButton")
      tabButton:SetScript("OnDragStart", function(_, button)
        if addonTable.Config.Get(addonTable.Config.Options.LOCKED) then
          return
        end
        if tabButton:GetID() == 1 and button == "LeftButton" then
          self.chatFrame:StartMoving()
        elseif tabButton.isDraggable then
          self:StartDragging(tabButton:GetID())
        end
      end)
      tabButton:SetScript("OnDragStop", function()
        self.chatFrame:StopMovingOrSizing()
        self.chatFrame:SavePosition()
      end)
      function tabButton:SetSelected(state)
        self:SetFlashing(false)
        self.selected = state
      end
      function tabButton:SetColor(r, g, b)
        self.color = {r = r, g = g, b = b}
      end
      function tabButton:GetColor()
        return self.color.r, self.color.g, self.color.b
      end
      function tabButton:SetFlashing(state)
        self.flashing = state
      end
      addonTable.Skins.AddFrame("ChatTab", tabButton)
    end
  )
end

function addonTable.Display.TabsBarMixin:ApplyFlashing(newMessages)
  if not newMessages then
    return
  end
  local state = addonTable.Config.Get(addonTable.Config.Options.TAB_FLASH_ON)
  local messages = {}
  if state == "whispers" then
    while newMessages > 0 do
      newMessages = newMessages - 1
      local data = addonTable.Messages:GetMessageRaw(1 + #messages)
      if data and (data.typeInfo.type == "WHISPER" or data.typeInfo.type == "BN_WHISPER") and (not data.typeInfo.event or not data.typeInfo.event:match("_INFORM$")) then
        table.insert(messages, data)
      end
    end
    if #messages == 0 then
      return
    end
  elseif state == "all" then
    while newMessages > 0 do
      newMessages = newMessages - 1
      local data = addonTable.Messages:GetMessageRaw(1 + #messages)
      if data and (not data.typeInfo.event or not data.typeInfo.event:match("_INFORM$")) then
        table.insert(messages, data)
      end
    end
  else
    return
  end
  local tabsMatching = {}
  for index, tab in ipairs(self.Tabs) do
    if tab.filter and FindInTableIf(messages, tab.filter) ~= nil then
      tabsMatching[index] = true
    end
  end

  if state ~= "whispers" and tabsMatching[self.chatFrame.tabIndex] then
    return
  end

  for index in pairs(tabsMatching) do
    self.Tabs[index]:SetFlashing(true)
  end
end

function addonTable.Display.TabsBarMixin:GetFilter(tabData, tabTag)
  local func
  if tabData.invert then
    func = function(data)
      return tabData.groups[data.typeInfo.type] ~= false and (data.typeInfo.tabTag == nil or data.typeInfo.tabTag == tabTag) and
        (
        not data.typeInfo.channel or
        (tabData.channels[data.typeInfo.channel.name] == nil and data.typeInfo.channel.isDefault) or
        tabData.channels[data.typeInfo.channel.name]
      ) and ((data.typeInfo.type ~= "WHISPER" and data.typeInfo.type ~= "BN_WHISPER") or tabData.whispersTemp[data.typeInfo.player and data.typeInfo.player.name] ~= false)
      or (data.typeInfo.type == "ADDON" and tabData.groups["ADDON"] == false and tabData.addons[data.typeInfo.source] ~= false and (data.typeInfo.tabTag == nil or data.typeInfo.tabTag == tabTag))
    end
  else
    func = function(data)
      return tabData.groups[data.typeInfo.type] and (data.typeInfo.tabTag == nil or data.typeInfo.tabTag == tabTag) or
        (data.typeInfo.type == "WHISPER" or data.typeInfo.type == "BN_WHISPER") and tabData.whispersTemp[data.typeInfo.player and data.typeInfo.player.name] or
        tabData.channels[data.typeInfo.channel and data.typeInfo.channel.name] or
        data.typeInfo.type == "ADDON" and not tabData.groups["ADDON"] and tabData.addons[data.typeInfo.source] and (data.typeInfo.tabTag == nil or data.typeInfo.tabTag == tabTag)
    end
  end
  if #tabData.filters > 0 then
    local core = func
    func = function(data)
      if not core(data) then
        return false
      end

      for _, f in ipairs(tabData.filters) do
        if not f(data) then
          return false
        end
      end
      return true
    end
  end

  return func
end

function addonTable.Display.GetTabNameFromName(name)
  if type(_G[name]) == "string" then
    return _G[name]
  else
    return name or UNKNOWN
  end
end

function addonTable.Display.TabsBarMixin:RefreshTabs()
  self.tabsPool:ReleaseAll()
  self.dropdownTabs = {}
  local allTabs = {}
  local windowData = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[self.chatFrame:GetID()]
  if not windowData or type(windowData.tabs) ~= "table" then
    return
  end

  for index, tabData in ipairs(windowData.tabs) do
    local tabButton = self.tabsPool:Acquire()
    tabButton.minWidth = false
    tabButton:SetID(index)
    tabButton:Show()
    tabButton:SetText(addonTable.Display.GetTabNameFromName(tabData.name))

    local tabColor = CreateColorFromRGBHexString(tabData.tabColor or "06a1ff")
    local bgColor = CreateColorFromRGBHexString(tabData.backgroundColor or "242424")
    local tabTag = self.chatFrame:GetID() .. "_" .. index
    tabButton.filter = self:GetFilter(tabData, tabTag)
    tabButton.bgColor = bgColor
    tabButton.isDraggable = false

    tabButton:SetScript("OnClick", function(_, mouseButton)
      if mouseButton == "RightButton" then
        local chatFrameID = tabButton:GetID()

        if chatFrameID == 1 and addonTable.Core and addonTable.Core.SyncBlizzardChatWindowSettings then
          addonTable.Core.SyncBlizzardChatWindowSettings()
        end

        if type(FCF_Tab_OnClick) == "function" then
          FCF_Tab_OnClick(tabButton, "RightButton")
        elseif type(FCF_Tab_SetupMenu) == "function" then
          CURRENT_CHAT_FRAME_ID = chatFrameID
          FCF_Tab_SetupMenu(tabButton)
        elseif ChatConfigFrame then
          ShowUIPanel(ChatConfigFrame)
        end
        return
      elseif mouseButton ~= "LeftButton" then
        return
      end

      for _, frame in pairs(self.customHolders) do
        frame:Hide()
      end
      for _, otherTab in ipairs(self.Tabs or {}) do
        otherTab:SetSelected(false)
      end

      tabButton:SetSelected(true)
      if self.dropdownTabButton then
        self.dropdownTabButton:SetSelected(false)
      end
      self.chatFrame:SetBackgroundColor(tabButton.bgColor.r, tabButton.bgColor.g, tabButton.bgColor.b)

      if tabData.custom and addonTable.API.CustomTabs[tabData.custom] then
        self.chatFrame.ScrollingMessages:Hide()
        self.chatFrame:SetTabSelectedOnly(tabButton:GetID())
        if not self.customHolders[tabData.custom] then
          self.customHolders[tabData.custom] = CreateFrame("Frame", nil, self.chatFrame)
          self.customHolders[tabData.custom]:SetAllPoints(self.chatFrame.ScrollingMessages)
        end
        self.customHolders[tabData.custom]:Show()
        addonTable.API.CustomTabs[tabData.custom].install(self.customHolders[tabData.custom])
      else
        self.chatFrame.ScrollingMessages:Show()
        self.chatFrame:SetTabSelectedAndFilter(tabButton:GetID(), tabButton.filter)
        self.chatFrame.ScrollingMessages:Render()
      end
    end)

    tabButton:SetColor(tabColor.r, tabColor.g, tabColor.b)
    table.insert(allTabs, tabButton)
  end

  self.dropdownTabButton = self.tabsPool:Acquire()
  self.dropdownTabButton.minWidth = true
  self.dropdownTabButton.isDraggable = false
  self.dropdownTabButton:SetText(addonTable.Constants.TabDropdownMarkup)
  self.dropdownTabButton:SetScript("OnClick", function()
    MenuUtil.CreateContextMenu(self, function(_, rootDescription)
      for _, tab in ipairs(self.dropdownTabs) do
        rootDescription:CreateButton(CreateColor(tab:GetColor()):WrapTextInColorCode(tab:GetText()), function()
          tab:Click("LeftButton")
        end)
      end
      rootDescription:SetScrollMode(20 * 20)
    end)
  end)
  self.dropdownTabButton:SetColor(0.3, 0.3, 0.3)
  self.dropdownTabButton:Hide()
  table.insert(allTabs, self.dropdownTabButton)

  for _, tab in ipairs(allTabs) do
    tab:SetSelected(false)
  end

  self.Tabs = allTabs
  self:PositionTabs()

  local tabCount = #windowData.tabs
  if tabCount > 0 then
    local currentTab = self.chatFrame.tabIndex and math.min(self.chatFrame.tabIndex, tabCount) or 1
    allTabs[currentTab]:Click("LeftButton")
  end

  self.active = true
  self.lockActive = true
  self:SetScript("OnEnter", nil)
  self:SetScript("OnLeave", nil)
  if self.hideTimer then
    self.hideTimer:Cancel()
    self.hideTimer = nil
  end
  self:SetAlpha(1)
  self:Show()
end

function addonTable.Display.TabsBarMixin:OnEnter()
  if self.hideTimer then
    self.hideTimer:Cancel()
  end
  self.active = true
  self.fadeInterpolator:Interpolate(self:GetAlpha(), 1, 0.15, function(value)
    self:SetAlpha(value)
  end)
end

function addonTable.Display.TabsBarMixin:OnLeave()
  if self:IsMouseOver() then
    return
  end
  if self.hideTimer then
    self.hideTimer:Cancel()
  end
  self.hideTimer = C_Timer.NewTimer(2, function()
    self.fadeInterpolator:Interpolate(self:GetAlpha(), 0, 0.15, function(value)
      self:SetAlpha(value)
    end)
    self.active = false
  end)
end

addonTable.CallbackRegistry:RegisterCallback("Render", function(_, newMessages)
  local targetWindow = addonTable.Config.Get(addonTable.Config.Options.NEW_WHISPER_NEW_TAB)
  if targetWindow ~= 0 and newMessages then
    for i = 1, newMessages do
      local m = addonTable.Messages:GetMessageRaw(i)
      if m.typeInfo.type == "WHISPER" or m.typeInfo.type == "BN_WHISPER" then
        local window = addonTable.Config.Get(addonTable.Config.Options.WINDOWS)[targetWindow]
        if m.typeInfo.player then
          local testPlayer = m.typeInfo.player.name
          local any = false
          for _, tab in ipairs(window.tabs) do
            if tab.whispersTemp[testPlayer] then
              any = true
              break
            end
          end
          if not any then
            local tabConfig = addonTable.Config.GetEmptyTabConfig(Ambiguate(m.typeInfo.player.name, "short"))
            local c = addonTable.Config.Get(addonTable.Config.Options.CHAT_COLORS)[m.typeInfo.type]
            tabConfig.tabColor = CreateColor(c.r, c.g, c.b):GenerateHexColorNoAlpha()
            tabConfig.whispersTemp[testPlayer] = true
            tabConfig.isTemporary = true
            table.insert(window.tabs, tabConfig)
            C_Timer.After(0, function()
              addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
              addonTable.allChatFrames[targetWindow].TabsBar.Tabs[#window.tabs]:SetFlashing(true)
            end)
          end
        else
          local groups = {[m.typeInfo.type] = true}
          local channels = {}
          local addons = {}
          local any = false
          for _, tab in ipairs(window.tabs) do
            if tab.name == "WHISPER" or tCompare(tab.groups, groups) and tCompare(tab.channels, channels) and tCompare(tab.addons, addons) and not tab.invert then
              any = true
              break
            end
          end
          if not any then
            local tabConfig = addonTable.Config.GetEmptyTabConfig("WHISPER")
            local c = addonTable.Config.Get(addonTable.Config.Options.CHAT_COLORS)[m.typeInfo.type]
            tabConfig.tabColor = CreateColor(c.r, c.g, c.b):GenerateHexColorNoAlpha()
            tabConfig.groups = groups
            tabConfig.isTemporary = true
            table.insert(window.tabs, tabConfig)
            C_Timer.After(0, function()
              addonTable.CallbackRegistry:TriggerEvent("RefreshStateChange", {[addonTable.Constants.RefreshReason.Tabs] = true})
              addonTable.allChatFrames[targetWindow].TabsBar.Tabs[#window.tabs]:SetFlashing(true)
            end)
          end
        end
      end
    end
  end
end)
