# ChayChat

## Session whisper menu

- Right-click the minimap / broker button to open a session-only conversation menu.
- Click a listed whisper name to reopen that popout.
- Left-click the minimap / broker button still opens options.
- Added `/chaypop conversations` and `/chaypop whispers`.
- Kept whisper messages session-only with no saved whisper/chat history.
