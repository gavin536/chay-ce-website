# ChayChat 2.42

- Fixed outgoing whispers containing item hyperlinks appearing twice in the ChayChat popout.
- Local-echo suppression now compares the rendered hyperlink text instead of Blizzard's raw hyperlink payload, which can be normalized before `CHAT_MSG_WHISPER_INFORM` / `CHAT_MSG_BN_WHISPER_INFORM` is fired.
- Preserved the 2.41 Shift-click item-link hook and the 2.40 right-click **Link to Chat** focus override.
- No Blizzard chat function is replaced; the Shift-click path remains a secure post-hook scoped to the focused ChayChat reply box.

# ChayChat 2.41

- Fixed Shift-click item-link insertion into a focused ChayChat whisper reply box on Retail/Midnight 12.0+.
- Added a secure post-hook to Blizzard's `ChatFrameUtil.InsertLink` so normal Shift-click chat links route into ChayChat without replacing Blizzard functions or hooking `SetItemRef`.
- Deactivates any Blizzard active chat edit box when the ChayChat reply field gains focus, preventing an item link from being routed to both edit boxes.
- Preserved the 2.40 gear-context **Link to Chat** focus override, GW2 config guard, Battle.net whisper API update, whisper history, search, copy, invites, SharedMedia, minimap integration, styling, and Midnight secret-value guards.

# ChayChat 2.40

- Added Retail/Midnight gear-item **Link to Chat** support for the focused ChayChat whisper reply box using Blizzard's `ChatFrameUtil.SetChatFocusOverride` path.
- Item links selected from Blizzard's gear/item context UI now route into the focused ChayChat reply field without replacing Blizzard chat functions or hooking `SetItemRef`.
- Enabled hyperlink handling on the reply edit box when the current client exposes `EditBox:SetHyperlinksEnabled`.
- Removed the deprecated `BNSendWhisper` fallback; Battle.net replies now use `C_BattleNet.SendWhisper`.
- Carried forward the GW2 skin-option guard so `skins.gw2_ui.fade_chat` is only written when that nested setting actually exists.
- Preserved existing whisper windows, history, search, copy, invites, SharedMedia, minimap integration, styling, and Midnight secret-value guards.

# ChayChat 2.38

- Reduced the ChayChat Options window minimum width from 620 to 480 pixels and the default width from 650 to 560 pixels.
- Made the options scroll content responsive to the actual window width so controls stay inside the panel while resizing narrower.
- Made dropdown buttons and their popup menus resize with the options content instead of using the previous fixed 368-pixel width.
- Preserved the 2.37 dark GUI styling, frame height behavior, whisper popouts, history, search, copy, invites, SharedMedia, minimap integration, and Midnight secret-value guards.

# ChayChat 2.37

- Darkened the main ChayChat Options GUI while preserving the existing dragon background, layout, controls, border settings, and live preview behavior.
- Reduced the options background image intensity, increased the black overlay, and made the base options backdrop substantially more opaque so the world UI no longer washes through the settings panel.
- Added Blizzard-standard Escape-key closing for the named ChayChat Options, whisper search, copy, and recent-conversation utility windows.
- Preserved whisper popouts, 72-hour history, search, copy, invites, SharedMedia, minimap/LibDBIcon integration, main-chat behavior, and Midnight secret-value guards.
- Reviewed current Retail 12.1 chat addons for improvement candidates without importing third-party code or adding unrelated features.

# ChayChat 2.36

- Fixed the Lua load failure `main function has more than 200 local variables` in `Display/WhisperPopout.lua`.
- Reorganized the 3-day whisper-history helpers under one private `History` namespace so they no longer consume separate top-level chunk locals.
- Preserved the full 72-hour whisper-history behavior, saved conversation reopening, minimap conversation menu, mock preview, SharedMedia images/sounds, search, copy, invites, and live whisper handling.
- No new globals, polling loops, timers, combat hooks, or protected-data APIs were added.
- Verified the previous 2.35 file reproduces Lua's 200-local compiler failure and the 2.36 file compiles successfully under the same compiler.

# ChayChat 2.35

- Added automatic persistent whisper history with a strict 72-hour retention window.
- Saved history uses the existing ChayChatDB SavedVariables database; no new dependency or background timer was added.
- Retained records contain only conversation identity, direction, message text, and epoch timestamp plus existing display metadata needed to reopen the conversation.
- History is pruned on initialization and when the conversation menu is opened; each conversation is bounded to 250 retained messages and the database to 100 recent conversations for SavedVariables integrity.
- The minimap/broker conversation menu now includes retained conversations after /reload and can reopen them without creating popouts at login.
- Opening a live whisper conversation loads its retained messages first, then appends new messages normally without duplicating the saved records.
- Mock and /chaypop test messages are never written to persistent history.
- Existing mock preview, SharedMedia backgrounds/sounds, minimap integration, live whisper handling, search, copy, invites, and Midnight-safe secret-value guards are preserved.

# ChayChat 2.34

- Reworked the mock preview visibility path without changing live whisper handling.
- Mock preview now uses a dedicated named frame created on FULLSCREEN_DIALOG strata.
- Mock Window button is explicitly click-registered and raised above the options content.
- Every mock-open action force-restores parent, alpha, clamping, position, visibility, and raise state.
- Narrow UI scales no longer fall back to centering the mock directly under the options panel; the preview anchors near the top of the screen instead.
- A one-frame visibility reassertion protects against skins/layout code that finishes after the click handler.
- SharedMedia backgrounds/sounds, minimap integration, and normal whisper popouts are unchanged.

# ChayChat

## 233-midnight-mock-window-fix

- Fixed the Mock Window opening underneath the larger Options panel at the same screen position.
- Mock Window now opens above normal dialog frames and, when possible, beside the Options panel so both remain usable for live preview.
- Mock Window visibility state is now set when opened and cleared when its close button is used.
- Initialization no longer repeatedly clears the mock-open state after the addon has already initialized.
- Preserved all 2.32 minimap, LibSharedMedia backgrounds/sounds, whisper, search, copy, invite, and session-history behavior.

## 232-midnight-minimap-sharedmedia-integrity

- Replaced ChayChat's custom minimal LibDBIcon/LibDataBroker copies with the proven embedded library versions from the supplied Prat 3.9.104 build.
- Repaired minimap launcher registration and reset behavior, including the LibDBIcon saved position and visibility state.
- Switched the minimap launcher texture to ChayChat's visible red Chay_CE icon and enabled Blizzard AddOn Compartment registration as a second launcher location.
- Registered ChayChat background images and whisper sounds with LibSharedMedia-3.0.
- Background selection now reads the SharedMedia background registry, including media supplied by other SharedMedia packs.
- Incoming whisper sound selection now reads the SharedMedia sound registry while retaining Blizzard SoundKit choices.
- Local PNG/TGA/BLP backgrounds added from ChayChat\Media are also registered into SharedMedia.
- Preserved the existing whisper-window, search, copy, invite, URL, sound playback, and session-only message behavior.

## 231-midnight-search-integrity

- Added a lightweight Find button to each whisper popout, based on the useful conversation-search concept in Prat without importing Prat code or dependencies.
- Search is session-only, case-insensitive, and uses ChayChat's existing in-memory whisper lines; it adds no polling, timers, or saved-message database.
- Added `/chaypop find` / `/chaypop search` support for the most recent whisper popout.
- Updated the Retail TOC interface to 120100 for Midnight 12.1 while retaining the existing secondary interface entries.
- Preserved existing whisper popout behavior, copy mode, invites, URL handling, sounds, minimap behavior, and session-only history policy.

## Session whisper menu

- Right-click the minimap / broker button to open a session-only conversation menu.
- Click a listed whisper name to reopen that popout.
- Left-click the minimap / broker button still opens options.
- Added `/chaypop conversations` and `/chaypop whispers`.
- Kept whisper messages session-only with no saved whisper/chat history.
