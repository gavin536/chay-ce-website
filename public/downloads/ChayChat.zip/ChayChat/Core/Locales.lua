---@class addonTableChayChat
local addonTable = select(2, ...)
addonTable.Locales = CopyTable(CHAYCHAT_LOCALES.enUS)
for key, translation in pairs(CHAYCHAT_LOCALES[GetLocale()]) do
  addonTable.Locales[key] = translation
end
for key, translation in pairs(addonTable.Locales) do
  _G["CHAYCHAT_L_" .. key] = translation

  if key:match("^BINDING") then
    _G["CHAYCHAT_NAME_BAGANATOR_" .. key:match("BINDING_(.*)")] = translation
  end
end
