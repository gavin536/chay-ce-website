---@class addonTableChayChat
local addonTable = select(2, ...)

function addonTable.Utilities.Message(text)
  addonTable.Messages:SetIncomingType({type = "ADDON", event = "NONE", source = "CHAYCHAT"})
  addonTable.Messages:AddMessage("|cffea7ed8" .. addonTable.Locales.CHAYCHAT .. "|r: " .. text)
end
