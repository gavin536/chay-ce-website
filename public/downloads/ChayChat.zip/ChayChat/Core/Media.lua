local addonName = ...

local LSM = LibStub and LibStub:GetLibrary("LibSharedMedia-3.0", true)
if not LSM then
  return
end

local addonPath = "Interface\\AddOns\\" .. tostring(addonName or "ChayChat") .. "\\"
local mediaPath = addonPath .. "Media\\"
local assetsPath = addonPath .. "Assets\\"

local backgrounds = {
  ["ChayChat - Dragon Background"] = mediaPath .. "DragonBackground.tga",
  ["ChayChat - Chay Logo"] = mediaPath .. "chay-logo.png",
  ["ChayChat - Chay"] = mediaPath .. "Chay.png",
  ["ChayChat - Latency Issues"] = mediaPath .. "Latency Issues.png",
  ["ChayChat - Chat Background"] = assetsPath .. "ChatBackground.tga",
  ["ChayChat - Chat Logo"] = assetsPath .. "Logo.png",
}

local sounds = {
  ["Chay Ping - Loud"] = mediaPath .. "WhisperPing.ogg",
  ["Chay Chime - Loud"] = mediaPath .. "WhisperChime.ogg",
  ["Chay Soft - Loud"] = mediaPath .. "WhisperSoft.ogg",
  ["Chay Alert - Loud"] = mediaPath .. "WhisperAlert.ogg",
  ["Chay Double - Loud"] = mediaPath .. "WhisperDouble.ogg",
  ["Chay Cascade - Loud"] = mediaPath .. "WhisperCascade.ogg",
}

for name, path in pairs(backgrounds) do
  LSM:Register("background", name, path)
end

for name, path in pairs(sounds) do
  LSM:Register("sound", name, path)
end
