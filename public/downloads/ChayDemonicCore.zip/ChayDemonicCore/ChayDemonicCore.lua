local ADDON_NAME = ...

local DEMONIC_CORE_AURA_ID = 264173
local DEMONBOLT_SPELL_ID = 264178
local VOIDFALL_TALENT_ID = 1253304
local VOIDFALL_AURA_ID = 1256301
local BUILTIN_DEFAULT_PROC_VERSION = 2
local MAX_DEMONIC_CORE_PROCS = 4
local OPTIONS_BACKGROUND_TEXTURE = "Interface\\AddOns\\ChayDemonicCore\\Media\\options-dragon.tga"
local MINIMAP_ICON_TEXTURE = "Interface\\AddOns\\ChayDemonicCore\\Media\\minimap-icon.tga"

local PROC_ICON_SIZE = 58
local DEFAULT_ICON_PADDING = 6
local DISPLAY_PADDING = 6
local DISPLAY_HEIGHT = PROC_ICON_SIZE + (DISPLAY_PADDING * 2)
local OPTIONS_BASE_WIDTH = 510
local OPTIONS_BASE_HEIGHT = 760


local DEFAULTS = {
    locked = false,

    scale = 1.00,
    point = "CENTER",
    relativePoint = "CENTER",
    x = 0,
    y = -150,

    showStackText = true,
    textSize = 22,
    textX = 0,
    textY = 0,

    iconBrightness = 1.00,
    iconOpacity = 1.00,
    iconPadding = DEFAULT_ICON_PADDING,

    optionsWidth = 560,
    optionsHeight = 980,
    optionsPoint = "CENTER",
    optionsRelativePoint = "CENTER",
    optionsX = 0,
    optionsY = 0,

    procManagerPoint = "CENTER",
    procManagerRelativePoint = "CENTER",
    procManagerX = 360,
    procManagerY = 0,

    customProcs = {},
    savedProcs = {},
    autoLearnProcIDs = true,
    builtInDefaultProcVersion = 0,

    glowEnabled = true,
    glowPulse = true,
    glowStyleIndex = 1,
    glowColorIndex = 1,
    glowIntensity = 0.90,
    glowThickness = 2,
    glowSpeed = 0.60,

    soundEnabled = true,
    soundKitIndex = 1,
    soundChannelIndex = 1,

    minimapAngle = 225,
}

local SOUND_KITS = {}

local function AddSoundKit(name, soundKitKey, fallbackID)
    local soundKitID

    if SOUNDKIT and soundKitKey then
        soundKitID = SOUNDKIT[soundKitKey]
    end

    if type(soundKitID) ~= "number" then
        soundKitID = fallbackID
    end

    if type(soundKitID) == "number" then
        SOUND_KITS[#SOUND_KITS + 1] = {
            name = name,
            id = soundKitID,
        }
    end
end

-- Verified Blizzard SoundKit names. Entries without a known numeric fallback
-- are included only when the current client exposes the SoundKit constant.
AddSoundKit("Raid Warning", "RAID_WARNING", 8959)
AddSoundKit("Ready Check", "READY_CHECK", 8960)
AddSoundKit("Bell", "ALARM_CLOCK_WARNING_3", 12889)
AddSoundKit("Checkbox On", "IG_MAINMENU_OPTION_CHECKBOX_ON", 856)
AddSoundKit("Checkbox Off", "IG_MAINMENU_OPTION_CHECKBOX_OFF", 857)
AddSoundKit("Menu Open", "IG_MAINMENU_OPEN")
AddSoundKit("Menu Close", "IG_MAINMENU_QUIT")
AddSoundKit("Character Open", "IG_CHARACTER_INFO_OPEN")
AddSoundKit("Character Close", "IG_CHARACTER_INFO_CLOSE")
AddSoundKit("Window Close", "GS_TITLE_OPTION_EXIT", 799)

local GLOW_STYLES = {
    "Border",
    "Corners",
    "Full Pulse",
    "Double Border",
}

local GLOW_COLORS = {
    { name = "Gold",   r = 1.00, g = 0.58, b = 0.08 },
    { name = "Red",    r = 1.00, g = 0.12, b = 0.08 },
    { name = "Purple", r = 0.72, g = 0.22, b = 1.00 },
    { name = "Blue",   r = 0.15, g = 0.55, b = 1.00 },
    { name = "Green",  r = 0.15, g = 1.00, b = 0.32 },
    { name = "White",  r = 1.00, g = 1.00, b = 1.00 },
}

local SOUND_CHANNELS = {
    "Master",
    "SFX",
    "Dialog",
}

-- Auto-learned proc IDs are tagged with the class of the character that
-- actually triggered Blizzard's proc-overlay event. We never guess a spell's
-- class from its Spell ID. The sort order is alphabetical for the manager.
local CLASS_LIBRARY_INFO = {
    DEATHKNIGHT = { id = 6,  name = "Death Knight",  sort = 1 },
    DEMONHUNTER = { id = 12, name = "Demon Hunter", sort = 2 },
    DRUID       = { id = 11, name = "Druid",        sort = 3 },
    EVOKER      = { id = 13, name = "Evoker",       sort = 4 },
    HUNTER      = { id = 3,  name = "Hunter",       sort = 5 },
    MAGE        = { id = 8,  name = "Mage",         sort = 6 },
    MONK        = { id = 10, name = "Monk",         sort = 7 },
    PALADIN     = { id = 2,  name = "Paladin",      sort = 8 },
    PRIEST      = { id = 5,  name = "Priest",       sort = 9 },
    ROGUE       = { id = 4,  name = "Rogue",        sort = 10 },
    SHAMAN      = { id = 7,  name = "Shaman",       sort = 11 },
    WARLOCK     = { id = 9,  name = "Warlock",      sort = 12 },
    WARRIOR     = { id = 1,  name = "Warrior",      sort = 13 },
}

local eventFrame = CreateFrame("Frame")
local displayFrame
local optionsFrame
local minimapButton
local initialized = false
local testMode = false
local updateQueued = false
local refreshingOptions = false

local trackedAuraInstanceID
local trackedCDMFrame
local viewerHooked = false
local hookedCDMFrames = setmetatable({}, { __mode = "k" })

local procWasActive = false
local lastReadableCount

-- Generic all-class proc rows. Demonic Core keeps its existing dedicated
-- tracker above; these rows are an additive layer and do not replace it.
local customRowsContainer
local customRows = {}
local customRowsBySpellID = {}
local customRowPool = {}
local customOptionRows = {}
local savedProcOptionRows = {}
local savedProcClassHeaders = {}
local customProcManager
local currentPlayerClassFile
local currentPlayerClassID
local currentPlayerClassName
local customUpdateQueued = false
local customUpdateSilent = true

local ApplyCustomProcVisualSettings
local ApplyCustomProcGlowSettings
local ApplyCustomProcLayout
local ApplyCustomProcLockState
local ApplyCustomProcTextSettings
local UpdateAllCustomProcStates
local QueueCustomUpdate
local RebuildCustomRows
local RefreshCustomProcOptions
local RefreshSavedProcList
local FindCustomRowForSpellID
local ToggleCustomProcManager
local RunCustomProcTest

local function CopyDefaults(target, source)
    for key, value in pairs(source) do
        if target[key] == nil then
            target[key] = value
        end
    end
end

local function GetDB()
    ChayDemonicCoreDB = ChayDemonicCoreDB or {}
    CopyDefaults(ChayDemonicCoreDB, DEFAULTS)

    -- Do not share the defaults table if an older saved-variable version did
    -- not yet contain the generic proc list.
    if type(ChayDemonicCoreDB.customProcs) ~= "table" or ChayDemonicCoreDB.customProcs == DEFAULTS.customProcs then
        ChayDemonicCoreDB.customProcs = {}
    end

    -- Saved proc IDs are also character-specific. This library remembers valid
    -- Spell IDs after they are entered once so they can be re-added without
    -- looking them up again.
    if type(ChayDemonicCoreDB.savedProcs) ~= "table" or ChayDemonicCoreDB.savedProcs == DEFAULTS.savedProcs then
        ChayDemonicCoreDB.savedProcs = {}
    end

    return ChayDemonicCoreDB
end

local function Print(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cffc41f3bChay Demonic Core:|r " .. tostring(message))
end

local function Clamp(value, minimum, maximum)
    value = tonumber(value) or minimum

    if value < minimum then
        return minimum
    end

    if value > maximum then
        return maximum
    end

    return value
end

local function Round(value, step)
    step = step or 1
    return math.floor((value / step) + 0.5) * step
end

local function IsSecretValue(value)
    return issecretvalue and issecretvalue(value) or false
end

local function RefreshCurrentPlayerClassMetadata()
    if not UnitClassBase then
        return false
    end

    -- Only consume UnitClassBase's locale-independent classFilename return.
    -- The numeric class ID is derived from our fixed Retail class table so the
    -- auto-learning path never needs to inspect any additional return value.
    local classFile = UnitClassBase("player")
    if type(classFile) ~= "string" then
        return false
    end

    local info = CLASS_LIBRARY_INFO[classFile]
    if not info then
        return false
    end

    currentPlayerClassFile = classFile
    currentPlayerClassID = info.id
    currentPlayerClassName = info.name
    return true
end

local function GetCurrentPlayerClassMetadata()
    if not currentPlayerClassFile or not currentPlayerClassID then
        RefreshCurrentPlayerClassMetadata()
    end

    return currentPlayerClassFile, currentPlayerClassID, currentPlayerClassName
end

local function GetSavedProcClassGroup(entry)
    local classFile = type(entry) == "table" and entry.classFile or nil
    local info = classFile and CLASS_LIBRARY_INFO[classFile] or nil

    if info then
        return classFile, info.name, info.sort
    end

    return "CUSTOM", "Custom / Manual", 999
end

local function GetSortedSavedProcEntries()
    local sorted = {}

    for _, entry in ipairs(GetDB().savedProcs) do
        sorted[#sorted + 1] = entry
    end

    table.sort(sorted, function(left, right)
        local _, leftClassName, leftClassSort = GetSavedProcClassGroup(left)
        local _, rightClassName, rightClassSort = GetSavedProcClassGroup(right)

        if leftClassSort ~= rightClassSort then
            return leftClassSort < rightClassSort
        end

        if leftClassName ~= rightClassName then
            return leftClassName < rightClassName
        end

        local leftName = string.lower(tostring(left.name or ""))
        local rightName = string.lower(tostring(right.name or ""))
        if leftName ~= rightName then
            return leftName < rightName
        end

        return (tonumber(left.spellID) or 0) < (tonumber(right.spellID) or 0)
    end)

    return sorted
end

local function GetDemonboltTexture()
    if C_Spell and C_Spell.GetSpellTexture then
        local texture = C_Spell.GetSpellTexture(DEMONBOLT_SPELL_ID)
        if texture then
            return texture
        end
    end

    return 136172
end

local function GetSoundKit()
    local db = GetDB()
    local index = tonumber(db.soundKitIndex) or DEFAULTS.soundKitIndex
    return SOUND_KITS[index] or SOUND_KITS[1]
end

local function GetSoundChannel()
    local db = GetDB()
    local index = tonumber(db.soundChannelIndex) or DEFAULTS.soundChannelIndex
    return SOUND_CHANNELS[index] or SOUND_CHANNELS[1]
end

local function GetGlowStyle()
    local db = GetDB()
    local index = tonumber(db.glowStyleIndex) or DEFAULTS.glowStyleIndex
    return GLOW_STYLES[index] or GLOW_STYLES[1], index
end

local function GetGlowColor()
    local db = GetDB()
    local index = tonumber(db.glowColorIndex) or DEFAULTS.glowColorIndex
    return GLOW_COLORS[index] or GLOW_COLORS[1], index
end

local function PlayCue(force)
    local db = GetDB()

    if not force and not db.soundEnabled then
        return
    end

    local soundKit = GetSoundKit()
    if soundKit and soundKit.id then
        PlaySound(soundKit.id, GetSoundChannel())
    end
end

local function SafeGetPlayerAura()
    if not C_UnitAuras or not C_UnitAuras.GetPlayerAuraBySpellID then
        return nil
    end

    local ok, auraData = pcall(C_UnitAuras.GetPlayerAuraBySpellID, DEMONIC_CORE_AURA_ID)
    if ok then
        return auraData
    end

    return nil
end

local function SafeGetAuraByInstanceID(auraInstanceID)
    if not auraInstanceID or not C_UnitAuras or not C_UnitAuras.GetAuraDataByAuraInstanceID then
        return nil
    end

    local ok, auraData = pcall(C_UnitAuras.GetAuraDataByAuraInstanceID, "player", auraInstanceID)
    if ok then
        return auraData
    end

    return nil
end

local function IsDemonboltOverlayActive()
    if not C_SpellActivationOverlay or not C_SpellActivationOverlay.IsSpellOverlayed then
        return false
    end

    local active = false
    local ok = pcall(function()
        active = C_SpellActivationOverlay.IsSpellOverlayed(DEMONBOLT_SPELL_ID) and true or false
    end)

    return ok and active or false
end

local function SavePosition()
    if not displayFrame then
        return
    end

    local db = GetDB()
    local point, _, relativePoint, xOffset, yOffset = displayFrame:GetPoint(1)

    db.point = point or DEFAULTS.point
    db.relativePoint = relativePoint or DEFAULTS.relativePoint
    db.x = xOffset or DEFAULTS.x
    db.y = yOffset or DEFAULTS.y
end

local function ApplyPosition()
    if not displayFrame then
        return
    end

    local db = GetDB()

    displayFrame:ClearAllPoints()
    displayFrame:SetPoint(
        db.point or DEFAULTS.point,
        UIParent,
        db.relativePoint or DEFAULTS.relativePoint,
        db.x or DEFAULTS.x,
        db.y or DEFAULTS.y
    )
    displayFrame:SetScale(Clamp(db.scale or DEFAULTS.scale, 0.50, 2.50))
end

local function ClearStackText()
    if not displayFrame or not displayFrame.stackText then
        return
    end

    if displayFrame.stackText.ClearText then
        displayFrame.stackText:ClearText()
    else
        displayFrame.stackText:SetText("")
    end
    displayFrame.stackText:Hide()
end

local function ApplyTextSettings()
    if not displayFrame or not displayFrame.stackText then
        return
    end

    local db = GetDB()
    local fontPath = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"

    displayFrame.stackText:SetFont(fontPath, Clamp(db.textSize or DEFAULTS.textSize, 8, 48), "OUTLINE")
    displayFrame.stackText:ClearAllPoints()
    displayFrame.stackText:SetPoint(
        "TOP",
        displayFrame,
        "BOTTOM",
        Clamp(db.textX or DEFAULTS.textX, -150, 150),
        -4 + Clamp(db.textY or DEFAULTS.textY, -150, 150)
    )

    if not db.showStackText then
        ClearStackText()
    end

    if ApplyCustomProcTextSettings then
        ApplyCustomProcTextSettings()
    end
end

local function HideGlowTextures(holder)
    if not holder then
        return
    end

    if holder.borders then
        for _, texture in pairs(holder.borders) do
            texture:Hide()
        end
    end

    if holder.innerBorders then
        for _, texture in pairs(holder.innerBorders) do
            texture:Hide()
        end
    end

    if holder.corners then
        for _, texture in pairs(holder.corners) do
            texture:Hide()
        end
    end

    if holder.fullOverlay then
        holder.fullOverlay:Hide()
    end
end

local function SetGlowTextureColor(texture, color, alpha)
    if not texture or not color then
        return
    end

    texture:SetColorTexture(color.r, color.g, color.b, alpha or 1)
end

local function ConfigureFullBorder(holder, borders, inset, thickness, color)
    if not holder or not borders then
        return
    end

    inset = inset or 0
    thickness = Clamp(thickness, 1, 6)

    local top = borders.top
    local bottom = borders.bottom
    local left = borders.left
    local right = borders.right

    top:ClearAllPoints()
    top:SetPoint("TOPLEFT", holder, "TOPLEFT", inset, -inset)
    top:SetPoint("TOPRIGHT", holder, "TOPRIGHT", -inset, -inset)
    top:SetHeight(thickness)

    bottom:ClearAllPoints()
    bottom:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", inset, inset)
    bottom:SetPoint("BOTTOMRIGHT", holder, "BOTTOMRIGHT", -inset, inset)
    bottom:SetHeight(thickness)

    left:ClearAllPoints()
    left:SetPoint("TOPLEFT", holder, "TOPLEFT", inset, -(inset + thickness))
    left:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", inset, inset + thickness)
    left:SetWidth(thickness)

    right:ClearAllPoints()
    right:SetPoint("TOPRIGHT", holder, "TOPRIGHT", -inset, -(inset + thickness))
    right:SetPoint("BOTTOMRIGHT", holder, "BOTTOMRIGHT", -inset, inset + thickness)
    right:SetWidth(thickness)

    for _, texture in pairs(borders) do
        SetGlowTextureColor(texture, color, 1)
        texture:Show()
    end
end

local function ConfigureCornerGlow(holder, thickness, color)
    if not holder or not holder.corners then
        return
    end

    thickness = Clamp(thickness, 1, 6)
    local length = Clamp(12 + (thickness * 2), 14, 26)
    local corners = holder.corners

    local definitions = {
        { corners.tlH, "TOPLEFT", 0, 0, length, thickness },
        { corners.tlV, "TOPLEFT", 0, 0, thickness, length },
        { corners.trH, "TOPRIGHT", 0, 0, length, thickness },
        { corners.trV, "TOPRIGHT", 0, 0, thickness, length },
        { corners.blH, "BOTTOMLEFT", 0, 0, length, thickness },
        { corners.blV, "BOTTOMLEFT", 0, 0, thickness, length },
        { corners.brH, "BOTTOMRIGHT", 0, 0, length, thickness },
        { corners.brV, "BOTTOMRIGHT", 0, 0, thickness, length },
    }

    for _, definition in ipairs(definitions) do
        local texture, point, x, y, width, height = unpack(definition)
        texture:ClearAllPoints()
        texture:SetPoint(point, holder, point, x, y)
        texture:SetSize(width, height)
        SetGlowTextureColor(texture, color, 1)
        texture:Show()
    end
end

local function ConfigureGlowStyle(holder, style, thickness, color)
    HideGlowTextures(holder)

    if style == "Corners" then
        ConfigureCornerGlow(holder, thickness, color)
    elseif style == "Full Pulse" then
        holder.fullOverlay:SetAllPoints(holder)
        holder.fullOverlay:SetColorTexture(color.r, color.g, color.b, 0.34)
        holder.fullOverlay:SetBlendMode("ADD")
        holder.fullOverlay:Show()
    elseif style == "Double Border" then
        ConfigureFullBorder(holder, holder.borders, 0, thickness, color)
        ConfigureFullBorder(holder, holder.innerBorders, thickness + 2, math.max(1, thickness - 1), color)
    else
        ConfigureFullBorder(holder, holder.borders, 0, thickness, color)
    end
end

local function ApplyGlowSettings()
    if not displayFrame or not displayFrame.glowHolders then
        return
    end

    local db = GetDB()
    local enabled = db.glowEnabled and true or false
    local pulse = db.glowPulse and true or false
    local intensity = Clamp(db.glowIntensity or DEFAULTS.glowIntensity, 0.20, 1.00)
    local speed = Clamp(db.glowSpeed or DEFAULTS.glowSpeed, 0.20, 2.00)
    local thickness = Clamp(db.glowThickness or DEFAULTS.glowThickness, 1, 6)
    local style = GetGlowStyle()
    local color = GetGlowColor()

    for _, holder in ipairs(displayFrame.glowHolders) do
        ConfigureGlowStyle(holder, style, thickness, color)

        if enabled then
            holder:Show()

            if pulse then
                holder.glowIn:SetDuration(speed * 0.5)
                holder.glowOut:SetDuration(speed * 0.5)
                holder.glowIn:SetFromAlpha(math.max(0.10, intensity * 0.28))
                holder.glowIn:SetToAlpha(intensity)
                holder.glowOut:SetFromAlpha(intensity)
                holder.glowOut:SetToAlpha(math.max(0.10, intensity * 0.28))

                if not holder.glowAnim:IsPlaying() then
                    holder.glowAnim:Play()
                end
            else
                if holder.glowAnim:IsPlaying() then
                    holder.glowAnim:Stop()
                end
                holder:SetAlpha(intensity)
            end
        else
            if holder.glowAnim:IsPlaying() then
                holder.glowAnim:Stop()
            end
            holder:Hide()
        end
    end

    if ApplyCustomProcGlowSettings then
        ApplyCustomProcGlowSettings()
    end
end

local function ApplyIconVisualSettings()
    if not displayFrame then
        return
    end

    local db = GetDB()
    local brightness = Clamp(db.iconBrightness or DEFAULTS.iconBrightness, 0.25, 2.50)
    local opacity = Clamp(db.iconOpacity or DEFAULTS.iconOpacity, 0.10, 1.00)
    local baseBrightness = math.min(brightness, 1.00)
    local additiveAlpha = 0

    if brightness > 1.00 then
        additiveAlpha = Clamp((brightness - 1.00) * 0.55, 0, 0.82)
    end

    if displayFrame.activeIcons then
        for index, icon in ipairs(displayFrame.activeIcons) do
            icon:SetVertexColor(baseBrightness, baseBrightness, baseBrightness, 1)
            icon:SetAlpha(opacity)

            local bright = displayFrame.brightIcons and displayFrame.brightIcons[index]
            if bright then
                bright:SetAlpha(opacity * additiveAlpha)
                if additiveAlpha > 0 then
                    bright:Show()
                else
                    bright:Hide()
                end
            end

            local durationFill = displayFrame.durationFills and displayFrame.durationFills[index]
            if durationFill then
                durationFill:SetAlpha(opacity)
            end
        end
    end

    if displayFrame.previewIcons then
        for _, slot in ipairs(displayFrame.previewIcons) do
            slot:SetAlpha(math.max(0.20, opacity * 0.55))
        end
    end

    if ApplyCustomProcVisualSettings then
        ApplyCustomProcVisualSettings()
    end
end

local function ApplyIconLayout()
    if not displayFrame then
        return
    end

    local db = GetDB()
    local iconPadding = Clamp(db.iconPadding or DEFAULTS.iconPadding, 0, 30)
    local pitch = PROC_ICON_SIZE + iconPadding
    local driverWidth = MAX_DEMONIC_CORE_PROCS * pitch
    local displayWidth = driverWidth + DISPLAY_PADDING

    displayFrame:SetSize(displayWidth, DISPLAY_HEIGHT)

    if displayFrame.stackDriver then
        displayFrame.stackDriver:SetSize(driverWidth, PROC_ICON_SIZE)
    end

    if displayFrame.previewIcons then
        for index, slot in ipairs(displayFrame.previewIcons) do
            local x = DISPLAY_PADDING + ((index - 1) * pitch)
            slot:ClearAllPoints()
            slot:SetPoint("TOPLEFT", displayFrame, "TOPLEFT", x, -DISPLAY_PADDING)
        end
    end

    if displayFrame.activeIcons then
        for index, icon in ipairs(displayFrame.activeIcons) do
            local x = (index - 1) * pitch
            icon:ClearAllPoints()
            icon:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)

            local bright = displayFrame.brightIcons and displayFrame.brightIcons[index]
            if bright then
                bright:ClearAllPoints()
                bright:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
            end

            local durationFill = displayFrame.durationFills and displayFrame.durationFills[index]
            if durationFill then
                durationFill:ClearAllPoints()
                durationFill:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
            end

            local glow = displayFrame.glowHolders and displayFrame.glowHolders[index]
            if glow then
                glow:ClearAllPoints()
                glow:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
            end
        end
    end

    if ApplyCustomProcLayout then
        ApplyCustomProcLayout()
    end
end

local function ApplyLockState()
    if not displayFrame then
        return
    end

    local db = GetDB()
    local unlocked = not db.locked

    displayFrame:EnableMouse(unlocked)
    displayFrame:SetMovable(unlocked)

    if unlocked then
        displayFrame:SetBackdropColor(0.025, 0.025, 0.03, 0.86)
        displayFrame:SetBackdropBorderColor(0.75, 0.04, 0.10, 1)
        displayFrame.lockText:SetText("UNLOCKED - DRAG ICONS")
        displayFrame.lockText:Show()

        for _, icon in ipairs(displayFrame.previewIcons) do
            if procWasActive or testMode then
                icon:Hide()
            else
                icon:Show()
            end
        end
    else
        displayFrame:SetBackdropColor(0, 0, 0, 0)
        displayFrame:SetBackdropBorderColor(0, 0, 0, 0)
        displayFrame.lockText:Hide()

        for _, icon in ipairs(displayFrame.previewIcons) do
            icon:Hide()
        end
    end

    if ApplyCustomProcLockState then
        ApplyCustomProcLockState()
    end
end

local function SetDriverValue(value)
    if not displayFrame or not displayFrame.stackDriver then
        return
    end

    displayFrame.stackDriver:SetValue(value)
end

local function SetStackTextFromCount(applicationCount)
    if not displayFrame or not displayFrame.stackText then
        return
    end

    local db = GetDB()
    if not db.showStackText then
        ClearStackText()
        return
    end

    -- Midnight allows secret strings/numbers to be concatenated and passed
    -- directly to FontString:SetText. Nothing is read back or converted.
    local ok = pcall(function()
        displayFrame.stackText:SetText("" .. applicationCount)
        displayFrame.stackText:Show()
    end)

    if not ok then
        ClearStackText()
    end
end

local function SetStackTextFromAuraInstanceID(auraInstanceID)
    if not displayFrame or not displayFrame.stackText then
        return
    end

    local db = GetDB()
    if not db.showStackText then
        ClearStackText()
        return
    end

    if not auraInstanceID or not C_UnitAuras or not C_UnitAuras.GetAuraApplicationDisplayCount then
        return
    end

    -- Same pass-through pattern used by TweaksUI: never inspect the returned
    -- display string because it can be protected. Send it straight to SetText.
    pcall(function()
        displayFrame.stackText:SetText(
            C_UnitAuras.GetAuraApplicationDisplayCount("player", auraInstanceID, 1, MAX_DEMONIC_CORE_PROCS)
        )
        displayFrame.stackText:Show()
    end)
end

local function ClearDurationCountdowns()
    if not displayFrame or not displayFrame.durationFills then
        return
    end

    for _, cooldown in ipairs(displayFrame.durationFills) do
        cooldown:Clear()
        cooldown:Hide()
    end
end

local function ApplyDurationCountdown(auraInstanceID)
    if not displayFrame or not displayFrame.durationFills then
        return false
    end

    if not auraInstanceID or not C_UnitAuras or not C_UnitAuras.GetAuraDuration then
        ClearDurationCountdowns()
        return false
    end

    local ok, durationObject = pcall(C_UnitAuras.GetAuraDuration, "player", auraInstanceID)
    if not ok or not durationObject then
        ClearDurationCountdowns()
        return false
    end

    local applied = false

    for _, cooldown in ipairs(displayFrame.durationFills) do
        local setOk = pcall(cooldown.SetCooldownFromDurationObject, cooldown, durationObject, true)
        if setOk then
            cooldown:Show()
            applied = true
        else
            cooldown:Clear()
            cooldown:Hide()
        end
    end

    return applied
end

local function SetTestDurationCountdown()
    if not displayFrame or not displayFrame.durationFills then
        return
    end

    if not C_DurationUtil or not C_DurationUtil.CreateDuration then
        ClearDurationCountdowns()
        return
    end

    local durationObject = C_DurationUtil.CreateDuration()
    if not durationObject or not durationObject.SetTimeFromStart then
        ClearDurationCountdowns()
        return
    end

    durationObject:SetTimeFromStart(GetTime(), 20)

    for _, cooldown in ipairs(displayFrame.durationFills) do
        local ok = pcall(cooldown.SetCooldownFromDurationObject, cooldown, durationObject, true)
        if ok then
            cooldown:Show()
        else
            cooldown:Clear()
            cooldown:Hide()
        end
    end
end

local function SetInactiveVisuals()
    if not displayFrame then
        return
    end

    procWasActive = false
    lastReadableCount = nil

    SetDriverValue(0)
    ClearStackText()
    ClearDurationCountdowns()

    local db = GetDB()
    if db.locked and not testMode then
        displayFrame:Hide()
    else
        displayFrame:SetAlpha(1)
        displayFrame:Show()
        ApplyLockState()
    end
end

local function HandleSoundForCount(applicationCount, silent)
    if silent then
        if not IsSecretValue(applicationCount) then
            lastReadableCount = tonumber(applicationCount)
        else
            lastReadableCount = nil
        end
        return
    end

    local firstProcAppeared = not procWasActive
    local readableCountIncreased = false

    if not IsSecretValue(applicationCount) then
        local readableCount = tonumber(applicationCount)
        if readableCount and lastReadableCount and readableCount > lastReadableCount then
            readableCountIncreased = true
        end
        lastReadableCount = readableCount
    else
        lastReadableCount = nil
    end

    if firstProcAppeared or readableCountIncreased then
        PlayCue(false)
    end
end

local function SetActiveVisuals(applicationCount, auraInstanceID, silent)
    if not displayFrame then
        return
    end

    -- The numeric stack count may be a Midnight secret. StatusBar:SetValue is
    -- explicitly allowed to accept secret numeric values. The fill edge reveals
    -- exactly one complete icon per stack without Lua comparing the count.
    SetDriverValue(applicationCount)

    if auraInstanceID then
        SetStackTextFromAuraInstanceID(auraInstanceID)
    else
        SetStackTextFromCount(applicationCount)
    end

    if auraInstanceID then
        ApplyDurationCountdown(auraInstanceID)
    else
        ClearDurationCountdowns()
    end

    HandleSoundForCount(applicationCount, silent)
    procWasActive = true

    displayFrame:SetAlpha(1)
    displayFrame:Show()
    ApplyLockState()
end

local function ApplyAuraData(auraData, silent)
    if not auraData then
        return false
    end

    local success = false

    local ok = pcall(function()
        local auraInstanceID = auraData.auraInstanceID
        local applications = auraData.applications

        if auraInstanceID then
            trackedAuraInstanceID = auraInstanceID
        end

        if applications then
            SetActiveVisuals(applications, auraInstanceID or trackedAuraInstanceID, silent)
            success = true
        end
    end)

    return ok and success
end

local function UpdateProcState(silent)
    if not displayFrame or testMode then
        return
    end

    -- Primary fallback outside restricted states: direct Demonic Core spell-ID
    -- query. No list scans and no periodic polling.
    local auraData = SafeGetPlayerAura()
    if ApplyAuraData(auraData, silent) then
        return
    end

    -- TweaksUI-style identity bridge fallback: if CDM already gave us the
    -- non-secret auraInstanceID, try the instance data API when it is permitted.
    if trackedAuraInstanceID then
        auraData = SafeGetAuraByInstanceID(trackedAuraInstanceID)
        if ApplyAuraData(auraData, silent) then
            return
        end
    end

    -- Spell activation overlay is a safe presence fallback. If CDM has not yet
    -- delivered a stack count, show one icon rather than losing the proc alert.
    if IsDemonboltOverlayActive() then
        if not procWasActive then
            SetActiveVisuals(1, trackedAuraInstanceID, silent)
        end
        return
    end

    SetInactiveVisuals()
end

local function QueueUpdate(silent)
    if updateQueued then
        return
    end

    updateQueued = true

    C_Timer.After(0, function()
        updateQueued = false
        UpdateProcState(silent)
    end)
end

local function VisitCDMSpellCandidates(frame, auraInfo, visitor)
    if not frame or not visitor then
        return
    end

    local seen = {}

    local function Visit(candidateID)
        if candidateID == nil or IsSecretValue(candidateID) then
            return false
        end

        local numericSpellID = tonumber(candidateID)
        if not numericSpellID or numericSpellID <= 0 then
            return false
        end

        numericSpellID = math.floor(numericSpellID + 0.5)
        if seen[numericSpellID] then
            return false
        end
        seen[numericSpellID] = true

        return visitor(numericSpellID) and true or false
    end

    -- The aura spell identity is the strongest match when Blizzard exposes it
    -- as a non-secret value. The aura instance ID itself remains usable even
    -- when the rest of AuraData is restricted.
    if auraInfo then
        local auraSpellID
        pcall(function()
            auraSpellID = auraInfo.spellId
        end)
        if Visit(auraSpellID) then
            return
        end
    end

    local frameAuraSpellID
    pcall(function()
        frameAuraSpellID = frame.auraSpellID
    end)
    if Visit(frameAuraSpellID) then
        return
    end

    if frame.GetAuraSpellID then
        local returnedAuraSpellID
        pcall(function()
            returnedAuraSpellID = frame:GetAuraSpellID()
        end)
        if Visit(returnedAuraSpellID) then
            return
        end
    end

    local cooldownInfo = frame.cooldownInfo
    if not cooldownInfo then
        return
    end

    -- Blizzard's Cooldown Viewer has used both singular linkedSpellID and the
    -- linkedSpellIDs vector across its item-data paths. Check every public
    -- static identity so procs such as Voidfall can be resolved even when the
    -- active AuraData spell ID is secret.
    if Visit(cooldownInfo.spellID) then
        return
    end
    if Visit(cooldownInfo.overrideSpellID) then
        return
    end
    if Visit(cooldownInfo.overrideTooltipSpellID) then
        return
    end
    if Visit(cooldownInfo.linkedSpellID) then
        return
    end

    if type(cooldownInfo.linkedSpellIDs) == "table" then
        for _, candidateID in ipairs(cooldownInfo.linkedSpellIDs) do
            if Visit(candidateID) then
                return
            end
        end
    end
end

local function CDMFrameMatchesSpellID(frame, auraInfo, spellID)
    spellID = tonumber(spellID)
    if not spellID then
        return false
    end

    local matched = false
    pcall(function()
        VisitCDMSpellCandidates(frame, auraInfo, function(candidateID)
            if candidateID == spellID then
                matched = true
                return true
            end
            return false
        end)
    end)
    return matched
end

local function GetCDMFrameSpellID(frame, auraInfo)
    local result
    pcall(function()
        VisitCDMSpellCandidates(frame, auraInfo, function(candidateID)
            result = candidateID
            return true
        end)
    end)
    return result
end

local function FindCustomRowForCDMFrame(frame, auraInfo)
    if not frame or not FindCustomRowForSpellID then
        return nil
    end

    local foundRow
    pcall(function()
        VisitCDMSpellCandidates(frame, auraInfo, function(candidateID)
            foundRow = FindCustomRowForSpellID(candidateID)
            return foundRow ~= nil
        end)
    end)

    return foundRow
end

local function OnCDMSetAuraInstanceInfo(frame, cdmAuraInstance)
    local spellID = GetCDMFrameSpellID(frame, cdmAuraInstance)

    local customRow = FindCustomRowForCDMFrame(frame, cdmAuraInstance)
    if customRow then
        local customAuraInstanceID
        local customOK = pcall(function()
            customAuraInstanceID = cdmAuraInstance and cdmAuraInstance.auraInstanceID
        end)

        customRow.trackedCDMFrame = frame
        if customOK and customAuraInstanceID then
            customRow.trackedAuraInstanceID = customAuraInstanceID
        end

        if QueueCustomUpdate then
            QueueCustomUpdate(false)
        end
    end

    if spellID ~= DEMONIC_CORE_AURA_ID
        and not CDMFrameMatchesSpellID(frame, cdmAuraInstance, DEMONIC_CORE_AURA_ID) then
        return
    end

    trackedCDMFrame = frame

    -- TweaksUI's combat-safe bridge uses SetAuraInstanceInfo only to capture
    -- the auraInstanceID. Do not assume the CDM payload exposes stack data.
    local auraInstanceID
    local ok = pcall(function()
        auraInstanceID = cdmAuraInstance and cdmAuraInstance.auraInstanceID
    end)

    if not ok or not auraInstanceID then
        QueueUpdate(false)
        return
    end

    trackedAuraInstanceID = auraInstanceID

    -- On 12.0.x this is the same aura-instance fallback pattern used by
    -- TweaksUI. If Blizzard restricts the query, SafeGetAuraByInstanceID
    -- catches it and the normal event/overlay fallbacks remain active.
    local auraData = SafeGetAuraByInstanceID(auraInstanceID)
    if not ApplyAuraData(auraData, false) then
        QueueUpdate(false)
    end
end

local function HookCDMFrame(frame)
    if not frame or hookedCDMFrames[frame] or not frame.SetAuraInstanceInfo then
        return
    end

    hookedCDMFrames[frame] = true

    hooksecurefunc(frame, "SetAuraInstanceInfo", function(self, cdmAuraInstance)
        pcall(OnCDMSetAuraInstanceInfo, self, cdmAuraInstance)
    end)

    -- If this frame already represents one of our tracked procs, remember its
    -- current non-secret aura instance ID and refresh immediately.
    pcall(function()
        local frameSpellID = GetCDMFrameSpellID(frame)

        local customRow = FindCustomRowForCDMFrame(frame)
        if customRow then
            customRow.trackedCDMFrame = frame
            if frame.auraInstanceID then
                customRow.trackedAuraInstanceID = frame.auraInstanceID
            end
            if QueueCustomUpdate then
                QueueCustomUpdate(true)
            end
        end

        if frameSpellID == DEMONIC_CORE_AURA_ID
            or CDMFrameMatchesSpellID(frame, nil, DEMONIC_CORE_AURA_ID) then
            trackedCDMFrame = frame
            if frame.auraInstanceID then
                trackedAuraInstanceID = frame.auraInstanceID
            end
            QueueUpdate(true)
        end
    end)
end

local function HookCooldownViewer()
    local viewer = _G["BuffIconCooldownViewer"]
    if not viewer then
        return false
    end

    if not viewerHooked then
        viewerHooked = true

        if viewer.OnAcquireItemFrame then
            hooksecurefunc(viewer, "OnAcquireItemFrame", function(_, frame)
                HookCDMFrame(frame)
            end)
        end

        if viewer.OnReleaseItemFrame then
            hooksecurefunc(viewer, "OnReleaseItemFrame", function(_, frame)
                if frame and frame == trackedCDMFrame then
                    trackedCDMFrame = nil
                    trackedAuraInstanceID = nil
                    QueueUpdate(false)
                end

                if frame and customRows then
                    local customChanged = false
                    for _, customRow in ipairs(customRows) do
                        if customRow.trackedCDMFrame == frame then
                            customRow.trackedCDMFrame = nil
                            customRow.trackedAuraInstanceID = nil
                            customChanged = true
                        end
                    end
                    if customChanged and QueueCustomUpdate then
                        QueueCustomUpdate(false)
                    end
                end
            end)
        end
    end

    local children = { viewer:GetChildren() }
    for _, child in ipairs(children) do
        HookCDMFrame(child)
    end

    return true
end

local function SetLocked(locked)
    local db = GetDB()
    db.locked = locked and true or false

    ApplyLockState()
    UpdateProcState(true)

    if db.locked then
        Print("proc icons locked.")
    else
        Print("proc icons unlocked. Drag the icon row, then use /cdc lock.")
    end
end

local function SetScale(value)
    local db = GetDB()
    db.scale = Clamp(value, 0.50, 2.50)
    ApplyPosition()
    if ApplyCustomProcLayout then
        ApplyCustomProcLayout()
    end
end

local function ResetPosition()
    local db = GetDB()

    db.point = DEFAULTS.point
    db.relativePoint = DEFAULTS.relativePoint
    db.x = DEFAULTS.x
    db.y = DEFAULTS.y
    db.scale = DEFAULTS.scale

    db.showStackText = DEFAULTS.showStackText
    db.textSize = DEFAULTS.textSize
    db.textX = DEFAULTS.textX
    db.textY = DEFAULTS.textY

    db.iconBrightness = DEFAULTS.iconBrightness
    db.iconOpacity = DEFAULTS.iconOpacity
    db.iconPadding = DEFAULTS.iconPadding

    db.glowEnabled = DEFAULTS.glowEnabled
    db.glowPulse = DEFAULTS.glowPulse
    db.glowStyleIndex = DEFAULTS.glowStyleIndex
    db.glowColorIndex = DEFAULTS.glowColorIndex
    db.glowIntensity = DEFAULTS.glowIntensity
    db.glowThickness = DEFAULTS.glowThickness
    db.glowSpeed = DEFAULTS.glowSpeed

    ApplyPosition()
    ApplyTextSettings()
    ApplyIconLayout()
    ApplyIconVisualSettings()
    ApplyGlowSettings()
    ApplyLockState()
    UpdateProcState(true)
    Print("position and visual settings reset.")
end

local function RunVisualTest(stackCount, playSound)
    if not displayFrame then
        return
    end

    stackCount = Clamp(stackCount or MAX_DEMONIC_CORE_PROCS, 1, MAX_DEMONIC_CORE_PROCS)
    testMode = true

    SetDriverValue(stackCount)
    SetStackTextFromCount(stackCount)
    SetTestDurationCountdown()
    displayFrame:SetAlpha(1)
    displayFrame:Show()

    for _, icon in ipairs(displayFrame.previewIcons) do
        icon:Hide()
    end

    if playSound then
        PlayCue(true)
    end

    C_Timer.After(3, function()
        testMode = false
        ApplyLockState()
        UpdateProcState(true)
    end)
end

local function CreateBackdrop(frame, backgroundAlpha)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.025, 0.025, 0.03, backgroundAlpha or 0.96)
    frame:SetBackdropBorderColor(0.75, 0.04, 0.10, 1)
end

local function CreateButton(parent, label, width, height)
    local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
    button:SetSize(width or 130, height or 26)
    CreateBackdrop(button, 0.95)
    button:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")

    button.text = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.text:SetPoint("CENTER")
    button.text:SetText(label or "Button")
    button.text:SetTextColor(1, 0.82, 0.25, 1)

    button:SetScript("OnMouseDown", function(self)
        self.text:SetPoint("CENTER", 1, -1)
    end)

    button:SetScript("OnMouseUp", function(self)
        self.text:SetPoint("CENTER", 0, 0)
    end)

    return button
end

local function CreateCheckbox(parent, label)
    local checkbox = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    checkbox.text = checkbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    checkbox.text:SetPoint("LEFT", checkbox, "RIGHT", 2, 0)
    checkbox.text:SetText(label)
    checkbox.text:SetTextColor(0.92, 0.92, 0.92, 1)
    return checkbox
end

local function CreateSlider(parent, label, minimum, maximum, step, width)
    local labelText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    labelText:SetText(label)

    local slider = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
    slider:SetSize(width or 250, 18)
    slider:SetMinMaxValues(minimum, maximum)
    slider:SetValueStep(step)
    slider:SetObeyStepOnDrag(true)
    slider.Low:SetText(tostring(minimum))
    slider.High:SetText(tostring(maximum))
    slider.Text:SetText("")

    local valueText = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    valueText:SetPoint("LEFT", slider, "RIGHT", 14, 0)

    return slider, labelText, valueText
end

local function CreateDisplayFrame()
    displayFrame = CreateFrame("Frame", "ChayDemonicCoreFrame", UIParent, "BackdropTemplate")
    displayFrame:SetSize((MAX_DEMONIC_CORE_PROCS * (PROC_ICON_SIZE + DEFAULT_ICON_PADDING)) + DISPLAY_PADDING, DISPLAY_HEIGHT)
    displayFrame:SetFrameStrata("HIGH")
    displayFrame:SetClampedToScreen(true)
    displayFrame:SetClipsChildren(false)
    CreateBackdrop(displayFrame, 0.86)

    local texture = GetDemonboltTexture()

    -- While unlocked, show only empty slot outlines behind the live icons.
    -- Using a second Demonbolt texture here caused the live icon to look doubled.
    displayFrame.previewIcons = {}
    for index = 1, MAX_DEMONIC_CORE_PROCS do
        local slot = CreateFrame("Frame", nil, displayFrame, "BackdropTemplate")
        local x = DISPLAY_PADDING + ((index - 1) * (PROC_ICON_SIZE + DEFAULT_ICON_PADDING))
        slot:SetPoint("TOPLEFT", displayFrame, "TOPLEFT", x, -DISPLAY_PADDING)
        slot:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        slot:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        slot:SetBackdropColor(0.02, 0.02, 0.025, 0.45)
        slot:SetBackdropBorderColor(0.45, 0.03, 0.08, 0.80)
        displayFrame.previewIcons[index] = slot
    end

    -- Secret-safe cumulative stack driver. A value of 1/2/3/4 moves the native
    -- StatusBar fill edge by exactly one icon slot each time.
    displayFrame.stackDriver = CreateFrame("StatusBar", nil, displayFrame)
    displayFrame.stackDriver:SetPoint("TOPLEFT", displayFrame, "TOPLEFT", DISPLAY_PADDING, -DISPLAY_PADDING)
    displayFrame.stackDriver:SetSize(MAX_DEMONIC_CORE_PROCS * (PROC_ICON_SIZE + DEFAULT_ICON_PADDING), PROC_ICON_SIZE)
    displayFrame.stackDriver:SetMinMaxValues(0, MAX_DEMONIC_CORE_PROCS)
    displayFrame.stackDriver:SetValue(0)
    displayFrame.stackDriver:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    displayFrame.stackDriver:SetStatusBarColor(1, 1, 1, 0)

    local driverTexture = displayFrame.stackDriver:GetStatusBarTexture()

    displayFrame.activeClip = CreateFrame("Frame", nil, displayFrame)
    displayFrame.activeClip:SetClipsChildren(true)
    displayFrame.activeClip:SetPoint("TOPLEFT", displayFrame, "TOPLEFT", DISPLAY_PADDING, -DISPLAY_PADDING)
    displayFrame.activeClip:SetPoint("BOTTOMLEFT", displayFrame, "BOTTOMLEFT", DISPLAY_PADDING, DISPLAY_PADDING)
    displayFrame.activeClip:SetPoint("RIGHT", driverTexture, "RIGHT", 0, 0)

    displayFrame.activeIcons = {}
    displayFrame.brightIcons = {}
    displayFrame.durationFills = {}
    displayFrame.glowHolders = {}

    for index = 1, MAX_DEMONIC_CORE_PROCS do
        local x = (index - 1) * (PROC_ICON_SIZE + DEFAULT_ICON_PADDING)

        local icon = displayFrame.activeClip:CreateTexture(nil, "ARTWORK")
        icon:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
        icon:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        icon:SetTexture(texture)
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        displayFrame.activeIcons[index] = icon

        local bright = displayFrame.activeClip:CreateTexture(nil, "ARTWORK", nil, 1)
        bright:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
        bright:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        bright:SetTexture(texture)
        bright:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        bright:SetBlendMode("ADD")
        bright:Hide()
        displayFrame.brightIcons[index] = bright

        -- Blizzard-style circular cooldown swipe. The aura's DurationObject is
        -- passed directly into the Cooldown widget so protected timing values
        -- never need to be compared or converted in Lua.
        local durationFill = CreateFrame("Cooldown", nil, displayFrame.activeClip, "CooldownFrameTemplate")
        durationFill:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
        durationFill:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        durationFill:SetFrameLevel(displayFrame.activeClip:GetFrameLevel() + 2)
        durationFill:SetDrawSwipe(true)
        durationFill:SetDrawEdge(false)
        durationFill:SetDrawBling(false)
        durationFill:SetHideCountdownNumbers(true)
        durationFill:SetReverse(false)
        durationFill:SetSwipeColor(0, 0, 0, 0.62)
        durationFill:Hide()
        displayFrame.durationFills[index] = durationFill

        local glow = CreateFrame("Frame", nil, displayFrame.activeClip)
        glow:SetPoint("TOPLEFT", displayFrame.activeClip, "TOPLEFT", x, 0)
        glow:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        glow:SetFrameLevel(displayFrame.activeClip:GetFrameLevel() + 3)

        glow.borders = {
            top = glow:CreateTexture(nil, "OVERLAY"),
            bottom = glow:CreateTexture(nil, "OVERLAY"),
            left = glow:CreateTexture(nil, "OVERLAY"),
            right = glow:CreateTexture(nil, "OVERLAY"),
        }

        glow.innerBorders = {
            top = glow:CreateTexture(nil, "OVERLAY"),
            bottom = glow:CreateTexture(nil, "OVERLAY"),
            left = glow:CreateTexture(nil, "OVERLAY"),
            right = glow:CreateTexture(nil, "OVERLAY"),
        }

        glow.corners = {
            tlH = glow:CreateTexture(nil, "OVERLAY"),
            tlV = glow:CreateTexture(nil, "OVERLAY"),
            trH = glow:CreateTexture(nil, "OVERLAY"),
            trV = glow:CreateTexture(nil, "OVERLAY"),
            blH = glow:CreateTexture(nil, "OVERLAY"),
            blV = glow:CreateTexture(nil, "OVERLAY"),
            brH = glow:CreateTexture(nil, "OVERLAY"),
            brV = glow:CreateTexture(nil, "OVERLAY"),
        }

        glow.fullOverlay = glow:CreateTexture(nil, "OVERLAY")
        glow.fullOverlay:SetBlendMode("ADD")

        glow.glowAnim = glow:CreateAnimationGroup()
        glow.glowAnim:SetLooping("REPEAT")

        glow.glowIn = glow.glowAnim:CreateAnimation("Alpha")
        glow.glowIn:SetOrder(1)
        glow.glowIn:SetSmoothing("IN_OUT")

        glow.glowOut = glow.glowAnim:CreateAnimation("Alpha")
        glow.glowOut:SetOrder(2)
        glow.glowOut:SetSmoothing("IN_OUT")

        displayFrame.glowHolders[index] = glow
    end

    displayFrame.stackText = displayFrame:CreateFontString(nil, "OVERLAY")
    displayFrame.stackText:SetTextColor(1, 0.90, 0.25, 1)
    displayFrame.stackText:SetShadowColor(0, 0, 0, 1)
    displayFrame.stackText:SetShadowOffset(1, -1)

    displayFrame.lockText = displayFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    displayFrame.lockText:SetPoint("BOTTOM", displayFrame, "TOP", 0, 5)
    displayFrame.lockText:SetTextColor(0.92, 0.92, 0.92, 1)
    displayFrame.lockText:SetShadowColor(0, 0, 0, 1)
    displayFrame.lockText:SetShadowOffset(1, -1)

    displayFrame:RegisterForDrag("LeftButton")
    displayFrame:SetScript("OnDragStart", function(self)
        if GetDB().locked then
            return
        end
        self:StartMoving()
    end)

    displayFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SavePosition()
    end)

    ApplyPosition()
    ApplyTextSettings()
    ApplyIconLayout()
    ApplyIconVisualSettings()
    ApplyGlowSettings()
    ApplyLockState()
    SetInactiveVisuals()
end

-- ============================================================================
-- ALL-CLASS CUSTOM PROC TRACKER
-- Each user-added spell gets its own independently movable cumulative icon row.
-- The existing Demonic Core tracker above remains unchanged.
-- ============================================================================

local function GetCustomSpellInfo(spellID)
    spellID = tonumber(spellID)
    if not spellID or spellID <= 0 or not C_Spell then
        return nil, nil
    end

    local info
    if C_Spell.GetSpellInfo then
        pcall(function()
            info = C_Spell.GetSpellInfo(spellID)
        end)
    end

    local name = info and info.name
    local icon = info and info.iconID

    if not icon and C_Spell.GetSpellTexture then
        pcall(function()
            icon = C_Spell.GetSpellTexture(spellID)
        end)
    end

    return name, icon
end

local function ResolveCustomLinkedAuraSpellID(spellID)
    spellID = tonumber(spellID)
    if not spellID or not C_UnitAuras or not C_UnitAuras.GetCooldownAuraBySpellID then
        return nil
    end

    local linkedAuraSpellID
    local ok = pcall(function()
        linkedAuraSpellID = C_UnitAuras.GetCooldownAuraBySpellID(spellID)
    end)

    if ok and type(linkedAuraSpellID) == "number" and linkedAuraSpellID > 0 then
        return linkedAuraSpellID
    end

    return nil
end

local function NormalizeCustomProcConfig(config, index)
    if type(config) ~= "table" then
        return false
    end

    local spellID = tonumber(config.spellID)
    if not spellID or spellID <= 0 then
        return false
    end

    spellID = math.floor(spellID + 0.5)

    -- Voidfall has separate public identities for the talent/passive and the
    -- stack-bearing player aura. Keep 1256301 as the tracked/default row ID,
    -- while 1253304 is retained as a source/CDM alias so Blizzard's Cooldown
    -- Manager can hand us the non-secret auraInstanceID in restricted combat.
    if spellID == VOIDFALL_TALENT_ID or config.isBuiltInVoidfall then
        spellID = VOIDFALL_AURA_ID
        config.isBuiltInVoidfall = true
        config.sourceSpellID = VOIDFALL_TALENT_ID
    end

    config.spellID = spellID
    config.maxStacks = Clamp(math.floor((tonumber(config.maxStacks) or 1) + 0.5), 1, 8)

    if config.enabled == nil then
        config.enabled = true
    end

    local name, icon = GetCustomSpellInfo(spellID)
    if config.isBuiltInVoidfall then
        local sourceName, sourceIcon = GetCustomSpellInfo(VOIDFALL_TALENT_ID)
        config.name = name or sourceName or config.name or "Voidfall"
        config.icon = icon or sourceIcon or config.icon or 134400

        local linkedAuraSpellID = ResolveCustomLinkedAuraSpellID(VOIDFALL_TALENT_ID)
        if linkedAuraSpellID == VOIDFALL_AURA_ID then
            config.linkedAuraSpellID = linkedAuraSpellID
        else
            config.linkedAuraSpellID = VOIDFALL_AURA_ID
        end
    else
        config.name = name or config.name or ("Spell " .. spellID)
        config.icon = icon or config.icon or 134400
        config.linkedAuraSpellID = ResolveCustomLinkedAuraSpellID(spellID)
        config.sourceSpellID = nil
    end

    if not config.point then
        config.point = "CENTER"
        config.relativePoint = "CENTER"
        config.x = 0
        config.y = -230 - (((index or 1) - 1) * 82)
    end

    config.relativePoint = config.relativePoint or "CENTER"
    config.x = tonumber(config.x) or 0
    config.y = tonumber(config.y) or (-230 - (((index or 1) - 1) * 82))

    return true
end

local function CreateCustomGlowHolder(parent, x)
    local glow = CreateFrame("Frame", nil, parent)
    glow:SetPoint("TOPLEFT", parent, "TOPLEFT", x, 0)
    glow:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
    glow:SetFrameLevel(parent:GetFrameLevel() + 3)

    glow.borders = {
        top = glow:CreateTexture(nil, "OVERLAY"),
        bottom = glow:CreateTexture(nil, "OVERLAY"),
        left = glow:CreateTexture(nil, "OVERLAY"),
        right = glow:CreateTexture(nil, "OVERLAY"),
    }

    glow.innerBorders = {
        top = glow:CreateTexture(nil, "OVERLAY"),
        bottom = glow:CreateTexture(nil, "OVERLAY"),
        left = glow:CreateTexture(nil, "OVERLAY"),
        right = glow:CreateTexture(nil, "OVERLAY"),
    }

    glow.corners = {
        tlH = glow:CreateTexture(nil, "OVERLAY"),
        tlV = glow:CreateTexture(nil, "OVERLAY"),
        trH = glow:CreateTexture(nil, "OVERLAY"),
        trV = glow:CreateTexture(nil, "OVERLAY"),
        blH = glow:CreateTexture(nil, "OVERLAY"),
        blV = glow:CreateTexture(nil, "OVERLAY"),
        brH = glow:CreateTexture(nil, "OVERLAY"),
        brV = glow:CreateTexture(nil, "OVERLAY"),
    }

    glow.fullOverlay = glow:CreateTexture(nil, "OVERLAY")
    glow.fullOverlay:SetBlendMode("ADD")

    glow.glowAnim = glow:CreateAnimationGroup()
    glow.glowAnim:SetLooping("REPEAT")

    glow.glowIn = glow.glowAnim:CreateAnimation("Alpha")
    glow.glowIn:SetOrder(1)
    glow.glowIn:SetSmoothing("IN_OUT")

    glow.glowOut = glow.glowAnim:CreateAnimation("Alpha")
    glow.glowOut:SetOrder(2)
    glow.glowOut:SetSmoothing("IN_OUT")

    return glow
end

local function CreateCustomRowShell(maxStacks)
    local row = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    row.maxStacks = maxStacks
    row:SetFrameStrata("HIGH")
    row:SetClampedToScreen(true)
    row:SetClipsChildren(false)
    CreateBackdrop(row, 0.86)

    row.previewIcons = {}
    row.activeIcons = {}
    row.brightIcons = {}
    row.durationFills = {}
    row.glowHolders = {}

    for index = 1, maxStacks do
        local slot = CreateFrame("Frame", nil, row, "BackdropTemplate")
        slot:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        slot:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        slot:SetBackdropColor(0.02, 0.02, 0.025, 0.45)
        slot:SetBackdropBorderColor(0.45, 0.03, 0.08, 0.80)
        row.previewIcons[index] = slot
    end

    row.stackDriver = CreateFrame("StatusBar", nil, row)
    row.stackDriver:SetPoint("TOPLEFT", row, "TOPLEFT", DISPLAY_PADDING, -DISPLAY_PADDING)
    row.stackDriver:SetMinMaxValues(0, maxStacks)
    row.stackDriver:SetValue(0)
    row.stackDriver:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    row.stackDriver:SetStatusBarColor(1, 1, 1, 0)

    local driverTexture = row.stackDriver:GetStatusBarTexture()

    row.activeClip = CreateFrame("Frame", nil, row)
    row.activeClip:SetClipsChildren(true)
    row.activeClip:SetPoint("TOPLEFT", row, "TOPLEFT", DISPLAY_PADDING, -DISPLAY_PADDING)
    row.activeClip:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", DISPLAY_PADDING, DISPLAY_PADDING)
    row.activeClip:SetPoint("RIGHT", driverTexture, "RIGHT", 0, 0)

    for index = 1, maxStacks do
        local icon = row.activeClip:CreateTexture(nil, "ARTWORK")
        icon:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        row.activeIcons[index] = icon

        local bright = row.activeClip:CreateTexture(nil, "ARTWORK", nil, 1)
        bright:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        bright:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        bright:SetBlendMode("ADD")
        bright:Hide()
        row.brightIcons[index] = bright

        local cooldown = CreateFrame("Cooldown", nil, row.activeClip, "CooldownFrameTemplate")
        cooldown:SetSize(PROC_ICON_SIZE, PROC_ICON_SIZE)
        cooldown:SetFrameLevel(row.activeClip:GetFrameLevel() + 2)
        cooldown:SetDrawSwipe(true)
        cooldown:SetDrawEdge(false)
        cooldown:SetDrawBling(false)
        cooldown:SetHideCountdownNumbers(true)
        cooldown:SetReverse(false)
        cooldown:SetSwipeColor(0, 0, 0, 0.62)
        cooldown:Hide()
        row.durationFills[index] = cooldown

        row.glowHolders[index] = CreateCustomGlowHolder(row.activeClip, 0)
    end

    row.stackText = row:CreateFontString(nil, "OVERLAY")
    row.stackText:SetTextColor(1, 0.90, 0.25, 1)
    row.stackText:SetShadowColor(0, 0, 0, 1)
    row.stackText:SetShadowOffset(1, -1)

    row.lockText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.lockText:SetPoint("BOTTOM", row, "TOP", 0, 5)
    row.lockText:SetTextColor(0.92, 0.92, 0.92, 1)
    row.lockText:SetShadowColor(0, 0, 0, 1)
    row.lockText:SetShadowOffset(1, -1)

    row:RegisterForDrag("LeftButton")
    row:SetScript("OnDragStart", function(self)
        if GetDB().locked or not self.config or self.config.enabled == false then
            return
        end
        self:StartMoving()
    end)

    row:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        if not self.config then
            return
        end

        local point, _, relativePoint, xOffset, yOffset = self:GetPoint(1)
        self.config.point = point or "CENTER"
        self.config.relativePoint = relativePoint or "CENTER"
        self.config.x = xOffset or 0
        self.config.y = yOffset or 0
    end)

    row:Hide()
    return row
end

local function AcquireCustomRow(maxStacks)
    for index = #customRowPool, 1, -1 do
        local row = customRowPool[index]
        if row.maxStacks == maxStacks then
            table.remove(customRowPool, index)
            return row
        end
    end

    return CreateCustomRowShell(maxStacks)
end

local function ReleaseCustomRow(row)
    if not row then
        return
    end

    row:Hide()
    row.config = nil
    row.procWasActive = false
    row.lastReadableCount = nil
    row.trackedAuraInstanceID = nil
    row.trackedCDMFrame = nil
    row.testMode = false

    if row.stackDriver then
        pcall(row.stackDriver.SetValue, row.stackDriver, 0)
    end

    if row.stackText then
        row.stackText:SetText("")
        row.stackText:Hide()
    end

    if row.durationFills then
        for _, cooldown in ipairs(row.durationFills) do
            cooldown:Clear()
            cooldown:Hide()
        end
    end

    customRowPool[#customRowPool + 1] = row
end

local function SetupCustomRow(row, config, index)
    row.config = config
    row.procWasActive = false
    row.lastReadableCount = nil
    row.trackedAuraInstanceID = nil
    row.trackedCDMFrame = nil
    row.testMode = false

    local iconTexture = config.icon or 134400
    for iconIndex = 1, row.maxStacks do
        row.activeIcons[iconIndex]:SetTexture(iconTexture)
        row.brightIcons[iconIndex]:SetTexture(iconTexture)
    end

    row.lockText:SetText((config.name or ("Spell " .. config.spellID)) .. " [" .. config.spellID .. "] - DRAG")

    row:ClearAllPoints()
    row:SetPoint(
        config.point or "CENTER",
        UIParent,
        config.relativePoint or "CENTER",
        config.x or 0,
        config.y or (-230 - ((index - 1) * 82))
    )
end

ApplyCustomProcLayout = function()
    local db = GetDB()
    local iconPadding = Clamp(db.iconPadding or DEFAULTS.iconPadding, 0, 30)
    local pitch = PROC_ICON_SIZE + iconPadding

    for _, row in ipairs(customRows) do
        local driverWidth = row.maxStacks * pitch
        row:SetSize(driverWidth + DISPLAY_PADDING, DISPLAY_HEIGHT)
        row:SetScale(Clamp(db.scale or DEFAULTS.scale, 0.50, 2.50))
        row.stackDriver:SetSize(driverWidth, PROC_ICON_SIZE)

        for index = 1, row.maxStacks do
            local previewX = DISPLAY_PADDING + ((index - 1) * pitch)
            row.previewIcons[index]:ClearAllPoints()
            row.previewIcons[index]:SetPoint("TOPLEFT", row, "TOPLEFT", previewX, -DISPLAY_PADDING)

            local x = (index - 1) * pitch
            row.activeIcons[index]:ClearAllPoints()
            row.activeIcons[index]:SetPoint("TOPLEFT", row.activeClip, "TOPLEFT", x, 0)

            row.brightIcons[index]:ClearAllPoints()
            row.brightIcons[index]:SetPoint("TOPLEFT", row.activeClip, "TOPLEFT", x, 0)

            row.durationFills[index]:ClearAllPoints()
            row.durationFills[index]:SetPoint("TOPLEFT", row.activeClip, "TOPLEFT", x, 0)

            row.glowHolders[index]:ClearAllPoints()
            row.glowHolders[index]:SetPoint("TOPLEFT", row.activeClip, "TOPLEFT", x, 0)
        end
    end
end

ApplyCustomProcTextSettings = function()
    local db = GetDB()
    local fontPath = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"

    for _, row in ipairs(customRows) do
        row.stackText:SetFont(fontPath, Clamp(db.textSize or DEFAULTS.textSize, 8, 48), "OUTLINE")
        row.stackText:ClearAllPoints()
        row.stackText:SetPoint("TOP", row, "BOTTOM", 0, -4)

        if not db.showStackText or not row.procWasActive then
            row.stackText:Hide()
        end
    end
end

ApplyCustomProcVisualSettings = function()
    local db = GetDB()
    local brightness = Clamp(db.iconBrightness or DEFAULTS.iconBrightness, 0.25, 2.50)
    local opacity = Clamp(db.iconOpacity or DEFAULTS.iconOpacity, 0.10, 1.00)
    local baseBrightness = math.min(brightness, 1.00)
    local additiveAlpha = 0

    if brightness > 1.00 then
        additiveAlpha = Clamp((brightness - 1.00) * 0.55, 0, 0.82)
    end

    for _, row in ipairs(customRows) do
        for index = 1, row.maxStacks do
            local icon = row.activeIcons[index]
            icon:SetVertexColor(baseBrightness, baseBrightness, baseBrightness, 1)
            icon:SetAlpha(opacity)

            local bright = row.brightIcons[index]
            bright:SetAlpha(opacity * additiveAlpha)
            if additiveAlpha > 0 then
                bright:Show()
            else
                bright:Hide()
            end

            row.durationFills[index]:SetAlpha(opacity)
            row.previewIcons[index]:SetAlpha(math.max(0.20, opacity * 0.55))
        end
    end
end

ApplyCustomProcGlowSettings = function()
    local db = GetDB()
    local enabled = db.glowEnabled and true or false
    local pulse = db.glowPulse and true or false
    local intensity = Clamp(db.glowIntensity or DEFAULTS.glowIntensity, 0.20, 1.00)
    local speed = Clamp(db.glowSpeed or DEFAULTS.glowSpeed, 0.20, 2.00)
    local thickness = Clamp(db.glowThickness or DEFAULTS.glowThickness, 1, 6)
    local style = GetGlowStyle()
    local color = GetGlowColor()

    for _, row in ipairs(customRows) do
        local rowActive = (row.procWasActive or row.testMode) and row.config and row.config.enabled ~= false

        for _, holder in ipairs(row.glowHolders) do
            ConfigureGlowStyle(holder, style, thickness, color)

            if enabled and rowActive then
                holder:Show()

                if pulse then
                    holder.glowIn:SetDuration(speed * 0.5)
                    holder.glowOut:SetDuration(speed * 0.5)
                    holder.glowIn:SetFromAlpha(math.max(0.10, intensity * 0.28))
                    holder.glowIn:SetToAlpha(intensity)
                    holder.glowOut:SetFromAlpha(intensity)
                    holder.glowOut:SetToAlpha(math.max(0.10, intensity * 0.28))
                    if not holder.glowAnim:IsPlaying() then
                        holder.glowAnim:Play()
                    end
                else
                    if holder.glowAnim:IsPlaying() then
                        holder.glowAnim:Stop()
                    end
                    holder:SetAlpha(intensity)
                end
            else
                if holder.glowAnim:IsPlaying() then
                    holder.glowAnim:Stop()
                end
                holder:Hide()
            end
        end
    end
end

ApplyCustomProcLockState = function()
    local db = GetDB()
    local unlocked = not db.locked

    for _, row in ipairs(customRows) do
        local enabled = row.config and row.config.enabled ~= false

        row:EnableMouse(unlocked and enabled)
        row:SetMovable(unlocked and enabled)

        if not enabled then
            row:Hide()
        elseif unlocked then
            row:SetBackdropColor(0.025, 0.025, 0.03, 0.86)
            row:SetBackdropBorderColor(0.75, 0.04, 0.10, 1)
            row.lockText:Show()
            row:Show()

            for _, preview in ipairs(row.previewIcons) do
                if row.procWasActive or row.testMode then
                    preview:Hide()
                else
                    preview:Show()
                end
            end
        else
            row:SetBackdropColor(0, 0, 0, 0)
            row:SetBackdropBorderColor(0, 0, 0, 0)
            row.lockText:Hide()
            for _, preview in ipairs(row.previewIcons) do
                preview:Hide()
            end

            if row.procWasActive or row.testMode then
                row:Show()
            else
                row:Hide()
            end
        end
    end
end

local function ClearCustomCooldowns(row)
    for _, cooldown in ipairs(row.durationFills) do
        cooldown:Clear()
        cooldown:Hide()
    end
end

local function ApplyCustomCooldowns(row, auraInstanceID, auraData)
    local applied = false

    if auraInstanceID and C_UnitAuras and C_UnitAuras.GetAuraDuration then
        local ok, durationObject = pcall(C_UnitAuras.GetAuraDuration, "player", auraInstanceID)
        if ok and durationObject then
            for _, cooldown in ipairs(row.durationFills) do
                local setOk = pcall(cooldown.SetCooldownFromDurationObject, cooldown, durationObject, true)
                if setOk then
                    cooldown:Show()
                    applied = true
                else
                    cooldown:Clear()
                    cooldown:Hide()
                end
            end
        end
    end

    if not applied and auraData then
        local expirationTime
        local duration
        local ok = pcall(function()
            expirationTime = auraData.expirationTime
            duration = auraData.duration
        end)

        if ok then
            for _, cooldown in ipairs(row.durationFills) do
                local setOk = pcall(cooldown.SetCooldownFromExpirationTime, cooldown, expirationTime, duration)
                if setOk then
                    cooldown:Show()
                    applied = true
                else
                    cooldown:Clear()
                    cooldown:Hide()
                end
            end
        end
    end

    if not applied then
        ClearCustomCooldowns(row)
    end

    return applied
end

local function SetCustomStackText(row, auraInstanceID, applicationCount)
    local db = GetDB()
    if not db.showStackText then
        row.stackText:SetText("")
        row.stackText:Hide()
        return
    end

    if auraInstanceID and C_UnitAuras and C_UnitAuras.GetAuraApplicationDisplayCount then
        local ok = pcall(function()
            row.stackText:SetText(
                C_UnitAuras.GetAuraApplicationDisplayCount("player", auraInstanceID, 1, row.maxStacks)
            )
            row.stackText:Show()
        end)
        if ok then
            return
        end
    end

    if IsSecretValue(applicationCount) then
        row.stackText:SetText("")
        row.stackText:Hide()
        return
    end

    row.stackText:SetText(tostring(tonumber(applicationCount) or 1))
    row.stackText:Show()
end

local function SetCustomDriverValue(row, applicationCount)
    if IsSecretValue(applicationCount) then
        pcall(row.stackDriver.SetValue, row.stackDriver, applicationCount)
        return
    end

    local readableCount = tonumber(applicationCount) or 1
    row.stackDriver:SetValue(Clamp(readableCount, 0, row.maxStacks))
end

local function HandleCustomSound(row, applicationCount, silent)
    if silent then
        if not IsSecretValue(applicationCount) then
            row.lastReadableCount = tonumber(applicationCount)
        else
            row.lastReadableCount = nil
        end
        return
    end

    local firstProcAppeared = not row.procWasActive
    local countIncreased = false

    if not IsSecretValue(applicationCount) then
        local readableCount = tonumber(applicationCount)
        if readableCount and row.lastReadableCount and readableCount > row.lastReadableCount then
            countIncreased = true
        end
        row.lastReadableCount = readableCount
    else
        row.lastReadableCount = nil
    end

    if firstProcAppeared or countIncreased then
        PlayCue(false)
    end
end

local function SetCustomRowInactive(row)
    row.procWasActive = false
    row.lastReadableCount = nil
    row.stackDriver:SetValue(0)
    row.stackText:SetText("")
    row.stackText:Hide()
    ClearCustomCooldowns(row)

    for _, holder in ipairs(row.glowHolders) do
        if holder.glowAnim:IsPlaying() then
            holder.glowAnim:Stop()
        end
        holder:Hide()
    end

    ApplyCustomProcLockState()
end

local function SetCustomRowActive(row, applicationCount, auraInstanceID, auraData, silent)
    if not row or not row.config or row.config.enabled == false then
        return
    end

    if auraInstanceID then
        row.trackedAuraInstanceID = auraInstanceID
    end

    SetCustomDriverValue(row, applicationCount)
    SetCustomStackText(row, auraInstanceID or row.trackedAuraInstanceID, applicationCount)
    ApplyCustomCooldowns(row, auraInstanceID or row.trackedAuraInstanceID, auraData)
    HandleCustomSound(row, applicationCount, silent)

    row.procWasActive = true
    row:Show()

    for _, preview in ipairs(row.previewIcons) do
        preview:Hide()
    end

    ApplyCustomProcVisualSettings()
    ApplyCustomProcGlowSettings()
    ApplyCustomProcLockState()
end

local function SafeGetCustomAuraBySpellID(spellID)
    if not spellID or not C_UnitAuras or not C_UnitAuras.GetPlayerAuraBySpellID then
        return nil
    end

    local ok, auraData = pcall(C_UnitAuras.GetPlayerAuraBySpellID, spellID)
    if ok then
        return auraData
    end

    return nil
end

local function IsCustomOverlayActive(spellID)
    if not spellID or not C_SpellActivationOverlay or not C_SpellActivationOverlay.IsSpellOverlayed then
        return false
    end

    local active = false
    local ok = pcall(function()
        active = C_SpellActivationOverlay.IsSpellOverlayed(spellID) and true or false
    end)

    return ok and active or false
end

local function ApplyCustomAuraData(row, auraData, silent)
    if not row or not auraData then
        return false
    end

    local applicationCount
    local auraInstanceID

    local ok = pcall(function()
        applicationCount = auraData.applications
        auraInstanceID = auraData.auraInstanceID
    end)

    if not ok then
        return false
    end

    if not IsSecretValue(applicationCount) and applicationCount == nil then
        applicationCount = 1
    end

    SetCustomRowActive(row, applicationCount, auraInstanceID, auraData, silent)
    return true
end

local function UpdateCustomRowState(row, silent)
    if not row or not row.config or row.testMode then
        return
    end

    if row.config.enabled == false then
        SetCustomRowInactive(row)
        row:Hide()
        return
    end

    local auraData = SafeGetCustomAuraBySpellID(row.config.spellID)
    if ApplyCustomAuraData(row, auraData, silent) then
        return
    end

    local linkedAuraSpellID = row.config.linkedAuraSpellID
    if row.config.isBuiltInVoidfall then
        linkedAuraSpellID = VOIDFALL_AURA_ID
        row.config.linkedAuraSpellID = VOIDFALL_AURA_ID
        customRowsBySpellID[VOIDFALL_AURA_ID] = row
        customRowsBySpellID[VOIDFALL_TALENT_ID] = row
    elseif row.config.sourceSpellID then
        local resolvedFromSource = ResolveCustomLinkedAuraSpellID(row.config.sourceSpellID)
        if resolvedFromSource then
            linkedAuraSpellID = resolvedFromSource
            row.config.linkedAuraSpellID = resolvedFromSource
            customRowsBySpellID[resolvedFromSource] = row
        end
    elseif not linkedAuraSpellID then
        linkedAuraSpellID = ResolveCustomLinkedAuraSpellID(row.config.spellID)
        row.config.linkedAuraSpellID = linkedAuraSpellID
        if linkedAuraSpellID then
            customRowsBySpellID[linkedAuraSpellID] = row
        end
    end

    if linkedAuraSpellID and linkedAuraSpellID ~= row.config.spellID then
        auraData = SafeGetCustomAuraBySpellID(linkedAuraSpellID)
        if ApplyCustomAuraData(row, auraData, silent) then
            return
        end
    end

    -- In restricted Midnight combat the direct spell-ID aura query can be
    -- unavailable/secret. The Blizzard Cooldown Manager bridge gives us a
    -- NeverSecret auraInstanceID, which is then sufficient to drive the same
    -- secret-safe StatusBar/cooldown pass-through path used by Demonic Core.
    if row.trackedAuraInstanceID then
        auraData = SafeGetAuraByInstanceID(row.trackedAuraInstanceID)
        if ApplyCustomAuraData(row, auraData, silent) then
            return
        end
    end

    if IsCustomOverlayActive(row.config.spellID)
        or (row.config.sourceSpellID and IsCustomOverlayActive(row.config.sourceSpellID)) then
        SetCustomRowActive(row, 1, row.trackedAuraInstanceID, nil, silent)
        return
    end

    SetCustomRowInactive(row)
end

UpdateAllCustomProcStates = function(silent)
    for _, row in ipairs(customRows) do
        UpdateCustomRowState(row, silent)
    end
end

QueueCustomUpdate = function(silent)
    if not customUpdateQueued then
        customUpdateSilent = silent and true or false
        customUpdateQueued = true

        C_Timer.After(0, function()
            local useSilent = customUpdateSilent
            customUpdateQueued = false
            customUpdateSilent = true
            UpdateAllCustomProcStates(useSilent)
        end)
    elseif not silent then
        customUpdateSilent = false
    end
end

FindCustomRowForSpellID = function(spellID)
    if spellID == nil or IsSecretValue(spellID) then
        return nil
    end

    local numericSpellID = tonumber(spellID)
    if not numericSpellID then
        return nil
    end

    return customRowsBySpellID[numericSpellID]
end

RebuildCustomRows = function()
    for _, row in ipairs(customRows) do
        ReleaseCustomRow(row)
    end

    customRows = {}
    customRowsBySpellID = {}

    local db = GetDB()
    local validConfigs = {}

    for index, config in ipairs(db.customProcs) do
        if NormalizeCustomProcConfig(config, index) then
            validConfigs[#validConfigs + 1] = config
        end
    end

    db.customProcs = validConfigs

    for index, config in ipairs(db.customProcs) do
        local row = AcquireCustomRow(config.maxStacks)
        SetupCustomRow(row, config, index)
        customRows[#customRows + 1] = row
        customRowsBySpellID[config.spellID] = row
        if config.linkedAuraSpellID then
            customRowsBySpellID[config.linkedAuraSpellID] = row
        end
        if config.sourceSpellID then
            customRowsBySpellID[config.sourceSpellID] = row
        end
    end

    ApplyCustomProcLayout()
    ApplyCustomProcTextSettings()
    ApplyCustomProcVisualSettings()
    ApplyCustomProcGlowSettings()
    ApplyCustomProcLockState()
    QueueCustomUpdate(true)

    if HookCooldownViewer then
        HookCooldownViewer()
    end
end

RunCustomProcTest = function(row)
    if not row or not row.config or row.config.enabled == false then
        return
    end

    row.testMode = true
    SetCustomRowActive(row, row.maxStacks, nil, nil, true)

    if C_DurationUtil and C_DurationUtil.CreateDuration then
        local durationObject = C_DurationUtil.CreateDuration()
        if durationObject and durationObject.SetTimeFromStart then
            durationObject:SetTimeFromStart(GetTime(), 20)
            for _, cooldown in ipairs(row.durationFills) do
                local ok = pcall(cooldown.SetCooldownFromDurationObject, cooldown, durationObject, true)
                if ok then
                    cooldown:Show()
                end
            end
        end
    end

    PlayCue(true)

    C_Timer.After(3, function()
        if not row.config then
            return
        end
        row.testMode = false
        UpdateCustomRowState(row, true)
    end)
end

local function IsCustomProcAlreadyAdded(spellID)
    spellID = tonumber(spellID)
    if not spellID then
        return false
    end

    for _, config in ipairs(GetDB().customProcs) do
        if tonumber(config.spellID) == spellID then
            return true
        end
    end

    return false
end

local function GetSavedProcEntry(spellID)
    spellID = tonumber(spellID)
    if not spellID then
        return nil, nil
    end

    for index, entry in ipairs(GetDB().savedProcs) do
        if tonumber(entry.spellID) == spellID then
            return entry, index
        end
    end

    return nil, nil
end

local function RememberSavedProc(spellID, maxStacks, name, icon, source, preserveExistingMaxStacks)
    spellID = tonumber(spellID)
    if not spellID or spellID <= 0 then
        return false
    end

    spellID = math.floor(spellID + 0.5)
    maxStacks = Clamp(math.floor((tonumber(maxStacks) or 1) + 0.5), 1, 8)

    local resolvedName, resolvedIcon = GetCustomSpellInfo(spellID)
    name = resolvedName or name or ("Spell " .. spellID)
    icon = resolvedIcon or icon or 134400
    source = source or "manual"

    local autoClassFile, autoClassID, autoClassName
    if source == "auto" then
        autoClassFile, autoClassID, autoClassName = GetCurrentPlayerClassMetadata()
    end

    local db = GetDB()
    local entry, index = GetSavedProcEntry(spellID)

    if entry then
        entry.spellID = spellID
        if not preserveExistingMaxStacks then
            entry.maxStacks = maxStacks
        elseif not tonumber(entry.maxStacks) then
            entry.maxStacks = maxStacks
        end
        entry.name = name
        entry.icon = icon

        -- An automatic proc event is authoritative for the class that learned
        -- it because the event fired for this character. Manual Spell IDs are
        -- deliberately not assigned to a class; that would require guessing.
        if source == "auto" and autoClassFile and autoClassID then
            entry.classFile = autoClassFile
            entry.classID = autoClassID
            entry.className = autoClassName
        end

        -- Manual use takes precedence over the automatic discovery label.
        if source == "manual" or not entry.source then
            entry.source = source
        end

        -- Only manual interaction reorders an existing entry. Auto-discovery
        -- can fire frequently, so it must not churn SavedVariables or the UI.
        if source == "manual" and index and index > 1 then
            table.remove(db.savedProcs, index)
            table.insert(db.savedProcs, 1, entry)
        end

        if RefreshSavedProcList then
            RefreshSavedProcList()
        end
        return false
    end

    table.insert(db.savedProcs, 1, {
        spellID = spellID,
        maxStacks = maxStacks,
        name = name,
        icon = icon,
        source = source,
        classFile = source == "auto" and autoClassFile or nil,
        classID = source == "auto" and autoClassID or nil,
        className = source == "auto" and autoClassName or nil,
    })

    -- A character should never need an unbounded history. Forty remembered
    -- proc IDs keeps the list useful without growing SavedVariables forever.
    while #db.savedProcs > 40 do
        table.remove(db.savedProcs)
    end

    if RefreshSavedProcList then
        RefreshSavedProcList()
    end

    return true
end

local function BackfillAutoProcClassMetadata()
    local classFile, classID, className = GetCurrentPlayerClassMetadata()
    if not classFile or not classID then
        return
    end

    -- Version 1.3.2 already saved the library per character, so an older AUTO
    -- entry without class metadata can safely inherit this character's class.
    -- Manual entries stay unclassified because their Spell IDs may belong to
    -- any class and the addon must not guess.
    for _, entry in ipairs(GetDB().savedProcs) do
        if type(entry) == "table" and entry.source == "auto" and not entry.classFile then
            entry.classFile = classFile
            entry.classID = classID
            entry.className = className
        end
    end
end

local function EnsureBuiltInDefaultProcs()
    local db = GetDB()
    local currentVersion = tonumber(db.builtInDefaultProcVersion) or 0
    if currentVersion >= BUILTIN_DEFAULT_PROC_VERSION then
        return
    end

    local voidfallConfig
    local voidfallIndex

    -- Prefer an existing 1256301 row because that is the actual stack aura.
    -- This also preserves the user's existing row position/settings when the
    -- previous 1.3.4 default is being migrated.
    for index, config in ipairs(db.customProcs) do
        if type(config) == "table" then
            local spellID = tonumber(config.spellID)
            if spellID == VOIDFALL_AURA_ID or config.isBuiltInVoidfall then
                voidfallConfig = config
                voidfallIndex = index
                break
            end
        end
    end

    -- Older tests may have added the talent/passive ID instead. Reuse that row
    -- only when there was no 1256301 row to preserve.
    if not voidfallConfig then
        for index, config in ipairs(db.customProcs) do
            if type(config) == "table" and tonumber(config.spellID) == VOIDFALL_TALENT_ID then
                voidfallConfig = config
                voidfallIndex = index
                break
            end
        end
    end

    if voidfallConfig then
        -- Migrate either the original failed 1256301 default or an older
        -- manually-added 1253304 row into one canonical Voidfall tracker.
        voidfallConfig.spellID = VOIDFALL_AURA_ID
        voidfallConfig.sourceSpellID = VOIDFALL_TALENT_ID
        voidfallConfig.linkedAuraSpellID = VOIDFALL_AURA_ID
        voidfallConfig.isBuiltInVoidfall = true
        if (tonumber(voidfallConfig.maxStacks) or 1) <= 1 then
            voidfallConfig.maxStacks = 3
        end

        local auraName, auraIcon = GetCustomSpellInfo(VOIDFALL_AURA_ID)
        local talentName, talentIcon = GetCustomSpellInfo(VOIDFALL_TALENT_ID)
        voidfallConfig.name = auraName or talentName or voidfallConfig.name or "Voidfall"
        voidfallConfig.icon = auraIcon or talentIcon or voidfallConfig.icon or 134400

        -- If both IDs were added while troubleshooting, collapse them to the
        -- one canonical row so two UI rows cannot fight over the same aliases.
        for index = #db.customProcs, 1, -1 do
            if index ~= voidfallIndex then
                local config = db.customProcs[index]
                if type(config) == "table" then
                    local spellID = tonumber(config.spellID)
                    if spellID == VOIDFALL_AURA_ID or spellID == VOIDFALL_TALENT_ID or config.isBuiltInVoidfall then
                        table.remove(db.customProcs, index)
                    end
                end
            end
        end
    else
        local index = #db.customProcs + 1
        local auraName, auraIcon = GetCustomSpellInfo(VOIDFALL_AURA_ID)
        local talentName, talentIcon = GetCustomSpellInfo(VOIDFALL_TALENT_ID)

        db.customProcs[index] = {
            spellID = VOIDFALL_AURA_ID,
            sourceSpellID = VOIDFALL_TALENT_ID,
            linkedAuraSpellID = VOIDFALL_AURA_ID,
            isBuiltInVoidfall = true,
            maxStacks = 3,
            enabled = true,
            name = auraName or talentName or "Voidfall",
            icon = auraIcon or talentIcon or 134400,
            point = "CENTER",
            relativePoint = "CENTER",
            x = 0,
            y = -230 - ((index - 1) * 82),
        }
    end

    -- Remove the obsolete source-ID quick-add entry from previous testing. The
    -- canonical 1256301 row is re-seeded into savedProcs immediately afterward.
    for index = #db.savedProcs, 1, -1 do
        local entry = db.savedProcs[index]
        if type(entry) == "table" and tonumber(entry.spellID) == VOIDFALL_TALENT_ID then
            table.remove(db.savedProcs, index)
        end
    end

    db.builtInDefaultProcVersion = BUILTIN_DEFAULT_PROC_VERSION
end

local function SeedSavedProcListFromCurrentRows()
    local db = GetDB()
    for index = #db.customProcs, 1, -1 do
        local config = db.customProcs[index]
        if type(config) == "table" and tonumber(config.spellID) then
            RememberSavedProc(config.spellID, config.maxStacks, config.name, config.icon, "manual")
        end
    end
end

local function DiscoverProcSpellID(spellID)
    local db = GetDB()
    if db.autoLearnProcIDs == false then
        return false
    end

    if spellID == nil or IsSecretValue(spellID) or type(spellID) ~= "number" then
        return false
    end

    spellID = math.floor(spellID + 0.5)
    if spellID <= 0 then
        return false
    end

    -- Demonic Core is already the addon's dedicated four-stack tracker.
    -- Do not create a duplicate quick-add entry for its own overlay.
    if spellID == DEMONBOLT_SPELL_ID or spellID == DEMONIC_CORE_AURA_ID
        or spellID == VOIDFALL_TALENT_ID or spellID == VOIDFALL_AURA_ID then
        return false
    end

    if GetSavedProcEntry(spellID) then
        return false
    end

    local name, icon = GetCustomSpellInfo(spellID)
    if not name and not icon then
        return false
    end

    -- Blizzard's proc-overlay event identifies the proc spell directly.
    -- The stack count is not implied by that event, so newly learned entries
    -- default to one icon and can be changed in the manager after adding.
    return RememberSavedProc(spellID, 1, name, icon, "auto", true)
end

local function AddCustomProc(spellID, maxStacks)
    spellID = tonumber(spellID)
    maxStacks = Clamp(math.floor((tonumber(maxStacks) or 1) + 0.5), 1, 8)

    if not spellID or spellID <= 0 then
        Print("enter a valid numeric Spell ID.")
        return false
    end

    spellID = math.floor(spellID + 0.5)
    local name, icon = GetCustomSpellInfo(spellID)
    if not name and not icon then
        Print("Spell ID " .. spellID .. " was not found by the current client.")
        return false
    end

    local db = GetDB()
    if IsCustomProcAlreadyAdded(spellID) then
        Print((name or ("Spell " .. spellID)) .. " is already added.")
        RememberSavedProc(spellID, maxStacks, name, icon, "manual")
        return false
    end

    local index = #db.customProcs + 1
    db.customProcs[index] = {
        spellID = spellID,
        maxStacks = maxStacks,
        enabled = true,
        name = name or ("Spell " .. spellID),
        icon = icon or 134400,
        linkedAuraSpellID = ResolveCustomLinkedAuraSpellID(spellID),
        point = "CENTER",
        relativePoint = "CENTER",
        x = 0,
        y = -230 - ((index - 1) * 82),
    }

    RememberSavedProc(spellID, maxStacks, name, icon, "manual")
    RebuildCustomRows()
    RefreshCustomProcOptions()
    if RefreshSavedProcList then
        RefreshSavedProcList()
    end
    Print("added " .. (name or ("Spell " .. spellID)) .. " [" .. spellID .. "] with up to " .. maxStacks .. " icon(s).")
    return true
end

local function RemoveCustomProcBySpellID(spellID)
    spellID = tonumber(spellID)
    if not spellID then
        return false
    end

    local db = GetDB()
    for index, config in ipairs(db.customProcs) do
        if tonumber(config.spellID) == spellID then
            local name = config.name or ("Spell " .. spellID)
            table.remove(db.customProcs, index)
            RebuildCustomRows()
            RefreshCustomProcOptions()
            if RefreshSavedProcList then
                RefreshSavedProcList()
            end
            Print("removed " .. name .. " [" .. spellID .. "].")
            return true
        end
    end

    Print("Spell ID " .. spellID .. " is not in the custom proc list.")
    return false
end

local function CreateProcManagerEditBox(parent, width, numeric)
    local editBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    editBox:SetSize(width, 26)
    editBox:SetAutoFocus(false)
    editBox:SetFontObject("GameFontHighlight")
    editBox:SetJustifyH("CENTER")
    editBox:SetTextInsets(5, 5, 0, 0)
    editBox:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    editBox:SetBackdropColor(0.015, 0.015, 0.02, 0.96)
    editBox:SetBackdropBorderColor(0.75, 0.04, 0.10, 1)
    if numeric then
        editBox:SetNumeric(true)
    end
    editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    return editBox
end

local function CreateCustomProcManager()
    if customProcManager then
        return customProcManager
    end

    local manager = CreateFrame("Frame", "ChayDemonicCoreProcManager", UIParent, "BackdropTemplate")
    manager:SetSize(650, 720)

    local db = GetDB()
    manager:SetPoint(
        db.procManagerPoint or DEFAULTS.procManagerPoint,
        UIParent,
        db.procManagerRelativePoint or DEFAULTS.procManagerRelativePoint,
        db.procManagerX or DEFAULTS.procManagerX,
        db.procManagerY or DEFAULTS.procManagerY
    )
    manager:SetFrameStrata("DIALOG")
    manager:SetClampedToScreen(true)
    manager:EnableMouse(true)
    manager:SetMovable(true)
    CreateBackdrop(manager, 0.98)
    customProcManager = manager

    manager:RegisterForDrag("LeftButton")
    manager:SetScript("OnDragStart", function(self) self:StartMoving() end)
    manager:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relativePoint, xOffset, yOffset = self:GetPoint(1)
        local db = GetDB()
        db.procManagerPoint = point or DEFAULTS.procManagerPoint
        db.procManagerRelativePoint = relativePoint or DEFAULTS.procManagerRelativePoint
        db.procManagerX = xOffset or DEFAULTS.procManagerX
        db.procManagerY = yOffset or DEFAULTS.procManagerY
    end)

    local title = manager:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -16)
    title:SetText("All-Class Proc Manager")
    title:SetTextColor(1, 0.82, 0.25, 1)

    local subtitle = manager:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOP", title, "BOTTOM", 0, -6)
    subtitle:SetWidth(590)
    subtitle:SetText("Saved separately for each character. Auto-learned IDs are tagged and sorted by the class that triggered them.")

    local hint = manager:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOP", subtitle, "BOTTOM", 0, -4)
    hint:SetWidth(590)
    hint:SetText("Auto-learn uses Blizzard proc-overlay events only; no spell scanning or polling. Max Icons controls cumulative stack icons (1-8).")
    hint:SetTextColor(0.78, 0.78, 0.78, 1)

    local close = CreateButton(manager, "X", 28, 24)
    close:SetPoint("TOPRIGHT", -9, -9)
    close:SetScript("OnClick", function() manager:Hide() end)

    local spellLabel = manager:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    spellLabel:SetPoint("TOPLEFT", 24, -102)
    spellLabel:SetText("Spell ID")

    manager.spellEdit = CreateProcManagerEditBox(manager, 150, true)
    manager.spellEdit:SetPoint("TOPLEFT", 24, -124)

    local maxLabel = manager:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    maxLabel:SetPoint("TOPLEFT", 190, -102)
    maxLabel:SetText("Max Icons")

    manager.maxEdit = CreateProcManagerEditBox(manager, 80, true)
    manager.maxEdit:SetPoint("TOPLEFT", 190, -124)
    manager.maxEdit:SetText("1")

    manager.addButton = CreateButton(manager, "Add Proc", 130, 28)
    manager.addButton:SetPoint("TOPLEFT", 286, -123)
    manager.addButton:SetScript("OnClick", function()
        if AddCustomProc(manager.spellEdit:GetText(), manager.maxEdit:GetText()) then
            manager.spellEdit:SetText("")
            manager.maxEdit:SetText("1")
        end
    end)

    manager.unlockButton = CreateButton(manager, "Unlock Rows", 130, 28)
    manager.unlockButton:SetPoint("LEFT", manager.addButton, "RIGHT", 12, 0)
    manager.unlockButton:SetScript("OnClick", function()
        SetLocked(false)
        RefreshOptions()
    end)

    manager.autoLearnCheckbox = CreateCheckbox(manager, "Auto-learn Blizzard proc Spell IDs")
    manager.autoLearnCheckbox:SetSize(24, 24)
    manager.autoLearnCheckbox:SetPoint("TOPLEFT", 24, -160)
    manager.autoLearnCheckbox:SetChecked(GetDB().autoLearnProcIDs ~= false)
    manager.autoLearnCheckbox:SetScript("OnClick", function(self)
        GetDB().autoLearnProcIDs = self:GetChecked() and true or false
        Print("automatic proc-ID learning " .. (GetDB().autoLearnProcIDs and "enabled." or "disabled."))
    end)

    local savedHeader = manager:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    savedHeader:SetPoint("TOPLEFT", 24, -196)
    savedHeader:SetText("Proc ID Library - this character")
    savedHeader:SetTextColor(1, 0.82, 0.25, 1)

    local savedHint = manager:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    savedHint:SetPoint("LEFT", savedHeader, "RIGHT", 10, 0)
    savedHint:SetText("AUTO entries are grouped by class; manual IDs stay under Custom / Manual.")
    savedHint:SetTextColor(0.72, 0.72, 0.72, 1)

    manager.savedScroll = CreateFrame("ScrollFrame", nil, manager, "UIPanelScrollFrameTemplate")
    manager.savedScroll:SetPoint("TOPLEFT", 24, -218)
    manager.savedScroll:SetSize(580, 140)

    manager.savedContent = CreateFrame("Frame", nil, manager.savedScroll)
    manager.savedContent:SetSize(560, 1)
    manager.savedScroll:SetScrollChild(manager.savedContent)

    local header = manager:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    header:SetPoint("TOPLEFT", 24, -378)
    header:SetText("Added Proc Rows")
    header:SetTextColor(1, 0.82, 0.25, 1)

    manager.scroll = CreateFrame("ScrollFrame", nil, manager, "UIPanelScrollFrameTemplate")
    manager.scroll:SetPoint("TOPLEFT", 24, -400)
    manager.scroll:SetPoint("BOTTOMRIGHT", -46, 24)

    manager.content = CreateFrame("Frame", nil, manager.scroll)
    manager.content:SetSize(560, 1)
    manager.scroll:SetScrollChild(manager.content)

    manager:SetScript("OnShow", function()
        if manager.autoLearnCheckbox then
            manager.autoLearnCheckbox:SetChecked(GetDB().autoLearnProcIDs ~= false)
        end
        RefreshCustomProcOptions()
        if RefreshSavedProcList then
            RefreshSavedProcList()
        end
    end)

    manager:Hide()
    return manager
end

RefreshSavedProcList = function()
    if not customProcManager or not customProcManager.savedContent then
        return
    end

    local db = GetDB()
    local content = customProcManager.savedContent

    for _, optionRow in ipairs(savedProcOptionRows) do
        optionRow:Hide()
    end

    for _, classHeader in ipairs(savedProcClassHeaders) do
        classHeader:Hide()
    end

    if #db.savedProcs == 0 then
        content:SetHeight(1)
        if not customProcManager.savedEmptyText then
            customProcManager.savedEmptyText = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            customProcManager.savedEmptyText:SetPoint("TOPLEFT", content, "TOPLEFT", 8, -8)
            customProcManager.savedEmptyText:SetWidth(520)
            customProcManager.savedEmptyText:SetJustifyH("LEFT")
            customProcManager.savedEmptyText:SetTextColor(0.72, 0.72, 0.72, 1)
        end
        customProcManager.savedEmptyText:SetText("No proc IDs learned yet. Use a proc once with Auto-learn enabled, or enter a valid Spell ID above.")
        customProcManager.savedEmptyText:Show()
        return
    elseif customProcManager.savedEmptyText then
        customProcManager.savedEmptyText:Hide()
    end

    local sortedEntries = GetSortedSavedProcEntries()
    local rowHeight = 42
    local headerHeight = 24
    local yOffset = 0
    local rowIndex = 0
    local headerIndex = 0
    local previousClassKey

    for _, entry in ipairs(sortedEntries) do
        local classKey, className = GetSavedProcClassGroup(entry)

        if classKey ~= previousClassKey then
            headerIndex = headerIndex + 1
            local classHeader = savedProcClassHeaders[headerIndex]
            if not classHeader then
                classHeader = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                classHeader:SetWidth(540)
                classHeader:SetJustifyH("LEFT")
                classHeader:SetTextColor(1, 0.82, 0.25, 1)
                savedProcClassHeaders[headerIndex] = classHeader
            end

            classHeader:ClearAllPoints()
            classHeader:SetPoint("TOPLEFT", content, "TOPLEFT", 6, -yOffset)
            classHeader:SetText(className)
            classHeader:Show()

            yOffset = yOffset + headerHeight
            previousClassKey = classKey
        end

        rowIndex = rowIndex + 1
        local optionRow = savedProcOptionRows[rowIndex]
        if not optionRow then
            optionRow = CreateFrame("Frame", nil, content, "BackdropTemplate")
            optionRow:SetSize(550, 36)
            optionRow:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            optionRow:SetBackdropColor(0.02, 0.02, 0.025, 0.88)
            optionRow:SetBackdropBorderColor(0.28, 0.03, 0.06, 0.90)

            optionRow.icon = optionRow:CreateTexture(nil, "ARTWORK")
            optionRow.icon:SetPoint("LEFT", 6, 0)
            optionRow.icon:SetSize(28, 28)
            optionRow.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

            optionRow.nameText = optionRow:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            optionRow.nameText:SetPoint("LEFT", 42, 0)
            optionRow.nameText:SetWidth(215)
            optionRow.nameText:SetJustifyH("LEFT")

            optionRow.idText = optionRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            optionRow.idText:SetPoint("LEFT", 262, 0)
            optionRow.idText:SetWidth(108)
            optionRow.idText:SetJustifyH("LEFT")

            optionRow.maxText = optionRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            optionRow.maxText:SetPoint("LEFT", 372, 0)
            optionRow.maxText:SetWidth(72)
            optionRow.maxText:SetJustifyH("LEFT")

            optionRow.addButton = CreateButton(optionRow, "Add", 82, 24)
            optionRow.addButton:SetPoint("RIGHT", -8, 0)

            savedProcOptionRows[rowIndex] = optionRow
        end

        optionRow:ClearAllPoints()
        optionRow:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -yOffset)
        optionRow.icon:SetTexture(entry.icon or 134400)
        local entryName = entry.name or ("Spell " .. entry.spellID)
        if entry.source == "auto" then
            entryName = entryName .. " |cff66ccffAUTO|r"
        end
        optionRow.nameText:SetText(entryName)
        optionRow.idText:SetText("ID " .. tostring(entry.spellID))
        optionRow.maxText:SetText("Max " .. tostring(entry.maxStacks or 1))

        local savedEntry = entry
        local alreadyAdded = IsCustomProcAlreadyAdded(savedEntry.spellID)
        optionRow.addButton.text:SetText(alreadyAdded and "Added" or "Add")
        optionRow.addButton:SetEnabled(not alreadyAdded)
        optionRow.addButton:SetAlpha(alreadyAdded and 0.55 or 1)
        optionRow.addButton:SetScript("OnClick", function()
            AddCustomProc(savedEntry.spellID, savedEntry.maxStacks or 1)
        end)

        optionRow:Show()
        yOffset = yOffset + rowHeight
    end

    content:SetHeight(math.max(1, yOffset))
end

RefreshCustomProcOptions = function()
    if not customProcManager then
        return
    end

    local db = GetDB()
    local content = customProcManager.content

    for _, optionRow in ipairs(customOptionRows) do
        optionRow:Hide()
    end

    local rowHeight = 58
    content:SetHeight(math.max(1, #db.customProcs * rowHeight))

    for index, config in ipairs(db.customProcs) do
        local optionRow = customOptionRows[index]
        if not optionRow then
            optionRow = CreateFrame("Frame", nil, content, "BackdropTemplate")
            optionRow:SetSize(550, 52)
            optionRow:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            optionRow:SetBackdropColor(0.025, 0.025, 0.03, 0.90)
            optionRow:SetBackdropBorderColor(0.35, 0.03, 0.07, 0.95)

            optionRow.icon = optionRow:CreateTexture(nil, "ARTWORK")
            optionRow.icon:SetPoint("LEFT", 8, 0)
            optionRow.icon:SetSize(36, 36)
            optionRow.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

            optionRow.nameText = optionRow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            optionRow.nameText:SetPoint("TOPLEFT", 52, -8)
            optionRow.nameText:SetWidth(190)
            optionRow.nameText:SetJustifyH("LEFT")

            optionRow.idText = optionRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            optionRow.idText:SetPoint("TOPLEFT", 52, -28)
            optionRow.idText:SetWidth(210)
            optionRow.idText:SetJustifyH("LEFT")

            optionRow.enabledCheck = CreateFrame("CheckButton", nil, optionRow, "UICheckButtonTemplate")
            optionRow.enabledCheck:SetPoint("LEFT", 255, 0)

            optionRow.enabledLabel = optionRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            optionRow.enabledLabel:SetPoint("LEFT", optionRow.enabledCheck, "RIGHT", -2, 0)
            optionRow.enabledLabel:SetText("On")

            optionRow.maxLabel = optionRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            optionRow.maxLabel:SetPoint("LEFT", 318, 0)
            optionRow.maxLabel:SetText("Max")

            optionRow.maxEdit = CreateProcManagerEditBox(optionRow, 42, true)
            optionRow.maxEdit:SetPoint("LEFT", 348, 0)

            optionRow.testButton = CreateButton(optionRow, "Test", 62, 24)
            optionRow.testButton:SetPoint("LEFT", 400, 0)

            optionRow.removeButton = CreateButton(optionRow, "Remove", 72, 24)
            optionRow.removeButton:SetPoint("LEFT", 470, 0)

            customOptionRows[index] = optionRow
        end

        optionRow:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((index - 1) * rowHeight))
        optionRow.icon:SetTexture(config.icon or 134400)
        optionRow.nameText:SetText(config.name or ("Spell " .. config.spellID))

        if config.linkedAuraSpellID and config.linkedAuraSpellID ~= config.spellID then
            optionRow.idText:SetText("Spell " .. config.spellID .. "  -> aura " .. config.linkedAuraSpellID)
        else
            optionRow.idText:SetText("Spell " .. config.spellID)
        end

        optionRow.enabledCheck:SetChecked(config.enabled ~= false)
        optionRow.maxEdit:SetText(tostring(config.maxStacks or 1))

        local rowConfig = config
        local rowIndex = index

        optionRow.enabledCheck:SetScript("OnClick", function(self)
            rowConfig.enabled = self:GetChecked() and true or false
            QueueCustomUpdate(true)
            ApplyCustomProcLockState()
        end)

        local function CommitMaxIcons(editBox)
            local newMax = Clamp(math.floor((tonumber(editBox:GetText()) or rowConfig.maxStacks or 1) + 0.5), 1, 8)
            editBox:SetText(tostring(newMax))
            if newMax ~= rowConfig.maxStacks then
                rowConfig.maxStacks = newMax
                RememberSavedProc(rowConfig.spellID, newMax, rowConfig.name, rowConfig.icon, "manual")
                RebuildCustomRows()
                RefreshCustomProcOptions()
            end
            editBox:ClearFocus()
        end

        optionRow.maxEdit:SetScript("OnEnterPressed", CommitMaxIcons)
        optionRow.maxEdit:SetScript("OnEditFocusLost", function(self)
            CommitMaxIcons(self)
        end)

        optionRow.testButton:SetScript("OnClick", function()
            local trackerRow = FindCustomRowForSpellID(rowConfig.spellID)
            RunCustomProcTest(trackerRow)
        end)

        optionRow.removeButton:SetScript("OnClick", function()
            table.remove(GetDB().customProcs, rowIndex)
            RebuildCustomRows()
            RefreshCustomProcOptions()
            if RefreshSavedProcList then
                RefreshSavedProcList()
            end
        end)

        optionRow:Show()
    end
end

ToggleCustomProcManager = function()
    local manager = CreateCustomProcManager()
    if manager:IsShown() then
        manager:Hide()
    else
        manager:Show()
    end
end


local function RefreshOptions()
    if not optionsFrame then
        return
    end

    refreshingOptions = true

    local db = GetDB()

    optionsFrame.lockCheckbox:SetChecked(db.locked)
    optionsFrame.textCheckbox:SetChecked(db.showStackText)
    optionsFrame.glowCheckbox:SetChecked(db.glowEnabled)
    optionsFrame.pulseCheckbox:SetChecked(db.glowPulse)
    optionsFrame.soundCheckbox:SetChecked(db.soundEnabled)

    optionsFrame.scaleSlider:SetValue(db.scale or DEFAULTS.scale)
    optionsFrame.scaleValue:SetText(string.format("%.2f", db.scale or DEFAULTS.scale))

    optionsFrame.brightnessSlider:SetValue(db.iconBrightness or DEFAULTS.iconBrightness)
    optionsFrame.brightnessValue:SetText(string.format("%.2f", db.iconBrightness or DEFAULTS.iconBrightness))

    optionsFrame.opacitySlider:SetValue(db.iconOpacity or DEFAULTS.iconOpacity)
    optionsFrame.opacityValue:SetText(string.format("%.2f", db.iconOpacity or DEFAULTS.iconOpacity))

    optionsFrame.paddingSlider:SetValue(db.iconPadding or DEFAULTS.iconPadding)
    optionsFrame.paddingValue:SetText(tostring(math.floor((db.iconPadding or DEFAULTS.iconPadding) + 0.5)))

    optionsFrame.glowIntensitySlider:SetValue(db.glowIntensity or DEFAULTS.glowIntensity)
    optionsFrame.glowIntensityValue:SetText(string.format("%.2f", db.glowIntensity or DEFAULTS.glowIntensity))

    optionsFrame.glowThicknessSlider:SetValue(db.glowThickness or DEFAULTS.glowThickness)
    optionsFrame.glowThicknessValue:SetText(tostring(math.floor((db.glowThickness or DEFAULTS.glowThickness) + 0.5)))

    optionsFrame.glowSpeedSlider:SetValue(db.glowSpeed or DEFAULTS.glowSpeed)
    optionsFrame.glowSpeedValue:SetText(string.format("%.2f", db.glowSpeed or DEFAULTS.glowSpeed))

    local selectedGlowStyle = GetGlowStyle()
    local selectedGlowColor = GetGlowColor()

    optionsFrame.soundButton.text:SetText("Sound: " .. GetSoundKit().name)
    optionsFrame.channelButton.text:SetText("Channel: " .. GetSoundChannel())
    optionsFrame.glowStyleButton.text:SetText("Glow: " .. selectedGlowStyle)
    optionsFrame.glowColorButton.text:SetText("Color: " .. selectedGlowColor.name)

    if optionsFrame.procManagerButton then
        optionsFrame.procManagerButton.text:SetText("Manage Procs (" .. #db.customProcs .. ")")
    end

    if trackedCDMFrame then
        optionsFrame.trackingText:SetText("Tracking: Demonic Core + circular cooldown swipe")
        optionsFrame.trackingText:SetTextColor(0.25, 1, 0.35, 1)
    elseif procWasActive then
        optionsFrame.trackingText:SetText("Tracking: Demonic Core active via fallback")
        optionsFrame.trackingText:SetTextColor(1, 0.82, 0.25, 1)
    else
        optionsFrame.trackingText:SetText("Tracking: waiting for the next Demonic Core proc")
        optionsFrame.trackingText:SetTextColor(0.92, 0.92, 0.92, 1)
    end

    refreshingOptions = false
end

local function UpdateOptionsUIScale()
    if not optionsFrame or not optionsFrame.uiRoot then
        return
    end

    local width = optionsFrame:GetWidth() or OPTIONS_BASE_WIDTH
    local height = optionsFrame:GetHeight() or OPTIONS_BASE_HEIGHT
    local scale = math.min(width / OPTIONS_BASE_WIDTH, height / OPTIONS_BASE_HEIGHT)
    scale = Clamp(scale, 0.72, 1.75)

    optionsFrame.uiRoot:SetScale(scale)
    optionsFrame.uiRoot:ClearAllPoints()
    optionsFrame.uiRoot:SetPoint("CENTER", optionsFrame, "CENTER", 0, 0)

    if optionsFrame.resizeGrip then
        local gripSize = 22 * scale
        optionsFrame.resizeGrip:SetSize(gripSize, gripSize)
    end
end

local function CreateOptionsFrame()
    optionsFrame = CreateFrame("Frame", "ChayDemonicCoreOptions", UIParent, "BackdropTemplate")
    local db = GetDB()
    optionsFrame:SetSize(
        Clamp(db.optionsWidth or DEFAULTS.optionsWidth, 430, 900),
        Clamp(db.optionsHeight or DEFAULTS.optionsHeight, 640, 1100)
    )
    optionsFrame:SetPoint(
        db.optionsPoint or DEFAULTS.optionsPoint,
        UIParent,
        db.optionsRelativePoint or DEFAULTS.optionsRelativePoint,
        db.optionsX or DEFAULTS.optionsX,
        db.optionsY or DEFAULTS.optionsY
    )
    optionsFrame:SetFrameStrata("DIALOG")
    optionsFrame:SetClampedToScreen(true)
    optionsFrame:EnableMouse(true)
    optionsFrame:SetMovable(true)
    optionsFrame:SetResizable(true)
    optionsFrame:SetResizeBounds(430, 640, 900, 1100)
    optionsFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    optionsFrame:SetBackdropColor(0, 0, 0, 0.96)
    optionsFrame:SetBackdropBorderColor(0.75, 0.04, 0.10, 0.90)

    optionsFrame.blackBackground = optionsFrame:CreateTexture(nil, "BACKGROUND")
    optionsFrame.blackBackground:SetPoint("TOPLEFT", optionsFrame, "TOPLEFT", 1, -1)
    optionsFrame.blackBackground:SetPoint("BOTTOMRIGHT", optionsFrame, "BOTTOMRIGHT", -1, 1)
    optionsFrame.blackBackground:SetColorTexture(0, 0, 0, 0.92)

    optionsFrame.dragonBackground = optionsFrame:CreateTexture(nil, "BACKGROUND", nil, 1)
    optionsFrame.dragonBackground:SetPoint("TOPLEFT", optionsFrame, "TOPLEFT", 1, -1)
    optionsFrame.dragonBackground:SetPoint("BOTTOMRIGHT", optionsFrame, "BOTTOMRIGHT", -1, 1)
    optionsFrame.dragonBackground:SetTexture(OPTIONS_BACKGROUND_TEXTURE)
    optionsFrame.dragonBackground:SetTexCoord(0, 1, 0, 1)
    optionsFrame.dragonBackground:SetAlpha(0.90)

    -- Fixed-size design surface. This entire frame is scaled when the options
    -- window is resized, so buttons, sliders, labels, spacing and text all grow
    -- or shrink together instead of only the background changing size.
    optionsFrame.uiRoot = CreateFrame("Frame", nil, optionsFrame)
    optionsFrame.uiRoot:SetSize(OPTIONS_BASE_WIDTH, OPTIONS_BASE_HEIGHT)
    optionsFrame.uiRoot:SetPoint("CENTER", optionsFrame, "CENTER", 0, 0)

    local ui = optionsFrame.uiRoot

    optionsFrame:Hide()

    optionsFrame:RegisterForDrag("LeftButton")
    optionsFrame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    optionsFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relativePoint, xOffset, yOffset = self:GetPoint(1)
        local db = GetDB()
        db.optionsPoint = point or DEFAULTS.optionsPoint
        db.optionsRelativePoint = relativePoint or DEFAULTS.optionsRelativePoint
        db.optionsX = xOffset or DEFAULTS.optionsX
        db.optionsY = yOffset or DEFAULTS.optionsY
    end)
    optionsFrame:SetScript("OnShow", function()
        UpdateOptionsUIScale()
        RefreshOptions()
    end)
    optionsFrame:SetScript("OnSizeChanged", function()
        UpdateOptionsUIScale()
    end)

    optionsFrame.resizeGrip = CreateFrame("Button", nil, optionsFrame)
    optionsFrame.resizeGrip:SetSize(22, 22)
    optionsFrame.resizeGrip:SetPoint("BOTTOMRIGHT", optionsFrame, "BOTTOMRIGHT", -2, 2)
    optionsFrame.resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    optionsFrame.resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    optionsFrame.resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    optionsFrame.resizeGrip:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then
            optionsFrame:StartSizing("BOTTOMRIGHT", true)
        end
    end)
    optionsFrame.resizeGrip:SetScript("OnMouseUp", function(_, button)
        if button == "LeftButton" then
            optionsFrame:StopMovingOrSizing()
            local db = GetDB()
            db.optionsWidth = optionsFrame:GetWidth()
            db.optionsHeight = optionsFrame:GetHeight()
            UpdateOptionsUIScale()
        end
    end)

    local title = ui:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -16)
    title:SetText("Chay Demonic Core")
    title:SetTextColor(1, 0.82, 0.25, 1)

    local subtitle = ui:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOP", title, "BOTTOM", 0, -5)
    subtitle:SetText("Demonic Core + custom proc rows | all settings save per character")

    local commandHint = ui:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    commandHint:SetPoint("TOP", subtitle, "BOTTOM", 0, -4)
    commandHint:SetText("|cffffd24a/cdc|r to open")
    commandHint:SetTextColor(0.92, 0.92, 0.92, 1)

    local closeButton = CreateButton(ui, "X", 28, 24)
    closeButton:SetPoint("TOPRIGHT", ui, "TOPRIGHT", -9, -9)
    closeButton:SetScript("OnClick", function()
        optionsFrame:Hide()
    end)

    -- Top strip only. The center of the panel is intentionally left clear so
    -- none of these controls cover the dragon's face.
    optionsFrame.lockCheckbox = CreateCheckbox(ui, "Lock proc icons")
    optionsFrame.lockCheckbox:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -80)
    optionsFrame.lockCheckbox:SetScript("OnClick", function(self)
        if refreshingOptions then return end
        SetLocked(self:GetChecked())
        RefreshOptions()
    end)

    optionsFrame.textCheckbox = CreateCheckbox(ui, "Show stack text")
    optionsFrame.textCheckbox:SetPoint("TOPRIGHT", ui, "TOPRIGHT", -150, -80)
    optionsFrame.textCheckbox:SetScript("OnClick", function(self)
        if refreshingOptions then return end
        GetDB().showStackText = self:GetChecked() and true or false
        ApplyTextSettings()
        UpdateProcState(true)
    end)

    optionsFrame.glowCheckbox = CreateCheckbox(ui, "Enable proc glow")
    optionsFrame.glowCheckbox:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -112)
    optionsFrame.glowCheckbox:SetScript("OnClick", function(self)
        if refreshingOptions then return end
        GetDB().glowEnabled = self:GetChecked() and true or false
        ApplyGlowSettings()
    end)

    optionsFrame.pulseCheckbox = CreateCheckbox(ui, "Pulse glow")
    optionsFrame.pulseCheckbox:SetPoint("TOPRIGHT", ui, "TOPRIGHT", -150, -112)
    optionsFrame.pulseCheckbox:SetScript("OnClick", function(self)
        if refreshingOptions then return end
        GetDB().glowPulse = self:GetChecked() and true or false
        ApplyGlowSettings()
    end)

    optionsFrame.soundCheckbox = CreateCheckbox(ui, "Enable proc sound")
    optionsFrame.soundCheckbox:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -144)
    optionsFrame.soundCheckbox:SetScript("OnClick", function(self)
        if refreshingOptions then return end
        GetDB().soundEnabled = self:GetChecked() and true or false
    end)

    optionsFrame.procManagerButton = CreateButton(ui, "Manage Procs", 170, 26)
    optionsFrame.procManagerButton:SetPoint("TOPRIGHT", ui, "TOPRIGHT", -24, -140)
    optionsFrame.procManagerButton:SetScript("OnClick", function()
        ToggleCustomProcManager()
    end)

    -- Clear dragon-face zone: approximately Y 165-355 on the base layout.
    -- Sound / glow selectors and all sliders begin below it.
    optionsFrame.soundButton = CreateButton(ui, "Sound", 210, 28)
    optionsFrame.soundButton:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -370)
    optionsFrame.soundButton:SetScript("OnClick", function()
        local db = GetDB()
        db.soundKitIndex = (tonumber(db.soundKitIndex) or 1) + 1
        if db.soundKitIndex > #SOUND_KITS then
            db.soundKitIndex = 1
        end
        RefreshOptions()
        PlayCue(true)
    end)

    optionsFrame.channelButton = CreateButton(ui, "Channel", 210, 28)
    optionsFrame.channelButton:SetPoint("TOPRIGHT", ui, "TOPRIGHT", -24, -370)
    optionsFrame.channelButton:SetScript("OnClick", function()
        local db = GetDB()
        db.soundChannelIndex = (tonumber(db.soundChannelIndex) or 1) + 1
        if db.soundChannelIndex > #SOUND_CHANNELS then
            db.soundChannelIndex = 1
        end
        RefreshOptions()
        PlayCue(true)
    end)

    optionsFrame.glowStyleButton = CreateButton(ui, "Glow Style", 210, 28)
    optionsFrame.glowStyleButton:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -406)
    optionsFrame.glowStyleButton:SetScript("OnClick", function()
        local db = GetDB()
        db.glowStyleIndex = (tonumber(db.glowStyleIndex) or 1) + 1
        if db.glowStyleIndex > #GLOW_STYLES then
            db.glowStyleIndex = 1
        end
        ApplyGlowSettings()
        RefreshOptions()
    end)

    optionsFrame.glowColorButton = CreateButton(ui, "Glow Color", 210, 28)
    optionsFrame.glowColorButton:SetPoint("TOPRIGHT", ui, "TOPRIGHT", -24, -406)
    optionsFrame.glowColorButton:SetScript("OnClick", function()
        local db = GetDB()
        db.glowColorIndex = (tonumber(db.glowColorIndex) or 1) + 1
        if db.glowColorIndex > #GLOW_COLORS then
            db.glowColorIndex = 1
        end
        ApplyGlowSettings()
        RefreshOptions()
    end)

    -- Lower two-column settings section. Keeping sliders short and in columns
    -- leaves the dragon artwork visible while retaining every working option.
    optionsFrame.scaleSlider, optionsFrame.scaleLabel, optionsFrame.scaleValue = CreateSlider(
        ui,
        "Icon row size",
        0.50,
        2.50,
        0.05,
        185
    )
    optionsFrame.scaleLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -450)
    optionsFrame.scaleSlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -472)
    optionsFrame.scaleSlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 0.05)
        optionsFrame.scaleValue:SetText(string.format("%.2f", rounded))
        if refreshingOptions then return end
        SetScale(rounded)
    end)

    optionsFrame.glowIntensitySlider, optionsFrame.glowIntensityLabel, optionsFrame.glowIntensityValue = CreateSlider(
        ui,
        "Glow intensity",
        0.20,
        1.00,
        0.05,
        170
    )
    optionsFrame.glowIntensityLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 276, -450)
    optionsFrame.glowIntensitySlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 276, -472)
    optionsFrame.glowIntensitySlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 0.05)
        optionsFrame.glowIntensityValue:SetText(string.format("%.2f", rounded))
        if refreshingOptions then return end
        GetDB().glowIntensity = rounded
        ApplyGlowSettings()
    end)

    optionsFrame.brightnessSlider, optionsFrame.brightnessLabel, optionsFrame.brightnessValue = CreateSlider(
        ui,
        "Icon brightness",
        0.25,
        2.50,
        0.05,
        185
    )
    optionsFrame.brightnessLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -510)
    optionsFrame.brightnessSlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -532)
    optionsFrame.brightnessSlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 0.05)
        optionsFrame.brightnessValue:SetText(string.format("%.2f", rounded))
        if refreshingOptions then return end
        GetDB().iconBrightness = rounded
        ApplyIconVisualSettings()
    end)

    optionsFrame.glowThicknessSlider, optionsFrame.glowThicknessLabel, optionsFrame.glowThicknessValue = CreateSlider(
        ui,
        "Glow thickness",
        1,
        6,
        1,
        170
    )
    optionsFrame.glowThicknessLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 276, -510)
    optionsFrame.glowThicknessSlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 276, -532)
    optionsFrame.glowThicknessSlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 1)
        optionsFrame.glowThicknessValue:SetText(tostring(rounded))
        if refreshingOptions then return end
        GetDB().glowThickness = rounded
        ApplyGlowSettings()
    end)

    optionsFrame.opacitySlider, optionsFrame.opacityLabel, optionsFrame.opacityValue = CreateSlider(
        ui,
        "Icon fade / opacity",
        0.10,
        1.00,
        0.05,
        185
    )
    optionsFrame.opacityLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -570)
    optionsFrame.opacitySlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -592)
    optionsFrame.opacitySlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 0.05)
        optionsFrame.opacityValue:SetText(string.format("%.2f", rounded))
        if refreshingOptions then return end
        GetDB().iconOpacity = rounded
        ApplyIconVisualSettings()
    end)

    optionsFrame.glowSpeedSlider, optionsFrame.glowSpeedLabel, optionsFrame.glowSpeedValue = CreateSlider(
        ui,
        "Glow pulse speed",
        0.20,
        2.00,
        0.05,
        170
    )
    optionsFrame.glowSpeedLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 276, -570)
    optionsFrame.glowSpeedSlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 276, -592)
    optionsFrame.glowSpeedSlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 0.05)
        optionsFrame.glowSpeedValue:SetText(string.format("%.2f", rounded))
        if refreshingOptions then return end
        GetDB().glowSpeed = rounded
        ApplyGlowSettings()
    end)

    optionsFrame.paddingSlider, optionsFrame.paddingLabel, optionsFrame.paddingValue = CreateSlider(
        ui,
        "Padding between icons",
        0,
        30,
        1,
        185
    )
    optionsFrame.paddingLabel:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -630)
    optionsFrame.paddingSlider:SetPoint("TOPLEFT", ui, "TOPLEFT", 24, -652)
    optionsFrame.paddingSlider:SetScript("OnValueChanged", function(_, value)
        local rounded = Round(value, 1)
        optionsFrame.paddingValue:SetText(tostring(rounded))
        if refreshingOptions then return end
        GetDB().iconPadding = rounded
        ApplyIconLayout()
    end)

    local test1 = CreateButton(ui, "Test 1", 78, 26)
    test1:SetPoint("BOTTOMLEFT", ui, "BOTTOMLEFT", 24, 18)
    test1:SetScript("OnClick", function() RunVisualTest(1, true) end)

    local test2 = CreateButton(ui, "Test 2", 78, 26)
    test2:SetPoint("LEFT", test1, "RIGHT", 8, 0)
    test2:SetScript("OnClick", function() RunVisualTest(2, true) end)

    local test3 = CreateButton(ui, "Test 3", 78, 26)
    test3:SetPoint("LEFT", test2, "RIGHT", 8, 0)
    test3:SetScript("OnClick", function() RunVisualTest(3, true) end)

    local test4 = CreateButton(ui, "Test 4", 78, 26)
    test4:SetPoint("LEFT", test3, "RIGHT", 8, 0)
    test4:SetScript("OnClick", function() RunVisualTest(4, true) end)

    local resetButton = CreateButton(ui, "Reset", 94, 26)
    resetButton:SetPoint("LEFT", test4, "RIGHT", 8, 0)
    resetButton:SetScript("OnClick", function()
        ResetPosition()
        RefreshOptions()
    end)

    optionsFrame.trackingText = ui:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    optionsFrame.trackingText:SetPoint("BOTTOMLEFT", ui, "BOTTOMLEFT", 24, 54)
    optionsFrame.trackingText:SetWidth(462)
    optionsFrame.trackingText:SetJustifyH("LEFT")

    UpdateOptionsUIScale()
end

local function ToggleOptions()
    if not optionsFrame then
        return
    end

    if optionsFrame:IsShown() then
        optionsFrame:Hide()
    else
        optionsFrame:Show()
    end
end

local function IsMinimapButtonDocked()
    return minimapButton and minimapButton:GetParent() ~= Minimap
end

local function UpdateMinimapButtonPosition()
    if not minimapButton or not Minimap or IsMinimapButtonDocked() then
        return
    end

    local angle = math.rad(tonumber(GetDB().minimapAngle) or DEFAULTS.minimapAngle)
    local radius = 78
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    if minimapButton or not Minimap then
        return
    end

    minimapButton = CreateFrame("Button", "ChayDemonicCoreMinimapButton", Minimap)
    minimapButton:SetSize(32, 32)
    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    minimapButton:RegisterForDrag("LeftButton")

    minimapButton.icon = minimapButton:CreateTexture(nil, "ARTWORK")
    minimapButton.icon:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 2, -2)
    minimapButton.icon:SetPoint("BOTTOMRIGHT", minimapButton, "BOTTOMRIGHT", -2, 2)
    minimapButton.icon:SetTexture(MINIMAP_ICON_TEXTURE)

    minimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight", "ADD")

    minimapButton:SetScript("OnClick", function()
        ToggleOptions()
    end)

    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Chay Demonic Core", 1, 0.82, 0.25)
        GameTooltip:AddLine("Left click: Open / close options", 1, 1, 1)
        if IsMinimapButtonDocked() then
            GameTooltip:AddLine("Position managed by your minimap button bar", 0.75, 0.75, 0.75)
        else
            GameTooltip:AddLine("Drag: Move minimap button", 0.75, 0.75, 0.75)
        end
        GameTooltip:Show()
    end)

    minimapButton:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    minimapButton:SetScript("OnDragStart", function(self)
        if IsMinimapButtonDocked() then
            return
        end

        self.dragging = true
        self:SetScript("OnUpdate", function()
            if IsMinimapButtonDocked() then
                self.dragging = false
                self:SetScript("OnUpdate", nil)
                return
            end

            local centerX, centerY = Minimap:GetCenter()
            if not centerX or not centerY then
                return
            end

            local scale = Minimap:GetEffectiveScale()
            local cursorX, cursorY = GetCursorPosition()
            cursorX = cursorX / scale
            cursorY = cursorY / scale

            local angle = math.deg(math.atan2(cursorY - centerY, cursorX - centerX))
            GetDB().minimapAngle = angle
            UpdateMinimapButtonPosition()
        end)
    end)

    minimapButton:SetScript("OnDragStop", function(self)
        self.dragging = false
        self:SetScript("OnUpdate", nil)
        UpdateMinimapButtonPosition()
    end)

    UpdateMinimapButtonPosition()
end

local function PrintStatus()
    Print("Demonic Core spell: 264173; Demonbolt proc spell: 264178.")
    Print("Cooldown Manager bridge: " .. (trackedCDMFrame and "connected." or "waiting for Demonic Core to appear."))
    Print("Current proc state: " .. (procWasActive and "active." or "inactive."))
    Print("Custom all-class proc rows: " .. #GetDB().customProcs .. ".")
    Print("Saved proc-ID library: " .. #GetDB().savedProcs .. "; auto-learn " .. (GetDB().autoLearnProcIDs ~= false and "enabled." or "disabled."))
end

local function ShowHelp()
    Print("/cdc - open options")
    Print("/cdc unlock - unlock and show the four-icon mover")
    Print("/cdc lock - lock the four-icon display")
    Print("/cdc sound - toggle proc sound")
    Print("/cdc test - test all four icons")
    Print("/cdc test 1|2|3|4 - test a specific Demonic Core stack count")
    Print("/cdc procs - open the proc manager and per-character proc-ID library")
    Print("/cdc list - open the proc-ID library")
    Print("/cdc learn - toggle automatic Blizzard proc-ID learning")
    Print("/cdc add <spellID> [maxIcons] - add a custom proc row and remember the ID")
    Print("/cdc remove <spellID> - remove a custom proc row")
    Print("/cdc status - show tracking status")
    Print("/cdc reset - reset position and visual settings")
end

local function SlashHandler(message)
    local raw = (message or ""):match("^%s*(.-)%s*$") or ""
    local command, argument = raw:match("^(%S+)%s*(.-)$")
    command = string.lower(command or "")

    if command == "" or command == "options" then
        ToggleOptions()
    elseif command == "unlock" then
        SetLocked(false)
        RefreshOptions()
    elseif command == "lock" then
        SetLocked(true)
        RefreshOptions()
    elseif command == "sound" then
        local db = GetDB()
        db.soundEnabled = not db.soundEnabled
        Print("proc sound " .. (db.soundEnabled and "enabled." or "disabled."))
        RefreshOptions()
    elseif command == "test" then
        local count = tonumber(argument)
        if count then
            RunVisualTest(Clamp(count, 1, 4), true)
        else
            RunVisualTest(4, true)
        end
    elseif command == "procs" or command == "proc" or command == "list" or command == "saved" then
        ToggleCustomProcManager()
    elseif command == "learn" then
        local db = GetDB()
        db.autoLearnProcIDs = not (db.autoLearnProcIDs ~= false)
        Print("automatic proc-ID learning " .. (db.autoLearnProcIDs and "enabled." or "disabled."))
        if customProcManager and customProcManager.autoLearnCheckbox then
            customProcManager.autoLearnCheckbox:SetChecked(db.autoLearnProcIDs)
        end
    elseif command == "add" then
        local spellIDText, maxText = argument:match("^(%d+)%s*(%d*)$")
        if spellIDText then
            AddCustomProc(spellIDText, maxText ~= "" and maxText or 1)
        else
            Print("usage: /cdc add <spellID> [maxIcons]")
        end
        RefreshOptions()
    elseif command == "remove" then
        local spellIDText = argument:match("^(%d+)$")
        if spellIDText then
            RemoveCustomProcBySpellID(spellIDText)
        else
            Print("usage: /cdc remove <spellID>")
        end
        RefreshOptions()
    elseif command == "status" then
        PrintStatus()
    elseif command == "reset" then
        ResetPosition()
        RefreshOptions()
    else
        ShowHelp()
    end
end

local function RegisterSlashCommands()
    SLASH_CHAYDEMONICCORE1 = "/cdc"
    SLASH_CHAYDEMONICCORE2 = "/chaycore"
    SlashCmdList.CHAYDEMONICCORE = SlashHandler
end

local function RegisterEvents()
    eventFrame:RegisterEvent("PLAYER_LOGIN")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    eventFrame:RegisterEvent("SPELLS_CHANGED")
    eventFrame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_SHOW")
    eventFrame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_HIDE")
    eventFrame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_GLOW_SHOW")
    eventFrame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_GLOW_HIDE")
    eventFrame:RegisterUnitEvent("UNIT_AURA", "player")
end

local function Initialize()
    if initialized then
        return
    end

    initialized = true
    GetDB()
    RefreshCurrentPlayerClassMetadata()
    EnsureBuiltInDefaultProcs()
    BackfillAutoProcClassMetadata()
    SeedSavedProcListFromCurrentRows()
    CreateDisplayFrame()
    RebuildCustomRows()
    CreateOptionsFrame()
    CreateMinimapButton()
    RegisterSlashCommands()
    RegisterEvents()

    HookCooldownViewer()
    C_Timer.After(0.25, HookCooldownViewer)
    C_Timer.After(1.00, HookCooldownViewer)

    QueueUpdate(true)
    QueueCustomUpdate(true)
    Print("loaded. Settings and proc-ID library are per character. Auto-learn tags proc IDs with the triggering class and the library groups them by class. Type /cdc procs to manage them.")
end

eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == ADDON_NAME then
            Initialize()
        elseif initialized and arg1 == "Blizzard_CooldownViewer" then
            HookCooldownViewer()
        end
        return
    end

    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        RefreshCurrentPlayerClassMetadata()
        BackfillAutoProcClassMetadata()
        HookCooldownViewer()
        QueueUpdate(true)
        QueueCustomUpdate(true)
        return
    end

    if event == "PLAYER_SPECIALIZATION_CHANGED" then
        if arg1 ~= "player" then
            return
        end

        trackedAuraInstanceID = nil
        trackedCDMFrame = nil
        procWasActive = false
        lastReadableCount = nil
        RebuildCustomRows()
        C_Timer.After(0.25, HookCooldownViewer)
        QueueUpdate(true)
        QueueCustomUpdate(true)
        return
    end

    if event == "UNIT_AURA" then
        if arg1 ~= "player" then
            return
        end
        QueueUpdate(false)
        QueueCustomUpdate(false)
        return
    end

    if event == "SPELLS_CHANGED" then
        RebuildCustomRows()
        C_Timer.After(0, HookCooldownViewer)
        QueueUpdate(true)
        QueueCustomUpdate(true)
        return
    end

    if event == "SPELL_ACTIVATION_OVERLAY_SHOW" or event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" then
        DiscoverProcSpellID(arg1)

        if arg1 == DEMONBOLT_SPELL_ID or arg1 == DEMONIC_CORE_AURA_ID then
            if not procWasActive and not testMode then
                SetActiveVisuals(1, trackedAuraInstanceID, false)
            end
            QueueUpdate(true)
        end

        if FindCustomRowForSpellID(arg1) then
            QueueCustomUpdate(false)
        end
        return
    end

    if event == "SPELL_ACTIVATION_OVERLAY_HIDE" or event == "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then
        if arg1 == DEMONBOLT_SPELL_ID or arg1 == DEMONIC_CORE_AURA_ID then
            -- Do not force-clear here. Blizzard can update the overlay and aura
            -- state in separate callbacks. Re-read Demonic Core on the next
            -- frame so an intermediate hide event cannot make the tracker flash.
            QueueUpdate(false)
        end

        if FindCustomRowForSpellID(arg1) then
            QueueCustomUpdate(false)
        end
    end
end)
