local addonName = ...
local CT = _G.ChayAlertHUD
if not CT then return end

local TankSwap = {}
CT.TankSwap = TankSwap
_G.ChayAlertHUDTankSwap = TankSwap

local BUILTIN_TAUNT_SOUNDS = {
    ZIRA = "Interface\\AddOns\\" .. addonName .. "\\Media\\TauntNow_Zira.wav",
    DAVID = "Interface\\AddOns\\" .. addonName .. "\\Media\\TauntNow_David.wav",
}

local TAUNT_VOICE_LABELS = {
    FOLLOW_TTS = "Same as TTS voice",
    ZIRA = "Zira (Female)",
    DAVID = "David (Male)",
}

local TAUNT_VOICE_KEYS = {
    ["Same as TTS voice"] = "FOLLOW_TTS",
    ["Zira (Female)"] = "ZIRA",
    ["David (Male)"] = "DAVID",
}

-- Midnight 12.1 makes ordinary live aura inspection unsuitable for addon-side
-- tank-swap decisions in restricted encounters. These triggers use Blizzard's
-- C_UnitAuras.AddAuraSound registration path and static, verified player-aura
-- spell IDs. The sound is registered on the OTHER tank's unit token, so this
-- client hears "Taunt now" when the co-tank reaches the exact handoff state.
--
-- Do not add ordinary tankbusters here. A trigger belongs here only when the
-- current Season 2 strategy gives the off-tank a deterministic handoff cue.
local SWAP_AURAS = {
    -- The Lost Explorers intentionally has no automatic AuraSound taunt.
    -- Shredding Shards applies repeated stacks every 0.5 sec during its 4 sec
    -- sequence. Added fires on the first shard and ApplicationsIncreased fires
    -- repeatedly during the same cast, so neither is an accurate post-cast
    -- "Taunt now" trigger. The normal Shredding Shards tank warning remains.

    -- The Coiled Altar: each Sever vulnerability is applied by the completed
    -- frontal. The first application or a later dose increase is therefore the
    -- outgoing tank's exact handoff state.
    { spellID = 1301690, triggerName = "Added", encounterID = 3429 }, -- Sever
    { spellID = 1301690, triggerName = "ApplicationsIncreased", encounterID = 3429 }, -- Sever
    { spellID = 1307959, triggerName = "Added", encounterID = 3429 }, -- Soul Sever
    { spellID = 1307959, triggerName = "ApplicationsIncreased", encounterID = 3429 }, -- Soul Sever
    { spellID = 1307403, triggerName = "Added", encounterID = 3429 }, -- Blighted Sever
    { spellID = 1307403, triggerName = "ApplicationsIncreased", encounterID = 3429 }, -- Blighted Sever

    -- Nek'zali: current tank guidance naturally hands off after Possession
    -- Barrage, once Hollowing Strikes is around 5-6 stacks. The 2 sec Barrage
    -- target aura ending is a deterministic post-mechanic handoff cue.
    { spellID = 1284103, triggerName = "Removed", encounterID = 3470 }, -- Possession Barrage

    -- Entombed Sentinels intentionally has no automatic AuraSound taunt.
    -- Tanks swap bosses when Vitriolic Stasis actually ends, but Helical Toxins
    -- can be removed from individual players as they solve the intermission
    -- puzzle. Its Removed transition is therefore not a safe phase-end cue and
    -- can fire Taunt Now early. The normal tank/intermission warnings remain.

    -- Sszorak intentionally has no automatic AuraSound taunt. The live rule
    -- depends on the first Ravage/Mutilate in the random Apex Predator combo
    -- and Corroding Venom state. Mutilated Gash can also hit soak participants,
    -- so a player-aura-only trigger cannot identify the active-tank handoff.

    -- The Twin Fangs intentionally has no automatic AuraSound taunt. The live
    -- tank trade is coordinated around the paired serpent mechanics: Vexhul's
    -- Caustic Deluge vulnerability and Ithraz's three-hit Stone Breaker soak.
    -- Caustic Deluge ending can occur before the Ithraz tank completes the full
    -- Stone Breaker set, while Stone Breaker's aura transitions cannot express
    -- "after the third hit only". A player-aura-only trigger would therefore be
    -- early or repeat. Both mechanics remain tank warnings, but ChayAlert does
    -- not issue an automatic Taunt Now without an exact handoff signal.

    -- Ula'tek intentionally has no automatic "Taunt now" AuraSound. Tanks do
    -- swap after Mother's Wrath, but Stage 1 requires the actual taunt to occur
    -- in a safe handoff window (for example during Caustic Waves/Mephitic
    -- Thrash or after Submerge). Mother's Wrath removal alone cannot encode
    -- that condition, so an immediate taunt call can be wrong. The normal
    -- Mother's Wrath tank warning remains.

    -- Vashnik: current Season 2 tank guidance explicitly swaps after every
    -- Dripping Fangs / at one stack. The tank debuff is applied by the finished
    -- hit, making Added the direct handoff cue; ApplicationsIncreased remains a
    -- recovery cue if a missed swap lets the same tank receive another stack.
    { spellID = 1280934, triggerName = "Added", encounterID = 3455 }, -- Dripping Fangs
    { spellID = 1280934, triggerName = "ApplicationsIncreased", encounterID = 3455 }, -- Dripping Fangs

    -- Nymrissa Wavecaller: retained Tidebound Grotto coverage. These auras span
    -- the tank sequence/channel, so Removed is the post-mechanic handoff cue.
    { spellID = 1282947, triggerName = "Removed", encounterID = 3379 }, -- Iceblade Flurry tank aura
    { spellID = 1258901, triggerName = "Removed", encounterID = 3379 }, -- Water Jet
}

local function SelectedTauntVoiceKey()
    local db = type(CT.GetDB) == "function" and CT:GetDB() or nil
    local key = type(db) == "table" and db.tankSwapVoice or nil
    if key == "FOLLOW_TTS" or key == "ZIRA" or key == "DAVID" then return key end
    return "FOLLOW_TTS"
end

local function TauntSoundFile()
    local key = SelectedTauntVoiceKey()

    -- AddAuraSound requires a prerecorded sound file. FOLLOW_TTS mirrors the
    -- currently resolved dynamic WoW TTS voice whenever it is Zira or David,
    -- using the bundled matching WAV for the protected "Taunt now" cue.
    if key == "FOLLOW_TTS" then
        local ttsKey = CT.TTS and type(CT.TTS.GetResolvedPreferredVoiceKey) == "function"
            and CT.TTS:GetResolvedPreferredVoiceKey() or nil
        return BUILTIN_TAUNT_SOUNDS[ttsKey] or BUILTIN_TAUNT_SOUNDS.ZIRA
    end

    return BUILTIN_TAUNT_SOUNDS[key] or BUILTIN_TAUNT_SOUNDS.ZIRA
end

local registrations = {}
local refreshPending = false
local status = {
    enabled = false,
    deferred = false,
    otherTankCount = 0,
    attempted = 0,
    registered = 0,
    failed = 0,
    reason = "Not initialized",
}

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value)
end

local function GetDB()
    return type(CT.GetDB) == "function" and CT:GetDB() or nil
end

local function Enabled()
    local db = GetDB()
    return db ~= nil
        and db.ttsEnabled == true
        and type(CT.GetActualRole) == "function"
        and CT:GetActualRole() == "TANK"
end

local function RestrictionType(name, fallback)
    local values = Enum and Enum.AddOnRestrictionType
    local value = values and values[name]
    return value ~= nil and value or fallback
end

local function RestrictionState(name, fallback)
    local values = Enum and Enum.AddOnRestrictionState
    local value = values and values[name]
    return value ~= nil and value or fallback
end

local RESTRICTION_COMBAT = RestrictionType("Combat", 0)
local RESTRICTION_ENCOUNTER = RestrictionType("Encounter", 1)
local RESTRICTION_CHALLENGE = RestrictionType("ChallengeMode", 2)
local RESTRICTION_INACTIVE = RestrictionState("Inactive", 0)
local RESTRICTION_ACTIVATING = RestrictionState("Activating", 1)

local function IsRestrictionActive(restrictionType)
    if not (C_RestrictedActions and type(C_RestrictedActions.IsAddOnRestrictionActive) == "function") then
        return false
    end
    local ok, active = pcall(C_RestrictedActions.IsAddOnRestrictionActive, restrictionType)
    return ok and active == true
end

local function AuraSoundRestrictionsActive()
    return IsRestrictionActive(RESTRICTION_ENCOUNTER)
        or (IsRestrictionActive(RESTRICTION_CHALLENGE) and IsRestrictionActive(RESTRICTION_COMBAT))
end

local function RemoveRegistrations()
    if C_UnitAuras and type(C_UnitAuras.RemoveAuraSound) == "function" then
        for _, registrationID in ipairs(registrations) do
            if type(registrationID) == "number" then
                pcall(C_UnitAuras.RemoveAuraSound, registrationID)
            end
        end
    end
    wipe(registrations)
end

local function UnitIsPlayer(unit)
    if type(UnitIsUnit) ~= "function" then return false end
    local ok, same = pcall(UnitIsUnit, unit, "player")
    if not ok or IsSecret(same) then return false end
    return same == true
end

local function UnitRole(unit)
    if type(UnitGroupRolesAssigned) ~= "function" then return nil end
    local ok, role = pcall(UnitGroupRolesAssigned, unit)
    if not ok or IsSecret(role) or type(role) ~= "string" then return nil end
    return role
end

local function AddOtherTank(tanks, unit)
    if type(UnitExists) ~= "function" then return end
    local ok, exists = pcall(UnitExists, unit)
    if not ok or IsSecret(exists) or exists ~= true then return end
    if UnitIsPlayer(unit) or UnitRole(unit) ~= "TANK" then return end
    tanks[#tanks + 1] = unit
end

local function OtherTankTokens()
    local tanks = {}

    local inRaid = false
    if type(IsInRaid) == "function" then
        local ok, result = pcall(IsInRaid)
        inRaid = ok and not IsSecret(result) and result == true
    end

    if inRaid then
        local count = type(GetNumGroupMembers) == "function" and GetNumGroupMembers() or 0
        if IsSecret(count) or type(count) ~= "number" then count = 0 end
        for i = 1, count do
            AddOtherTank(tanks, "raid" .. i)
        end
        return tanks
    end

    local count = type(GetNumGroupMembers) == "function" and GetNumGroupMembers() or 0
    if IsSecret(count) or type(count) ~= "number" then count = 0 end
    for i = 1, math.max(0, count - 1) do
        AddOtherTank(tanks, "party" .. i)
    end
    return tanks
end

local function AuraTrigger(name)
    local triggerEnum = Enum and Enum.UnitAuraSoundTrigger
    return triggerEnum and triggerEnum[name] or nil
end

local function ResetStatus()
    status.enabled = Enabled()
    status.deferred = false
    status.otherTankCount = 0
    status.attempted = 0
    status.registered = #registrations
    status.failed = 0
    status.reason = nil
end

local function RegisterNow()
    ResetStatus()

    -- RemoveAuraSound itself is not a restricted API. If the master is turned
    -- off during combat, remove existing automatic sounds immediately.
    if not status.enabled then
        RemoveRegistrations()
        status.registered = 0
        status.reason = "Tank role or global TTS is disabled"
        return
    end

    -- AddAuraSound is restricted in 12.1. Existing registrations must remain
    -- intact while restrictions are active and are rebuilt when legal again.
    if AuraSoundRestrictionsActive() then
        status.deferred = true
        status.registered = #registrations
        status.reason = "Aura-sound registration is restricted; existing registrations retained"
        return
    end
    if not (C_UnitAuras and type(C_UnitAuras.AddAuraSound) == "function") then
        status.reason = "C_UnitAuras.AddAuraSound is unavailable"
        return
    end

    local otherTanks = OtherTankTokens()
    status.otherTankCount = #otherTanks
    if #otherTanks == 0 then
        RemoveRegistrations()
        status.registered = 0
        status.reason = "No other tank unit token found"
        return
    end

    RemoveRegistrations()

    for _, unit in ipairs(otherTanks) do
        for _, swap in ipairs(SWAP_AURAS) do
            local trigger = AuraTrigger(swap.triggerName)
            if trigger ~= nil then
                status.attempted = status.attempted + 1
                local info = {
                    unitToken = unit,
                    spellID = swap.spellID,
                    soundFileName = TauntSoundFile(),
                    outputChannel = "Master",
                }
                local ok, registrationID = pcall(C_UnitAuras.AddAuraSound, trigger, info)
                if ok and type(registrationID) == "number" then
                    registrations[#registrations + 1] = registrationID
                else
                    status.failed = status.failed + 1
                end
            else
                status.failed = status.failed + 1
            end
        end
    end

    status.registered = #registrations
    if status.failed > 0 then
        status.reason = "One or more tank-swap aura sounds failed to register"
    elseif status.registered > 0 then
        status.reason = "Armed"
    else
        status.reason = "No tank-swap aura sounds registered"
    end
end

function TankSwap:Refresh(immediate)
    if immediate then
        refreshPending = false
        RegisterNow()
        return
    end

    if refreshPending then return end
    refreshPending = true

    local function DoRefresh()
        refreshPending = false
        RegisterNow()
    end

    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0.2, DoRefresh)
    else
        DoRefresh()
    end
end

function TankSwap:GetRegistrationCount()
    return #registrations
end

function TankSwap:PreviewActualTaunt()
    if type(PlaySoundFile) ~= "function" then return false end
    local path = TauntSoundFile()
    if type(path) ~= "string" or path == "" then return false end
    local ok, willPlay = pcall(PlaySoundFile, path, "Master")
    return ok and willPlay ~= false
end

function TankSwap:GetTauntSoundFile()
    return TauntSoundFile()
end

function TankSwap:GetVoiceChoices()
    return {
        TAUNT_VOICE_LABELS.FOLLOW_TTS,
        TAUNT_VOICE_LABELS.ZIRA,
        TAUNT_VOICE_LABELS.DAVID,
    }
end

function TankSwap:GetSelectedVoiceLabel()
    return TAUNT_VOICE_LABELS[SelectedTauntVoiceKey()] or TAUNT_VOICE_LABELS.FOLLOW_TTS
end

function TankSwap:SetSelectedVoiceLabel(label)
    local db = GetDB()
    if not db then return end
    db.tankSwapVoice = TAUNT_VOICE_KEYS[label] or "FOLLOW_TTS"
    self:Refresh()
end

function TankSwap:GetStatus()
    return {
        enabled = status.enabled,
        deferred = status.deferred,
        otherTankCount = status.otherTankCount,
        attempted = status.attempted,
        registered = status.registered,
        failed = status.failed,
        reason = status.reason,
    }
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:RegisterEvent("PLAYER_ROLES_ASSIGNED")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
events:RegisterEvent("ADDON_RESTRICTION_STATE_CHANGED")
events:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_SPECIALIZATION_CHANGED" then
        local unit = ...
        if unit ~= nil and unit ~= "player" then return end
    elseif event == "ADDON_RESTRICTION_STATE_CHANGED" then
        local restrictionType, state = ...

        -- Blizzard dispatches Activating before the encounter restriction is
        -- enforced. Use that final legal window synchronously so the current
        -- co-tank token is armed before AddAuraSound becomes restricted.
        if state == RESTRICTION_ACTIVATING and restrictionType == RESTRICTION_ENCOUNTER then
            TankSwap:Refresh(true)
            return
        end

        -- Rebuild after any relevant restriction fully deactivates.
        if state ~= RESTRICTION_INACTIVE then return end
        if restrictionType ~= RESTRICTION_ENCOUNTER
            and restrictionType ~= RESTRICTION_COMBAT
            and restrictionType ~= RESTRICTION_CHALLENGE then
            return
        end
    end

    TankSwap:Refresh()
end)
