local CT = _G.ChayAlertHUD
if not CT then return end

local VoicePacks = {}
CT.VoicePacks = VoicePacks
_G.ChayAlertHUDVoicePacks = VoicePacks

local NATIVE_KEY = "NATIVE_TTS"
local MIN_DBM_VOICE_VERSION = 20
local packs = {}
local labels = {}
local labelToKey = {}

local ACTION_FILES = {
    INTERRUPT = "kickcast",
    TANK = "defensive",
    AOE_DAMAGE = "aesoon",
}

local function GetDB()
    return type(CT.GetDB) == "function" and CT:GetDB() or nil
end

local function SafeMetadata(addon, field)
    if not (C_AddOns and type(C_AddOns.GetAddOnMetadata) == "function") then return nil end
    local ok, value = pcall(C_AddOns.GetAddOnMetadata, addon, field)
    if not ok or type(value) ~= "string" or value == "" then return nil end
    return value
end

local function Refresh()
    wipe(packs)
    wipe(labels)
    wipe(labelToKey)

    labels[1] = "Native WoW TTS"
    labelToKey[labels[1]] = NATIVE_KEY

    if not (C_AddOns and type(C_AddOns.GetNumAddOns) == "function" and type(C_AddOns.GetAddOnName) == "function") then
        return
    end

    local ok, count = pcall(C_AddOns.GetNumAddOns)
    if not ok or type(count) ~= "number" then return end

    local discovered = {}
    for index = 1, count do
        local okName, addon = pcall(C_AddOns.GetAddOnName, index)
        if okName and type(addon) == "string" and addon ~= "" then
            local isVoice = SafeMetadata(addon, "X-DBM-Voice")
            if isVoice and isVoice ~= "0" then
                local displayName = SafeMetadata(addon, "X-DBM-Voice-Name") or addon
                local shortName = SafeMetadata(addon, "X-DBM-Voice-ShortName") or addon
                local version = tonumber(SafeMetadata(addon, "X-DBM-Voice-Version")) or 0
                local key = "DBM:" .. addon
                local label
                if version > 0 and version < MIN_DBM_VOICE_VERSION then
                    label = string.format("Compatible Voice Pack: %s (legacy v%d)", displayName, version)
                elseif version == 0 then
                    label = string.format("Compatible Voice Pack: %s (legacy)", displayName)
                else
                    label = string.format("Compatible Voice Pack: %s", displayName)
                end
                packs[key] = {
                    key = key,
                    addon = addon,
                    name = displayName,
                    shortName = shortName,
                    version = version,
                    basePath = "Interface\\AddOns\\" .. addon .. "\\",
                }
                discovered[#discovered + 1] = { key = key, label = label }
            end
        end
    end

    table.sort(discovered, function(a, b) return a.label:lower() < b.label:lower() end)
    for _, item in ipairs(discovered) do
        labels[#labels + 1] = item.label
        labelToKey[item.label] = item.key
        packs[item.key].label = item.label
    end
end

local function SelectedKey()
    local db = GetDB()
    local key = type(db) == "table" and db.voicePackSource or nil
    if key == nil or key == "" then return NATIVE_KEY end
    Refresh()
    if key == NATIVE_KEY or packs[key] then return key end
    return NATIVE_KEY
end

function VoicePacks:GetChoices()
    Refresh()
    local copy = {}
    for i, label in ipairs(labels) do copy[i] = label end
    return copy
end

function VoicePacks:GetSelectedLabel()
    local key = SelectedKey()
    if key == NATIVE_KEY then return "Native WoW TTS" end
    return packs[key] and packs[key].label or "Native WoW TTS"
end

function VoicePacks:SetSelectedLabel(label)
    Refresh()
    local db = GetDB()
    if not db then return end
    db.voicePackSource = labelToKey[label] or NATIVE_KEY
    if CT.TankSwap and type(CT.TankSwap.Refresh) == "function" then
        CT.TankSwap:Refresh()
    end
end

function VoicePacks:GetSelectedPack()
    local key = SelectedKey()
    return key ~= NATIVE_KEY and packs[key] or nil
end

function VoicePacks:IsNativeTTSSelected()
    return SelectedKey() == NATIVE_KEY
end

function VoicePacks:GetActionFile(mechanicType)
    local pack = self:GetSelectedPack()
    if not pack then return nil end
    mechanicType = type(mechanicType) == "string" and mechanicType:upper() or ""
    local file = ACTION_FILES[mechanicType]
    if not file then return nil end
    return pack.basePath .. file .. ".ogg"
end

function VoicePacks:GetTauntFile()
    local pack = self:GetSelectedPack()
    if not pack then return nil end

    -- Compatible voice packs expose a vocabulary version. Current packs use
    -- the dedicated tauntboss cue; older or unknown packs use changemt so an
    -- optional legacy pack cannot silence ChayAlert's protected tank swap.
    if (tonumber(pack.version) or 0) >= MIN_DBM_VOICE_VERSION then
        return pack.basePath .. "tauntboss.ogg"
    end
    return pack.basePath .. "changemt.ogg"
end

function VoicePacks:GetSelectedPackVersionStatus()
    local pack = self:GetSelectedPack()
    if not pack then return nil end
    local version = tonumber(pack.version) or 0
    return {
        version = version,
        current = version >= MIN_DBM_VOICE_VERSION,
        minimum = MIN_DBM_VOICE_VERSION,
    }
end

function VoicePacks:PlayAction(mechanicType)
    local path = self:GetActionFile(mechanicType)
    if not path or type(PlaySoundFile) ~= "function" then return false end
    local ok, willPlay = pcall(PlaySoundFile, path, "Master")
    return ok and willPlay ~= false
end

function VoicePacks:Preview()
    local pack = self:GetSelectedPack()
    if not pack then return false end
    if type(PlaySoundFile) ~= "function" then return false end
    local path = pack.basePath .. "aesoon.ogg"
    local ok, willPlay = pcall(PlaySoundFile, path, "Master")
    return ok and willPlay ~= false
end

Refresh()
