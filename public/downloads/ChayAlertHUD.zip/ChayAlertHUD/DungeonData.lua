-- ChayAlert HUD DungeonData.lua
-- Static Season 2 dungeon/NPC/spell catalog used by ChayAlert HUD.
-- The table contains factual IDs and observable spell traits only; no runtime
-- timers are inferred from this catalog.

local data = {
    version = "2026-08-18-s2",
    order = {
        "altar_of_fangs",
        "murder_row",
        "den_of_nalorakk",
        "the_blinding_vale",
        "voidscar_arena",
        "kings_rest",
        "temple_of_sethraliss",
        "ruby_life_pools",
    },
    dungeons = {
        ["altar_of_fangs"] = {
            name = "Altar of Fangs",
            mapID = 588,
            zones = { 2588, 2589, 2590 },
            mobs = {
                {
                    name = "Ritual Chieftain", npcID = 270306, count = 25,
                    spells = {
                        { id = 1221063 },
                        { id = 1306517, curated = true },
                        { id = 1306550, curated = true },
                        { id = 1306641 },
                        { id = 1306844 },
                        { id = 1306893 },
                        { id = 1306911, curated = true },
                    },
                },
                {
                    name = "Bloodletter", npcID = 261552, count = 5,
                    spells = {
                        { id = 1221063 },
                        { id = 1307526 },
                    },
                },
                {
                    name = "High Evolutionist", npcID = 261557, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1287544 },
                        { id = 1289416, interruptible = true, poison = true },
                        { id = 1292904 },
                        { id = 1306385, curated = true },
                        { id = 1307567, interruptible = true },
                        { id = 1307571, poison = true, curated = true },
                        { id = 1307602 },
                    },
                },
                {
                    name = "Hatchling", npcID = 261556, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1306383 },
                    },
                },
                {
                    name = "Living Venom", npcID = 263112, count = 1,
                    spells = {
                        { id = 1303366 },
                        { id = 1306230, poison = true },
                    },
                },
                {
                    name = "Primal Serpent", npcID = 261560, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1294557, interruptible = true },
                        { id = 1306381 },
                    },
                },
                {
                    name = "Ravenous Descendant", npcID = 261553, count = 5,
                    spells = {
                        { id = 1221063 },
                        { id = 1306308, enrage = true },
                        { id = 1306333 },
                        { id = 1306338 },
                    },
                },
                {
                    name = "Ula'tek's Chosen", npcID = 263109, count = 25,
                    spells = {
                        { id = 1289416, interruptible = true, poison = true },
                        { id = 1292892 },
                        { id = 1306852, curated = true },
                        { id = 1306853 },
                        { id = 1306856 },
                        { id = 1307567, interruptible = true },
                        { id = 1307571, poison = true, curated = true },
                    },
                },
                {
                    name = "Ascendant Serpent", npcID = 261573, count = 30,
                    spells = {
                        { id = 1221063 },
                        { id = 1293420 },
                        { id = 1294934, curated = true },
                        { id = 1294958 },
                        { id = 1295055, curated = true },
                        { id = 1295073 },
                        { id = 1308864, curated = true },
                        { id = 1308865, curated = true },
                        { id = 1309382 },
                        { id = 1309398 },
                        { id = 1309415 },
                        { id = 1309416 },
                    },
                },
                {
                    name = "Twinfang Harrower", npcID = 261554, count = 25,
                    spells = {
                        { id = 1221063 },
                        { id = 1294567, curated = true },
                        { id = 1294568 },
                        { id = 1294569, magic = true, curated = true },
                        { id = 1294570 },
                        { id = 1294572 },
                        { id = 1306668, curated = true },
                        { id = 1306669, curated = true },
                        { id = 1307269 },
                    },
                },
                {
                    name = "Venom Leech", npcID = 261550, count = 1,
                    spells = {
                        { id = 1294432 },
                        { id = 1305637 },
                        { id = 1306232, curated = true },
                        { id = 1306235 },
                        { id = 1307098 },
                        { id = 1307144 },
                    },
                },
                {
                    name = "Rattling Writhe", npcID = 262011, count = 25,
                    spells = {
                        { id = 1221063 },
                        { id = 1294845, poison = true, curated = true },
                        { id = 1294849, curated = true },
                        { id = 1294859 },
                    },
                },
                {
                    name = "Blade of the Altar", npcID = 271453, count = 5,
                    spells = {
                        { id = 1221063 },
                        { id = 1308518, curated = true },
                    },
                },
                {
                    name = "Rav'i", npcID = 259445, count = 0,
                    spells = {
                        { id = 1296050 },
                        { id = 1296058 },
                        { id = 1296069, disease = true },
                        { id = 1296216 },
                        { id = 1296219 },
                        { id = 1296220 },
                        { id = 1297876 },
                        { id = 1298221 },
                        { id = 1298223 },
                        { id = 1298683 },
                        { id = 1306345 },
                        { id = 1307573 },
                        { id = 1307700 },
                        { id = 1307703 },
                        { id = 1307765 },
                        { id = 1307768 },
                        { id = 1307894 },
                        { id = 1307915 },
                        { id = 1307921 },
                        { id = 1309522 },
                        { id = 1310378 },
                        { id = 1310413 },
                    },
                },
                {
                    name = "The Writhing Coil", npcID = 259446, count = 0,
                    spells = {
                        { id = 1287798 },
                        { id = 1287811 },
                        { id = 1298949 },
                        { id = 1299053 },
                        { id = 1299080 },
                        { id = 1299130 },
                        { id = 1299135 },
                        { id = 1299154 },
                        { id = 1299189 },
                        { id = 1299902 },
                        { id = 1299940 },
                        { id = 1300044 },
                        { id = 1300083 },
                        { id = 1300503 },
                        { id = 1300612 },
                        { id = 1300686 },
                        { id = 1305368, poison = true },
                        { id = 1305393 },
                        { id = 1310357 },
                        { id = 1310547 },
                        { id = 1310974 },
                    },
                },
                {
                    name = "Zul'jan", npcID = 259447, count = 0,
                    spells = {
                        { id = 1300876 },
                        { id = 1300886 },
                        { id = 1300888 },
                        { id = 1300892 },
                        { id = 1300894 },
                        { id = 1300901 },
                        { id = 1301111 },
                        { id = 1301114 },
                        { id = 1301217 },
                        { id = 1301350 },
                        { id = 1301353 },
                        { id = 1301413 },
                        { id = 1301508 },
                    },
                },
                {
                    name = "Uncoiled Writhe", npcID = 262398, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1300503 },
                        { id = 1300618 },
                        { id = 1300698 },
                        { id = 1305368, poison = true },
                        { id = 1305393 },
                        { id = 1310666, interruptible = true },
                    },
                },
                {
                    name = "Infused Eggs", npcID = 264798, count = 0,
                    spells = {
                        { id = 1293059 },
                        { id = 1293079 },
                    },
                },
                {
                    name = "Ritual Snake", npcID = 268358, count = 0,
                    spells = {
                        { id = 1300885 },
                    },
                },
                {
                    name = "Ritual Spirit", npcID = 270378, count = 0,
                    spells = {
                        { id = 1306657 },
                    },
                },
                {
                    name = "Uncoiled Writhe", npcID = 270417, count = 0,
                    spells = {
                        { id = 1300618 },
                        { id = 1300698 },
                        { id = 1305393 },
                    },
                },
            },
        },
        ["murder_row"] = {
            name = "Murder Row",
            mapID = 587,
            zones = { 2433, 2435, 2434 },
            mobs = {
                {
                    name = "Felwyrm", npcID = 236085, count = 1,
                    spells = {
                        { id = 1214966 },
                        { id = 1216538, magic = true },
                        { id = 1221063 },
                    },
                },
                {
                    name = "Row Hooligan", npcID = 236073, count = 3,
                    spells = {
                        { id = 1216300, curated = true },
                        { id = 1221063 },
                    },
                },
                {
                    name = "Felonious Mage", npcID = 236084, count = 7,
                    spells = {
                        { id = 1216570 },
                        { id = 1216571, interruptible = true },
                        { id = 1221063 },
                        { id = 1229433, magic = true },
                    },
                },
                {
                    name = "Bribed Guard", npcID = 236071, count = 25,
                    spells = {
                        { id = 1216529, curated = true },
                        { id = 1221063 },
                        { id = 1295035, curated = true },
                    },
                },
                {
                    name = "Bribed Captain", npcID = 252529, count = 35,
                    spells = {
                        { id = 1216529, curated = true },
                        { id = 1221063 },
                        { id = 1256276 },
                        { id = 1295035, curated = true },
                    },
                },
                {
                    name = "Seductive Sayaad", npcID = 236082, count = 6,
                    spells = {
                        { id = 1201554, interruptible = true, magic = true },
                    },
                },
                {
                    name = "Massive Felwyrm", npcID = 236902, count = 12,
                    spells = {
                        { id = 1217633, magic = true, curated = true },
                        { id = 1256299 },
                        { id = 1256300, magic = true },
                        { id = 1258537, curated = true },
                        { id = 1297667 },
                    },
                },
                {
                    name = "Street Sneak", npcID = 236091, count = 3,
                    spells = {
                        { id = 1216284 },
                        { id = 1216589 },
                        { id = 1216590, poison = true, curated = true },
                        { id = 1221063 },
                    },
                },
                {
                    name = "Warehouse Worker", npcID = 236893, count = 2,
                    spells = {
                        { id = 1216970, enrage = true },
                        { id = 1217992 },
                        { id = 1311136, curated = true },
                    },
                },
                {
                    name = "Keen Taskmaster", npcID = 236897, count = 7,
                    spells = {
                        { id = 1216970, enrage = true },
                    },
                },
                {
                    name = "Unleashed Imp", npcID = 234849, count = 2,
                    spells = {
                        { id = 1223204, interruptible = true },
                    },
                },
                {
                    name = "Trained Felhunter", npcID = 235261, count = 5,
                    spells = {
                        { id = 1217881 },
                        { id = 1217930, magic = true },
                        { id = 1221063 },
                        { id = 1293101 },
                    },
                },
                {
                    name = "Fel Invoker", npcID = 235268, count = 7,
                    spells = {
                        { id = 1214980, interruptible = true },
                        { id = 1221063 },
                        { id = 1297693 },
                        { id = 1297695 },
                        { id = 1309970 },
                    },
                },
                {
                    name = "Wrathguard Flayer", npcID = 235267, count = 5,
                    spells = {
                        { id = 1214922, interruptible = true, enrage = true },
                        { id = 1221063 },
                        { id = 1295426 },
                        { id = 1295427, curated = true },
                    },
                },
                {
                    name = "Corrupted Warlock", npcID = 235265, count = 25,
                    spells = {
                        { id = 1217973, curse = true, curated = true },
                        { id = 1221063 },
                        { id = 1294789 },
                        { id = 1297682, curated = true },
                        { id = 1297683 },
                        { id = 1297684, curated = true },
                        { id = 1297686 },
                    },
                },
                {
                    name = "Demon Fly", npcID = 235257, count = 1,
                    spells = {
                        { id = 1221063 },
                        { id = 1293022 },
                    },
                },
                {
                    name = "Shivan Punisher", npcID = 235465, count = 25,
                    spells = {
                        { id = 1294770 },
                        { id = 1294774 },
                        { id = 1297676 },
                        { id = 1297691, curated = true },
                    },
                },
                {
                    name = "Felmaster Lucsei", npcID = 236905, count = 30,
                    spells = {
                        { id = 1216954, curated = true },
                        { id = 1216955 },
                        { id = 1217930, magic = true },
                        { id = 1217937 },
                        { id = 1302007, curated = true },
                        { id = 1302010 },
                    },
                },
                {
                    name = "Defiled Golem", npcID = 235322, count = 35,
                    spells = {
                        { id = 1215872 },
                        { id = 1215961, curated = true },
                        { id = 1215985 },
                        { id = 1218187, curated = true },
                        { id = 1221063 },
                        { id = 1294824, curated = true },
                        { id = 1294827 },
                        { id = 1294836 },
                        { id = 1294870, curated = true },
                    },
                },
                {
                    name = "Xathuux the Annihilator", npcID = 234647, count = 0,
                    spells = {
                        { id = 473898 },
                        { id = 474197 },
                        { id = 474231 },
                        { id = 474234 },
                        { id = 1214637 },
                        { id = 1214641 },
                        { id = 1214647 },
                        { id = 1214663 },
                        { id = 1295453 },
                        { id = 1295455 },
                    },
                },
                {
                    name = "Kystia Manaheart", npcID = 234648, count = 0,
                    spells = {
                        { id = 474238 },
                        { id = 474240 },
                        { id = 1214959 },
                        { id = 1217464 },
                        { id = 1217989 },
                        { id = 1221063 },
                        { id = 1223906 },
                        { id = 1230298 },
                        { id = 1264095 },
                    },
                },
                {
                    name = "Zaen Bladesorrow", npcID = 234649, count = 0,
                    spells = {
                        { id = 474478 },
                        { id = 474483 },
                        { id = 474515, poison = true },
                        { id = 474545 },
                        { id = 474740 },
                        { id = 474763 },
                        { id = 734276, interruptible = true },
                        { id = 1214352 },
                        { id = 1214355 },
                        { id = 1214357 },
                        { id = 1217123 },
                        { id = 1218347 },
                        { id = 1221063 },
                        { id = 1222598 },
                        { id = 1222795 },
                        { id = 1223939, poison = true },
                    },
                },
                {
                    name = "Nibbles", npcID = 234660, count = 0,
                    spells = {
                        { id = 1217464 },
                        { id = 1221063 },
                        { id = 1228198, magic = true },
                        { id = 1230289 },
                        { id = 1230304 },
                        { id = 1253811 },
                        { id = 1253813 },
                    },
                },
                {
                    name = "Lithiel Cinderfury", npcID = 234763, count = 0,
                    spells = {
                        { id = 474375, interruptible = true },
                        { id = 474408 },
                        { id = 474457 },
                        { id = 474462 },
                        { id = 1214675 },
                        { id = 1214730 },
                        { id = 1214740 },
                        { id = 1216945, interruptible = true },
                        { id = 1217345 },
                        { id = 1217384 },
                        { id = 1217415 },
                        { id = 1217881 },
                        { id = 1226469 },
                        { id = 1287627 },
                    },
                },
                {
                    name = "Furious Vilefiend", npcID = 234799, count = 0,
                    spells = {
                        { id = 1217881 },
                        { id = 1293101 },
                    },
                },
                {
                    name = "Forbidden Freight", npcID = 234852, count = 0,
                    spells = {
                        { id = 1217099, interruptible = true },
                        { id = 1219631 },
                        { id = 1222598 },
                        { id = 1266241 },
                    },
                },
                {
                    name = "Crate Loader", npcID = 234860, count = 0,
                    spells = {
                        { id = 474766 },
                        { id = 474768 },
                    },
                },
                {
                    name = "Silvermoon Patron", npcID = 234984, count = 0,
                    spells = {
                        { id = 44427 },
                        { id = 1214260 },
                        { id = 1214487 },
                    },
                },
                {
                    name = "Legion Axe", npcID = 235520, count = 0,
                    spells = {
                        { id = 5543 },
                        { id = 1214650 },
                    },
                },
                {
                    name = "Selenar Sunshy", npcID = 235841, count = 0,
                    spells = {
                        { id = 1216074 },
                    },
                },
                {
                    name = "Masked Noble", npcID = 236088, count = 0,
                    spells = {
                        { id = 1219468 },
                    },
                },
                {
                    name = "Rowdy Patron", npcID = 236525, count = 0,
                    spells = {
                        { id = 1213658, interruptible = true, enrage = true },
                    },
                },
                {
                    name = "Wild Imp", npcID = 237626, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1223204, interruptible = true },
                        { id = 1226469 },
                    },
                },
                {
                    name = "Infernal", npcID = 238414, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1231256 },
                        { id = 1231262 },
                        { id = 1231353 },
                    },
                },
                {
                    name = "Nauseous Patron", npcID = 240289, count = 0,
                    spells = {
                        { id = 1216076 },
                    },
                },
                {
                    name = "Influentual Reviewer", npcID = 253081, count = 0,
                    spells = {
                        { id = 1257877, interruptible = true },
                    },
                },
                {
                    name = "Tiny Felwyrm", npcID = 253324, count = 0,
                    spells = {
                        { id = 1214966 },
                        { id = 1216538, magic = true },
                    },
                },
                {
                    name = "Kystia Manaheart", npcID = 255050, count = 0,
                    spells = {
                        { id = 1264106, interruptible = true },
                        { id = 1264110, interruptible = true },
                    },
                },
                {
                    name = "Seductive Sayaad", npcID = 255604, count = 6,
                    spells = {
                        { id = 1201554, interruptible = true, magic = true },
                    },
                },
                {
                    name = "Belath Dawnblade", npcID = 263940, count = 0,
                    spells = {
                        { id = 1218465 },
                        { id = 1218466 },
                        { id = 1218467 },
                        { id = 1218468 },
                        { id = 1218508, curated = true },
                        { id = 1255881 },
                    },
                },
                {
                    name = "Trained Felhunter", npcID = 272246, count = 0,
                    spells = {
                        { id = 1293101 },
                    },
                },
            },
        },
        ["den_of_nalorakk"] = {
            name = "Den of Nalorakk",
            mapID = 586,
            zones = { 2513, 2514, 2564 },
            mobs = {
                {
                    name = "Spirit of Hunger", npcID = 245855, count = 25,
                    spells = {
                        { id = 1221063 },
                        { id = 1238687, curated = true },
                        { id = 1238725 },
                        { id = 1238760, curated = true },
                        { id = 1249737 },
                    },
                },
                {
                    name = "Earthwhisper Tender", npcID = 241814, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1241214, interruptible = true },
                        { id = 1297696, interruptible = true, magic = true },
                    },
                },
                {
                    name = "Thornclaw Gatherer", npcID = 241813, count = 5,
                    spells = {
                        { id = 1221063 },
                        { id = 1241217, curated = true },
                        { id = 1297699, disease = true },
                        { id = 1297701, curated = true },
                    },
                },
                {
                    name = "Territorial Matriarch", npcID = 241808, count = 8,
                    spells = {
                        { id = 1221063 },
                        { id = 1238053, enrage = true },
                        { id = 1241219 },
                    },
                },
                {
                    name = "The Winter Squall", npcID = 250478, count = 50,
                    spells = {
                        { id = 1221063 },
                        { id = 1309947 },
                        { id = 1309964, curated = true },
                    },
                },
                {
                    name = "Frostfang", npcID = 241874, count = 5,
                    spells = {
                        { id = 1221063 },
                        { id = 1241226 },
                        { id = 1265400 },
                        { id = 1265402 },
                    },
                },
                {
                    name = "Terra Rumbler", npcID = 241911, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1296518 },
                        { id = 1296519 },
                    },
                },
                {
                    name = "Frigid Mauler", npcID = 241872, count = 9,
                    spells = {
                        { id = 1221063 },
                        { id = 1309919, interruptible = true, curated = true },
                    },
                },
                {
                    name = "Glacial Revenant", npcID = 241876, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1239860, magic = true },
                        { id = 1239871 },
                        { id = 1266178 },
                    },
                },
                {
                    name = "Avatar of Determination", npcID = 241869, count = 28,
                    spells = {
                        { id = 1221063 },
                        { id = 1240280, curated = true },
                        { id = 1241463, curated = true },
                        { id = 1241464, curated = true },
                    },
                },
                {
                    name = "Ruthless Totemcaller", npcID = 245143, count = 5,
                    spells = {
                        { id = 1246820 },
                    },
                },
                {
                    name = "Stormbound Mystic", npcID = 245139, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1246687, interruptible = true },
                        { id = 1297778, interruptible = true },
                    },
                },
                {
                    name = "Grizzled Warbringer", npcID = 245146, count = 25,
                    spells = {
                        { id = 1221063 },
                        { id = 1246957, curated = true },
                        { id = 1246986, curated = true },
                    },
                },
                {
                    name = "Bonded Beasttamer", npcID = 245145, count = 6,
                    spells = {
                        { id = 1246847, interruptible = true },
                        { id = 1246860 },
                        { id = 1246865, enrage = true },
                        { id = 1246877 },
                        { id = 1266207 },
                    },
                },
                {
                    name = "Curious Yearling", npcID = 241809, count = 0,
                    spells = {
                        { id = 1238053, enrage = true },
                    },
                },
                {
                    name = "The Hoardmonger", npcID = 241812, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1232012 },
                        { id = 1234021 },
                        { id = 1234233 },
                        { id = 1234681 },
                        { id = 1234734 },
                        { id = 1234846, poison = true },
                        { id = 1235072 },
                        { id = 1235075 },
                        { id = 1235076 },
                        { id = 1235079 },
                        { id = 1235105 },
                        { id = 1235125 },
                        { id = 1235129 },
                        { id = 1235405 },
                        { id = 1245593 },
                    },
                },
                {
                    name = "Keen-Eyed Striker", npcID = 241816, count = 7,
                    spells = {
                        { id = 1221063 },
                        { id = 1238439, curated = true },
                        { id = 1238440 },
                    },
                },
                {
                    name = "Sentinel of Winter", npcID = 244100, count = 0,
                    spells = {
                        { id = 1235548 },
                        { id = 1235549, magic = true },
                        { id = 1235623 },
                        { id = 1235635 },
                        { id = 1235656 },
                        { id = 1235658 },
                        { id = 1235783 },
                        { id = 1235795 },
                        { id = 1236289 },
                        { id = 1297749 },
                    },
                },
                {
                    name = "Raging Squall", npcID = 244696, count = 0,
                    spells = {
                        { id = 1235638 },
                        { id = 1235641 },
                    },
                },
                {
                    name = "Fractured Shivercore", npcID = 244759, count = 0,
                    spells = {
                        { id = 1234314 },
                        { id = 1235829, interruptible = true },
                        { id = 1263590 },
                        { id = 1263597 },
                    },
                },
                {
                    name = "Loa Speaker Nanea", npcID = 244889, count = 35,
                    spells = {
                        { id = 1247366 },
                        { id = 1247367, curated = true },
                        { id = 1251027 },
                        { id = 1264753 },
                        { id = 1290205, interruptible = true },
                        { id = 1296722, curated = true },
                        { id = 1309924 },
                        { id = 1309925, curated = true },
                    },
                },
                {
                    name = "Grizzled Warbringer", npcID = 245148, count = 0,
                    spells = {
                        { id = 1247030 },
                        { id = 1311572 },
                    },
                },
                {
                    name = "Loyal Saberfang", npcID = 245190, count = 5,
                    spells = {
                        { id = 1246865, enrage = true },
                        { id = 1246882 },
                    },
                },
                {
                    name = "Starvation Effigy", npcID = 245567, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1238801, curse = true, curated = true },
                    },
                },
                {
                    name = "Nalorakk", npcID = 246404, count = 0,
                    spells = {
                        { id = 1221063 },
                        { id = 1242860 },
                        { id = 1242869 },
                        { id = 1242887 },
                        { id = 1243002 },
                        { id = 1243011 },
                        { id = 1243273 },
                        { id = 1243408 },
                        { id = 1243569 },
                        { id = 1254622 },
                        { id = 1261976 },
                        { id = 1297792 },
                        { id = 1297793 },
                        { id = 1297796 },
                        { id = 1297797 },
                    },
                },
                {
                    name = "Zul'jarra", npcID = 246409, count = 0,
                    spells = {
                        { id = 1243018 },
                        { id = 1243078 },
                        { id = 1243856 },
                        { id = 1249186 },
                        { id = 1261776 },
                        { id = 1262253 },
                        { id = 1270826 },
                    },
                },
                {
                    name = "Echo of Nalorakk", npcID = 247301, count = 0,
                    spells = {
                        { id = 1242976 },
                        { id = 1255570 },
                        { id = 1255577 },
                        { id = 1262577 },
                    },
                },
                {
                    name = "Snow Orb Stalker", npcID = 251189, count = 0,
                    spells = {
                        { id = 1253083 },
                    },
                },
                {
                    name = "Volatile Totem", npcID = 272074, count = 0,
                    spells = {
                        { id = 1309931 },
                    },
                },
                {
                    name = "The Pale Eye", npcID = 245076, count = 0,
                    spells = {
                        { id = 1250805 },
                    },
                },
                {
                    name = "Keen-Eyed Striker", npcID = 245752, count = 7,
                    spells = {
                        { id = 110960 },
                        { id = 1238439, curated = true },
                        { id = 1238440 },
                        { id = 1239394, interruptible = true },
                    },
                },
                {
                    name = "Magma Totem", npcID = 248666, count = 0,
                    spells = {
                        { id = 1246821 },
                        { id = 1246825 },
                    },
                },
            },
        },
        ["the_blinding_vale"] = {
            name = "The Blinding Vale",
            mapID = 584,
            zones = { 2500 },
            mobs = {
                {
                    name = "Lightgorged Lasher", npcID = 245345, count = 7,
                    spells = {
                        { id = 1238158, interruptible = true },
                        { id = 1238173 },
                    },
                },
                {
                    name = "Lasher", npcID = 245410, count = 1,
                    spells = {
                        { id = 1238084, magic = true, curated = true },
                    },
                },
                {
                    name = "Underbrush Stalker", npcID = 245339, count = 6,
                    spells = {
                        { id = 1238066 },
                        { id = 1238071 },
                        { id = 1238076, curated = true },
                    },
                },
                {
                    name = "Virid Grovekeeper", npcID = 245346, count = 20,
                    spells = {
                        { id = 1237855, curated = true },
                        { id = 1237858, curated = true },
                        { id = 1255205, curated = true },
                    },
                },
                {
                    name = "Sporeblight Belcher", npcID = 254850, count = 25,
                    spells = {
                        { id = 1242180 },
                        { id = 1242200 },
                        { id = 1263628 },
                        { id = 1263636, curated = true },
                        { id = 1263642 },
                        { id = 1271385, curated = true },
                    },
                },
                {
                    name = "Radiant Spellsower", npcID = 245336, count = 7,
                    spells = {
                        { id = 1238063, interruptible = true },
                        { id = 1238200, interruptible = true },
                        { id = 1267029 },
                        { id = 1301834, interruptible = true },
                    },
                },
                {
                    name = "Lightfeather Petalwing", npcID = 245484, count = 7,
                    spells = {
                        { id = 1238294, interruptible = true, curated = true },
                        { id = 1242180 },
                        { id = 1242200 },
                    },
                },
                {
                    name = "Thorny Saptor", npcID = 245473, count = 5,
                    spells = {
                        { id = 269230 },
                        { id = 269231 },
                        { id = 269232 },
                        { id = 1242180 },
                        { id = 1242200 },
                        { id = 1303039 },
                    },
                },
                {
                    name = "Spineshield Beetle", npcID = 245527, count = 1,
                    spells = {
                        { id = 1238581, magic = true },
                        { id = 1238588 },
                        { id = 1242180 },
                        { id = 1242200 },
                    },
                },
                {
                    name = "Leafy Grovecrawler", npcID = 245460, count = 7,
                    spells = {
                        { id = 1238232, interruptible = true },
                        { id = 1242180 },
                        { id = 1242200 },
                    },
                },
                {
                    name = "Overgrown Hydra", npcID = 245513, count = 25,
                    spells = {
                        { id = 1238368, curated = true },
                        { id = 1238463 },
                        { id = 1238638 },
                        { id = 1238642, curated = true },
                    },
                },
                {
                    name = "Luminous Thornmaw", npcID = 246871, count = 22,
                    spells = {
                        { id = 1242135, curated = true },
                        { id = 1242138, curated = true },
                        { id = 1242180 },
                        { id = 1242200 },
                    },
                },
                {
                    name = "Meittik", npcID = 243028, count = 0,
                    spells = {
                        { id = 1234753 },
                        { id = 1234773 },
                        { id = 1234802 },
                        { id = 1253028 },
                        { id = 1276586 },
                    },
                },
                {
                    name = "Kezkitt", npcID = 243029, count = 0,
                    spells = {
                        { id = 1235564 },
                        { id = 1235574 },
                        { id = 1235616, interruptible = true },
                        { id = 1235828 },
                        { id = 1253028 },
                    },
                },
                {
                    name = "Lekshi", npcID = 243030, count = 0,
                    spells = {
                        { id = 1234850 },
                        { id = 1235546 },
                        { id = 1235640 },
                        { id = 1235642 },
                        { id = 1235865 },
                        { id = 1253028 },
                        { id = 1261011 },
                        { id = 1261013 },
                    },
                },
                {
                    name = "Lightwarden Ruia", npcID = 245912, count = 0,
                    spells = {
                        { id = 1239821, interruptible = true },
                        { id = 1239824 },
                        { id = 1239825 },
                        { id = 1239882 },
                        { id = 1239883 },
                        { id = 1239885 },
                        { id = 1239919 },
                        { id = 1240100 },
                        { id = 1240152 },
                        { id = 1240210 },
                        { id = 1240257 },
                        { id = 1241058 },
                        { id = 1241067 },
                        { id = 1242180 },
                        { id = 1242244 },
                        { id = 1257094 },
                        { id = 1272265 },
                    },
                },
                {
                    name = "Ziekket", npcID = 247676, count = 0,
                    spells = {
                        { id = 1246372 },
                        { id = 1246527 },
                        { id = 1246607 },
                        { id = 1246751 },
                        { id = 1246753 },
                        { id = 1246858 },
                        { id = 1247039 },
                        { id = 1247050 },
                        { id = 1247377 },
                        { id = 1247644 },
                        { id = 1247685 },
                        { id = 1247746 },
                    },
                },
                {
                    name = "Ikuzz the Light Hunter", npcID = 244887, count = 0,
                    spells = {
                        { id = 1236709 },
                        { id = 1236731 },
                        { id = 1236746 },
                        { id = 1236747 },
                        { id = 1237073 },
                        { id = 1237093 },
                        { id = 1237166 },
                        { id = 1237267 },
                        { id = 1237330 },
                        { id = 1253410 },
                        { id = 1263420 },
                        { id = 1272290 },
                    },
                },
                {
                    name = "Lightblossom", npcID = 244528, count = 0,
                    spells = {
                        { id = 1235752 },
                    },
                },
                {
                    name = "Spirit Bear", npcID = 246367, count = 0,
                    spells = {
                        { id = 1240210 },
                        { id = 1240257 },
                        { id = 1241058 },
                        { id = 1257094 },
                    },
                },
                {
                    name = "Spirit Moonkin", npcID = 246371, count = 0,
                    spells = {
                        { id = 1239824 },
                        { id = 1239825 },
                        { id = 1240100 },
                        { id = 1240152 },
                    },
                },
                {
                    name = "Lightspawn Lasher", npcID = 247755, count = 0,
                    spells = {
                        { id = 1246527 },
                        { id = 1247669, interruptible = true },
                        { id = 1253320 },
                    },
                },
                {
                    name = "Potatoad Matriarch", npcID = 249756, count = 30,
                    spells = {
                        { id = 1250100, curated = true },
                        { id = 1250199, curated = true },
                        { id = 1250200 },
                        { id = 1250813 },
                        { id = 1250937, poison = true, curated = true },
                    },
                },
                {
                    name = "Potadpole Egg", npcID = 249783, count = 0,
                    spells = {
                        { id = 1250203 },
                    },
                },
                {
                    name = "Newborn Potadpole", npcID = 250202, count = 0,
                    spells = {
                        { id = 1250829 },
                        { id = 1250831 },
                    },
                },
                {
                    name = "Bloodthorn Roots", npcID = 253571, count = 0,
                    spells = {
                        { id = 1259365, magic = true },
                    },
                },
            },
        },
        ["voidscar_arena"] = {
            name = "Voidscar Arena",
            mapID = 585,
            zones = { 2572, 2573, 2574 },
            mobs = {
                {
                    name = "Lost Sethrak", npcID = 243996, count = 4,
                    spells = {
                        { id = 1250640 },
                        { id = 1268707 },
                    },
                },
                {
                    name = "Feral Saberon", npcID = 243988, count = 4,
                    spells = {
                        { id = 1249661, enrage = true },
                        { id = 1267754 },
                        { id = 1267894, curated = true },
                    },
                },
                {
                    name = "Sycophantic Tarasek", npcID = 243983, count = 4,
                    spells = {
                        { id = 1249661, enrage = true },
                        { id = 1250043, magic = true, curated = true },
                    },
                },
                {
                    name = "Longtooth Tuskarr", npcID = 243985, count = 5,
                    spells = {
                        { id = 1249661, enrage = true },
                        { id = 1310319, enrage = true },
                    },
                },
                {
                    name = "Dominated Brawler", npcID = 238883, count = 7,
                    spells = {
                        { id = 1254826, enrage = true },
                        { id = 1298899, interruptible = true, curated = true },
                    },
                },
                {
                    name = "Enthralled Shaman", npcID = 241496, count = 7,
                    spells = {
                        { id = 1228176, interruptible = true },
                        { id = 1246820 },
                    },
                },
                {
                    name = "Voidtouched Magi", npcID = 252072, count = 25,
                    spells = {
                        { id = 1299913, curated = true },
                        { id = 1299938, interruptible = true, curated = true },
                    },
                },
                {
                    name = "Brutal Overseer", npcID = 252053, count = 25,
                    spells = {
                        { id = 1228126 },
                        { id = 1228127 },
                        { id = 1261645 },
                        { id = 1298900, curated = true },
                        { id = 1298901 },
                        { id = 1310309, curated = true },
                    },
                },
                {
                    name = "Aegyra the Unyielding", npcID = 267545, count = 40,
                    spells = {
                        { id = 1298903 },
                        { id = 1298908, curated = true },
                        { id = 1298922, curated = true },
                        { id = 1298924, curated = true },
                        { id = 1298933 },
                        { id = 1299125, curated = true },
                        { id = 1299133, curated = true },
                        { id = 1299145, curated = true },
                        { id = 1299210, curated = true },
                    },
                },
                {
                    name = "Raj'kess the Spellstorm", npcID = 267546, count = 40,
                    spells = {
                        { id = 1298902 },
                        { id = 1299240 },
                        { id = 1299244 },
                        { id = 1299257 },
                        { id = 1299270, curated = true },
                        { id = 1299273 },
                        { id = 1311712 },
                        { id = 1311747, curated = true },
                        { id = 1311754 },
                    },
                },
                {
                    name = "Chitigoth", npcID = 244260, count = 25,
                    spells = {
                        { id = 1234833, curated = true },
                        { id = 1234855, curated = true },
                        { id = 1249661, enrage = true },
                        { id = 1250079 },
                        { id = 1250695 },
                    },
                },
                {
                    name = "Raging Raptor", npcID = 249608, count = 5,
                    spells = {
                        { id = 1249661, enrage = true },
                    },
                },
                {
                    name = "Protective Turtle", npcID = 249603, count = 5,
                    spells = {
                        { id = 1249661, enrage = true },
                        { id = 1250021 },
                        { id = 1250023 },
                        { id = 1310320 },
                    },
                },
                {
                    name = "Brutok", npcID = 244309, count = 25,
                    spells = {
                        { id = 1234890, curated = true },
                        { id = 1234917 },
                        { id = 1245186, curated = true },
                        { id = 1249661, enrage = true },
                        { id = 1269284 },
                        { id = 1310321 },
                    },
                },
                {
                    name = "Abducted Drakonid", npcID = 249461, count = 5,
                    spells = {
                        { id = 1249236 },
                        { id = 1249238, magic = true, curated = true },
                        { id = 1249661, enrage = true },
                    },
                },
                {
                    name = "Angry Krolusk", npcID = 249590, count = 8,
                    spells = {
                        { id = 1249621, interruptible = true, curated = true },
                    },
                },
                {
                    name = "Savage Shredclaw", npcID = 243835, count = 5,
                    spells = {
                        { id = 1233535, curated = true },
                    },
                },
                {
                    name = "Kilivore Screamer", npcID = 243766, count = 7,
                    spells = {
                        { id = 1233398, interruptible = true, curated = true },
                    },
                },
                {
                    name = "Agitated Voidscythe", npcID = 263228, count = 25,
                    spells = {
                        { id = 1233472, curated = true },
                        { id = 1233485 },
                        { id = 1289258, poison = true, curated = true },
                        { id = 1289265, curated = true },
                        { id = 1311778, curated = true },
                    },
                },
                {
                    name = "Blistercreep", npcID = 243736, count = 1,
                    spells = {
                        { id = 1233264 },
                    },
                },
                {
                    name = "Watchful Harrower", npcID = 245950, count = 65,
                    spells = {
                        { id = 1239855, magic = true },
                        { id = 1239856, curated = true },
                        { id = 1300116 },
                        { id = 1300138, curated = true },
                        { id = 1300156 },
                    },
                },
                {
                    name = "Devouring Brutalizer", npcID = 268184, count = 30,
                    spells = {
                        { id = 1252406, curated = true },
                        { id = 1282959 },
                        { id = 1300243, curated = true },
                        { id = 1300244 },
                        { id = 1300248 },
                        { id = 1300249, curated = true },
                        { id = 1300250 },
                        { id = 1310324, interruptible = true },
                    },
                },
                {
                    name = "Scavenging Siphoid", npcID = 252508, count = 1,
                    spells = {
                        { id = 1269866 },
                        { id = 1269878 },
                    },
                },
                {
                    name = "Voidminder", npcID = 244708, count = 7,
                    spells = {
                        { id = 1227020 },
                        { id = 1310324, interruptible = true },
                    },
                },
                {
                    name = "Taz'Rah", npcID = 238887, count = 0,
                    spells = {
                        { id = 1296889 },
                        { id = 1296963 },
                        { id = 1296967 },
                        { id = 1297017 },
                        { id = 1300259 },
                        { id = 1300262 },
                    },
                },
                {
                    name = "Atroxus", npcID = 239008, count = 0,
                    spells = {
                        { id = 1222484 },
                        { id = 1222519 },
                        { id = 1222642 },
                        { id = 1222721 },
                        { id = 1222724 },
                        { id = 1226031, poison = true },
                        { id = 1226120 },
                        { id = 1247395 },
                        { id = 1262497 },
                        { id = 1263971, poison = true },
                        { id = 1300351 },
                    },
                },
                {
                    name = "Charonus", npcID = 239167, count = 0,
                    spells = {
                        { id = 1222755 },
                        { id = 1227197 },
                        { id = 1227247 },
                        { id = 1248112 },
                        { id = 1248121 },
                        { id = 1300372 },
                        { id = 1310025 },
                        { id = 1311923 },
                    },
                },
                {
                    name = "Toxic Creeper", npcID = 239070, count = 0,
                    spells = {
                        { id = 1222692 },
                        { id = 1222693 },
                        { id = 1282892 },
                    },
                },
                {
                    name = "Magma Totem", npcID = 248666, count = 0,
                    spells = {
                        { id = 1246821 },
                        { id = 1246825 },
                    },
                },
                {
                    name = "Ethereal Shade", npcID = 254677, count = 0,
                    spells = {
                        { id = 1222100 },
                        { id = 1222103 },
                        { id = 1222105 },
                        { id = 1296963 },
                    },
                },
                {
                    name = "Targeting Stalker", npcID = 255000, count = 0,
                    spells = {
                        { id = 1263984 },
                        { id = 1264188 },
                    },
                },
                {
                    name = "Gravitic Orb", npcID = 255001, count = 0,
                    spells = {
                        { id = 1263983 },
                    },
                },
            },
        },
        ["kings_rest"] = {
            name = "Kings' Rest",
            mapID = 249,
            zones = { 1004 },
            mobs = {
                {
                    name = "Animated Guardian", npcID = 133935, count = 22,
                    spells = {
                        { id = 270003, curated = true },
                        { id = 270016, curated = true },
                        { id = 1310755 },
                    },
                },
                {
                    name = "Minion of Zul", npcID = 133943, count = 0,
                    spells = {
                        { id = 269935, magic = true },
                    },
                },
                {
                    name = "Risen Hexer", npcID = 134174, count = 20,
                    spells = {
                        { id = 269972, interruptible = true, curse = true, curated = true },
                        { id = 1294815, interruptible = true, magic = true },
                    },
                },
                {
                    name = "Shadow-Borne Champion", npcID = 134158, count = 25,
                    spells = {
                        { id = 269928, curated = true },
                        { id = 269976, enrage = true, curated = true },
                        { id = 1305945, curated = true },
                        { id = 1310758 },
                    },
                },
                {
                    name = "Umbral Warrior", npcID = 134157, count = 5,
                    spells = {
                        { id = 1311942 },
                    },
                },
                {
                    name = "The Golden Serpent", npcID = 135322, count = 0,
                    spells = {
                        { id = 265773 },
                        { id = 265781 },
                        { id = 265910 },
                        { id = 265923 },
                        { id = 265991 },
                        { id = 1306736 },
                        { id = 1311987 },
                        { id = 1311988 },
                        { id = 1312104 },
                    },
                },
                {
                    name = "Skeletal Hunting Raptor", npcID = 137487, count = 10,
                    spells = {
                        { id = 270500 },
                        { id = 270502, curated = true },
                        { id = 270503, curated = true },
                        { id = 1297763, enrage = true },
                    },
                },
                {
                    name = "Queen Patlaa", npcID = 137486, count = 25,
                    spells = {
                        { id = 270931, curated = true },
                        { id = 1294883 },
                        { id = 1297763, enrage = true },
                        { id = 1305982, curated = true },
                        { id = 1306761 },
                        { id = 1306763, poison = true, curated = true },
                    },
                },
                {
                    name = "King A'akul", npcID = 137484, count = 25,
                    spells = {
                        { id = 1297918, curated = true },
                        { id = 1297970, curated = true },
                    },
                },
                {
                    name = "Bloodsworn Assassin", npcID = 137485, count = 7,
                    spells = {
                        { id = 1297781, curated = true },
                    },
                },
                {
                    name = "Seneschal M'bara", npcID = 134251, count = 10,
                    spells = {
                        { id = 270901, interruptible = true, magic = true, curated = true },
                        { id = 1296671, magic = true },
                    },
                },
                {
                    name = "Guard Captain Atu", npcID = 137473, count = 10,
                    spells = {
                        { id = 1296671, magic = true, curated = true },
                    },
                },
                {
                    name = "King Rahu'ai", npcID = 134331, count = 25,
                    spells = {
                        { id = 270889, curated = true },
                        { id = 270891, curated = true },
                        { id = 1296671, magic = true },
                        { id = 1296719 },
                    },
                },
                {
                    name = "King Timalji", npcID = 137474, count = 25,
                    spells = {
                        { id = 270927, curated = true },
                        { id = 270928, curated = true },
                        { id = 1297326 },
                        { id = 1306049, curated = true },
                        { id = 1306056 },
                    },
                },
                {
                    name = "Queen Wasi", npcID = 137478, count = 25,
                    spells = {
                        { id = 270920, interruptible = true, magic = true, curated = true },
                        { id = 1294972, interruptible = true, magic = true },
                        { id = 1297326 },
                    },
                },
                {
                    name = "Purification Construct", npcID = 134739, count = 25,
                    spells = {
                        { id = 270292, curated = true },
                        { id = 270293, curated = true },
                        { id = 1310755 },
                    },
                },
                {
                    name = "Interment Construct", npcID = 137969, count = 15,
                    spells = {
                        { id = 271555, curated = true },
                        { id = 271561 },
                        { id = 271562 },
                        { id = 1310755 },
                        { id = 1312569 },
                    },
                },
                {
                    name = "Mchimba the Embalmer", npcID = 134993, count = 0,
                    spells = {
                        { id = 267618 },
                        { id = 267639 },
                        { id = 267702 },
                        { id = 267874 },
                        { id = 271290 },
                        { id = 1312146 },
                        { id = 1312848 },
                    },
                },
                {
                    name = "Phantom Hex Priest", npcID = 135204, count = 7,
                    spells = {
                        { id = 270492, interruptible = true, curse = true, curated = true },
                        { id = 1295125, interruptible = true, magic = true },
                    },
                },
                {
                    name = "Royal Berserker", npcID = 135167, count = 22,
                    spells = {
                        { id = 270482, curated = true },
                        { id = 270485 },
                        { id = 1301851, curated = true },
                    },
                },
                {
                    name = "Spectral Shaman", npcID = 135239, count = 7,
                    spells = {
                        { id = 270497, curated = true },
                        { id = 270499, magic = true, curated = true },
                    },
                },
                {
                    name = "Ghostly Brute", npcID = 135231, count = 25,
                    spells = {
                        { id = 270514, curated = true },
                        { id = 1302028, curated = true },
                    },
                },
                {
                    name = "Honored Raptor", npcID = 135192, count = 5,
                    spells = {
                        { id = 270500 },
                        { id = 270502, curated = true },
                        { id = 270503, curated = true },
                    },
                },
                {
                    name = "Shadow of Zul", npcID = 138489, count = 30,
                    spells = {
                        { id = 272388, curated = true },
                        { id = 1298304, curated = true },
                        { id = 1309385, curated = true },
                    },
                },
                {
                    name = "King Dazar", npcID = 136160, count = 0,
                    spells = {
                        { id = 268586 },
                        { id = 268587 },
                        { id = 268589 },
                        { id = 268590 },
                        { id = 268591 },
                        { id = 269503 },
                        { id = 1302945 },
                        { id = 1303105 },
                        { id = 1303111 },
                        { id = 1303115 },
                        { id = 1303267 },
                        { id = 1303372 },
                        { id = 1303374 },
                        { id = 1303396 },
                        { id = 1303399 },
                    },
                },
                {
                    name = "Embalming Fluid", npcID = 137989, count = 1,
                    spells = {
                        { id = 271563 },
                        { id = 1298104, poison = true },
                    },
                },
                {
                    name = "Disruption Totem", npcID = 135761, count = 0,
                    spells = {
                        { id = 267257 },
                        { id = 1309499 },
                    },
                },
                {
                    name = "Explosive Totem", npcID = 135764, count = 0,
                    spells = {
                        { id = 267077 },
                        { id = 1309499 },
                    },
                },
                {
                    name = "Torrent Totem", npcID = 135765, count = 0,
                    spells = {
                        { id = 267105 },
                        { id = 1309499 },
                    },
                },
                {
                    name = "Coffin", npcID = 136256, count = 0,
                    spells = {
                    },
                },
                {
                    name = "T'zala", npcID = 136976, count = 0,
                    spells = {
                        { id = 1303324 },
                        { id = 1303326 },
                        { id = 1303327 },
                        { id = 1303396 },
                        { id = 1303399 },
                        { id = 1303488 },
                        { id = 1303490 },
                    },
                },
                {
                    name = "Reban", npcID = 136984, count = 0,
                    spells = {
                        { id = 269230 },
                        { id = 269231 },
                        { id = 269232 },
                        { id = 269369, interruptible = true },
                        { id = 1303039 },
                    },
                },
                {
                    name = "Minion of Zul", npcID = 138493, count = 0,
                    spells = {
                        { id = 269935, magic = true },
                    },
                },
                {
                    name = "Aka'ali the Conqueror", npcID = 269808, count = 0,
                    spells = {
                        { id = 266237 },
                        { id = 266951 },
                        { id = 267494 },
                        { id = 1310761 },
                    },
                },
                {
                    name = "Zanazal the Wise", npcID = 269810, count = 0,
                    spells = {
                        { id = 267060 },
                        { id = 267273, interruptible = true, poison = true },
                        { id = 1305810 },
                    },
                },
                {
                    name = "Kula the Butcher", npcID = 269811, count = 0,
                    spells = {
                        { id = 266191 },
                        { id = 266206 },
                        { id = 266231 },
                    },
                },
                {
                    name = "Half-Finished Mummy", npcID = 270502, count = 7,
                    spells = {
                        { id = 267763, interruptible = true, disease = true },
                    },
                },
                {
                    name = "Animated Gold", npcID = 135406, count = 0,
                    spells = {
                        { id = 265991 },
                        { id = 1289063 },
                    },
                },
                {
                    name = "Healing Tide Totem", npcID = 137591, count = 0,
                    spells = {
                    },
                },
            },
        },
        ["temple_of_sethraliss"] = {
            name = "Temple of Sethraliss",
            mapID = 250,
            zones = { 1038, 1043 },
            mobs = {
                {
                    name = "Sandswept Hunter", npcID = 134600, count = 7,
                    spells = {
                        { id = 1292585 },
                        { id = 1292623 },
                        { id = 1308113, curated = true },
                        { id = 1308116 },
                    },
                },
                {
                    name = "Barbed Krolusk", npcID = 134616, count = 5,
                    spells = {
                        { id = 1291399, curated = true },
                    },
                },
                {
                    name = "Storm Adept", npcID = 134990, count = 7,
                    spells = {
                        { id = 1291262, interruptible = true },
                    },
                },
                {
                    name = "Sandfury Stonefist", npcID = 134991, count = 25,
                    spells = {
                        { id = 265966, curated = true },
                        { id = 1291468, curated = true },
                    },
                },
                {
                    name = "Shrouded Fang", npcID = 134602, count = 7,
                    spells = {
                        { id = 1295610 },
                        { id = 1295635 },
                        { id = 1308100, interruptible = true, poison = true, curated = true },
                    },
                },
                {
                    name = "Sand-Sworn Rider", npcID = 134629, count = 25,
                    spells = {
                        { id = 262046 },
                        { id = 272655, curated = true },
                        { id = 1291399, curated = true },
                        { id = 1292990, curated = true },
                    },
                },
                {
                    name = "Poisonous Viper", npcID = 135562, count = 7,
                    spells = {
                        { id = 1308148, interruptible = true, poison = true, curated = true },
                    },
                },
                {
                    name = "Lightning Serpent", npcID = 135846, count = 5,
                    spells = {
                        { id = 1293133, curated = true },
                        { id = 1310396 },
                        { id = 1310402 },
                    },
                },
                {
                    name = "Dutiful Tamer", npcID = 139422, count = 7,
                    spells = {
                        { id = 1291399, curated = true },
                        { id = 1292990 },
                    },
                },
                {
                    name = "Krolusk Matriarch", npcID = 134686, count = 16,
                    spells = {
                        { id = 272654, curated = true },
                        { id = 272655, curated = true },
                    },
                },
                {
                    name = "Faithless Subjugator", npcID = 134364, count = 7,
                    spells = {
                        { id = 269896 },
                        { id = 1293307, interruptible = true, curse = true },
                    },
                },
                {
                    name = "Brood Tender", npcID = 139425, count = 7,
                    spells = {
                        { id = 1310683, interruptible = true },
                    },
                },
                {
                    name = "Merektha", npcID = 133384, count = 0,
                    spells = {
                        { id = 264172 },
                        { id = 1289205 },
                        { id = 1289589 },
                        { id = 1289602 },
                        { id = 1290031 },
                        { id = 1290797 },
                        { id = 1291734 },
                        { id = 1293048 },
                        { id = 1296738 },
                        { id = 1296912 },
                        { id = 1297034 },
                        { id = 1298329 },
                        { id = 1308838 },
                    },
                },
                {
                    name = "Agitated Nimbus", npcID = 136076, count = 25,
                    spells = {
                        { id = 1293464, magic = true, curated = true },
                        { id = 1293475, curated = true },
                        { id = 1293650, curated = true },
                        { id = 1293652 },
                        { id = 1310739, magic = true },
                    },
                },
                {
                    name = "Imbued Stormcaller", npcID = 134599, count = 7,
                    spells = {
                        { id = 269116 },
                        { id = 1291262, interruptible = true },
                        { id = 1296045 },
                        { id = 1296052, magic = true, curated = true },
                        { id = 1310739, magic = true },
                    },
                },
                {
                    name = "Static Anomaly", npcID = 134691, count = 5,
                    spells = {
                        { id = 264763 },
                        { id = 1310693 },
                    },
                },
                {
                    name = "Twisted Hexxer", npcID = 136250, count = 25,
                    spells = {
                        { id = 268013, interruptible = true },
                        { id = 1300666 },
                        { id = 1300684, curated = true },
                        { id = 1311964 },
                        { id = 1311980 },
                        { id = 1311981, curated = true },
                    },
                },
                {
                    name = "Avatar of Sethraliss", npcID = 133392, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Spark Channeler", npcID = 265057, count = 5,
                    spells = {
                    },
                },
                {
                    name = "A Knot of Snakes", npcID = 134388, count = 0,
                    spells = {
                        { id = 263958 },
                    },
                },
                {
                    name = "Toxic Viper", npcID = 134389, count = 0,
                    spells = {
                        { id = 267027, interruptible = true, poison = true },
                    },
                },
                {
                    name = "Storm Serpent", npcID = 134390, count = 0,
                    spells = {
                        { id = 1289589 },
                        { id = 1291622, curated = true },
                    },
                },
                {
                    name = "Merektha", npcID = 134487, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Orb Watcher", npcID = 135007, count = 25,
                    spells = {
                        { id = 1303443, curated = true },
                        { id = 1303452 },
                        { id = 1303486, curated = true },
                        { id = 1308546, curated = true },
                    },
                },
                {
                    name = "Lightning Spire", npcID = 135445, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Sandswept Marksman", npcID = 139097, count = 0,
                    spells = {
                        { id = 273225 },
                    },
                },
                {
                    name = "Loose Spark", npcID = 139108, count = 0,
                    spells = {
                        { id = 267483 },
                        { id = 273241 },
                        { id = 1225638 },
                    },
                },
                {
                    name = "Polarized Spire", npcID = 139131, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Eye of Sethraliss", npcID = 240681, count = 0,
                    spells = {
                        { id = 1303596, curated = true },
                    },
                },
                {
                    name = "Adderis", npcID = 262530, count = 0,
                    spells = {
                        { id = 263425 },
                        { id = 1288092 },
                        { id = 1288235 },
                        { id = 1288428 },
                        { id = 1289229 },
                        { id = 1308738 },
                        { id = 1308740 },
                        { id = 1310311 },
                    },
                },
                {
                    name = "Aspix", npcID = 262822, count = 0,
                    spells = {
                        { id = 1288457 },
                        { id = 1288864 },
                        { id = 1288885 },
                        { id = 1289062 },
                        { id = 1289229 },
                        { id = 1292035 },
                        { id = 1310311 },
                        { id = 1310712 },
                        { id = 1311808 },
                    },
                },
                {
                    name = "Egg Marker", npcID = 263181, count = 0,
                    spells = {
                        { id = 1289208 },
                        { id = 1296738 },
                    },
                },
                {
                    name = "Galvazzt", npcID = 263658, count = 0,
                    spells = {
                        { id = 1290531 },
                        { id = 1291815 },
                    },
                },
                {
                    name = "Swarming Krolusk", npcID = 264785, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Faithless Tormentor", npcID = 268317, count = 5,
                    spells = {
                        { id = 1300704, curated = true },
                        { id = 1300714 },
                    },
                },
                {
                    name = "Corrupted Guardian", npcID = 268344, count = 0,
                    spells = {
                        { id = 1300803, curated = true },
                        { id = 1302616 },
                        { id = 1302618 },
                        { id = 1302761 },
                        { id = 1303446 },
                    },
                },
                {
                    name = "Lifeforce", npcID = 268364, count = 0,
                    spells = {
                        { id = 1300871 },
                        { id = 1302826 },
                        { id = 1302897 },
                        { id = 1312214 },
                    },
                },
                {
                    name = "Essence Defiler", npcID = 268427, count = 0,
                    spells = {
                        { id = 1301199 },
                    },
                },
                {
                    name = "Twisted Hexxer", npcID = 268491, count = 0,
                    spells = {
                        { id = 1300684, curated = true },
                        { id = 1302153, curated = true },
                        { id = 1302158, interruptible = true },
                        { id = 1311964 },
                        { id = 1311979 },
                    },
                },
                {
                    name = "Faithless Tormentor", npcID = 268729, count = 0,
                    spells = {
                        { id = 1300704, curated = true },
                        { id = 1300714 },
                    },
                },
                {
                    name = "Spark Channeler", npcID = 139110, count = 5,
                    spells = {
                        { id = 267483 },
                    },
                },
                {
                    name = "Faithless Conscript", npcID = 135971, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Snake", npcID = 263383, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Lesser Lifeforce", npcID = 268747, count = 0,
                    spells = {
                    },
                },
                {
                    name = "Temple Disruptor", npcID = 269227, count = 5,
                    spells = {
                    },
                },
            },
        },
        ["ruby_life_pools"] = {
            name = "Ruby Life Pools",
            mapID = 399,
            zones = { 2094, 2095 },
            mobs = {
                {
                    name = "Primal Juggernaut", npcID = 188244, count = 25,
                    spells = {
                        { id = 372730, curated = true },
                        { id = 372793 },
                        { id = 1305201, curated = true },
                        { id = 1305213 },
                        { id = 1310489 },
                    },
                },
                {
                    name = "Deepstone Earthshaper", npcID = 187969, count = 5,
                    spells = {
                        { id = 371471 },
                        { id = 1305225, curated = true },
                    },
                },
                {
                    name = "Earthbound Guardian", npcID = 188011, count = 5,
                    spells = {
                        { id = 384933, interruptible = true },
                        { id = 1307205, curated = true },
                    },
                },
                {
                    name = "Flashfrost Chillweaver", npcID = 188067, count = 7,
                    spells = {
                        { id = 371489 },
                        { id = 371984, interruptible = true },
                        { id = 372743, interruptible = true, curated = true },
                        { id = 372749 },
                        { id = 384933, interruptible = true },
                    },
                },
                {
                    name = "Infused Whelp", npcID = 187894, count = 0,
                    spells = {
                        { id = 1305234, magic = true, curated = true },
                    },
                },
                {
                    name = "Defier Draghar", npcID = 187897, count = 30,
                    spells = {
                        { id = 372047, curated = true },
                        { id = 372087, curated = true },
                        { id = 372794 },
                        { id = 1309705 },
                    },
                },
                {
                    name = "Melidrussa Chillworn", npcID = 188252, count = 0,
                    spells = {
                        { id = 372808, interruptible = true },
                        { id = 372851 },
                        { id = 372988 },
                        { id = 373046 },
                        { id = 373680 },
                        { id = 373688 },
                        { id = 373727 },
                        { id = 383925 },
                        { id = 384024 },
                        { id = 396044 },
                        { id = 397077 },
                    },
                },
                {
                    name = "Scorchling", npcID = 190205, count = 0,
                    spells = {
                        { id = 1307372, curated = true },
                    },
                },
                {
                    name = "Thunderhead", npcID = 197698, count = 48,
                    spells = {
                        { id = 391726, curated = true },
                        { id = 391727 },
                        { id = 392395, curated = true },
                        { id = 392640, curated = true },
                        { id = 392641, magic = true, curated = true },
                        { id = 395303 },
                        { id = 1310599, curated = true },
                    },
                },
                {
                    name = "Primalist Cinderweaver", npcID = 190207, count = 7,
                    spells = {
                        { id = 373693, curated = true },
                        { id = 384194, interruptible = true },
                    },
                },
                {
                    name = "Blazebound Destroyer", npcID = 190034, count = 25,
                    spells = {
                        { id = 373614, curated = true },
                        { id = 373692, curated = true },
                        { id = 384139, curated = true },
                        { id = 1305955, interruptible = true },
                    },
                },
                {
                    name = "Ashseer Flamelasher", npcID = 190206, count = 7,
                    spells = {
                        { id = 373972, magic = true, curated = true },
                        { id = 373973 },
                        { id = 373977 },
                        { id = 385536, curated = true },
                        { id = 385567 },
                        { id = 1305865 },
                    },
                },
                {
                    name = "Ruinous Stormbringer", npcID = 195119, count = 10,
                    spells = {
                        { id = 385310, interruptible = true },
                        { id = 385311 },
                        { id = 385312 },
                        { id = 385313, curated = true },
                        { id = 385314 },
                        { id = 385316 },
                    },
                },
                {
                    name = "Flamegullet", npcID = 197697, count = 40,
                    spells = {
                        { id = 391723, curated = true },
                        { id = 392394, curated = true },
                        { id = 392569, curated = true },
                        { id = 392570 },
                        { id = 395292, curated = true },
                    },
                },
                {
                    name = "Kokia Blazehoof", npcID = 189232, count = 0,
                    spells = {
                        { id = 372107 },
                        { id = 372811 },
                        { id = 372819 },
                        { id = 372820 },
                        { id = 372858 },
                        { id = 372859 },
                        { id = 372860 },
                        { id = 372863 },
                        { id = 1306272 },
                        { id = 1309540 },
                    },
                },
                {
                    name = "Storm Warrior", npcID = 197982, count = 5,
                    spells = {
                        { id = 392406 },
                    },
                },
                {
                    name = "Primal Thundercloud", npcID = 197509, count = 0,
                    spells = {
                        { id = 391031, magic = true },
                        { id = 392399 },
                    },
                },
                {
                    name = "Tempest Channeler", npcID = 198047, count = 25,
                    spells = {
                        { id = 392576, interruptible = true, curated = true },
                        { id = 1306366, curated = true },
                        { id = 1307488 },
                        { id = 1307502, curated = true },
                    },
                },
                {
                    name = "High Channeler Ryvati", npcID = 197535, count = 30,
                    spells = {
                        { id = 1306366, curated = true },
                        { id = 1307488 },
                        { id = 1307511, curated = true },
                        { id = 1310355, curated = true },
                        { id = 1310361 },
                        { id = 1310363 },
                    },
                },
                {
                    name = "Erkhart Stormvein", npcID = 190485, count = 0,
                    spells = {
                        { id = 181089 },
                        { id = 381512 },
                        { id = 381513 },
                        { id = 381514 },
                        { id = 381515, magic = true },
                        { id = 381516 },
                        { id = 381517 },
                        { id = 381518 },
                    },
                },
                {
                    name = "Kyrakka", npcID = 190484, count = 0,
                    spells = {
                        { id = 381525 },
                        { id = 381526 },
                        { id = 381602 },
                        { id = 381605 },
                        { id = 381862 },
                        { id = 381864 },
                        { id = 384773 },
                        { id = 1312669 },
                        { id = 1312684 },
                    },
                },
                {
                    name = "Blazebound Firestorm", npcID = 189886, count = 0,
                    spells = {
                        { id = 373017, interruptible = true },
                        { id = 373087 },
                        { id = 384823, curated = true },
                    },
                },
                {
                    name = "Infused Whelp", npcID = 189893, count = 0,
                    spells = {
                        { id = 1305234, magic = true, curated = true },
                    },
                },
                {
                    name = "Scorchling", npcID = 194622, count = 0,
                    spells = {
                        { id = 1307372, curated = true },
                    },
                },
            },
        },
    },
}


-- Build lightweight lookup indices at load. These contain references to the factual
-- static tables above and are not SavedVariables.
data.zoneIndex = {}
data.challengeMapIndex = {}
data.npcIndex = {}

for dungeonKey, dungeon in pairs(data.dungeons) do
    dungeon.key = dungeonKey
    dungeon.mobByID = {}

    if type(dungeon.mapID) == "number" then
        data.challengeMapIndex[dungeon.mapID] = dungeonKey
    end

    for _, zoneID in ipairs(dungeon.zones or {}) do
        data.zoneIndex[zoneID] = dungeonKey
    end

    for _, mob in ipairs(dungeon.mobs or {}) do
        mob.dungeonKey = dungeonKey
        dungeon.mobByID[mob.npcID] = mob

        local bucket = data.npcIndex[mob.npcID]
        if not bucket then
            bucket = {}
            data.npcIndex[mob.npcID] = bucket
        end
        bucket[#bucket + 1] = mob

        mob.spellByID = {}
        for _, spell in ipairs(mob.spells or {}) do
            spell.mob = mob
            mob.spellByID[spell.id] = spell
        end
    end
end

function data:GetCurrentDungeonKey()
    -- In an active Mythic+ run, the challenge-map ID is the most stable dungeon
    -- identifier and avoids relying on which sub-zone C_Map currently reports.
    if C_ChallengeMode and C_ChallengeMode.GetActiveChallengeMapID then
        local ok, challengeMapID = pcall(C_ChallengeMode.GetActiveChallengeMapID)
        if ok and type(challengeMapID) == "number" then
            local dungeonKey = self.challengeMapIndex[challengeMapID]
            if dungeonKey then return dungeonKey end
        end
    end

    -- Outside an active challenge (normal/heroic/mythic, or before the key
    -- starts), fall back to the public area-map IDs maintained per dungeon.
    if C_Map and C_Map.GetBestMapForUnit then
        local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
        if ok and type(mapID) == "number" then
            return self.zoneIndex[mapID]
        end
    end
    return nil
end

function data:ResolveMob(npcID, unitName)
    npcID = tonumber(npcID)
    if not npcID then return nil, nil end

    local currentKey = self:GetCurrentDungeonKey()
    if currentKey then
        local dungeon = self.dungeons[currentKey]
        local mob = dungeon and dungeon.mobByID and dungeon.mobByID[npcID]
        if mob then
            return currentKey, mob
        end
    end

    local candidates = self.npcIndex[npcID]
    if type(candidates) ~= "table" or #candidates == 0 then
        return nil, nil
    end
    if #candidates == 1 then
        return candidates[1].dungeonKey, candidates[1]
    end

    if type(unitName) == "string" and unitName ~= "" then
        local found
        for _, mob in ipairs(candidates) do
            if mob.name == unitName then
                if found then
                    return nil, nil
                end
                found = mob
            end
        end
        if found then
            return found.dungeonKey, found
        end
    end

    return nil, nil
end

_G.ChayAlertHUDDungeonData = data

