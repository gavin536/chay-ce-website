local addonName = ...
local CT = _G.ChayAlertHUD
if not CT then return end

local GROUP_KEY = "importantPlayerDebuffs"
local RING_TEXTURE = "Interface\\AddOns\\ChayAlertHUD\\Media\\RingBW.png"

local auraContainer
local auraContainerReady = false
local setupErrorPrinted = false
local layoutPending = false

local function GetLayout()
    if CT.GetAuraContainerLayout then
        return CT:GetAuraContainerLayout()
    end
    return { x = 0, y = -58, size = 132, spacing = 14, maxAlerts = 3 }
end

local function ApplyAuraButtonLayout(button, layout)
    if not button or not layout then return end

    local size = tonumber(layout.size) or 132
    local iconSize = math.max(72, math.floor(size * 0.76 + 0.5))
    local ringSize = math.max(iconSize + 10, math.floor(size * 0.91 + 0.5))

    button:SetSize(size, size)

    if button._chayIcon then
        button._chayIcon:SetSize(iconSize, iconSize)
        button._chayIcon:ClearAllPoints()
        button._chayIcon:SetPoint("CENTER", button, "CENTER", 0, 8)
    end

    if button._chayCooldown then
        button._chayCooldown:SetSize(iconSize, iconSize)
        button._chayCooldown:ClearAllPoints()
        button._chayCooldown:SetPoint("CENTER", button, "CENTER", 0, 8)
        local countdown = button._chayCooldown:GetCountdownFontString()
        if countdown then
            countdown:SetFont(STANDARD_TEXT_FONT, math.max(16, math.floor(size * 0.18 + 0.5)), "OUTLINE")
        end
    end

    if button._chayRing then
        button._chayRing:SetSize(ringSize, ringSize)
        button._chayRing:ClearAllPoints()
        button._chayRing:SetPoint("CENTER", button, "CENTER", 0, 8)
    end

    if button._chayName then
        button._chayName:SetWidth(math.max(88, size - 8))
        button._chayName:SetFont(STANDARD_TEXT_FONT, math.max(9, math.floor(size * 0.085 + 0.5)), "OUTLINE")
    end

    if button._chayStacks then
        button._chayStacks:SetFont(STANDARD_TEXT_FONT, math.max(14, math.floor(size * 0.15 + 0.5)), "OUTLINE")
        button._chayStacks:ClearAllPoints()
        button._chayStacks:SetPoint("TOPRIGHT", button, "TOPRIGHT", -8, -6)
    end
end

local function InitializeAuraButton(button)
    local layout = GetLayout()
    button:EnableMouse(false)

    local icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    button:SetIcon(icon)
    button._chayIcon = icon

    local cooldown = CreateFrame("Cooldown", nil, button, "CooldownFrameTemplate")
    cooldown:SetReverse(true)
    cooldown:SetDrawEdge(false)
    cooldown:SetDrawBling(false)
    cooldown:SetDrawSwipe(true)
    cooldown:SetHideCountdownNumbers(false)
    cooldown:SetCountdownMillisecondsThreshold(3)
    button:SetDurationCooldown(cooldown)
    button._chayCooldown = cooldown

    local ring = button:CreateTexture(nil, "OVERLAY")
    ring:SetTexture(RING_TEXTURE)
    ring:SetVertexColor(1.00, 0.12, 0.12, 0.96)
    ring:SetBlendMode("ADD")
    button._chayRing = ring

    local name = button:CreateFontString(nil, "OVERLAY")
    name:SetPoint("BOTTOM", button, "BOTTOM", 0, 2)
    name:SetJustifyH("CENTER")
    name:SetJustifyV("MIDDLE")
    name:SetTextColor(1, 0.88, 0.35, 1)
    button:SetSpellName(name)
    button._chayName = name

    local stacks = button:CreateFontString(nil, "OVERLAY")
    stacks:SetTextColor(1, 1, 1, 1)
    button:SetApplicationCount(stacks, {})
    button._chayStacks = stacks

    ApplyAuraButtonLayout(button, layout)
end

local function LoadAuraContainerAddon()
    if _G.CustomAuraContainerSharedMixin then
        return true
    end

    if not (C_AddOns and C_AddOns.LoadAddOn) then
        return false
    end

    local ok = pcall(C_AddOns.LoadAddOn, "Blizzard_AuraContainer")
    return ok and _G.CustomAuraContainerSharedMixin ~= nil
end

local function GetAuraSortConstants()
    -- CustomAuraContainerTemplate uses the AuraContainer-specific constants.
    -- If Blizzard's layout helpers are unavailable, omit the optional sort
    -- fields and let AddAuraGroup use its native defaults rather than guessing
    -- numeric values or substituting an enum from a different API family.
    local methodTable = rawget(_G, "AuraContainerSortMethod")
    local directionTable = rawget(_G, "AuraContainerSortDirection")

    local method = methodTable and methodTable.ExpirationOnly or nil
    local direction = directionTable and directionTable.Normal or nil
    return method, direction
end

local function EnsureAuraContainer(shouldWarn)
    if auraContainerReady and auraContainer then return true end

    -- Blizzard applies AuraContainer access restrictions around login/world entry.
    -- Never try to create or configure a new container while combat lockdown is active.
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        return false
    end

    if not LoadAuraContainerAddon() then
        if shouldWarn and not setupErrorPrinted then
            setupErrorPrinted = true
            print("|cffff3030ChayAlert HUD|r player debuff alerts are unavailable because Blizzard_AuraContainer could not be loaded. Cast/boss/raid alerts are unaffected.")
        end
        return false
    end

    if not (AnchorUtil and AnchorUtil.FlowDirection and AnchorUtil.FlowLayoutAxis) then
        if shouldWarn and not setupErrorPrinted then
            setupErrorPrinted = true
            print("|cffff3030ChayAlert HUD|r player debuff alerts are unavailable because Blizzard's AuraContainer layout helpers are not ready. Cast/boss/raid alerts are unaffected.")
        end
        return false
    end

    local layout = GetLayout()
    local sortMethod, sortDirection = GetAuraSortConstants()

    auraContainer = CreateFrame("AuraContainer", "ChayAlertHUDImportantAuraContainer", UIParent, "CustomAuraContainerTemplate")
    auraContainer:SetEnabled(false)
    auraContainer:SetUnit("player")

    auraContainer:AddAuraGroup(GROUP_KEY, "HARMFUL", {
        maxFrameCount = layout.maxAlerts,
        initializeFrame = InitializeAuraButton,
        candidateFilters = {
            maxDuration = math.huge,
            isBossOrRoleAura = true,
        },
        sortMethod = sortMethod,
        sortDirection = sortDirection,
        layout = {
            elementSpacing = layout.spacing,
            elementWidth = layout.size,
            elementHeight = layout.size,
        },
    })

    auraContainer:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Horizontal)
    auraContainer:SetFlowLayoutAnchorPoint("LEFT")
    auraContainer:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right, AnchorUtil.FlowDirection.Down)
    auraContainer:Show()

    auraContainerReady = true
    return true
end

function CT:RefreshAuraContainerLayout()
    if not auraContainerReady then
        local needed = CT.ShouldEnableImportantAuraContainer and CT:ShouldEnableImportantAuraContainer() or false
        if not needed then return end
        if not EnsureAuraContainer(true) then return end
    end

    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        layoutPending = true
        return
    end

    layoutPending = false
    local layout = GetLayout()

    auraContainer:SetAuraGroupMaxFrameCount(GROUP_KEY, layout.maxAlerts)
    auraContainer:SetAuraGroupLayout(GROUP_KEY, {
        elementSpacing = layout.spacing,
        elementWidth = layout.size,
        elementHeight = layout.size,
    })

    for index = 1, auraContainer:GetAuraGroupFrameCount(GROUP_KEY) do
        local button = auraContainer:GetAuraGroupFrame(GROUP_KEY, index)
        ApplyAuraButtonLayout(button, layout)
    end

    local totalWidth = (layout.maxAlerts * layout.size) + (math.max(0, layout.maxAlerts - 1) * layout.spacing)
    auraContainer:ClearAllPoints()
    auraContainer:SetPoint("LEFT", WorldFrame, "CENTER", layout.x - (totalWidth * 0.5), layout.y)
end

function CT:RefreshAuraContainerState()
    local enabled = CT.ShouldEnableImportantAuraContainer and CT:ShouldEnableImportantAuraContainer() or false

    -- Lazy initialization avoids a misleading login warning in the open world.
    -- The protected player-debuff container is created only when the feature is
    -- actually needed in supported content.
    if not enabled then
        if auraContainer then
            auraContainer:SetEnabled(false)
            auraContainer:Hide()
        end
        return
    end

    if not EnsureAuraContainer(true) then return end
    auraContainer:SetEnabled(true)
    auraContainer:Show()
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_ENABLED" and layoutPending then
        CT:RefreshAuraContainerLayout()
    end
    CT:RefreshAuraContainerState()
end)

