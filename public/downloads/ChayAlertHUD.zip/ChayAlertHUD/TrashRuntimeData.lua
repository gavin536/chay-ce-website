-- ChayAlert HUD TrashRuntimeData.lua
-- Static runtime data used by ChayAlert HUD.

local data = {
    source = "ChayAlert HUD runtime model",
    version = "2026-08-20",
    dungeons = {
        ["kings_rest"] = { mapID = 249, mobs = {
            [133935] = { name = "Animated Guardian", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [270003] = { spellID = 270003, castTime = 3.5, first = 6.4, cd = { 18.3 }, targetAPIExists = true, enabled = true },
            } },
            [134158] = { name = "Shadow-Borne Champion", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [269928] = { spellID = 269928, channelTime = 6, openingCastOrder = 2, first = 12, cd = { 18.1 }, targetAPIExists = false, enabled = true },
                [269976] = { spellID = 269976, castTime = 1, openingCastOrder = 3, first = 18.2, cd = { 23.1 }, targetAPIExists = false, enabled = true },
                [1305945] = { spellID = 1305945, castTime = 4, openingCastOrder = 1, first = 7.5, cd = { 20.1 }, targetAPIExists = false, enabled = true },
            } },
            [134174] = { name = "Risen Hexer", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [269972] = { spellID = 269972, castTime = 3.5, first = 12.4, cd = { 19.6 }, enabled = nil },
                [1294815] = { spellID = 1294815, castTime = 2.5, first = 0, cd = { 3.6 }, enabled = nil },
            } },
            [134251] = { name = "Seneschal M'bara", traits = { level = 90, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [270901] = { spellID = 270901, castTime = 2.5, first = 10.1, targetAPIExists = false, enabled = false },
            } },
            [134331] = { name = "King Rahu'ai", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [270889] = { spellID = 270889, castTime = 3, channelTime = 4, first = 16.2, cd = { 14.8 }, targetAPIExists = false, enabled = true },
                [1296719] = { spellID = 1296719, castTime = 2.5, first = 48.7, cd = { 3.6, 3.7, 4.8, 4.8, 8.7, 4.5, 4.5, 4.8, 4.8, 4.5, 4.8, 4.8, 4.8, 4.6, 4.8, 4.6, 4.4, 4.8, 8.7, 9.7 }, targetAPIExists = true, enabled = false },
            } },
            [134739] = { name = "Purification Construct", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [270293] = { spellID = 270293, castTime = 2, first = 2.8, cd = { 8.9 }, targetAPIExists = false, enabled = true },
            } },
            [135167] = { name = "Royal Berserker", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [270482] = { spellID = 270482, castTime = 3, first = 15.9, cd = { 16.4, 18.8 }, targetAPIExists = false, enabled = true },
                [1301851] = { spellID = 1301851, castTime = 2, first = 5.9, cd = { 14.6, 17.4, 33.2 }, targetAPIExists = true, enabled = true },
            } },
            [135192] = { name = "Honored Raptor", traits = { level = 90, power = 1, nonElite = false, hasCastSpell = false, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [270502] = { spellID = 270502, channelTime = 5, first = 5.8, cd = { 10 }, targetAPIExists = false, enabled = true },
            } },
            [135231] = { name = "Ghostly Brute", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [270514] = { spellID = 270514, castTime = 5, openingCastOrder = 2, first = 16.8, cd = { 19.3 }, targetAPIExists = false, enabled = true },
                [1302028] = { spellID = 1302028, castTime = 2.5, openingCastOrder = 1, first = 5.3, cd = { 18.1, 19.3, 20.6, 19 }, targetAPIExists = true, enabled = true },
            } },
            [137473] = { name = "Guard Captain Atu", traits = { level = 90, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [1296671] = { spellID = 1296671, castTime = 2.5, first = 4, cd = { 21.8 }, targetAPIExists = false, enabled = true },
            } },
            [137474] = { name = "King Timalji", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [270927] = { spellID = 270927, castTime = 2.5, channelTime = 6, openingCastOrder = 2, first = 12.8, cd = { 14 }, targetAPIExists = true, enabled = true },
                [1306049] = { spellID = 1306049, castTime = 3, openingCastOrder = 1, first = 6.8, cd = { 17.6 }, targetAPIExists = true, enabled = true },
            } },
            [137478] = { name = "Queen Wasi", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [270920] = { spellID = 270920, castTime = 2.5, channelTime = 10, first = 6.8, cd = { 14.9, 13 }, enabled = false },
                [1294972] = { spellID = 1294972, castTime = 2.5, first = 52.9, cd = { 4.6 }, enabled = false },
            } },
            [137484] = { name = "King A'akul", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1297918] = { spellID = 1297918, castTime = 2.5, openingCastOrder = 1, first = 4.9, cd = { 20.1, 21.8 }, targetAPIExists = true, enabled = true },
                [1297970] = { spellID = 1297970, castTime = 2.5, openingCastOrder = 2, first = 13.3, cd = { 20.6, 21.8, 21.8, 23 }, targetAPIExists = false, enabled = true },
            } },
            [137486] = { name = "Queen Patlaa", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1305982] = { spellID = 1305982, channelTime = 2, first = 5.3, cd = { 16.2 }, targetAPIExists = true, enabled = true },
            } },
            [137487] = { name = "Skeletal Hunting Raptor", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [270502] = { spellID = 270502, channelTime = 5, first = 8.3, cd = { 7.1 }, targetAPIExists = false, enabled = true },
                [1297763] = { spellID = 1297763, castTime = 2.5, enabled = nil },
            } },
            [137969] = { name = "Interment Construct", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [271555] = { spellID = 271555, castTime = 3, first = 14.6, cd = { 20 }, targetAPIExists = true, enabled = true },
            } },
        } },
        ["temple_of_sethraliss"] = { mapID = 250, mobs = {
            [134390] = { name = "Storm Serpent", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1291622] = { spellID = 1291622, castTime = 2.5, first = 10, cd = { 5.1 }, targetAPIExists = false, enabled = true },
            } },
            [134600] = { name = "Sandswept Hunter", traits = { level = 90, nonElite = false, hasCastSpell = false, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [1308113] = { spellID = 1308113, channelTime = 9, first = 3.3, cd = { 8.6 }, enabled = nil },
            } },
            [134629] = { name = "Sand-Sworn Rider", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [272655] = { spellID = 272655, castTime = 4.5, first = 5, cd = { 14.9, 13.7, 14.9, 18.5 }, targetAPIExists = false, enabled = true },
                [1292990] = { spellID = 1292990, castTime = 2.5, first = 19.4, cd = { 25.4 }, targetAPIExists = false, enabled = true },
            } },
            [134686] = { name = "Krolusk Matriarch", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [272654] = { spellID = 272654, castTime = 3, cd = { 18.9 }, targetAPIExists = true, enabled = true },
                [272655] = { spellID = 272655, castTime = 4.5, cd = { 15.8 }, targetAPIExists = false, enabled = true },
            } },
            [134991] = { name = "Sandfury Stonefist", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [265966] = { spellID = 265966, castTime = 4, first = 13.7, cd = { 25.1 }, targetAPIExists = false, enabled = true },
                [1291468] = { spellID = 1291468, castTime = 3, first = 1.6, cd = { 17.6 }, targetAPIExists = true, enabled = true },
            } },
            [135007] = { name = "Orb Watcher", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1303443] = { spellID = 1303443, castTime = 2.5, first = 20, cd = { 20.6 }, targetAPIExists = true, enabled = true },
                [1303486] = { spellID = 1303486, castTime = 3.5, first = 27.3, cd = { 24 }, targetAPIExists = false, enabled = true },
            } },
            [136076] = { name = "Agitated Nimbus", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1293464] = { spellID = 1293464, castTime = 1.5, first = 19.4, cd = { 8.2, 5.8, 5.8, 5.8, 5.8, 5.8, 5.8 }, targetAPIExists = false, enabled = true },
                [1293475] = { spellID = 1293475, castTime = 3, first = 4.9, cd = { 25 }, targetAPIExists = false, enabled = true },
                [1293650] = { spellID = 1293650, castTime = 1.5, first = 10.9, cd = { 11.8 }, targetAPIExists = false, enabled = true },
            } },
            [136250] = { name = "Twisted Hexxer", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [268013] = { spellID = 268013, castTime = 4, first = 4.4, enabled = nil },
            } },
            [268344] = { name = "Corrupted Guardian", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1300803] = { spellID = 1300803, castTime = 2.5, first = 8.3, cd = { 10.5 }, targetAPIExists = true, enabled = true },
            } },
            [268491] = { name = "Twisted Hexxer", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [1302153] = { spellID = 1302153, castTime = 2, first = 19.4, cd = { 15 }, targetAPIExists = true, enabled = true },
                [1302158] = { spellID = 1302158, castTime = 4, first = 14.5, cd = { 13 }, enabled = nil },
            } },
        } },
        ["ruby_life_pools"] = { mapID = 399, mobs = {
            [187897] = { name = "Defier Draghar", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [372047] = { spellID = 372047, castTime = 1, channelTime = 3, first = 9.2, cd = { 16.6 }, targetAPIExists = true, enabled = true },
                [372087] = { spellID = 372087, castTime = 4, first = 13.2, cd = { 16.6 }, enabled = true },
            } },
            [188067] = { name = "Flashfrost Chillweaver", traits = { level = 90, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [372743] = { spellID = 372743, channelTime = 15, first = 9.6, cd = { 10.5 }, enabled = true },
            } },
            [188244] = { name = "Primal Juggernaut", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [372730] = { spellID = 372730, castTime = 2.5, first = 7.5, cd = { 18.1 }, targetAPIExists = true, enabled = true },
                [1305201] = { spellID = 1305201, castTime = 3.5, first = 8.8, cd = { 23.2 }, targetAPIExists = false, enabled = true },
            } },
            [189886] = { name = "Blazebound Firestorm", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [373017] = { spellID = 373017, castTime = 3.5, cd = { 6.2 }, enabled = nil },
                [373087] = { spellID = 373087, castTime = 5, enabled = nil },
                [384823] = { spellID = 384823, castTime = 3, first = 16, cd = { 10.1 }, targetAPIExists = false, enabled = true },
            } },
            [190034] = { name = "Blazebound Destroyer", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [373614] = { spellID = 373614, castTime = 5, enabled = nil },
                [373692] = { spellID = 373692, castTime = 3.5, first = 10.4, cd = { 22 }, targetAPIExists = false, enabled = true },
                [384139] = { spellID = 384139, castTime = 1.5, first = 5.2, targetAPIExists = false, enabled = true },
                [1305955] = { spellID = 1305955, castTime = 4, cd = { 13 }, enabled = nil },
            } },
            [190206] = { name = "Ashseer Flamelasher", traits = { level = 90, power = 1, nonElite = false, hasCastSpell = false, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [373972] = { spellID = 373972, channelTime = 15, enabled = nil },
                [385536] = { spellID = 385536, channelTime = 10, first = 7.9, cd = { 16.6 }, enabled = true },
            } },
            [195119] = { name = "Ruinous Stormbringer", traits = { level = 91, power = 3, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [385310] = { spellID = 385310, castTime = 2.5, enabled = nil },
                [385313] = { spellID = 385313, castTime = 2, first = 4, cd = { 12.6 }, enabled = true },
            } },
            [197535] = { name = "High Channeler Ryvati", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1306366] = { spellID = 1306366, channelTime = 7, openingCastOrder = 3, first = 20.7, cd = { 25.7 }, enabled = true },
                [1307511] = { spellID = 1307511, castTime = 2, openingCastOrder = 1, first = 4.9, cd = { 30.4 }, targetAPIExists = false, enabled = true },
                [1310355] = { spellID = 1310355, openingCastOrder = 2, first = 12.2, cd = { 32.8 }, targetAPIExists = false, enabled = true },
                [1310361] = { spellID = 1310361, enabled = nil },
                [1310363] = { spellID = 1310363, enabled = nil },
            } },
            [197697] = { name = "Flamegullet", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [391723] = { spellID = 391723, castTime = 4, channelTime = 3, openingCastOrder = 1, first = 3.5, cd = { 12.4 }, targetAPIExists = true, enabled = true },
                [392394] = { spellID = 392394, castTime = 2.5, openingCastOrder = 2, first = 14.4, cd = { 18.1 }, targetAPIExists = true, enabled = true },
            } },
            [197698] = { name = "Thunderhead", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [391726] = { spellID = 391726, castTime = 4, channelTime = 3, cd = { 17.3 }, targetAPIExists = true, enabled = true },
                [392395] = { spellID = 392395, castTime = 2.5, cd = { 18.2 }, targetAPIExists = true, enabled = true },
                [392640] = { spellID = 392640, castTime = 1.5, cd = { 32.5 }, targetAPIExists = false, enabled = true },
            } },
            [198047] = { name = "Tempest Channeler", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [392576] = { spellID = 392576, castTime = 4, first = 0, cd = { 19.1 }, targetAPIExists = true, enabled = true },
                [1306366] = { spellID = 1306366, channelTime = 7, first = 7.3, cd = { 15.7 }, enabled = true },
                [1307502] = { spellID = 1307502, castTime = 2, first = 17, cd = { 6.4 }, targetAPIExists = false, enabled = true },
            } },
        } },
        ["the_blinding_vale"] = { mapID = 584, mobs = {
            [245346] = { name = "Virid Grovekeeper", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1237855] = { spellID = 1237855, castTime = 2.5, first = 5.6, cd = { 19.3 }, targetAPIExists = true, enabled = true },
                [1255205] = { spellID = 1255205, castTime = 3, first = 14.4, cd = { 30.6 }, targetAPIExists = false, enabled = true },
            } },
            [245513] = { name = "Overgrown Hydra", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1238368] = { spellID = 1238368, castTime = 2, channelTime = 6, openingCastOrder = 1, first = 3.4, cd = { 15 }, targetAPIExists = false, enabled = true },
                [1238642] = { spellID = 1238642, castTime = 3, openingCastOrder = 2, first = 12.1, cd = { 20, 23.6 }, targetAPIExists = false, enabled = true },
            } },
            [246871] = { name = "Luminous Thornmaw", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1242135] = { spellID = 1242135, castTime = 2.5, openingCastOrder = 1, first = 5, cd = { 15.5 }, targetAPIExists = true, enabled = true },
                [1242138] = { spellID = 1242138, castTime = 3, openingCastOrder = 2, first = 12.6, cd = { 20 }, targetAPIExists = false, enabled = true },
            } },
            [249756] = { name = "Potatoad Matriarch", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1250100] = { spellID = 1250100, castTime = 2, openingCastOrder = 1, first = 20.2, cd = { 24.7 }, targetAPIExists = true, enabled = true },
                [1250199] = { spellID = 1250199, castTime = 3, openingCastOrder = 2, first = 5.4, cd = { 24.9 }, targetAPIExists = false, enabled = true },
                [1250937] = { spellID = 1250937, castTime = 2, openingCastOrder = 3, first = 13.9, cd = { 24.7 }, targetAPIExists = false, enabled = true },
            } },
            [254850] = { name = "Sporeblight Belcher", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1263636] = { spellID = 1263636, castTime = 1.5, channelTime = 3, first = 15.8, cd = { 27 }, enabled = true },
                [1271385] = { spellID = 1271385, castTime = 2, first = 4.8, cd = { 24.7 }, enabled = true },
            } },
        } },
        ["voidscar_arena"] = { mapID = 585, mobs = {
            [244260] = { name = "Chitigoth", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = false, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1234855] = { spellID = 1234855, channelTime = 10, first = 17.1, cd = { 10.6 }, targetAPIExists = false, enabled = true },
            } },
            [244309] = { name = "Brutok", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1234890] = { spellID = 1234890, castTime = 3.5, first = 26.8, cd = { 19.6 }, targetAPIExists = false, enabled = true },
                [1245186] = { spellID = 1245186, castTime = 2.5, first = 47.4, cd = { 20.5 }, targetAPIExists = true, enabled = true },
            } },
            [245950] = { name = "Watchful Harrower", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1239856] = { spellID = 1239856, castTime = 5, first = 5.4, cd = { 20.5 }, enabled = true },
                [1300138] = { spellID = 1300138, castTime = 2, channelTime = 4, first = 13.9, cd = { 21.5 }, enabled = true },
            } },
            [252053] = { name = "Brutal Overseer", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1298900] = { spellID = 1298900, castTime = 2, channelTime = 30, first = 7.2, cd = { 20 }, targetAPIExists = false, enabled = true },
                [1310309] = { spellID = 1310309, channelTime = 6, first = 24, cd = { 26.8 }, targetAPIExists = false, enabled = true },
            } },
            [252072] = { name = "Voidtouched Magi", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = false }, spells = {
                [1299913] = { spellID = 1299913, castTime = 4, first = 14.3, cd = { 19 }, targetAPIExists = true, enabled = true },
                [1299938] = { spellID = 1299938, castTime = 4, first = 5.8, cd = { 5.3 }, targetAPIExists = false, enabled = true },
            } },
            [263228] = { name = "Agitated Voidscythe", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1233472] = { spellID = 1233472, channelTime = 6, openingCastOrder = 2, targetAPIExists = false, enabled = true },
                [1289265] = { spellID = 1289265, castTime = 2.5, openingCastOrder = 1, first = 7.5, cd = { 18.1 }, targetAPIExists = false, enabled = true },
                [1311778] = { spellID = 1311778, openingCastOrder = 2, targetAPIExists = false, enabled = true },
            } },
            [267545] = { name = "Aegyra the Unyielding", traits = {  }, spells = {
                [1298908] = { spellID = 1298908, castTime = 2, first = 24.6, cd = { 33.2 }, enabled = true },
                [1298924] = { spellID = 1298924, castTime = 8, first = 27.9, cd = { 27.5 }, enabled = true },
                [1299125] = { spellID = 1299125, castTime = 2, first = 7.6, cd = { 33.2 }, enabled = true },
                [1299145] = { spellID = 1299145, castTime = 3, first = 11.2, cd = { 32.2 }, enabled = true },
            } },
            [267546] = { name = "Raj'kess the Spellstorm", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1299270] = { spellID = 1299270, castTime = 3, channelTime = 9, first = 20.6, cd = { 20.8 }, targetAPIExists = false, enabled = true },
                [1311747] = { spellID = 1311747, castTime = 2, first = 10.8, cd = { 30.8 }, targetAPIExists = false, enabled = true },
            } },
            [268184] = { name = "Devouring Brutalizer", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1252406] = { spellID = 1252406, castTime = 4.5, first = 6.3, cd = { 23.5 }, targetAPIExists = false, enabled = true },
                [1300243] = { spellID = 1300243, castTime = 2, channelTime = 6, first = 13.5, cd = { 19.5 }, targetAPIExists = true, enabled = true },
                [1300249] = { spellID = 1300249, castTime = 9, first = 29.7, cd = { 15 }, enabled = true },
            } },
        } },
        ["den_of_nalorakk"] = { mapID = 586, mobs = {
            [241869] = { name = "Avatar of Determination", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1240280] = { spellID = 1240280, castTime = 4, openingCastOrder = 2, first = 10.4, cd = { 25.2, 27.6 }, targetAPIExists = false, enabled = true },
                [1241463] = { spellID = 1241463, castTime = 2, openingCastOrder = 1, first = 8.8, cd = { 15.1 }, targetAPIExists = false, enabled = true },
            } },
            [244889] = { name = "Loa Speaker Nanea", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1290205] = { spellID = 1290205, castTime = 2.5, first = 0, cd = { 4.9 }, targetAPIExists = true, enabled = false },
                [1296722] = { spellID = 1296722, castTime = 4, first = 6, cd = { 11.4 }, targetAPIExists = false, enabled = true },
                [1309925] = { spellID = 1309925, castTime = 3, first = 13.3, cd = { 27.3 }, targetAPIExists = false, enabled = true },
            } },
            [245146] = { name = "Grizzled Warbringer", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1246957] = { spellID = 1246957, castTime = 3, openingCastOrder = 1, first = 5, cd = { 20.1 }, targetAPIExists = false, enabled = true },
                [1246986] = { spellID = 1246986, castTime = 2, openingCastOrder = 2, first = 11.9, cd = { 16.2, 21 }, targetAPIExists = false, enabled = true },
            } },
            [245855] = { name = "Spirit of Hunger", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1238687] = { spellID = 1238687, castTime = 1.5, channelTime = 5, first = 10.2, cd = { 19, 20.6 }, targetAPIExists = false, enabled = true },
                [1238760] = { spellID = 1238760, castTime = 1.5, first = 6.6, cd = { 22.8, 24, 25.2 }, targetAPIExists = false, enabled = true },
            } },
            [250478] = { name = "The Winter Squall", traits = {  }, spells = {
                [1309947] = { spellID = 1309947, castTime = 0, channelTime = 604800, enabled = false },
            } },
        } },
        ["murder_row"] = { mapID = 587, mobs = {
            [235265] = { name = "Corrupted Warlock", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1217973] = { spellID = 1217973, castTime = 1.5, first = 16.2, cd = { 21.6 }, targetAPIExists = true, enabled = true },
                [1297682] = { spellID = 1297682, castTime = 2, channelTime = 7, first = 6.5, cd = { 11.6 }, targetAPIExists = true, enabled = true },
                [1297684] = { spellID = 1297684, castTime = 1.5, first = 23.5, cd = { 31.3 }, targetAPIExists = false, enabled = true },
            } },
            [235322] = { name = "Defiled Golem", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1215961] = { spellID = 1215961, castTime = 2, channelTime = 4, openingCastOrder = 2, first = 21.7, cd = { 24.3 }, enabled = true },
                [1294824] = { spellID = 1294824, castTime = 2, channelTime = 8, openingCastOrder = 1, first = 5.3, cd = { 19.2 }, enabled = true },
            } },
            [235465] = { name = "Shivan Punisher", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1294770] = { spellID = 1294770, castTime = 1, first = 22.6, enabled = nil },
                [1297691] = { spellID = 1297691, castTime = 4, first = 4.4, cd = { 18.8 }, targetAPIExists = false, enabled = true },
            } },
            [236071] = { name = "Bribed Guard", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = false, cannotInterrupt = true }, spells = {
                [1216529] = { spellID = 1216529, castTime = 3, first = 13.2, cd = { 21.2 }, targetAPIExists = true, enabled = true },
                [1295035] = { spellID = 1295035, castTime = 2, first = 8, cd = { 21 }, targetAPIExists = true, enabled = true },
            } },
            [236902] = { name = "Massive Felwyrm", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1217633] = { spellID = 1217633, castTime = 2, first = 6.2, cd = { 21 }, targetAPIExists = true, enabled = true },
                [1258537] = { spellID = 1258537, channelTime = 1, first = 8.6, cd = { 22.1 }, targetAPIExists = true, enabled = true },
            } },
            [236905] = { name = "Felmaster Lucsei", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1216954] = { spellID = 1216954, castTime = 2.5, channelTime = 2.5, openingCastOrder = 2, cd = { 15.6 }, enabled = true },
                [1302007] = { spellID = 1302007, channelTime = 1.2, openingCastOrder = 1, cd = { 19.4 }, enabled = true },
            } },
        } },
        ["altar_of_fangs"] = { mapID = 588, mobs = {
            [261554] = { name = "Twinfang Harrower", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1294567] = { spellID = 1294567, castTime = 3, openingCastOrder = 1, first = 5.5, cd = { 20 }, targetAPIExists = false, enabled = true },
                [1306668] = { spellID = 1306668, castTime = 3, channelTime = 5, openingCastOrder = 2, first = 15, cd = { 15 }, targetAPIExists = false, enabled = true },
            } },
            [261557] = { name = "High Evolutionist", traits = { level = 90, nonElite = false, hasCastSpell = false, hasChannelSpell = true, cannotInterrupt = false }, spells = {
                [1306385] = { spellID = 1306385, channelTime = 6, first = 11.5, cd = { 14.6 }, enabled = true },
            } },
            [261573] = { name = "Ascendant Serpent", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1294934] = { spellID = 1294934, castTime = 3, channelTime = 5, first = 30, cd = { 28.5 }, targetAPIExists = true, enabled = true },
                [1295055] = { spellID = 1295055, castTime = 2, first = 20, cd = { 34.5 }, targetAPIExists = false, enabled = true },
                [1308864] = { spellID = 1308864, castTime = 2, first = 4.5, cd = { 34.5 }, targetAPIExists = false, enabled = true },
            } },
            [262011] = { name = "Rattling Writhe", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1294845] = { spellID = 1294845, castTime = 3, first = 5.3, cd = { 25 }, targetAPIExists = true, enabled = true },
                [1294849] = { spellID = 1294849, castTime = 3, channelTime = 5, first = 11.5, cd = { 19.5 }, targetAPIExists = false, enabled = true },
            } },
            [263109] = { name = "Ula'tek's Chosen", traits = { level = 91, power = 0, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1306852] = { spellID = 1306852, castTime = 2, channelTime = 9, first = 14.5, cd = { 15.7 }, targetAPIExists = false, enabled = true },
            } },
            [270306] = { name = "Ritual Chieftain", traits = { level = 91, power = 1, nonElite = false, hasCastSpell = true, hasChannelSpell = true, cannotInterrupt = true }, spells = {
                [1306517] = { spellID = 1306517, castTime = 3, channelTime = 2, openingCastOrder = 2, first = 11, cd = { 18 }, targetAPIExists = false, enabled = true },
                [1306911] = { spellID = 1306911, castTime = 3, openingCastOrder = 1, first = 5, cd = { 20 }, targetAPIExists = true, enabled = true },
            } },
        } },
    },
}

function data:GetDungeon(dungeonKey)
    return type(dungeonKey) == "string" and self.dungeons[dungeonKey] or nil
end

function data:GetMob(dungeonKey, npcID)
    local dungeon = self:GetDungeon(dungeonKey)
    return dungeon and dungeon.mobs and dungeon.mobs[tonumber(npcID)] or nil
end

function data:GetSpell(dungeonKey, npcID, spellID)
    local mob = self:GetMob(dungeonKey, npcID)
    return mob and mob.spells and mob.spells[tonumber(spellID)] or nil
end

_G.ChayAlertHUDTrashRuntimeData = data
