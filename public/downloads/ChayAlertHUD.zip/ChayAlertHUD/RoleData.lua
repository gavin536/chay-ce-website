-- ChayAlert HUD RoleData.lua
-- Curated role/priority classifications for mechanics used by ChayAlert HUD.
-- Only high-priority and explicitly role-scoped mechanics are included in
-- automatic profile defaults; informational mechanics remain optional.

local data = { boss = {}, raid = {} }

-- Adderis and Aspix
data.boss[2124] = {
    [1289059] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1311805] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Merektha
data.boss[2125] = {
    [264172] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1293048] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Galvazzt
data.boss[2126] = {
    [1309525] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Avatar of Sethraliss
data.boss[2127] = {
    [1301202] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- The Golden Serpent
data.boss[2139] = {
    [265773] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [265781] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [265910] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
}

-- The Council of Tribes
data.boss[2140] = {
    [266206] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [266237] = { roles = "TANK", priority = 2, reason = "Chay role mechanic" },
    [1305810] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Mchimba the Embalmer
data.boss[2142] = {
    [1311956] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Dazar, The First King
data.boss[2143] = {
    [268586] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
    [269230] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [269369] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1303488] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Kokia Blazehoof
data.boss[2606] = {
    [372110] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [372858] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
}

-- Melidrussa Chillworn
data.boss[2609] = {
    [1307297] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Kyrakka and Erkhart Stormvein
data.boss[2623] = {
    [381512] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
    [381516] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [381525] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [381862] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Kystia Manaheart
data.boss[3101] = {
    [474240] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1253811] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Zaen Bladesorrow
data.boss[3102] = {
    [1214357] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1218347] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Xathuux the Annihilator
data.boss[3103] = {
    [1214637] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1295453] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Lithiel Cinderfury
data.boss[3105] = {
    [1218203] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1224478] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Lightblossom Trinity
data.boss[3199] = {
    [1234850] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Ikuzz the Light Hunter
data.boss[3200] = {
    [1237090] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Lightwarden Ruia
data.boss[3201] = {
    [1239824] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1240098] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1240210] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Ziekket
data.boss[3202] = {
    [1246607] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- The Hoardmonger
data.boss[3207] = {
    [1253268] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Sentinel of Winter
data.boss[3208] = {
    [1235783] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Nalorakk
data.boss[3209] = {
    [1243569] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Taz'Rah
data.boss[3285] = {
    [1222098] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1296963] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Atroxus
data.boss[3286] = {
    [1222642] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
    [1222721] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1262497] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Charonus
data.boss[3287] = {
    [1222755] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1227264] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1311923] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Rav'i
data.boss[3456] = {
    [1296050] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1296220] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1307894] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- The Writhing Coil
data.boss[3457] = {
    [1298949] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
    [1299053] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Zul'jan
data.boss[3458] = {
    [1301350] = { roles = "TANK_HEALER", priority = 2, reason = "Chay role mechanic" },
    [1301413] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Sszorak
data.raid[3420] = {
    [1277025] = { roles = "TANK", priority = 2, reason = "Chay role mechanic" },
    [1305959] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- The Twin Fangs
data.raid[3421] = {
    [1288538] = { roles = "TANK", priority = 3, reason = "Chay role mechanic" },
    [1289192] = { roles = "TANK", priority = 3, reason = "Chay role mechanic" },
    [1290516] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1290809] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1290956] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1308356] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- The Coiled Altar
data.raid[3429] = {
    [1282281] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1282487] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1283832] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1286573] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Soul Sever
    [1286918] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1298381] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1299680] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Sever
    [1307279] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Blighted Sever
}

-- Entombed Sentinels
data.raid[3445] = {
    [1284434] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1284458] = { roles = "TANK", priority = 2, reason = "Chay role mechanic" },
    [1284487] = { roles = "TANK", priority = 2, reason = "Chay role mechanic" },
    [1296878] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Ula'tek
-- Static ChayAlert HUD role defaults used only when Blizzard exposes a readable
-- timeline identity. Secret identities are never guessed from this table.
data.raid[3492] = {
    [1286860] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Rage of the Shackled
    [1286905] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Fury Unleashed
    [1292188] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Caustic Waves
    [1296301] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Mephitic Thrash
    [1298367] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Mother's Wrath
    [1299757] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Toxic Incubation
    [1300530] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Spectral Coils
    [1301510] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Circling Prey / Demolish
    [1302982] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" }, -- Virulent Spit
}

-- Vashnik the Malignant
data.raid[3455] = {
    [1280935] = { roles = "TANK", priority = 3, reason = "Chay role mechanic" },
    [1282525] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Nek'zali the Soulcoiler
data.raid[3470] = {
    [1292036] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Possession Barrage
    [1299673] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- The Lost Explorers
data.raid[3497] = {
    [1291759] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1292779] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1295854] = { roles = "TANK", priority = 2, reason = "Chay role mechanic" },
    [1295886] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1296092] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
    [1296249] = { roles = "ALL", priority = 3, reason = "Chay critical mechanic" },
}

-- Nymrissa Wavecaller (The Tidebound Grotto lair)
data.raid[3379] = {
    [1282937] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Iceblade Flurry
    [1268562] = { roles = "TANK", priority = 2, reason = "Chay tank mechanic" }, -- Water Jet
}

_G.ChayAlertHUDRoleData = data
