local CT = _G.ChayAlertHUD
if not CT then return end

local TTS = {}
CT.TTS = TTS
_G.ChayAlertHUDTTS = TTS

local DEFAULT_LABEL = "System Default"
local PREFERRED_VOICE_LABELS = {
    ZIRA = "Zira (Female)",
    DAVID = "David (Male)",
}
local PREFERRED_VOICE_ORDER = { "ZIRA", "DAVID" }
local voiceLabelToID = {}
local voiceIDToLabel = {}
local preferredVoiceIDs = {}
local spellNameCache = {}
local requestedSpellData = {}
local catalogAudit = { total = 0, resolved = 0, unresolved = 0 }

local ACTION_TEXT = {
    INTERRUPT = "Kick",
    TANK = "Tank buster",
    AOE_DAMAGE = "AOE incoming",
    UTILITY = "Utility",
    OTHER = "Watch",
}

local VALID_PHRASE_MODES = {
    ACTION_ONLY = true,
    ACTION_ABILITY = true,
    ABILITY_ONLY = true,
    CUSTOM = true,
}

local function GetDB()
    return type(CT.GetDB) == "function" and CT:GetDB() or nil
end

local function GetTTSVoices()
    if not (C_VoiceChat and type(C_VoiceChat.GetTtsVoices) == "function") then return {} end
    local ok, voices = pcall(C_VoiceChat.GetTtsVoices)
    return ok and type(voices) == "table" and voices or {}
end

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value)
end

local function PublicNumber(value)
    if IsSecret(value) or type(value) ~= "number" then return nil end
    return value
end

local function PublicText(value)
    if IsSecret(value) or type(value) ~= "string" then return nil end
    local text = value:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    if text == "" then return nil end
    return text
end

local GENERIC_ABILITY_TEXT = {
    ["ability"] = true,
    ["boss ability"] = true,
    ["trash cast"] = true,
    ["important trash cast"] = true,
    ["tracked trash cast"] = true,
}

local function PublicAbilityText(value)
    local text = PublicText(value)
    if not text then return nil end
    if GENERIC_ABILITY_TEXT[text:lower()] then return nil end
    return text
end

local function NormalizeSpeechPronunciation(text)
    text = PublicText(text)
    if not text then return nil end

    -- Windows TTS can interpret the fantasy spelling "wyrm" as letters.
    -- Normalize only the spoken string; displayed Blizzard spell names stay exact.
    text = text:gsub("%f[%a]WYRMS%f[%A]", "worms")
    text = text:gsub("%f[%a]Wyrms%f[%A]", "worms")
    text = text:gsub("%f[%a]wyrms%f[%A]", "worms")
    text = text:gsub("%f[%a]WYRM%f[%A]", "worm")
    text = text:gsub("%f[%a]Wyrm%f[%A]", "worm")
    text = text:gsub("%f[%a]wyrm%f[%A]", "worm")
    return text
end

local function CanRequestSpellData()
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return false end
    return C_Spell and type(C_Spell.RequestLoadSpellData) == "function"
end

local function RequestSpellData(spellID)
    if requestedSpellData[spellID] or not CanRequestSpellData() then return end
    local ok = pcall(C_Spell.RequestLoadSpellData, spellID)
    if ok then requestedSpellData[spellID] = true end
end

local function CatalogSpellName(spellID, requestIfMissing)
    spellID = PublicNumber(spellID)
    if not spellID then return nil end

    local cached = spellNameCache[spellID]
    if cached then return cached end

    if C_Spell and type(C_Spell.GetSpellName) == "function" then
        local ok, name = pcall(C_Spell.GetSpellName, spellID)
        name = ok and PublicAbilityText(name) or nil
        if name then
            spellNameCache[spellID] = name
            requestedSpellData[spellID] = nil
            return name
        end
    end

    if requestIfMissing ~= false then
        RequestSpellData(spellID)
    end
    return nil
end

local function AddSpellID(ids, spellID)
    spellID = PublicNumber(spellID)
    if spellID then ids[spellID] = true end
end

local function CollectCatalogSpellIDs()
    local ids = {}

    local dungeonData = _G.ChayAlertHUDDungeonData
    if type(dungeonData) == "table" and type(dungeonData.dungeons) == "table" then
        for _, dungeon in pairs(dungeonData.dungeons) do
            for _, mob in ipairs(type(dungeon) == "table" and dungeon.mobs or {}) do
                for _, spell in ipairs(type(mob) == "table" and mob.spells or {}) do
                    if type(spell) == "table" then AddSpellID(ids, spell.id) end
                end
            end
        end
    end

    local bossData = _G.ChayAlertHUDDungeonBossData
    if type(bossData) == "table" and type(bossData.dungeons) == "table" then
        for _, dungeon in pairs(bossData.dungeons) do
            for _, boss in ipairs(type(dungeon) == "table" and dungeon.bosses or {}) do
                for _, spell in ipairs(type(boss) == "table" and boss.spells or {}) do
                    if type(spell) == "table" then AddSpellID(ids, spell.id) end
                end
            end
        end
    end

    local raidData = _G.ChayAlertHUDRaidData
    if type(raidData) == "table" and type(raidData.raids) == "table" then
        for _, raid in pairs(raidData.raids) do
            for _, boss in ipairs(type(raid) == "table" and raid.bosses or {}) do
                for _, spell in ipairs(type(boss) == "table" and boss.spells or {}) do
                    if type(spell) == "table" then AddSpellID(ids, spell.id) end
                end
            end
        end
    end

    return ids
end

function TTS:PrimeCatalog()
    local ids = CollectCatalogSpellIDs()
    local total, resolved, unresolved = 0, 0, 0

    for spellID in pairs(ids) do
        total = total + 1
        if CatalogSpellName(spellID, true) then
            resolved = resolved + 1
        else
            unresolved = unresolved + 1
        end
    end

    catalogAudit.total = total
    catalogAudit.resolved = resolved
    catalogAudit.unresolved = unresolved

    return total, resolved, unresolved
end

function TTS:GetCatalogAudit()
    return catalogAudit.total, catalogAudit.resolved, catalogAudit.unresolved
end

local function ResolvePublicSpellID(candidate)
    if type(candidate) ~= "table" then return nil end
    local spellID = PublicNumber(candidate.catalogSpellID)
    if spellID then return spellID end
    return PublicNumber(candidate.spellID)
end

function TTS:ResolvePublicAbilityName(candidate)
    if type(candidate) ~= "table" then return nil end

    local spellID = ResolvePublicSpellID(candidate)
    if spellID then
        local resolved = CatalogSpellName(spellID, true)
            or PublicAbilityText(candidate.catalogSpellName)
        if resolved then return resolved end
    end

    -- Live fallbacks are public catalog/static text only. Secret combat values
    -- are never inspected or converted to strings.
    return PublicAbilityText(candidate.catalogSpellName)
        or PublicAbilityText(candidate.spellName)
        or PublicAbilityText(candidate.safeFallbackAbilityName)
end

local function PreferredVoiceKey(name)
    name = PublicText(name)
    if not name then return nil end
    local lower = name:lower()
    if lower:find("zira", 1, true) then return "ZIRA" end
    if lower:find("david", 1, true) then return "DAVID" end
    return nil
end

local function InstalledVoiceID(voices, wantedID)
    wantedID = tonumber(wantedID)
    if not wantedID then return nil end
    for _, voice in ipairs(voices or {}) do
        if type(voice) == "table" and tonumber(voice.voiceID) == wantedID then
            return wantedID
        end
    end
    return nil
end

local function PreferredInstalledVoiceID(voices, wantedKey)
    if wantedKey ~= "ZIRA" and wantedKey ~= "DAVID" then return nil end
    for _, voice in ipairs(voices or {}) do
        if type(voice) == "table" and PreferredVoiceKey(voice.name) == wantedKey then
            local id = tonumber(voice.voiceID)
            if id then return id end
        end
    end
    return nil
end

local function ResolveVoiceID()
    local voices = GetTTSVoices()
    if #voices == 0 then return nil end

    local db = GetDB()
    local preferredKey = type(db) == "table" and db.ttsVoiceKey or nil
    local preferredID = PreferredInstalledVoiceID(voices, preferredKey)
    if type(preferredID) == "number" then return preferredID end

    local configured = tonumber(db and db.ttsVoiceID)
    local installed = InstalledVoiceID(voices, configured)
    if installed then return installed end

    if C_TTSSettings and type(C_TTSSettings.GetVoiceOptionID) == "function"
        and Enum and Enum.TtsVoiceType and Enum.TtsVoiceType.Standard ~= nil then
        local ok, preferredID = pcall(C_TTSSettings.GetVoiceOptionID, Enum.TtsVoiceType.Standard)
        if ok then
            installed = InstalledVoiceID(voices, preferredID)
            if installed then return installed end
        end
    end

    local first = voices[1]
    return type(first) == "table" and tonumber(first.voiceID) or nil
end

local function SpeechRate()
    local db = GetDB()
    if db and type(db.ttsRate) == "number" then
        return math.max(-10, math.min(10, db.ttsRate))
    end
    if C_TTSSettings and type(C_TTSSettings.GetSpeechRate) == "function" then
        local ok, rate = pcall(C_TTSSettings.GetSpeechRate)
        if ok and type(rate) == "number" then return rate end
    end
    return 0
end

function TTS:RefreshVoices()
    wipe(voiceLabelToID)
    wipe(voiceIDToLabel)
    wipe(preferredVoiceIDs)
    voiceLabelToID[DEFAULT_LABEL] = -1
    voiceIDToLabel[-1] = DEFAULT_LABEL

    local preferredFound = {}
    local voices = GetTTSVoices()
    for _, voice in ipairs(voices) do
        local id = type(voice) == "table" and tonumber(voice.voiceID) or nil
        local name = type(voice) == "table" and PublicText(voice.name) or nil
        if id and name then
            local preferredKey = PreferredVoiceKey(name)
            local label
            if preferredKey and not preferredFound[preferredKey] then
                label = PREFERRED_VOICE_LABELS[preferredKey]
                preferredFound[preferredKey] = true
                preferredVoiceIDs[preferredKey] = id
            else
                label = string.format("%s [%d]", name, id)
            end
            voiceLabelToID[label] = id
            voiceIDToLabel[id] = label
        end
    end
end

function TTS:GetVoiceChoices()
    self:RefreshVoices()

    local result = {}
    local preferredLabels = {}
    for _, key in ipairs(PREFERRED_VOICE_ORDER) do
        local label = PREFERRED_VOICE_LABELS[key]
        preferredLabels[label] = true
        if voiceLabelToID[label] ~= nil then
            result[#result + 1] = label
        end
    end

    result[#result + 1] = DEFAULT_LABEL

    local extra = {}
    for label, id in pairs(voiceLabelToID) do
        if id ~= -1 and not preferredLabels[label] then
            extra[#extra + 1] = label
        end
    end
    table.sort(extra)
    for _, label in ipairs(extra) do result[#result + 1] = label end
    return result
end

function TTS:GetSelectedVoiceLabel()
    self:RefreshVoices()
    local db = GetDB()
    local key = type(db) == "table" and db.ttsVoiceKey or nil
    if (key == "ZIRA" or key == "DAVID") and preferredVoiceIDs[key] then
        return PREFERRED_VOICE_LABELS[key]
    end
    local id = tonumber(db and db.ttsVoiceID)
    local label = id and voiceIDToLabel[id] or DEFAULT_LABEL
    if type(db) == "table" then
        if label == PREFERRED_VOICE_LABELS.ZIRA then
            db.ttsVoiceKey = "ZIRA"
        elseif label == PREFERRED_VOICE_LABELS.DAVID then
            db.ttsVoiceKey = "DAVID"
        end
    end
    return label
end

function TTS:SetSelectedVoiceLabel(label)
    self:RefreshVoices()
    local db = GetDB()
    if not db then return end

    local preferredKey
    for key, preferredLabel in pairs(PREFERRED_VOICE_LABELS) do
        if label == preferredLabel then
            preferredKey = key
            break
        end
    end

    if preferredKey and preferredVoiceIDs[preferredKey] then
        db.ttsVoiceKey = preferredKey
        db.ttsVoiceID = preferredVoiceIDs[preferredKey]
    else
        local id = voiceLabelToID[label]
        db.ttsVoiceKey = nil
        db.ttsVoiceID = type(id) == "number" and id >= 0 and id or nil
    end

    if CT.TankSwap and type(CT.TankSwap.Refresh) == "function" then
        CT.TankSwap:Refresh()
    end
end

function TTS:GetResolvedPreferredVoiceKey()
    self:RefreshVoices()
    local db = GetDB()
    local configuredKey = type(db) == "table" and db.ttsVoiceKey or nil
    if (configuredKey == "ZIRA" or configuredKey == "DAVID") and preferredVoiceIDs[configuredKey] then
        return configuredKey
    end

    local voiceID = ResolveVoiceID()
    if type(voiceID) ~= "number" then return nil end

    local label = voiceIDToLabel[voiceID]
    if label == PREFERRED_VOICE_LABELS.ZIRA then return "ZIRA" end
    if label == PREFERRED_VOICE_LABELS.DAVID then return "DAVID" end

    for _, voice in ipairs(GetTTSVoices()) do
        if type(voice) == "table" and tonumber(voice.voiceID) == voiceID then
            return PreferredVoiceKey(voice.name)
        end
    end
    return nil
end

function TTS:GetActionText(mechanicType)
    mechanicType = type(mechanicType) == "string" and mechanicType:upper() or "OTHER"
    return ACTION_TEXT[mechanicType]
end

local function PhraseMode(db)
    local mode = type(db) == "table" and db.ttsPhraseMode or nil
    mode = type(mode) == "string" and mode:upper() or "ABILITY_ONLY"
    if mode == "CUSTOM" then return "CUSTOM" end
    return "ABILITY_ONLY"
end

function TTS:Speak(text, force)
    local db = GetDB()
    if not force and (not db or db.ttsEnabled ~= true) then return false end
    if not (C_VoiceChat and type(C_VoiceChat.SpeakText) == "function") then
        return false
    end

    text = PublicAbilityText(text)
    if not text then return false end
    text = NormalizeSpeechPronunciation(text)
    if not text then return false end

    local voiceID = ResolveVoiceID()
    if type(voiceID) ~= "number" then
        return false
    end

    local volume = math.max(0, math.min(100, tonumber(db and db.ttsVolume) or 100))
    local ok, result = pcall(C_VoiceChat.SpeakText, voiceID, text, SpeechRate(), volume, false)
    if ok and result ~= false then
        return true
    end

    return false
end

function TTS:BuildAbilityCallout(candidate)
    if type(candidate) ~= "table" then return nil end

    local db = GetDB()
    local mode = PhraseMode(db)
    local ability = self:ResolvePublicAbilityName(candidate)
    local perAbilityCustom = PublicText(candidate.ttsCustomText)
    local globalCustom = PublicText(db and db.ttsCustomPhrase)

    if mode == "CUSTOM" then
        return perAbilityCustom or globalCustom or ability
    end

    -- Normal mechanic speech is the real ability/spell name only. Do not prepend
    -- mechanic classifications such as Kick, Tank buster, AOE, Utility, Watch,
    -- Spell, or Ability. If no safe public/catalog name is available, fail closed
    -- instead of speaking a generic category that can be misleading or noisy.
    return ability
end

local function CandidateReadyForSpeech(candidate)
    if type(candidate) ~= "table" then return false end
    if candidate.isFutureEvent == true then
        local remaining = PublicNumber(candidate.remaining)
        local leadTime = PublicNumber(candidate.circleLeadTime)
        if remaining ~= nil and leadTime ~= nil and remaining > leadTime then
            return false
        end
    end
    return true
end

function TTS:SpeakAbility(candidate)
    if type(candidate) ~= "table" or (candidate.tts ~= true and candidate.ttsEnabled ~= true) then return false end
    local state = candidate.soundState
    if type(state) ~= "table" or state.ttsPlayed then return false end

    -- Boss timeline candidates can enter the Timeline HUD well before their
    -- circle/voice lead time. Never consume the one-shot TTS state merely
    -- because the visual timeline window is larger than the alert lead time.
    if not CandidateReadyForSpeech(candidate) then
        return false
    end

    -- Every normal mechanic callout goes through the selected WoW TTS voice.
    -- Normal callouts speak the resolved public/catalog ability name only; Custom
    -- mode remains an explicit user override. Protected tank swaps remain on their
    -- separate Blizzard AuraSound path.
    local text = self:BuildAbilityCallout(candidate)
    if not text then return false end

    if self:Speak(text, false) then
        state.ttsPlayed = true
        return true
    end
    return false
end

function TTS:AnnounceCandidate(candidate)
    return self:SpeakAbility(candidate)
end

function TTS:PreviewAbility(candidate)
    if type(candidate) ~= "table" then return false end
    return self:Speak(self:BuildAbilityCallout(candidate), true)
end

function TTS:Preview()
    -- Searing Blows is a static spell-ID preview that exercises the same
    -- ability-name-only speech path used by live mechanics.
    return self:PreviewAbility({ catalogSpellID = 372858, mechanicType = "TANK" })
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("SPELL_DATA_LOAD_RESULT")
events:SetScript("OnEvent", function(_, event, ...)
    if event == "SPELL_DATA_LOAD_RESULT" then
        local spellID, success = ...
        spellID = PublicNumber(spellID)
        if spellID then
            requestedSpellData[spellID] = nil
            if success == true then
                CatalogSpellName(spellID, false)
            end
        end
        return
    end

    if event == "PLAYER_REGEN_ENABLED" and catalogAudit.unresolved <= 0 then
        return
    end

    TTS:PrimeCatalog()
end)
