local CT = _G.ChayAlertHUD
local BossData = _G.ChayAlertHUDDungeonBossData
local RaidData = _G.ChayAlertHUDRaidData
local AU = _G.ChayAlertHUDAbilityUI
if not CT or not BossData or not RaidData or not AU then return end

local PRIORITY_LABELS = AU.PRIORITY_LABELS
local PRIORITY_COLORS = AU.PRIORITY_COLORS

local function MakeBackdrop(frame, alpha)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.015, 0.008, 0.012, alpha or 0.82)
    frame:SetBackdropBorderColor(0.42, 0.04, 0.055, 0.95)
end

local function CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width or 100, height or 22)
    button:SetText(text or "")
    if type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, false)
    end
    return button
end

local function CreateLabel(parent, text, template)
    local label = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    label:SetText(text or "")
    return label
end

-- Bounds a label to one line and truncates overflow instead of letting text
-- draw past its anchors or into a neighboring control.
local function TruncateSingleLine(fontString)
    fontString:SetWordWrap(true)
    if fontString.SetMaxLines then fontString:SetMaxLines(1) end
end

local function ColorSelectedButton(button, selected)
    if not button then return end
    button:SetEnabled(true)
    if type(CT.ApplyClassTabStyle) == "function" then
        CT:ApplyClassTabStyle(button, selected == true)
    elseif type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, selected == true)
    end
end

local function StyleStaticTab(button, selected)
    if not button then return end
    if type(CT.ApplyClassTabStyle) == "function" then
        CT:ApplyClassTabStyle(button, selected == true)
    elseif type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, selected == true)
    end
end

local function NormalizeAbilityName(name, spellID)
    if type(name) == "string" and name ~= "" then
        return string.lower(name:gsub("^%s+", ""):gsub("%s+$", ""))
    end
    return "spell:" .. tostring(spellID)
end

local function BuildAbilityGroups(spells)
    local groupsByKey, groups = {}, {}

    for _, spell in ipairs(spells or {}) do
        local info = AU.GetSpellInfo(spell.id)
        local name = info and info.name or ("Spell " .. tostring(spell.id))
        -- Keep each unique spell ID independently configurable. Same-name spells must not share one toggle.
        local key = "spell:" .. tostring(spell.id)
        local group = groupsByKey[key]

        if not group then
            group = {
                key = key,
                name = name,
                iconID = info and info.iconID or "Interface\\Icons\\INV_Misc_QuestionMark",
                spells = {},
            }
            groupsByKey[key] = group
            groups[#groups + 1] = group
        elseif (not group.iconID or group.iconID == "Interface\\Icons\\INV_Misc_QuestionMark") and info and info.iconID then
            group.iconID = info.iconID
        end

        group.spells[#group.spells + 1] = spell
    end

    return groups
end

local function GroupSpellIDs(group)
    local ids = {}
    for _, spell in ipairs(group and group.spells or {}) do
        ids[#ids + 1] = spell.id
    end
    return ids
end

local function EnsureSelectedGroupKey(state, visibleGroups)
    local found = false
    for _, group in ipairs(visibleGroups or {}) do
        if group.key == state.selectedAbilityKey then
            found = true
            break
        end
    end
    if not found then
        state.selectedAbilityKey = visibleGroups and visibleGroups[1] and visibleGroups[1].key or nil
    end
end

local function FindGroupByKey(groups, key)
    for _, group in ipairs(groups or {}) do
        if group.key == key then return group end
    end
    return nil
end

local function AcquireListRow(pool, parent, index, width, height)
    local row = pool[index]
    if row then return row end

    row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetSize(width, height)
    MakeBackdrop(row, 0.54)

    row.leftBar = row:CreateTexture(nil, "ARTWORK")
    row.leftBar:SetWidth(4)
    row.leftBar:SetPoint("TOPLEFT", 0, 0)
    row.leftBar:SetPoint("BOTTOMLEFT", 0, 0)

    row.name = CreateLabel(row, "", "GameFontHighlight")
    row.name:SetPoint("TOPLEFT", 8, -6)
    row.name:SetPoint("RIGHT", -8, 0)
    row.name:SetJustifyH("LEFT")
    TruncateSingleLine(row.name)

    row.meta = CreateLabel(row, "", "GameFontDisableSmall")
    row.meta:SetPoint("BOTTOMLEFT", 8, 5)
    row.meta:SetPoint("RIGHT", -8, 0)
    row.meta:SetJustifyH("LEFT")
    TruncateSingleLine(row.meta)

    pool[index] = row
    return row
end

local function AcquireAbilityCard(pool, parent, index)
    local card = pool[index]
    if card then return card end
    card = AU.CreateAbilityCard(parent)
    pool[index] = card
    return card
end

local function SortGroups(groups, getConfig)
    table.sort(groups, function(a, b)
        local ac = getConfig(a)
        local bc = getConfig(b)
        local ap = ac and tonumber(ac.priority) or 1
        local bp = bc and tonumber(bc.priority) or 1
        if ap ~= bp then return ap > bp end
        return string.lower(a.name or "") < string.lower(b.name or "")
    end)
end

-- ============================================================
-- Dungeon Bosses
-- ============================================================

local BossUI = {
    built = false,
    parent = nil,
    selectedDungeonKey = nil,
    selectedEncounterID = nil,
    selectedAbilityKey = nil,
    dungeonButtons = {},
    bossRows = {},
    abilityCards = {},
    filter = "RECOMMENDED",
    filterButtons = {},
    topButtons = {},
}

local function GetBossDungeon()
    return BossData.dungeons[BossUI.selectedDungeonKey]
end

local function GetSelectedDungeonBoss()
    local dungeon = GetBossDungeon()
    if not dungeon then return nil end
    for _, boss in ipairs(dungeon.bosses or {}) do
        if boss.encounterID == BossUI.selectedEncounterID then
            return boss
        end
    end
    return nil
end

local function BossGroupConfig(boss, group)
    if not boss or not group then return nil end

    local enabled, sound, recommended = false, false, false
    local important, roleRelevant, hasEnabledOverride = false, false, false
    local ttsEnabled, ttsPhrase = false, nil
    local priority = 1
    local label, leadTime, reason, displayMode, effectiveDisplayMode, mechanicType, mechanicTypeOverride
    local roleFlags = { TANK = false, HEALER = false, DAMAGER = false }
    local rolesAll = false

    for _, spell in ipairs(group.spells or {}) do
        local cfg = CT:GetBossAbilityEffectiveConfig(boss.encounterID, spell.id)
        if cfg then
            if cfg.enabled ~= false then enabled = true end
            if cfg.sound ~= false then sound = true end
            if cfg.ttsEnabled == true then ttsEnabled = true end
            ttsPhrase = ttsPhrase or cfg.ttsPhrase
            if cfg.recommended == true then recommended = true end
            if cfg.important == true then
                important = true
                if cfg.roleRelevant == true then roleRelevant = true end
                reason = reason or cfg.reason
                if cfg.roles == "ALL" or not cfg.roles or cfg.roles == "" then
                    rolesAll = true
                else
                    for role in pairs(roleFlags) do
                        if ("_" .. cfg.roles .. "_"):find("_" .. role .. "_", 1, true) then
                            roleFlags[role] = true
                        end
                    end
                end
            end
            if cfg.hasEnabledOverride == true then hasEnabledOverride = true end
            priority = math.max(priority, tonumber(cfg.priority) or 1)
            label = label or cfg.label
            leadTime = leadTime or cfg.leadTime
            reason = reason or cfg.reason
            displayMode = displayMode or cfg.displayMode
            effectiveDisplayMode = effectiveDisplayMode or cfg.effectiveDisplayMode
            mechanicType = mechanicType or cfg.mechanicType
            mechanicTypeOverride = mechanicTypeOverride or cfg.mechanicTypeOverride
        end
    end

    local roles = "ALL"
    if important and not rolesAll then
        local list = {}
        for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
            if roleFlags[role] then list[#list + 1] = role end
        end
        if #list > 0 then roles = table.concat(list, "_") end
    end

    return {
        enabled = enabled,
        sound = sound,
        ttsEnabled = ttsEnabled,
        ttsPhrase = ttsPhrase,
        priority = priority,
        leadTime = leadTime,
        label = label,
        recommended = recommended,
        important = important,
        roleRelevant = roleRelevant,
        roles = roles,
        reason = reason or "Catalog only",
        hasEnabledOverride = hasEnabledOverride,
        displayMode = displayMode or "INHERIT",
        effectiveDisplayMode = effectiveDisplayMode or (CT.GetDisplayMode and CT:GetDisplayMode()) or "BOTH",
        mechanicType = mechanicType or "OTHER",
        mechanicTypeOverride = mechanicTypeOverride,
    }
end

local function ApplyBossGroupEnabled(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityEnabled(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupSound(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilitySound(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupPriority(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityPriority(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupLabel(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityLabel(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupDisplayMode(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityDisplayMode(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupMechanicType(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityMechanicType(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupRoleOverride(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityRoleOverride(boss.encounterID, spell.id, value)
    end
end

local function ApplyBossGroupLeadTime(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetBossAbilityLeadTime(boss.encounterID, spell.id, value)
    end
end

local function ResetBossGroup(boss, group)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:ResetBossAbility(boss.encounterID, spell.id)
    end
end

local function BossRecommendationText(group, cfg)
    if not cfg then return "" end
    if cfg.important then
        local roles = CT:GetRolesLabel(cfg.roles)
        if cfg.roleRelevant then
            return "Important • " .. roles .. " • " .. (cfg.reason or "important mechanic")
        elseif cfg.hasEnabledOverride and cfg.enabled then
            return "Manual enable • important for " .. roles .. " • " .. (cfg.reason or "important mechanic")
        end
        return "Other role • important for " .. roles .. " • " .. (cfg.reason or "important mechanic")
    end
    if cfg.enabled then return "Manual enable • optional catalog ability" end
    return "Optional catalog ability • no automatic alert"
end

local function BossGroupContext(boss, group)
    if not boss or not group then return nil end
    local primary = group.spells and group.spells[1]
    return {
        name = group.name,
        iconID = group.iconID,
        primarySpellID = primary and primary.id,
        spellIDs = GroupSpellIDs(group),
        ownerText = boss.name .. "  •  Encounter " .. tostring(boss.encounterID),
        metaText = BossRecommendationText(group, BossGroupConfig(boss, group)),
        getConfig = function() return BossGroupConfig(boss, group) end,
        setEnabled = function(v) ApplyBossGroupEnabled(boss, group, v) end,
        setSound = function(v) ApplyBossGroupSound(boss, group, v) end,
        setTTS = function(v, phrase)
            if primary then CT:SetBossAbilityTTS(boss.encounterID, primary.id, v, phrase) end
        end,
        setPriority = function(v) ApplyBossGroupPriority(boss, group, v) end,
        setLabel = function(v) ApplyBossGroupLabel(boss, group, v) end,
        setDisplayMode = function(v) ApplyBossGroupDisplayMode(boss, group, v) end,
        setMechanicType = function(v) ApplyBossGroupMechanicType(boss, group, v) end,
        setRoles = function(v) ApplyBossGroupRoleOverride(boss, group, v) end,
        setLeadTime = function(v) ApplyBossGroupLeadTime(boss, group, v) end,
        reset = function() ResetBossGroup(boss, group) end,
        onChanged = function() CT:RefreshDungeonBossPage() end,
    }
end

local function GetBossRecommendationCount(boss)
    local recommended, enabled = 0, 0
    for _, group in ipairs(BuildAbilityGroups(boss and boss.spells or {})) do
        local cfg = BossGroupConfig(boss, group)
        if cfg and cfg.recommended then recommended = recommended + 1 end
        if cfg and cfg.enabled then enabled = enabled + 1 end
    end
    return recommended, enabled
end

local function RefreshBossAbilityCards(boss)
    for _, card in ipairs(BossUI.abilityCards) do card:Hide() end
    if not boss then
        BossUI.detail:SetContext(nil)
        BossUI.cardChild:SetHeight(1)
        return
    end

    local allGroups = BuildAbilityGroups(boss.spells or {})
    local visibleGroups = {}
    local showOptional = CT:GetShowOptionalAbilities()

    for _, group in ipairs(allGroups) do
        local cfg = BossGroupConfig(boss, group)
        local matchesFilter = BossUI.filter == "ALL"
            or (BossUI.filter == "ENABLED" and cfg and cfg.enabled)
            or (BossUI.filter == "RECOMMENDED" and cfg and cfg.recommended)
        if matchesFilter or (not BossUI.filter and (showOptional or (cfg and (cfg.recommended or cfg.enabled)))) then
            visibleGroups[#visibleGroups + 1] = group
        end
    end

    SortGroups(visibleGroups, function(group) return BossGroupConfig(boss, group) end)
    EnsureSelectedGroupKey(BossUI, visibleGroups)

    local columns = 2
    local gap = 8
    local scrollWidth = (BossUI.cardScroll and BossUI.cardScroll:GetWidth()) or 430
    local cardW = math.max(160, math.floor((scrollWidth - gap) / columns) - 1)
    local cardH = 58
    BossUI.cardChild:SetWidth(math.max(1, scrollWidth))

    for index, group in ipairs(visibleGroups) do
        local cfg = BossGroupConfig(boss, group)
        local card = AcquireAbilityCard(BossUI.abilityCards, BossUI.cardChild, index)
        local col = (index - 1) % columns
        local row = math.floor((index - 1) / columns)
        local primary = group.spells and group.spells[1]

        card:ClearAllPoints()
        card:SetPoint("TOPLEFT", col * (cardW + gap), -(row * (cardH + gap)))
        card:SetSize(cardW, cardH)
        card.group = group
        card:SetAbilityVisual(
            group.name,
            group.iconID,
            cfg and cfg.priority or 1,
            cfg and cfg.enabled or false,
            group.key == BossUI.selectedAbilityKey,
            primary and primary.id,
            nil,
            cfg and cfg.mechanicType or "OTHER",
            cfg and (cfg.effectiveDisplayMode == "CIRCLE" or cfg.effectiveDisplayMode == "BOTH"),
            cfg and cfg.ttsEnabled == true
        )
        card:SetScript("OnClick", function(self)
            BossUI.selectedAbilityKey = self.group and self.group.key or nil
            CT:RefreshDungeonBossPage()
        end)
        card:Show()
    end

    local rows = math.max(1, math.ceil(#visibleGroups / columns))
    BossUI.cardChild:SetHeight(rows * (cardH + gap))

    local selected = FindGroupByKey(visibleGroups, BossUI.selectedAbilityKey)
    BossUI.detail:SetContext(BossGroupContext(boss, selected))
end

function CT:RefreshDungeonBossPage()
    if not BossUI.built then return end

    if not BossUI.selectedDungeonKey or not BossData.dungeons[BossUI.selectedDungeonKey] then
        BossUI.selectedDungeonKey = CT:GetCurrentDungeonKey() or BossData.order[1]
        BossUI.selectedEncounterID = nil
        BossUI.selectedAbilityKey = nil
    end

    local dungeon = GetBossDungeon()
    if not dungeon then return end

    local validEncounter = false
    for _, boss in ipairs(dungeon.bosses or {}) do
        if boss.encounterID == BossUI.selectedEncounterID then
            validEncounter = true
            break
        end
    end
    if not validEncounter then
        BossUI.selectedEncounterID = dungeon.bosses[1] and dungeon.bosses[1].encounterID or nil
        BossUI.selectedAbilityKey = nil
    end

    for _, key in ipairs(BossData.order or {}) do
        ColorSelectedButton(BossUI.dungeonButtons[key], key == BossUI.selectedDungeonKey)
    end

    for _, row in ipairs(BossUI.bossRows) do row:Hide() end
    for index, boss in ipairs(dungeon.bosses or {}) do
        local recommended, enabled = GetBossRecommendationCount(boss)
        local total = #BuildAbilityGroups(boss.spells or {})
        local row = AcquireListRow(BossUI.bossRows, BossUI.bossChild, index, 228, 44)
        row.boss = boss
        row.name:SetText(boss.name)
        local aggregatePriority = AU.GetAggregatePriority(BuildAbilityGroups(boss.spells or {}), function(group)
            return BossGroupConfig(boss, group)
        end)
        local aggregateColor = AU.GetPriorityColor(aggregatePriority)
        row.name:SetTextColor(aggregateColor[1], aggregateColor[2], aggregateColor[3], 1)
        row.leftBar:SetColorTexture(aggregateColor[1], aggregateColor[2], aggregateColor[3], 1)
        row.meta:SetText(string.format("Encounter %d • %d important • %d enabled • %d total", boss.encounterID, recommended, enabled, total))
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 0, -((index - 1) * 55))
        row:SetScript("OnClick", function(self)
            BossUI.selectedEncounterID = self.boss.encounterID
            BossUI.selectedAbilityKey = nil
            CT:RefreshDungeonBossPage()
        end)
        row:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.17, 0.025, 0.035, 0.92)
        end)
        row:SetScript("OnLeave", function(self)
            if self.boss and self.boss.encounterID == BossUI.selectedEncounterID then
                self:SetBackdropColor(0.25, 0.025, 0.035, 0.95)
            else
                self:SetBackdropColor(0.015, 0.008, 0.012, 0.54)
            end
        end)
        if boss.encounterID == BossUI.selectedEncounterID then
            row:SetBackdropColor(0.25, 0.025, 0.035, 0.95)
        else
            row:SetBackdropColor(0.015, 0.008, 0.012, 0.54)
        end
        row:Show()
    end
    BossUI.bossChild:SetHeight(math.max(1, #(dungeon.bosses or {}) * 55))

    local boss = GetSelectedDungeonBoss()
    BossUI.rightTitle:SetText(boss and boss.name or "Select a boss")
    BossUI.showAll:SetText(CT:GetShowOptionalAbilities() and "Important Only" or "Show All")
    StyleStaticTab(BossUI.topButtons.currentContext, false)
    StyleStaticTab(BossUI.topButtons.showAll, CT:GetShowOptionalAbilities())
    for filter, button in pairs(BossUI.filterButtons) do
        ColorSelectedButton(button, filter == BossUI.filter)
    end
    BossUI.unknown:SetChecked(CT:GetTrackUnknownBossTimeline())
    if BossUI.roleSelector then BossUI.roleSelector:Refresh() end
    RefreshBossAbilityCards(boss)
end

function CT:BuildDungeonBossPage(parent)
    if BossUI.built then
        if parent and BossUI.parent ~= parent then
            BossUI.root:SetParent(parent)
            BossUI.root:ClearAllPoints()
            BossUI.root:SetAllPoints(parent)
            BossUI.parent = parent
        end
        return
    end
    if not parent then return end

    BossUI.built = true
    BossUI.parent = parent
    BossUI.selectedDungeonKey = CT:GetCurrentDungeonKey() or BossData.order[1]

    local root = CreateFrame("Frame", nil, parent)
    root:SetAllPoints()
    BossUI.root = root

    local title = CreateLabel(root, "Dungeon Bosses", "GameFontNormalLarge")

    local help = CreateLabel(root,
        "Choose a dungeon, then a boss, then configure each ability.",
        "GameFontDisableSmall")
    help:SetWidth(700)
    help:SetJustifyH("LEFT")
    help:SetWordWrap(true)
    if help.SetMaxLines then help:SetMaxLines(2) end

    local legend = AU.CreateSeverityLegend(root)

    -- A simple vertical cursor derives each header row from the row above it
    -- instead of scattered magic Y offsets that can drift out of sync.
    local headerY = 0
    local function NextHeaderRow(height, gap)
        local rowTop = headerY
        headerY = rowTop - height - (gap or 10)
        return rowTop
    end

    title:SetPoint("TOPLEFT", 0, NextHeaderRow(22, 8))
    help:SetPoint("TOPLEFT", 0, NextHeaderRow(32, 8))
    legend:SetPoint("TOPLEFT", 0, NextHeaderRow(16, 8))
    local filterRowY = NextHeaderRow(22, 8)
    local roleRowY = NextHeaderRow(24, 10)
    local top = headerY

    local viewLabel = CreateLabel(root, "View:", "GameFontHighlightSmall")
    viewLabel:SetPoint("TOPLEFT", 0, filterRowY)

    local previousFilterButton
    for _, filter in ipairs({ "RECOMMENDED", "ENABLED", "ALL" }) do
        local button = CreateButton(root, filter:sub(1, 1) .. filter:sub(2):lower(), 92, 22)
        if previousFilterButton then
            button:SetPoint("LEFT", previousFilterButton, "RIGHT", 6, 0)
        else
            button:SetPoint("LEFT", viewLabel, "RIGHT", 8, 0)
        end
        button:SetScript("OnClick", function()
            BossUI.filter = filter
            CT:RefreshDungeonBossPage()
        end)
        BossUI.filterButtons[filter] = button
        previousFilterButton = button
    end

    BossUI.unknown = CreateFrame("CheckButton", nil, root, "UICheckButtonTemplate")
    BossUI.unknown:SetSize(22, 22)
    BossUI.unknown:SetPoint("TOPRIGHT", -5, filterRowY)
    local unknownText = CreateLabel(root, "Unknown", "GameFontHighlightSmall")
    unknownText:SetPoint("RIGHT", BossUI.unknown, "LEFT", -4, 0)
    BossUI.unknown:SetScript("OnClick", function(self)
        CT:SetTrackUnknownBossTimeline(self:GetChecked() == true)
    end)
    BossUI.unknown:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Unknown timeline events", 1, 0.25, 0.25)
        GameTooltip:AddLine("Off by default. Enable only if you want Blizzard Encounter Timeline events that ChayAlert HUD cannot match to the curated boss catalog to create alerts.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    BossUI.unknown:SetScript("OnLeave", GameTooltip_Hide)

    BossUI.showAll = CreateButton(root, "Show All", 84, 22)
    BossUI.topButtons.showAll = BossUI.showAll
    StyleStaticTab(BossUI.showAll, false)
    BossUI.showAll:SetPoint("RIGHT", unknownText, "LEFT", -14, 0)
    BossUI.showAll:SetScript("OnClick", function()
        CT:SetShowOptionalAbilities(not CT:GetShowOptionalAbilities())
        CT:RefreshDungeonBossPage()
    end)
    BossUI.showAll:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Important Only / Show All", 1, 0.25, 0.25)
        GameTooltip:AddLine("Important Only uses Blizzard Important plus ChayAlert HUD high-priority/role-scoped classifications. Generic informational entries stay optional.", 1, 1, 1, true)
        GameTooltip:AddLine("Show All exposes the full boss catalog for manual opt-in.", 0.65, 0.9, 1, true)
        GameTooltip:Show()
    end)
    BossUI.showAll:SetScript("OnLeave", GameTooltip_Hide)

    local current = CreateButton(root, "Current Dungeon", 120, 22)
    BossUI.topButtons.currentContext = current
    StyleStaticTab(current, false)
    current:SetPoint("RIGHT", BossUI.showAll, "LEFT", -8, 0)
    current:SetScript("OnClick", function()
        local key = CT:GetCurrentDungeonKey()
        if key and BossData.dungeons[key] then
            BossUI.selectedDungeonKey = key
            BossUI.selectedEncounterID = nil
            BossUI.selectedAbilityKey = nil
            CT:RefreshDungeonBossPage()
        end
    end)

    BossUI.roleSelector = AU.CreateRoleSelector(root, function()
        CT:RefreshDungeonBossPage()
    end)
    BossUI.roleSelector:SetPoint("TOPRIGHT", -5, roleRowY)

    local dungeonPanel = CreateFrame("Frame", nil, root, "BackdropTemplate")
    dungeonPanel:SetPoint("TOPLEFT", 0, top)
    dungeonPanel:SetPoint("BOTTOMLEFT", 0, 0)
    dungeonPanel:SetWidth(174)
    MakeBackdrop(dungeonPanel, 0.72)

    local dungeonHeader = CreateLabel(dungeonPanel, "Dungeons", "GameFontNormal")
    dungeonHeader:SetPoint("TOPLEFT", 10, -9)

    local y = -34
    for _, key in ipairs(BossData.order or {}) do
        local dungeonKey = key
        local dungeon = BossData.dungeons[dungeonKey]
        local button = CreateButton(dungeonPanel, dungeon.name, 154, 26)
        button:SetPoint("TOPLEFT", 10, y)
        button:SetScript("OnClick", function()
            BossUI.selectedDungeonKey = dungeonKey
            BossUI.selectedEncounterID = nil
            BossUI.selectedAbilityKey = nil
            CT:RefreshDungeonBossPage()
        end)
        BossUI.dungeonButtons[dungeonKey] = button
        y = y - 31
    end

    local bossPanel = CreateFrame("Frame", nil, root, "BackdropTemplate")
    bossPanel:SetPoint("TOPLEFT", dungeonPanel, "TOPRIGHT", 8, 0)
    bossPanel:SetPoint("BOTTOMLEFT", dungeonPanel, "BOTTOMRIGHT", 8, 0)
    bossPanel:SetWidth(290)
    MakeBackdrop(bossPanel, 0.72)

    local bossHeader = CreateLabel(bossPanel, "Bosses", "GameFontNormal")
    bossHeader:SetPoint("TOPLEFT", 10, -9)

    local bossScroll = CreateFrame("ScrollFrame", nil, bossPanel, "UIPanelScrollFrameTemplate")
    bossScroll:SetPoint("TOPLEFT", 10, -34)
    bossScroll:SetPoint("BOTTOMRIGHT", -29, 10)
    BossUI.bossChild = CreateFrame("Frame", nil, bossScroll)
    BossUI.bossChild:SetSize(262, 1)
    BossUI.bossChild:ClearAllPoints()
    BossUI.bossChild:SetPoint("TOPLEFT", bossScroll, "TOPLEFT", 0, 0)
    bossScroll:SetScrollChild(BossUI.bossChild)
    AU.EnhanceScrollFrame(bossScroll)

    local right = CreateFrame("Frame", nil, root, "BackdropTemplate")
    right:SetPoint("TOPLEFT", bossPanel, "TOPRIGHT", 8, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)
    MakeBackdrop(right, 0.72)
    BossUI.right = right

    -- A local cursor keeps every selected-boss row derived from the row above
    -- it, instead of independent fixed offsets that can overlap.
    local rightY = -9
    local function NextRightRow(height, gap)
        local rowTop = rightY
        rightY = rowTop - height - (gap or 8)
        return rowTop
    end

    BossUI.rightTitle = CreateLabel(right, "Select a boss", "GameFontNormalLarge")
    BossUI.rightTitle:SetPoint("TOPLEFT", 12, NextRightRow(22, 8))
    BossUI.rightTitle:SetWidth(260)
    BossUI.rightTitle:SetJustifyH("LEFT")
    TruncateSingleLine(BossUI.rightTitle)

    local controlRowY = NextRightRow(20, 10)
    local resetBoss = CreateButton(right, "Reset", 70, 20)
    resetBoss:SetPoint("TOPRIGHT", -10, controlRowY)
    resetBoss:SetScript("OnClick", function()
        local boss = GetSelectedDungeonBoss()
        if boss then
            CT:ResetDungeonBossAbilities(boss.encounterID)
            CT:RefreshDungeonBossPage()
        end
    end)
    resetBoss:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Reset boss abilities", 1, 0.25, 0.25)
        GameTooltip:AddLine("Removes all custom Track, Sound, Importance, Label, and Lead settings for this boss.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    resetBoss:SetScript("OnLeave", GameTooltip_Hide)

    local disableAll = CreateButton(right, "Disable All", 82, 20)
    disableAll:SetPoint("RIGHT", resetBoss, "LEFT", -6, 0)
    disableAll:SetScript("OnClick", function()
        local boss = GetSelectedDungeonBoss()
        if not boss then return end
        for _, spell in ipairs(boss.spells or {}) do
            CT:SetBossAbilityEnabled(boss.encounterID, spell.id, false)
        end
        CT:RefreshDungeonBossPage()
    end)

    local enableAll = CreateButton(right, "Enable All", 82, 20)
    enableAll:SetPoint("RIGHT", disableAll, "LEFT", -6, 0)
    enableAll:SetScript("OnClick", function()
        local boss = GetSelectedDungeonBoss()
        if not boss then return end
        for _, spell in ipairs(boss.spells or {}) do
            CT:SetBossAbilityEnabled(boss.encounterID, spell.id, true)
        end
        CT:RefreshDungeonBossPage()
    end)

    local applyRecommendations = CreateButton(right, "Apply Recs", 94, 20)
    applyRecommendations:SetPoint("RIGHT", enableAll, "LEFT", -6, 0)
    applyRecommendations:SetScript("OnClick", function()
        local boss = GetSelectedDungeonBoss()
        if not boss then return end
        for _, spell in ipairs(boss.spells or {}) do
            local cfg = CT:GetBossAbilityEffectiveConfig(boss.encounterID, spell.id)
            if cfg then
                CT:SetBossAbilityEnabled(boss.encounterID, spell.id, cfg.recommended == true)
            end
        end
        CT:RefreshDungeonBossPage()
    end)
    applyRecommendations:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Apply Recommendations", 1, 0.25, 0.25)
        GameTooltip:AddLine("Turns each ability for this boss on or off to match ChayAlert HUD's current recommendation for your active role. Labels, sounds, priorities, lead times, and role overrides you customized are left untouched.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    applyRecommendations:SetScript("OnLeave", GameTooltip_Hide)

    local abilitiesLabel = CreateLabel(right, "Abilities", "GameFontNormal")
    abilitiesLabel:SetPoint("TOPLEFT", 12, NextRightRow(16, 4))
    abilitiesLabel:SetTextColor(0.45, 0.95, 1.0, 1)

    local cardScrollY = NextRightRow(140, 10)
    local cardScroll = CreateFrame("ScrollFrame", nil, right, "UIPanelScrollFrameTemplate")
    cardScroll:SetPoint("TOPLEFT", 12, cardScrollY)
    cardScroll:SetPoint("TOPRIGHT", -29, cardScrollY)
    cardScroll:SetHeight(140)
    BossUI.cardScroll = cardScroll
    BossUI.cardChild = CreateFrame("Frame", nil, cardScroll)
    BossUI.cardChild:SetSize(430, 1)
    BossUI.cardChild:ClearAllPoints()
    BossUI.cardChild:SetPoint("TOPLEFT", cardScroll, "TOPLEFT", 0, 0)
    cardScroll:SetScrollChild(BossUI.cardChild)
    AU.EnhanceScrollFrame(cardScroll)

    BossUI.detail = AU.CreateDetailPanel(right)
    BossUI.detail:SetPoint("TOPLEFT", 12, rightY)
    BossUI.detail:SetPoint("BOTTOMRIGHT", -12, 10)

    CT:RefreshDungeonBossPage()
end

-- ============================================================
-- Raids
-- ============================================================

local RaidUI = {
    built = false,
    parent = nil,
    selectedRaidKey = "the_venomous_abyss",
    selectedEncounterID = nil,
    selectedAbilityKey = nil,
    raidButtons = {},
    bossRows = {},
    abilityCards = {},
    filter = "RECOMMENDED",
    filterButtons = {},
    topButtons = {},
}

local function GetSelectedRaid()
    return RaidData.raids[RaidUI.selectedRaidKey]
end

local function GetSelectedRaidBoss()
    local raid = GetSelectedRaid()
    if not raid then return nil end
    for _, boss in ipairs(raid.bosses or {}) do
        if boss.encounterID == RaidUI.selectedEncounterID then return boss end
    end
    return nil
end

local function RaidGroupConfig(boss, group)
    if not boss or not group then return nil end

    local enabled, sound, recommended = false, false, false
    local important, roleRelevant, hasEnabledOverride = false, false, false
    local ttsEnabled, ttsPhrase = false, nil
    local priority = 1
    local label, leadTime, reason, displayMode, effectiveDisplayMode, mechanicType, mechanicTypeOverride
    local roleFlags = { TANK = false, HEALER = false, DAMAGER = false }
    local rolesAll = false

    for _, spell in ipairs(group.spells or {}) do
        local cfg = CT:GetRaidAbilityEffectiveConfig(boss.encounterID, spell.id)
        if cfg then
            if cfg.enabled ~= false then enabled = true end
            if cfg.sound ~= false then sound = true end
            if cfg.ttsEnabled == true then ttsEnabled = true end
            ttsPhrase = ttsPhrase or cfg.ttsPhrase
            if cfg.recommended == true then recommended = true end
            if cfg.important == true then
                important = true
                if cfg.roleRelevant == true then roleRelevant = true end
                reason = reason or cfg.reason
                if cfg.roles == "ALL" or not cfg.roles or cfg.roles == "" then
                    rolesAll = true
                else
                    for role in pairs(roleFlags) do
                        if ("_" .. cfg.roles .. "_"):find("_" .. role .. "_", 1, true) then
                            roleFlags[role] = true
                        end
                    end
                end
            end
            if cfg.hasEnabledOverride == true then hasEnabledOverride = true end
            priority = math.max(priority, tonumber(cfg.priority) or 1)
            label = label or cfg.label
            leadTime = leadTime or cfg.leadTime
            reason = reason or cfg.reason
            displayMode = displayMode or cfg.displayMode
            effectiveDisplayMode = effectiveDisplayMode or cfg.effectiveDisplayMode
            mechanicType = mechanicType or cfg.mechanicType
            mechanicTypeOverride = mechanicTypeOverride or cfg.mechanicTypeOverride
        end
    end

    local roles = "ALL"
    if important and not rolesAll then
        local list = {}
        for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
            if roleFlags[role] then list[#list + 1] = role end
        end
        if #list > 0 then roles = table.concat(list, "_") end
    end

    return {
        enabled = enabled,
        sound = sound,
        ttsEnabled = ttsEnabled,
        ttsPhrase = ttsPhrase,
        priority = priority,
        leadTime = leadTime,
        label = label,
        recommended = recommended,
        important = important,
        roleRelevant = roleRelevant,
        roles = roles,
        reason = reason or "Catalog only",
        hasEnabledOverride = hasEnabledOverride,
        displayMode = displayMode or "INHERIT",
        effectiveDisplayMode = effectiveDisplayMode or (CT.GetDisplayMode and CT:GetDisplayMode()) or "BOTH",
        mechanicType = mechanicType or "OTHER",
        mechanicTypeOverride = mechanicTypeOverride,
    }
end

local function ApplyRaidGroupEnabled(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityEnabled(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupSound(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilitySound(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupPriority(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityPriority(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupLabel(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityLabel(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupDisplayMode(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityDisplayMode(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupMechanicType(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityMechanicType(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupRoleOverride(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityRoleOverride(boss.encounterID, spell.id, value)
    end
end

local function ApplyRaidGroupLeadTime(boss, group, value)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetRaidAbilityLeadTime(boss.encounterID, spell.id, value)
    end
end

local function ResetRaidGroup(boss, group)
    for _, spell in ipairs(group and group.spells or {}) do
        CT:ResetRaidAbility(boss.encounterID, spell.id)
    end
end

local function RaidGroupContext(boss, group)
    if not boss or not group then return nil end
    local cfg = RaidGroupConfig(boss, group)
    local meta = ""
    if cfg then
        if cfg.important then
            local roles = CT:GetRolesLabel(cfg.roles)
            if cfg.roleRelevant then
                meta = "Important • " .. roles .. " • " .. (cfg.reason or "important mechanic")
            elseif cfg.hasEnabledOverride and cfg.enabled then
                meta = "Manual enable • important for " .. roles .. " • " .. (cfg.reason or "important mechanic")
            else
                meta = "Other role • important for " .. roles .. " • " .. (cfg.reason or "important mechanic")
            end
        elseif cfg.enabled then
            meta = "Manual enable • optional catalog ability"
        else
            meta = "Optional catalog ability • no automatic alert"
        end
    end
    local primary = group.spells and group.spells[1]
    return {
        name = group.name,
        iconID = group.iconID,
        primarySpellID = primary and primary.id,
        spellIDs = GroupSpellIDs(group),
        ownerText = boss.name .. "  •  Encounter " .. tostring(boss.encounterID),
        metaText = meta,
        getConfig = function() return RaidGroupConfig(boss, group) end,
        setEnabled = function(v) ApplyRaidGroupEnabled(boss, group, v) end,
        setSound = function(v) ApplyRaidGroupSound(boss, group, v) end,
        setTTS = function(v, phrase)
            if primary then CT:SetRaidAbilityTTS(boss.encounterID, primary.id, v, phrase) end
        end,
        setPriority = function(v) ApplyRaidGroupPriority(boss, group, v) end,
        setLabel = function(v) ApplyRaidGroupLabel(boss, group, v) end,
        setDisplayMode = function(v) ApplyRaidGroupDisplayMode(boss, group, v) end,
        setMechanicType = function(v) ApplyRaidGroupMechanicType(boss, group, v) end,
        setRoles = function(v) ApplyRaidGroupRoleOverride(boss, group, v) end,
        setLeadTime = function(v) ApplyRaidGroupLeadTime(boss, group, v) end,
        reset = function() ResetRaidGroup(boss, group) end,
        onChanged = function() CT:RefreshRaidPage() end,
    }
end

local function GetRaidRecommendationCount(boss)
    local recommended, enabled = 0, 0
    for _, group in ipairs(BuildAbilityGroups(boss and boss.spells or {})) do
        local cfg = RaidGroupConfig(boss, group)
        if cfg and cfg.recommended then recommended = recommended + 1 end
        if cfg and cfg.enabled then enabled = enabled + 1 end
    end
    return recommended, enabled
end

local function RefreshRaidAbilityCards(boss)
    for _, card in ipairs(RaidUI.abilityCards) do card:Hide() end
    if not boss then
        RaidUI.detail:SetContext(nil)
        RaidUI.cardChild:SetHeight(1)
        return
    end

    local allGroups = BuildAbilityGroups(boss.spells or {})
    local visibleGroups = {}
    local showOptional = CT:GetShowOptionalAbilities()
    for _, group in ipairs(allGroups) do
        local cfg = RaidGroupConfig(boss, group)
        local matchesFilter = RaidUI.filter == "ALL"
            or (RaidUI.filter == "ENABLED" and cfg and cfg.enabled)
            or (RaidUI.filter == "RECOMMENDED" and cfg and cfg.recommended)
        if matchesFilter or (not RaidUI.filter and (showOptional or (cfg and (cfg.recommended or cfg.enabled)))) then
            visibleGroups[#visibleGroups + 1] = group
        end
    end

    SortGroups(visibleGroups, function(group) return RaidGroupConfig(boss, group) end)
    EnsureSelectedGroupKey(RaidUI, visibleGroups)

    local columns = 2
    local gap = 8
    local scrollWidth = (RaidUI.cardScroll and RaidUI.cardScroll:GetWidth()) or 430
    local cardW = math.max(160, math.floor((scrollWidth - gap) / columns) - 1)
    local cardH = 58
    RaidUI.cardChild:SetWidth(math.max(1, scrollWidth))
    for index, group in ipairs(visibleGroups) do
        local cfg = RaidGroupConfig(boss, group)
        local card = AcquireAbilityCard(RaidUI.abilityCards, RaidUI.cardChild, index)
        local col = (index - 1) % columns
        local row = math.floor((index - 1) / columns)
        local primary = group.spells and group.spells[1]
        card:ClearAllPoints()
        card:SetPoint("TOPLEFT", col * (cardW + gap), -(row * (cardH + gap)))
        card:SetSize(cardW, cardH)
        card.group = group
        card:SetAbilityVisual(
            group.name,
            group.iconID,
            cfg and cfg.priority or 1,
            cfg and cfg.enabled or false,
            group.key == RaidUI.selectedAbilityKey,
            primary and primary.id,
            nil,
            cfg and cfg.mechanicType or "OTHER",
            cfg and (cfg.effectiveDisplayMode == "CIRCLE" or cfg.effectiveDisplayMode == "BOTH"),
            cfg and cfg.ttsEnabled == true
        )
        card:SetScript("OnClick", function(self)
            RaidUI.selectedAbilityKey = self.group and self.group.key or nil
            CT:RefreshRaidPage()
        end)
        card:Show()
    end

    local rows = math.max(1, math.ceil(#visibleGroups / columns))
    RaidUI.cardChild:SetHeight(rows * (cardH + gap))

    local selected = FindGroupByKey(visibleGroups, RaidUI.selectedAbilityKey)
    RaidUI.detail:SetContext(RaidGroupContext(boss, selected))
end

function CT:RefreshRaidPage()
    if not RaidUI.built then return end
    local raid = GetSelectedRaid()
    if not raid then return end

    local validEncounter = false
    for _, boss in ipairs(raid.bosses or {}) do
        if boss.encounterID == RaidUI.selectedEncounterID then validEncounter = true break end
    end
    if not validEncounter then
        RaidUI.selectedEncounterID = raid.bosses[1] and raid.bosses[1].encounterID or nil
        RaidUI.selectedAbilityKey = nil
    end

    for _, key in ipairs(RaidData.order or {}) do
        ColorSelectedButton(RaidUI.raidButtons[key], key == RaidUI.selectedRaidKey)
    end

    for _, row in ipairs(RaidUI.bossRows) do row:Hide() end
    for index, boss in ipairs(raid.bosses or {}) do
        local recommended, enabled = GetRaidRecommendationCount(boss)
        local total = #BuildAbilityGroups(boss.spells or {})
        local row = AcquireListRow(RaidUI.bossRows, RaidUI.bossChild, index, 228, 44)
        row.boss = boss
        row.name:SetText(boss.name)
        local aggregatePriority = AU.GetAggregatePriority(BuildAbilityGroups(boss.spells or {}), function(group)
            return RaidGroupConfig(boss, group)
        end)
        local aggregateColor = AU.GetPriorityColor(aggregatePriority)
        row.name:SetTextColor(aggregateColor[1], aggregateColor[2], aggregateColor[3], 1)
        row.leftBar:SetColorTexture(aggregateColor[1], aggregateColor[2], aggregateColor[3], 1)
        row.meta:SetText(string.format("Encounter %d • %d important • %d enabled • %d total", boss.encounterID, recommended, enabled, total))
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 0, -((index - 1) * 55))
        row:SetScript("OnClick", function(self)
            RaidUI.selectedEncounterID = self.boss.encounterID
            RaidUI.selectedAbilityKey = nil
            CT:RefreshRaidPage()
        end)
        row:SetScript("OnEnter", function(self) self:SetBackdropColor(0.17, 0.025, 0.035, 0.92) end)
        row:SetScript("OnLeave", function(self)
            if self.boss and self.boss.encounterID == RaidUI.selectedEncounterID then
                self:SetBackdropColor(0.25, 0.025, 0.035, 0.95)
            else
                self:SetBackdropColor(0.015, 0.008, 0.012, 0.54)
            end
        end)
        if boss.encounterID == RaidUI.selectedEncounterID then
            row:SetBackdropColor(0.25, 0.025, 0.035, 0.95)
        else
            row:SetBackdropColor(0.015, 0.008, 0.012, 0.54)
        end
        row:Show()
    end
    RaidUI.bossChild:SetHeight(math.max(1, #(raid.bosses or {}) * 55))

    local boss = GetSelectedRaidBoss()
    RaidUI.rightTitle:SetText(boss and boss.name or "Select a boss")
    RaidUI.showAll:SetText(CT:GetShowOptionalAbilities() and "Important Only" or "Show All")
    StyleStaticTab(RaidUI.topButtons.showAll, CT:GetShowOptionalAbilities())
    for filter, button in pairs(RaidUI.filterButtons) do
        ColorSelectedButton(button, filter == RaidUI.filter)
    end
    RaidUI.unknown:SetChecked(CT:GetTrackUnknownBossTimeline())
    if RaidUI.roleSelector then RaidUI.roleSelector:Refresh() end
    RefreshRaidAbilityCards(boss)
end

function CT:BuildRaidPage(parent)
    if RaidUI.built then
        if parent and RaidUI.parent ~= parent then
            RaidUI.root:SetParent(parent)
            RaidUI.root:ClearAllPoints()
            RaidUI.root:SetAllPoints(parent)
            RaidUI.parent = parent
        end
        return
    end
    if not parent then return end

    RaidUI.built = true
    RaidUI.parent = parent

    local root = CreateFrame("Frame", nil, parent)
    root:SetAllPoints()
    RaidUI.root = root

    local title = CreateLabel(root, "Raid Bosses", "GameFontNormalLarge")

    local help = CreateLabel(root,
        "Choose a raid, then a boss, then configure each ability.",
        "GameFontDisableSmall")
    help:SetWidth(700)
    help:SetJustifyH("LEFT")
    help:SetWordWrap(true)
    if help.SetMaxLines then help:SetMaxLines(2) end

    local legend = AU.CreateSeverityLegend(root)

    -- A simple vertical cursor derives each header row from the row above it
    -- instead of scattered magic Y offsets that can drift out of sync.
    local headerY = 0
    local function NextHeaderRow(height, gap)
        local rowTop = headerY
        headerY = rowTop - height - (gap or 10)
        return rowTop
    end

    title:SetPoint("TOPLEFT", 0, NextHeaderRow(22, 8))
    help:SetPoint("TOPLEFT", 0, NextHeaderRow(32, 8))
    legend:SetPoint("TOPLEFT", 0, NextHeaderRow(16, 8))
    local filterRowY = NextHeaderRow(22, 8)
    local roleRowY = NextHeaderRow(24, 10)
    local top = headerY

    local viewLabel = CreateLabel(root, "View:", "GameFontHighlightSmall")
    viewLabel:SetPoint("TOPLEFT", 0, filterRowY)

    local previousFilterButton
    for _, filter in ipairs({ "RECOMMENDED", "ENABLED", "ALL" }) do
        local button = CreateButton(root, filter:sub(1, 1) .. filter:sub(2):lower(), 92, 22)
        if previousFilterButton then
            button:SetPoint("LEFT", previousFilterButton, "RIGHT", 6, 0)
        else
            button:SetPoint("LEFT", viewLabel, "RIGHT", 8, 0)
        end
        button:SetScript("OnClick", function()
            RaidUI.filter = filter
            CT:RefreshRaidPage()
        end)
        RaidUI.filterButtons[filter] = button
        previousFilterButton = button
    end

    RaidUI.unknown = CreateFrame("CheckButton", nil, root, "UICheckButtonTemplate")
    RaidUI.unknown:SetSize(22, 22)
    RaidUI.unknown:SetPoint("TOPRIGHT", -5, filterRowY)
    local unknownText = CreateLabel(root, "Unknown", "GameFontHighlightSmall")
    unknownText:SetPoint("RIGHT", RaidUI.unknown, "LEFT", -4, 0)
    RaidUI.unknown:SetScript("OnClick", function(self)
        CT:SetTrackUnknownBossTimeline(self:GetChecked() == true)
    end)
    RaidUI.unknown:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Unknown timeline events", 1, 0.25, 0.25)
        GameTooltip:AddLine("Off by default. Enable only if you want unmatched Blizzard raid timeline events to create alerts.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    RaidUI.unknown:SetScript("OnLeave", GameTooltip_Hide)

    RaidUI.showAll = CreateButton(root, "Show All", 84, 22)
    RaidUI.topButtons.showAll = RaidUI.showAll
    StyleStaticTab(RaidUI.showAll, false)
    RaidUI.showAll:SetPoint("RIGHT", unknownText, "LEFT", -14, 0)
    RaidUI.showAll:SetScript("OnClick", function()
        CT:SetShowOptionalAbilities(not CT:GetShowOptionalAbilities())
        CT:RefreshRaidPage()
    end)
    RaidUI.showAll:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Important Only / Show All", 1, 0.25, 0.25)
        GameTooltip:AddLine("Important Only uses Blizzard Important plus ChayAlert HUD high-priority/role-scoped classifications. Generic informational warnings stay optional.", 1, 1, 1, true)
        GameTooltip:AddLine("Show All exposes the full raid catalog for manual opt-in.", 0.65, 0.9, 1, true)
        GameTooltip:Show()
    end)
    RaidUI.showAll:SetScript("OnLeave", GameTooltip_Hide)

    RaidUI.roleSelector = AU.CreateRoleSelector(root, function()
        CT:RefreshRaidPage()
    end)
    RaidUI.roleSelector:SetPoint("TOPRIGHT", -5, roleRowY)

    local raidPanel = CreateFrame("Frame", nil, root, "BackdropTemplate")
    raidPanel:SetPoint("TOPLEFT", 0, top)
    raidPanel:SetPoint("BOTTOMLEFT", 0, 0)
    raidPanel:SetWidth(174)
    MakeBackdrop(raidPanel, 0.72)

    local raidHeader = CreateLabel(raidPanel, "Raids", "GameFontNormal")
    raidHeader:SetPoint("TOPLEFT", 10, -9)

    local y = -34
    for _, key in ipairs(RaidData.order or {}) do
        local raidKey = key
        local raid = RaidData.raids[raidKey]
        local button = CreateButton(raidPanel, raid.name, 154, 28)
        button:SetPoint("TOPLEFT", 10, y)
        button:SetScript("OnClick", function()
            RaidUI.selectedRaidKey = raidKey
            RaidUI.selectedEncounterID = nil
            RaidUI.selectedAbilityKey = nil
            CT:RefreshRaidPage()
        end)
        RaidUI.raidButtons[raidKey] = button
        y = y - 33
    end

    local bossPanel = CreateFrame("Frame", nil, root, "BackdropTemplate")
    bossPanel:SetPoint("TOPLEFT", raidPanel, "TOPRIGHT", 8, 0)
    bossPanel:SetPoint("BOTTOMLEFT", raidPanel, "BOTTOMRIGHT", 8, 0)
    bossPanel:SetWidth(290)
    MakeBackdrop(bossPanel, 0.72)

    local bossHeader = CreateLabel(bossPanel, "Bosses", "GameFontNormal")
    bossHeader:SetPoint("TOPLEFT", 10, -9)

    local bossScroll = CreateFrame("ScrollFrame", nil, bossPanel, "UIPanelScrollFrameTemplate")
    bossScroll:SetPoint("TOPLEFT", 10, -34)
    bossScroll:SetPoint("BOTTOMRIGHT", -29, 10)
    RaidUI.bossChild = CreateFrame("Frame", nil, bossScroll)
    RaidUI.bossChild:SetSize(262, 1)
    RaidUI.bossChild:ClearAllPoints()
    RaidUI.bossChild:SetPoint("TOPLEFT", bossScroll, "TOPLEFT", 0, 0)
    bossScroll:SetScrollChild(RaidUI.bossChild)
    AU.EnhanceScrollFrame(bossScroll)

    local right = CreateFrame("Frame", nil, root, "BackdropTemplate")
    right:SetPoint("TOPLEFT", bossPanel, "TOPRIGHT", 8, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)
    MakeBackdrop(right, 0.72)

    -- A local cursor keeps every selected-boss row derived from the row above
    -- it, instead of independent fixed offsets that can overlap.
    local rightY = -9
    local function NextRightRow(height, gap)
        local rowTop = rightY
        rightY = rowTop - height - (gap or 8)
        return rowTop
    end

    RaidUI.rightTitle = CreateLabel(right, "Select a boss", "GameFontNormalLarge")
    RaidUI.rightTitle:SetPoint("TOPLEFT", 12, NextRightRow(22, 8))
    RaidUI.rightTitle:SetWidth(260)
    RaidUI.rightTitle:SetJustifyH("LEFT")
    TruncateSingleLine(RaidUI.rightTitle)

    local controlRowY = NextRightRow(20, 10)
    local resetBoss = CreateButton(right, "Reset", 70, 20)
    resetBoss:SetPoint("TOPRIGHT", -10, controlRowY)
    resetBoss:SetScript("OnClick", function()
        local boss = GetSelectedRaidBoss()
        if boss then
            CT:ResetRaidBossAbilities(boss.encounterID)
            CT:RefreshRaidPage()
        end
    end)
    resetBoss:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Reset raid boss abilities", 1, 0.25, 0.25)
        GameTooltip:AddLine("Removes all custom Track, Sound, Importance, Label, and Lead settings for this raid boss.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    resetBoss:SetScript("OnLeave", GameTooltip_Hide)

    local disableAll = CreateButton(right, "Disable All", 82, 20)
    disableAll:SetPoint("RIGHT", resetBoss, "LEFT", -6, 0)
    disableAll:SetScript("OnClick", function()
        local boss = GetSelectedRaidBoss()
        if not boss then return end
        for _, spell in ipairs(boss.spells or {}) do
            CT:SetRaidAbilityEnabled(boss.encounterID, spell.id, false)
        end
        CT:RefreshRaidPage()
    end)

    local enableAll = CreateButton(right, "Enable All", 82, 20)
    enableAll:SetPoint("RIGHT", disableAll, "LEFT", -6, 0)
    enableAll:SetScript("OnClick", function()
        local boss = GetSelectedRaidBoss()
        if not boss then return end
        for _, spell in ipairs(boss.spells or {}) do
            CT:SetRaidAbilityEnabled(boss.encounterID, spell.id, true)
        end
        CT:RefreshRaidPage()
    end)

    local applyRecommendations = CreateButton(right, "Apply Recs", 94, 20)
    applyRecommendations:SetPoint("RIGHT", enableAll, "LEFT", -6, 0)
    applyRecommendations:SetScript("OnClick", function()
        local boss = GetSelectedRaidBoss()
        if not boss then return end
        for _, spell in ipairs(boss.spells or {}) do
            local cfg = CT:GetRaidAbilityEffectiveConfig(boss.encounterID, spell.id)
            if cfg then
                CT:SetRaidAbilityEnabled(boss.encounterID, spell.id, cfg.recommended == true)
            end
        end
        CT:RefreshRaidPage()
    end)
    applyRecommendations:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Apply Recommendations", 1, 0.25, 0.25)
        GameTooltip:AddLine("Turns each ability for this raid boss on or off to match ChayAlert HUD's current recommendation for your active role. Labels, sounds, priorities, lead times, and role overrides you customized are left untouched.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    applyRecommendations:SetScript("OnLeave", GameTooltip_Hide)

    local abilitiesLabel = CreateLabel(right, "Abilities", "GameFontNormal")
    abilitiesLabel:SetPoint("TOPLEFT", 12, NextRightRow(16, 4))
    abilitiesLabel:SetTextColor(0.45, 0.95, 1.0, 1)

    local cardScrollY = NextRightRow(140, 10)
    local cardScroll = CreateFrame("ScrollFrame", nil, right, "UIPanelScrollFrameTemplate")
    cardScroll:SetPoint("TOPLEFT", 12, cardScrollY)
    cardScroll:SetPoint("TOPRIGHT", -29, cardScrollY)
    cardScroll:SetHeight(140)
    RaidUI.cardScroll = cardScroll
    RaidUI.cardChild = CreateFrame("Frame", nil, cardScroll)
    RaidUI.cardChild:SetSize(430, 1)
    RaidUI.cardChild:ClearAllPoints()
    RaidUI.cardChild:SetPoint("TOPLEFT", cardScroll, "TOPLEFT", 0, 0)
    cardScroll:SetScrollChild(RaidUI.cardChild)
    AU.EnhanceScrollFrame(cardScroll)

    RaidUI.detail = AU.CreateDetailPanel(right)
    RaidUI.detail:SetPoint("TOPLEFT", 12, rightY)
    RaidUI.detail:SetPoint("BOTTOMRIGHT", -12, 10)

    CT:RefreshRaidPage()
end
