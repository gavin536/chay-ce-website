-- ChayAlert HUD recommendation layer.
-- Recommendations are derived data. They never mutate per-ability user overrides
-- until the caller explicitly applies them.

local CT = _G.ChayAlertHUD
if type(CT) ~= "table" then return end

local Engine = {}
CT.RecommendationEngine = Engine
_G.ChayAlertHUDRecommendationEngine = Engine

local VALID_MODES = {
    CIRCLE = true,
    TIMELINE = true,
    BOTH = true,
    HIDDEN = true,
    REVIEW = true,
}

local function NormalizeRoles(value)
    if value == "ALL" or type(value) ~= "string" or value == "" then
        return { "TANK", "HEALER", "DAMAGER" }, "ALL"
    end

    local roles = {}
    for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
        if ("_" .. value .. "_"):find("_" .. role .. "_", 1, true) then
            roles[#roles + 1] = role
        end
    end
    return roles, #roles > 0 and table.concat(roles, "_") or "ALL"
end

local function ObservedSummary(context)
    local observation = type(context) == "table" and context.observation or nil
    if type(observation) ~= "table" then return "No clean observations yet." end

    local casts = tonumber(observation.castCount) or tonumber(observation.samples) or 0
    local cadence = tonumber(observation.cadence)
    if casts <= 0 then return "No clean observations yet." end
    if cadence and cadence > 0 then
        return string.format("%d casts observed, about %.1f sec cadence.", casts, cadence)
    end
    return string.format("%d casts observed.", casts)
end

function Engine:Recommend(context)
    context = type(context) == "table" and context or {}
    local explicit = type(context.recommendation) == "table" and context.recommendation or nil
    local roles, roleString = NormalizeRoles(context.roles)
    local reasons = {}
    local mode, confidence

    if explicit and VALID_MODES[explicit.mode] then
        mode = explicit.mode
        confidence = explicit.confidence or "HIGH"
        if type(explicit.reason) == "string" and explicit.reason ~= "" then
            reasons[#reasons + 1] = explicit.reason
        end
    elseif context.hidden == true then
        mode, confidence = "HIDDEN", "HIGH"
        reasons[#reasons + 1] = context.reason or "Curated clutter or irrelevant mechanic."
    elseif context.important == true then
        mode = context.defaultMode or "CIRCLE"
        confidence = context.blizzardImportant == true and "HIGH" or "MEDIUM"
        reasons[#reasons + 1] = context.reason or "Curated role-relevant mechanic."
        if context.blizzardImportant == true then
            reasons[#reasons + 1] = "Public Blizzard importance signal."
        end
    else
        -- Unknown is intentionally reviewable rather than silently hidden.
        mode, confidence = "REVIEW", "LOW"
        reasons[#reasons + 1] = context.reason or "Insufficient evidence for an automatic alert."
    end

    if not VALID_MODES[mode] then mode = "REVIEW" end
    return {
        mode = mode,
        confidence = confidence or "LOW",
        roles = roles,
        roleString = roleString,
        reasons = reasons,
        roleRelevant = type(CT.IsRoleRelevant) == "function" and CT:IsRoleRelevant(roleString) or true,
        observed = ObservedSummary(context),
    }
end

function Engine:IsVisibleForProfile(recommendation)
    if type(recommendation) ~= "table" or recommendation.mode == "HIDDEN" then return false end
    if type(CT.GetRoleProfile) == "function" and CT:GetRoleProfile() == "ALL" then return true end
    return recommendation.roleRelevant == true
end

return Engine
