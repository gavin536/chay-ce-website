-- ChayAlert HUD Season 2 dungeon boss catalog.
-- Static encounter and spell identifiers used by the ability manager.
-- Runtime detection remains driven by Blizzard encounter events.
local data = { order = {}, dungeons = {}, byEncounterID = {} }

data.order[#data.order + 1] = "altar_of_fangs"
data.dungeons["altar_of_fangs"] = { name = "Altar of Fangs", bosses = {} }
local b_3456 = { encounterID = 3456, key = "rav_i", name = "Rav'i", spells = {} }
table.insert(b_3456.spells, { id = 1296050 })
table.insert(b_3456.spells, { id = 1296216 })
table.insert(b_3456.spells, { id = 1296220 })
table.insert(b_3456.spells, { id = 1307703 })
table.insert(b_3456.spells, { id = 1307894 })
b_3456.spellByID = {}
for _, spell in ipairs(b_3456.spells) do b_3456.spellByID[spell.id] = spell end
table.insert(data.dungeons["altar_of_fangs"].bosses, b_3456)
data.byEncounterID[3456] = { dungeonKey = "altar_of_fangs", dungeon = data.dungeons["altar_of_fangs"], boss = b_3456 }
local b_3457 = { encounterID = 3457, key = "the_writhing_coil", name = "The Writhing Coil", spells = {} }
table.insert(b_3457.spells, { id = 1298949 })
table.insert(b_3457.spells, { id = 1299053 })
table.insert(b_3457.spells, { id = 1299130 })
table.insert(b_3457.spells, { id = 1299154 })
table.insert(b_3457.spells, { id = 1299940 })
table.insert(b_3457.spells, { id = 1300044 })
table.insert(b_3457.spells, { id = 1300686 })
table.insert(b_3457.spells, { id = 1310357 })
table.insert(b_3457.spells, { id = 1310358 })
table.insert(b_3457.spells, { id = 1310547 })
b_3457.spellByID = {}
for _, spell in ipairs(b_3457.spells) do b_3457.spellByID[spell.id] = spell end
table.insert(data.dungeons["altar_of_fangs"].bosses, b_3457)
data.byEncounterID[3457] = { dungeonKey = "altar_of_fangs", dungeon = data.dungeons["altar_of_fangs"], boss = b_3457 }
local b_3458 = { encounterID = 3458, key = "zul_jan", name = "Zul'jan", spells = {} }
table.insert(b_3458.spells, { id = 1300876 })
table.insert(b_3458.spells, { id = 1301111 })
table.insert(b_3458.spells, { id = 1301350 })
table.insert(b_3458.spells, { id = 1301413 })
b_3458.spellByID = {}
for _, spell in ipairs(b_3458.spells) do b_3458.spellByID[spell.id] = spell end
table.insert(data.dungeons["altar_of_fangs"].bosses, b_3458)
data.byEncounterID[3458] = { dungeonKey = "altar_of_fangs", dungeon = data.dungeons["altar_of_fangs"], boss = b_3458 }

data.order[#data.order + 1] = "murder_row"
data.dungeons["murder_row"] = { name = "Murder Row", bosses = {} }
local b_3101 = { encounterID = 3101, key = "kystia_manaheart", name = "Kystia Manaheart", spells = {} }
table.insert(b_3101.spells, { id = 474240 })
table.insert(b_3101.spells, { id = 1230304 })
table.insert(b_3101.spells, { id = 1253811 })
table.insert(b_3101.spells, { id = 1264095 })
b_3101.spellByID = {}
for _, spell in ipairs(b_3101.spells) do b_3101.spellByID[spell.id] = spell end
table.insert(data.dungeons["murder_row"].bosses, b_3101)
data.byEncounterID[3101] = { dungeonKey = "murder_row", dungeon = data.dungeons["murder_row"], boss = b_3101 }
local b_3102 = { encounterID = 3102, key = "zaen_bladesorrow", name = "Zaen Bladesorrow", spells = {} }
table.insert(b_3102.spells, { id = 474478 })
table.insert(b_3102.spells, { id = 474765 })
table.insert(b_3102.spells, { id = 1214357 })
table.insert(b_3102.spells, { id = 1218347 })
table.insert(b_3102.spells, { id = 1222795 })
b_3102.spellByID = {}
for _, spell in ipairs(b_3102.spells) do b_3102.spellByID[spell.id] = spell end
table.insert(data.dungeons["murder_row"].bosses, b_3102)
data.byEncounterID[3102] = { dungeonKey = "murder_row", dungeon = data.dungeons["murder_row"], boss = b_3102 }
local b_3103 = { encounterID = 3103, key = "xathuux_the_annihilator", name = "Xathuux the Annihilator", spells = {} }
table.insert(b_3103.spells, { id = 473898 })
table.insert(b_3103.spells, { id = 474197 })
table.insert(b_3103.spells, { id = 1214637 })
table.insert(b_3103.spells, { id = 1295453 })
b_3103.spellByID = {}
for _, spell in ipairs(b_3103.spells) do b_3103.spellByID[spell.id] = spell end
table.insert(data.dungeons["murder_row"].bosses, b_3103)
data.byEncounterID[3103] = { dungeonKey = "murder_row", dungeon = data.dungeons["murder_row"], boss = b_3103 }
local b_3105 = { encounterID = 3105, key = "lithiel_cinderfury", name = "Lithiel Cinderfury", spells = {} }
table.insert(b_3105.spells, { id = 474408 })
table.insert(b_3105.spells, { id = 1218203 })
table.insert(b_3105.spells, { id = 1224478 })
b_3105.spellByID = {}
for _, spell in ipairs(b_3105.spells) do b_3105.spellByID[spell.id] = spell end
table.insert(data.dungeons["murder_row"].bosses, b_3105)
data.byEncounterID[3105] = { dungeonKey = "murder_row", dungeon = data.dungeons["murder_row"], boss = b_3105 }

data.order[#data.order + 1] = "den_of_nalorakk"
data.dungeons["den_of_nalorakk"] = { name = "Den of Nalorakk", bosses = {} }
local b_3207 = { encounterID = 3207, key = "the_hoardmonger", name = "The Hoardmonger", spells = {} }
table.insert(b_3207.spells, { id = 1234233 })
table.insert(b_3207.spells, { id = 1235118 })
table.insert(b_3207.spells, { id = 1253268 })
b_3207.spellByID = {}
for _, spell in ipairs(b_3207.spells) do b_3207.spellByID[spell.id] = spell end
table.insert(data.dungeons["den_of_nalorakk"].bosses, b_3207)
data.byEncounterID[3207] = { dungeonKey = "den_of_nalorakk", dungeon = data.dungeons["den_of_nalorakk"], boss = b_3207 }
local b_3208 = { encounterID = 3208, key = "sentinel_of_winter", name = "Sentinel of Winter", spells = {} }
table.insert(b_3208.spells, { id = 1235548 })
table.insert(b_3208.spells, { id = 1235623 })
table.insert(b_3208.spells, { id = 1235656 })
table.insert(b_3208.spells, { id = 1235783 })
b_3208.spellByID = {}
for _, spell in ipairs(b_3208.spells) do b_3208.spellByID[spell.id] = spell end
table.insert(data.dungeons["den_of_nalorakk"].bosses, b_3208)
data.byEncounterID[3208] = { dungeonKey = "den_of_nalorakk", dungeon = data.dungeons["den_of_nalorakk"], boss = b_3208 }
local b_3209 = { encounterID = 3209, key = "nalorakk", name = "Nalorakk", spells = {} }
table.insert(b_3209.spells, { id = 1242860 })
table.insert(b_3209.spells, { id = 1243011 })
table.insert(b_3209.spells, { id = 1243569 })
b_3209.spellByID = {}
for _, spell in ipairs(b_3209.spells) do b_3209.spellByID[spell.id] = spell end
table.insert(data.dungeons["den_of_nalorakk"].bosses, b_3209)
data.byEncounterID[3209] = { dungeonKey = "den_of_nalorakk", dungeon = data.dungeons["den_of_nalorakk"], boss = b_3209 }

data.order[#data.order + 1] = "the_blinding_vale"
data.dungeons["the_blinding_vale"] = { name = "The Blinding Vale", bosses = {} }
local b_3199 = { encounterID = 3199, key = "lightblossom_trinity", name = "Lightblossom Trinity", spells = {} }
table.insert(b_3199.spells, { id = 1234753 })
table.insert(b_3199.spells, { id = 1234850 })
table.insert(b_3199.spells, { id = 1235564 })
table.insert(b_3199.spells, { id = 1235640 })
b_3199.spellByID = {}
for _, spell in ipairs(b_3199.spells) do b_3199.spellByID[spell.id] = spell end
table.insert(data.dungeons["the_blinding_vale"].bosses, b_3199)
data.byEncounterID[3199] = { dungeonKey = "the_blinding_vale", dungeon = data.dungeons["the_blinding_vale"], boss = b_3199 }
local b_3200 = { encounterID = 3200, key = "ikuzz_the_light_hunter", name = "Ikuzz the Light Hunter", spells = {} }
table.insert(b_3200.spells, { id = 1236709 })
table.insert(b_3200.spells, { id = 1236746 })
table.insert(b_3200.spells, { id = 1237090 })
b_3200.spellByID = {}
for _, spell in ipairs(b_3200.spells) do b_3200.spellByID[spell.id] = spell end
table.insert(data.dungeons["the_blinding_vale"].bosses, b_3200)
data.byEncounterID[3200] = { dungeonKey = "the_blinding_vale", dungeon = data.dungeons["the_blinding_vale"], boss = b_3200 }
local b_3201 = { encounterID = 3201, key = "lightwarden_ruia", name = "Lightwarden Ruia", spells = {} }
table.insert(b_3201.spells, { id = 1239824 })
table.insert(b_3201.spells, { id = 1239882 })
table.insert(b_3201.spells, { id = 1239883 })
table.insert(b_3201.spells, { id = 1239885 })
table.insert(b_3201.spells, { id = 1240098 })
table.insert(b_3201.spells, { id = 1240210 })
table.insert(b_3201.spells, { id = 1241058 })
b_3201.spellByID = {}
for _, spell in ipairs(b_3201.spells) do b_3201.spellByID[spell.id] = spell end
table.insert(data.dungeons["the_blinding_vale"].bosses, b_3201)
data.byEncounterID[3201] = { dungeonKey = "the_blinding_vale", dungeon = data.dungeons["the_blinding_vale"], boss = b_3201 }
local b_3202 = { encounterID = 3202, key = "ziekett", name = "Ziekket", spells = {} }
table.insert(b_3202.spells, { id = 1246372 })
table.insert(b_3202.spells, { id = 1246607 })
table.insert(b_3202.spells, { id = 1246858 })
table.insert(b_3202.spells, { id = 1247685 })
b_3202.spellByID = {}
for _, spell in ipairs(b_3202.spells) do b_3202.spellByID[spell.id] = spell end
table.insert(data.dungeons["the_blinding_vale"].bosses, b_3202)
data.byEncounterID[3202] = { dungeonKey = "the_blinding_vale", dungeon = data.dungeons["the_blinding_vale"], boss = b_3202 }

data.order[#data.order + 1] = "voidscar_arena"
data.dungeons["voidscar_arena"] = { name = "Voidscar Arena", bosses = {} }
local b_3285 = { encounterID = 3285, key = "taz_rah", name = "Taz'Rah", spells = {} }
table.insert(b_3285.spells, { id = 1222098 })
table.insert(b_3285.spells, { id = 1296963 })
table.insert(b_3285.spells, { id = 1297017 })
table.insert(b_3285.spells, { id = 1300259 })
b_3285.spellByID = {}
for _, spell in ipairs(b_3285.spells) do b_3285.spellByID[spell.id] = spell end
table.insert(data.dungeons["voidscar_arena"].bosses, b_3285)
data.byEncounterID[3285] = { dungeonKey = "voidscar_arena", dungeon = data.dungeons["voidscar_arena"], boss = b_3285 }
local b_3286 = { encounterID = 3286, key = "atroxus", name = "Atroxus", spells = {} }
table.insert(b_3286.spells, { id = 1222371 })
table.insert(b_3286.spells, { id = 1222642 })
table.insert(b_3286.spells, { id = 1222721 })
table.insert(b_3286.spells, { id = 1226120 })
table.insert(b_3286.spells, { id = 1262497 })
b_3286.spellByID = {}
for _, spell in ipairs(b_3286.spells) do b_3286.spellByID[spell.id] = spell end
table.insert(data.dungeons["voidscar_arena"].bosses, b_3286)
data.byEncounterID[3286] = { dungeonKey = "voidscar_arena", dungeon = data.dungeons["voidscar_arena"], boss = b_3286 }
local b_3287 = { encounterID = 3287, key = "charonus", name = "Charonus", spells = {} }
table.insert(b_3287.spells, { id = 1222755 })
table.insert(b_3287.spells, { id = 1227264 })
table.insert(b_3287.spells, { id = 1263982 })
table.insert(b_3287.spells, { id = 1282770 })
table.insert(b_3287.spells, { id = 1311923 })
b_3287.spellByID = {}
for _, spell in ipairs(b_3287.spells) do b_3287.spellByID[spell.id] = spell end
table.insert(data.dungeons["voidscar_arena"].bosses, b_3287)
data.byEncounterID[3287] = { dungeonKey = "voidscar_arena", dungeon = data.dungeons["voidscar_arena"], boss = b_3287 }

data.order[#data.order + 1] = "kings_rest"
data.dungeons["kings_rest"] = { name = "Kings' Rest", bosses = {} }
local b_2139 = { encounterID = 2139, key = "the_golden_serpent", name = "The Golden Serpent", spells = {} }
table.insert(b_2139.spells, { id = 265773 })
table.insert(b_2139.spells, { id = 265910 })
table.insert(b_2139.spells, { id = 265781 })
table.insert(b_2139.spells, { id = 265923 })
b_2139.spellByID = {}
for _, spell in ipairs(b_2139.spells) do b_2139.spellByID[spell.id] = spell end
table.insert(data.dungeons["kings_rest"].bosses, b_2139)
data.byEncounterID[2139] = { dungeonKey = "kings_rest", dungeon = data.dungeons["kings_rest"], boss = b_2139 }
local b_2140 = { encounterID = 2140, key = "the_council_of_tribes", name = "The Council of Tribes", spells = {} }
table.insert(b_2140.spells, { id = 266206 })
table.insert(b_2140.spells, { id = 266231 })
table.insert(b_2140.spells, { id = 267494 })
table.insert(b_2140.spells, { id = 266237 })
table.insert(b_2140.spells, { id = 1305810 })
table.insert(b_2140.spells, { id = 267273 })
table.insert(b_2140.spells, { id = 267060 })
b_2140.spellByID = {}
for _, spell in ipairs(b_2140.spells) do b_2140.spellByID[spell.id] = spell end
table.insert(data.dungeons["kings_rest"].bosses, b_2140)
data.byEncounterID[2140] = { dungeonKey = "kings_rest", dungeon = data.dungeons["kings_rest"], boss = b_2140 }
local b_2142 = { encounterID = 2142, key = "mchimba_the_embalmer", name = "Mchimba the Embalmer", spells = {} }
table.insert(b_2142.spells, { id = 267618 })
table.insert(b_2142.spells, { id = 1311956 })
table.insert(b_2142.spells, { id = 1312146 })
table.insert(b_2142.spells, { id = 267702 })
b_2142.spellByID = {}
for _, spell in ipairs(b_2142.spells) do b_2142.spellByID[spell.id] = spell end
table.insert(data.dungeons["kings_rest"].bosses, b_2142)
data.byEncounterID[2142] = { dungeonKey = "kings_rest", dungeon = data.dungeons["kings_rest"], boss = b_2142 }
local b_2143 = { encounterID = 2143, key = "king_dazar", name = "Dazar, The First King", spells = {} }
table.insert(b_2143.spells, { id = 269230 })
table.insert(b_2143.spells, { id = 269369 })
table.insert(b_2143.spells, { id = 1303115 })
table.insert(b_2143.spells, { id = 268586 })
table.insert(b_2143.spells, { id = 1303267 })
table.insert(b_2143.spells, { id = 1303327 })
table.insert(b_2143.spells, { id = 1303488 })
b_2143.spellByID = {}
for _, spell in ipairs(b_2143.spells) do b_2143.spellByID[spell.id] = spell end
table.insert(data.dungeons["kings_rest"].bosses, b_2143)
data.byEncounterID[2143] = { dungeonKey = "kings_rest", dungeon = data.dungeons["kings_rest"], boss = b_2143 }

data.order[#data.order + 1] = "temple_of_sethraliss"
data.dungeons["temple_of_sethraliss"] = { name = "Temple of Sethraliss", bosses = {} }
local b_2124 = { encounterID = 2124, key = "adderis_and_aspix", name = "Adderis and Aspix", spells = {} }
table.insert(b_2124.spells, { id = 1310311 })
table.insert(b_2124.spells, { id = 1289059 })
table.insert(b_2124.spells, { id = 1311805 })
table.insert(b_2124.spells, { id = 1288049 })
table.insert(b_2124.spells, { id = 1311804 })
b_2124.spellByID = {}
for _, spell in ipairs(b_2124.spells) do b_2124.spellByID[spell.id] = spell end
table.insert(data.dungeons["temple_of_sethraliss"].bosses, b_2124)
data.byEncounterID[2124] = { dungeonKey = "temple_of_sethraliss", dungeon = data.dungeons["temple_of_sethraliss"], boss = b_2124 }
local b_2125 = { encounterID = 2125, key = "merektha", name = "Merektha", spells = {} }
table.insert(b_2125.spells, { id = 1290797 })
table.insert(b_2125.spells, { id = 1290029 })
table.insert(b_2125.spells, { id = 1289109 })
table.insert(b_2125.spells, { id = 1293048 })
table.insert(b_2125.spells, { id = 1289205 })
table.insert(b_2125.spells, { id = 264172 })
b_2125.spellByID = {}
for _, spell in ipairs(b_2125.spells) do b_2125.spellByID[spell.id] = spell end
table.insert(data.dungeons["temple_of_sethraliss"].bosses, b_2125)
data.byEncounterID[2125] = { dungeonKey = "temple_of_sethraliss", dungeon = data.dungeons["temple_of_sethraliss"], boss = b_2125 }
local b_2126 = { encounterID = 2126, key = "galvazzt", name = "Galvazzt", spells = {} }
table.insert(b_2126.spells, { id = 1291618 })
table.insert(b_2126.spells, { id = 1309525 })
b_2126.spellByID = {}
for _, spell in ipairs(b_2126.spells) do b_2126.spellByID[spell.id] = spell end
table.insert(data.dungeons["temple_of_sethraliss"].bosses, b_2126)
data.byEncounterID[2126] = { dungeonKey = "temple_of_sethraliss", dungeon = data.dungeons["temple_of_sethraliss"], boss = b_2126 }
local b_2127 = { encounterID = 2127, key = "avatar_of_sethraliss", name = "Avatar of Sethraliss", spells = {} }
table.insert(b_2127.spells, { id = 1301202 })
table.insert(b_2127.spells, { id = 1273408 })
b_2127.spellByID = {}
for _, spell in ipairs(b_2127.spells) do b_2127.spellByID[spell.id] = spell end
table.insert(data.dungeons["temple_of_sethraliss"].bosses, b_2127)
data.byEncounterID[2127] = { dungeonKey = "temple_of_sethraliss", dungeon = data.dungeons["temple_of_sethraliss"], boss = b_2127 }

data.order[#data.order + 1] = "ruby_life_pools"
data.dungeons["ruby_life_pools"] = { name = "Ruby Life Pools", bosses = {} }
local b_2606 = { encounterID = 2606, key = "kokia_blazehoof", name = "Kokia Blazehoof", spells = {} }
table.insert(b_2606.spells, { id = 372864 })
table.insert(b_2606.spells, { id = 372110 })
table.insert(b_2606.spells, { id = 372858 })
b_2606.spellByID = {}
for _, spell in ipairs(b_2606.spells) do b_2606.spellByID[spell.id] = spell end
table.insert(data.dungeons["ruby_life_pools"].bosses, b_2606)
data.byEncounterID[2606] = { dungeonKey = "ruby_life_pools", dungeon = data.dungeons["ruby_life_pools"], boss = b_2606 }
local b_2609 = { encounterID = 2609, key = "melidrussa_chillworn", name = "Melidrussa Chillworn", spells = {} }
table.insert(b_2609.spells, { id = 1307297 })
table.insert(b_2609.spells, { id = 1307308 })
table.insert(b_2609.spells, { id = 373046 })
table.insert(b_2609.spells, { id = 373686 })
b_2609.spellByID = {}
for _, spell in ipairs(b_2609.spells) do b_2609.spellByID[spell.id] = spell end
table.insert(data.dungeons["ruby_life_pools"].bosses, b_2609)
data.byEncounterID[2609] = { dungeonKey = "ruby_life_pools", dungeon = data.dungeons["ruby_life_pools"], boss = b_2609 }
local b_2623 = { encounterID = 2623, key = "kyrakka_and_erkhart_stormvein", name = "Kyrakka and Erkhart Stormvein", spells = {} }
table.insert(b_2623.spells, { id = 381525 })
table.insert(b_2623.spells, { id = 381862 })
table.insert(b_2623.spells, { id = 381512 })
table.insert(b_2623.spells, { id = 381517 })
table.insert(b_2623.spells, { id = 381516 })
b_2623.spellByID = {}
for _, spell in ipairs(b_2623.spells) do b_2623.spellByID[spell.id] = spell end
table.insert(data.dungeons["ruby_life_pools"].bosses, b_2623)
data.byEncounterID[2623] = { dungeonKey = "ruby_life_pools", dungeon = data.dungeons["ruby_life_pools"], boss = b_2623 }

_G.ChayAlertHUDDungeonBossData = data
return data
