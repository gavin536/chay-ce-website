local CT = _G.ChayAlertHUD
if not CT then return end

-- ChayAlert HUD mechanic adapter/router.
-- This module intentionally does not detect mechanics. It consumes the existing
-- detector output, separates safe routing fields from display-only protected
-- values, and fans the same mechanic object out to independent renderers.

local Router = {}
CT.MechanicRouter = Router
_G.ChayAlertHUDMechanicRouter = Router

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value) or false
end

local function SafePublicNumber(value)
    if IsSecret(value) then return nil end
    return tonumber(value)
end

local function SafePublicString(value)
    if IsSecret(value) then return nil end
    return type(value) == "string" and value or nil
end

local function ResolveSpellIcon(spellID)
    spellID = SafePublicNumber(spellID)
    if not spellID or not C_Spell or type(C_Spell.GetSpellTexture) ~= "function" then return nil, false end
    local ok, texture = pcall(C_Spell.GetSpellTexture, spellID)
    if not ok then return nil, false end
    if IsSecret(texture) then
        -- Secret numeric file IDs are allowed to flow directly into SetTexture.
        return texture, true
    end
    return texture, texture ~= nil
end

local function ModeAllows(mode, target)
    mode = type(mode) == "string" and mode:upper() or "BOTH"
    if mode == "NONE" then return false end
    if mode == "BOTH" then return true end
    return mode == target
end

local function NormalizeCandidate(candidate)
    if type(candidate) ~= "table" then return nil end

    local displayMode = type(candidate.displayMode) == "string" and candidate.displayMode:upper() or nil
    if type(CT.ResolveDisplayMode) == "function" then
        displayMode = CT:ResolveDisplayMode(displayMode)
    end
    displayMode = displayMode or "BOTH"

    local mechanicType = type(candidate.mechanicType) == "string" and candidate.mechanicType:upper() or "OTHER"
    if type(CT.NormalizeMechanicType) == "function" then
        mechanicType = CT:NormalizeMechanicType(mechanicType)
    end

    local icon, iconPresent = candidate.icon, candidate.iconPresent == true
    if not iconPresent then
        icon, iconPresent = ResolveSpellIcon(candidate.spellID)
    end

    local namePresent
    if IsSecret(candidate.name) then
        namePresent = true
    else
        namePresent = candidate.namePresent ~= false and candidate.name ~= nil
    end

    -- displayName/icon may be secret. They are render-only: never compare,
    -- format, concatenate, sort, or use them as keys in this module.
    return {
        mechanicKey = SafePublicString(candidate.id) or SafePublicNumber(candidate.id) or "anonymous",
        spellID = SafePublicNumber(candidate.spellID),
        catalogSpellID = SafePublicNumber(candidate.catalogSpellID),
        catalogSpellName = candidate.catalogSpellName,
        spellName = candidate.spellName,
        displayName = candidate.name,
        displayNamePresent = namePresent,
        icon = icon,
        iconPresent = iconPresent,

        mechanicType = mechanicType,
        sourceType = SafePublicString(candidate.sourceType) or "OTHER",
        confidence = SafePublicString(candidate.confidence) or "UNKNOWN",

        startTime = SafePublicNumber(candidate.startedAt),
        duration = SafePublicNumber(candidate.duration),
        remaining = SafePublicNumber(candidate.remaining),
        durationObject = candidate.protectedTiming and candidate.durationObject or nil,
        durationRevision = SafePublicNumber(candidate.durationRevision) or 0,

        priority = SafePublicNumber(candidate.priority) or 1,
        ttsEnabled = candidate.ttsEnabled == true,
        ttsText = candidate.ttsText,
        ttsCustomText = candidate.ttsCustomText,
        actionLabel = candidate.actionLabel,
        displayMode = displayMode,
        circleLeadTime = SafePublicNumber(candidate.circleLeadTime),
        isActiveCast = candidate.isActiveCast == true,
        isFutureEvent = candidate.isFutureEvent == true,
        protectedTiming = candidate.protectedTiming == true,
        castBarID = SafePublicNumber(candidate.castBarID),

        -- Keep renderer-specific sound state on the circle path only. Timeline
        -- rendering never inspects it.
        soundEnabled = candidate.soundEnabled,
        soundState = candidate.soundState,
        rawCandidate = candidate,
    }
end

function Router:Route(candidates)
    local circles, timeline, normalized = {}, {}, {}
    if type(candidates) ~= "table" then return circles, timeline, normalized end

    for i = 1, #candidates do
        local mechanic = NormalizeCandidate(candidates[i])
        if mechanic then
            normalized[#normalized + 1] = mechanic
            local circleReady = true
            if mechanic.isFutureEvent and mechanic.remaining ~= nil and mechanic.circleLeadTime ~= nil then
                circleReady = mechanic.remaining <= mechanic.circleLeadTime
            end
            if ModeAllows(mechanic.displayMode, "CIRCLE") and circleReady then
                circles[#circles + 1] = candidates[i]
            end
            if ModeAllows(mechanic.displayMode, "TIMELINE") then
                timeline[#timeline + 1] = mechanic
            end
        end
    end

    return circles, timeline, normalized
end

function Router:Publish(candidates)
    local circles, timeline, normalized = self:Route(candidates)
    self.lastNormalized = normalized

    local hud = CT.TimelineHUD
    if type(hud) == "table" and type(hud.Render) == "function" then
        -- The Timeline HUD is a presentation consumer only. A renderer error
        -- must never abort Publish() and prevent already-routed circle
        -- candidates from reaching the working Circle HUD.
        pcall(hud.Render, hud, timeline)
    end

    return circles, timeline, normalized
end
