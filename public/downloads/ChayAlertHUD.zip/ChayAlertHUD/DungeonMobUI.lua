local CT = _G.ChayAlertHUD
local Data = _G.ChayAlertHUDDungeonData
local AU = _G.ChayAlertHUDAbilityUI
if not CT or not Data or not AU then return end

local PRIORITY_LABELS = AU.PRIORITY_LABELS
local PRIORITY_COLORS = AU.PRIORITY_COLORS

local UI = {
    built = false,
    parent = nil,
    selectedDungeonKey = nil,
    selectedNPCID = nil,
    selectedAbilityKey = nil,
    filter = "RECOMMENDED",
    filterButtons = {},
    dungeonButtons = {},
    topButtons = {},
    mobRows = {},
    abilityCards = {},
}

local function MakeBackdrop(frame, alpha)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.015, 0.008, 0.012, alpha or 0.82)
    frame:SetBackdropBorderColor(0.42, 0.04, 0.055, 0.95)
end

local function CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width or 100, height or 22)
    button:SetText(text or "")
    if type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, false)
    end
    return button
end

local function CreateLabel(parent, text, template)
    local label = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    label:SetText(text or "")
    return label
end

-- Bounds a label to one line and truncates overflow instead of letting text
-- draw past its anchors or into a neighboring control.
local function TruncateSingleLine(fontString)
    fontString:SetWordWrap(true)
    if fontString.SetMaxLines then fontString:SetMaxLines(1) end
end

local function ColorSelectedButton(button, selected)
    if not button then return end
    button:SetEnabled(true)
    if type(CT.ApplyClassTabStyle) == "function" then
        CT:ApplyClassTabStyle(button, selected == true)
    elseif type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, selected == true)
    end
end

local function StyleStaticTab(button, selected)
    if not button then return end
    if type(CT.ApplyClassTabStyle) == "function" then
        CT:ApplyClassTabStyle(button, selected == true)
    elseif type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, selected == true)
    end
end

local function GetDungeon()
    return Data.dungeons[UI.selectedDungeonKey]
end

local function GetSelectedMob()
    local dungeon = GetDungeon()
    return dungeon and dungeon.mobByID and dungeon.mobByID[UI.selectedNPCID] or nil
end

local function GetSearchText()
    if not UI.search then return "" end
    return string.lower((UI.search:GetText() or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function MobMatchesFilter(mob, filter)
    if not mob then return false end
    if filter == "" then return true end
    if string.find(string.lower(mob.name or ""), filter, 1, true) then return true end
    if string.find(tostring(mob.npcID or ""), filter, 1, true) then return true end
    return false
end

local function NormalizeAbilityName(name, spellID)
    if type(name) == "string" and name ~= "" then
        return string.lower(name:gsub("^%s+", ""):gsub("%s+$", ""))
    end
    return "spell:" .. tostring(spellID)
end

local function BuildAbilityGroups(spells)
    local byKey, groups = {}, {}
    for _, spell in ipairs(spells or {}) do
        local info = AU.GetSpellInfo(spell.id)
        local name = info and info.name or ("Spell " .. tostring(spell.id))
        -- Keep each unique spell ID independently configurable. Same-name spells must not share one toggle.
        local key = "spell:" .. tostring(spell.id)
        local group = byKey[key]

        if not group then
            group = {
                key = key,
                name = name,
                iconID = info and info.iconID or "Interface\\Icons\\INV_Misc_QuestionMark",
                spells = {},
            }
            byKey[key] = group
            groups[#groups + 1] = group
        elseif (not group.iconID or group.iconID == "Interface\\Icons\\INV_Misc_QuestionMark") and info and info.iconID then
            group.iconID = info.iconID
        end

        group.spells[#group.spells + 1] = spell
    end
    return groups
end

local function GroupSpellIDs(group)
    local out = {}
    for _, spell in ipairs(group and group.spells or {}) do out[#out + 1] = spell.id end
    return out
end

local function MobGroupConfig(mob, group)
    if not group or not mob or not UI.selectedDungeonKey then return nil end

    local enabled, sound, recommended = false, false, false
    local important, roleRelevant, hasEnabledOverride = false, false, false
    local ttsEnabled, ttsPhrase = false, nil
    local priority = 1
    local label, reason, displayMode, effectiveDisplayMode, mechanicType, mechanicTypeOverride
    local roleFlags = { TANK = false, HEALER = false, DAMAGER = false }
    local rolesAll = false

    for _, spell in ipairs(group.spells or {}) do
        local cfg = CT:GetAbilityEffectiveConfig(UI.selectedDungeonKey, mob.npcID, spell.id)
        if cfg then
            if cfg.enabled ~= false then enabled = true end
            if cfg.sound ~= false then sound = true end
            if cfg.ttsEnabled == true then ttsEnabled = true end
            ttsPhrase = ttsPhrase or cfg.ttsPhrase
            if cfg.recommended == true then recommended = true end
            if cfg.important == true then
                important = true
                if cfg.roleRelevant == true then roleRelevant = true end
                reason = reason or cfg.reason
                if cfg.roles == "ALL" or not cfg.roles or cfg.roles == "" then
                    rolesAll = true
                else
                    for role in pairs(roleFlags) do
                        if ("_" .. cfg.roles .. "_"):find("_" .. role .. "_", 1, true) then
                            roleFlags[role] = true
                        end
                    end
                end
            end
            if cfg.hasEnabledOverride == true then hasEnabledOverride = true end
            priority = math.max(priority, tonumber(cfg.priority) or 1)
            label = label or cfg.label
            reason = reason or cfg.reason
            displayMode = displayMode or cfg.displayMode
            effectiveDisplayMode = effectiveDisplayMode or cfg.effectiveDisplayMode
            mechanicType = mechanicType or cfg.mechanicType
            mechanicTypeOverride = mechanicTypeOverride or cfg.mechanicTypeOverride
        end
    end

    local roles = "ALL"
    if important and not rolesAll then
        local list = {}
        for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
            if roleFlags[role] then list[#list + 1] = role end
        end
        if #list > 0 then roles = table.concat(list, "_") end
    end

    return {
        enabled = enabled,
        sound = sound,
        ttsEnabled = ttsEnabled,
        ttsPhrase = ttsPhrase,
        priority = priority,
        label = label,
        recommended = recommended,
        important = important,
        roleRelevant = roleRelevant,
        roles = roles,
        reason = reason or "Catalog only",
        hasEnabledOverride = hasEnabledOverride,
        displayMode = displayMode or "INHERIT",
        effectiveDisplayMode = effectiveDisplayMode or (CT.GetDisplayMode and CT:GetDisplayMode()) or "BOTH",
        mechanicType = mechanicType or "OTHER",
        mechanicTypeOverride = mechanicTypeOverride,
    }
end

local function GroupEffectiveConfig(group)
    return MobGroupConfig(GetSelectedMob(), group)
end

-- Recommended = currently tracked. Clutter requires positive curated evidence
-- the ability is filler. Everything else stays Needs Review, never auto-hidden.
local function ClassifyGroupConfig(cfg)
    if not cfg then return "REVIEW" end
    if cfg.enabled then return "RECOMMENDED" end
    if cfg.reason == "Chay curated optional mechanic" then return "CLUTTER" end
    return "REVIEW"
end

local function ApplyGroupEnabled(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilityEnabled(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ApplyGroupSound(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilitySound(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ApplyGroupPriority(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilityPriority(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ApplyGroupLabel(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilityLabel(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ApplyGroupDisplayMode(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilityDisplayMode(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ApplyGroupMechanicType(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilityMechanicType(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ApplyGroupRoleOverride(group, value)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:SetAbilityRoleOverride(UI.selectedDungeonKey, mob.npcID, spell.id, value)
    end
end

local function ResetGroup(group)
    local mob = GetSelectedMob()
    if not mob then return end
    for _, spell in ipairs(group and group.spells or {}) do
        CT:ResetAbility(UI.selectedDungeonKey, mob.npcID, spell.id)
    end
end

local function GroupRecommendationText(group, cfg)
    if not cfg then return "" end

    if cfg.important then
        local roles = CT:GetRolesLabel(cfg.roles)
        if cfg.roleRelevant then
            return "Important • " .. roles .. " • " .. (cfg.reason or "important mechanic")
        elseif cfg.hasEnabledOverride and cfg.enabled then
            return "Manual enable • important for " .. roles .. " • " .. (cfg.reason or "important mechanic")
        end
        return "Other role • important for " .. roles .. " • " .. (cfg.reason or "important mechanic")
    end

    if cfg.enabled then
        return "Manual enable • optional catalog ability"
    end
    return "Optional catalog ability • no automatic alert"
end

local function GroupContext(group)
    local mob = GetSelectedMob()
    if not group or not mob then return nil end
    local cfg = GroupEffectiveConfig(group)
    local primary = group.spells and group.spells[1]
    return {
        name = group.name,
        iconID = group.iconID,
        primarySpellID = primary and primary.id,
        spellIDs = GroupSpellIDs(group),
        ownerText = mob.name .. "  •  NPC " .. tostring(mob.npcID) .. "  •  Enemy forces " .. tostring(mob.count or 0),
        metaText = GroupRecommendationText(group, cfg),
        getConfig = function() return GroupEffectiveConfig(group) end,
        setEnabled = function(v) ApplyGroupEnabled(group, v) end,
        setSound = function(v) ApplyGroupSound(group, v) end,
        setTTS = function(v, phrase)
            if primary then CT:SetAbilityTTS(UI.selectedDungeonKey, mob.npcID, primary.id, v, phrase) end
        end,
        setPriority = function(v) ApplyGroupPriority(group, v) end,
        setLabel = function(v) ApplyGroupLabel(group, v) end,
        setDisplayMode = function(v) ApplyGroupDisplayMode(group, v) end,
        setMechanicType = function(v) ApplyGroupMechanicType(group, v) end,
        setRoles = function(v) ApplyGroupRoleOverride(group, v) end,
        reset = function() ResetGroup(group) end,
        onChanged = function() CT:RefreshDungeonMobPage() end,
    }
end

local function FindGroup(groups, key)
    for _, group in ipairs(groups or {}) do if group.key == key then return group end end
    return nil
end

local function EnsureSelectedGroup(visibleGroups)
    if UI.selectedAbilityKey and FindGroup(visibleGroups, UI.selectedAbilityKey) then return end
    UI.selectedAbilityKey = visibleGroups and visibleGroups[1] and visibleGroups[1].key or nil
end

local function AcquireMobRow(index)
    local row = UI.mobRows[index]
    if row then return row end

    row = CreateFrame("Button", nil, UI.mobChild, "BackdropTemplate")
    row:SetSize(270, 48)
    MakeBackdrop(row, 0.52)

    row.leftBar = row:CreateTexture(nil, "ARTWORK")
    row.leftBar:SetWidth(4)
    row.leftBar:SetPoint("TOPLEFT", 0, 0)
    row.leftBar:SetPoint("BOTTOMLEFT", 0, 0)

    row.name = CreateLabel(row, "", "GameFontHighlight")
    row.name:SetPoint("TOPLEFT", 8, -5)
    row.name:SetPoint("RIGHT", -8, 0)
    row.name:SetJustifyH("LEFT")
    TruncateSingleLine(row.name)

    row.meta = CreateLabel(row, "", "GameFontDisableSmall")
    row.meta:SetPoint("BOTTOMLEFT", 8, 4)
    row.meta:SetPoint("RIGHT", -8, 0)
    row.meta:SetJustifyH("LEFT")
    TruncateSingleLine(row.meta)

    UI.mobRows[index] = row
    return row
end

local function AcquireAbilityCard(index)
    local card = UI.abilityCards[index]
    if card then return card end
    card = AU.CreateAbilityCard(UI.cardChild)
    UI.abilityCards[index] = card
    return card
end

local function GetMobRecommendationCounts(mob)
    local recommended, enabled = 0, 0
    local groups = BuildAbilityGroups(mob and mob.spells or {})

    for _, group in ipairs(groups) do
        local cfg = MobGroupConfig(mob, group)
        if cfg and cfg.recommended then recommended = recommended + 1 end
        if cfg and cfg.enabled then enabled = enabled + 1 end
    end

    return recommended, enabled, #groups
end

local function RefreshDungeonButtons()
    for _, key in ipairs(Data.order or {}) do
        ColorSelectedButton(UI.dungeonButtons[key], key == UI.selectedDungeonKey)
    end
end

local function RefreshMobList()
    for _, row in ipairs(UI.mobRows) do row:Hide() end
    local dungeon = GetDungeon()
    if not dungeon then
        UI.mobChild:SetHeight(1)
        return
    end

    local filter = GetSearchText()
    local showOptional = CT:GetShowOptionalAbilities()
    local visible = {}

    for _, mob in ipairs(dungeon.mobs or {}) do
        if MobMatchesFilter(mob, filter) then
            local recommended, enabled, total = GetMobRecommendationCounts(mob)
            if showOptional or filter ~= "" or recommended > 0 or enabled > 0 then
                visible[#visible + 1] = {
                    mob = mob,
                    recommended = recommended,
                    enabled = enabled,
                    total = total,
                }
            end
        end
    end

    table.sort(visible, function(a, b)
        local an = string.lower(a.mob.name or "")
        local bn = string.lower(b.mob.name or "")
        if an == bn then return a.mob.npcID < b.mob.npcID end
        return an < bn
    end)

    local selectedFound = false
    for _, entry in ipairs(visible) do
        if entry.mob.npcID == UI.selectedNPCID then selectedFound = true break end
    end
    if not selectedFound then
        UI.selectedNPCID = visible[1] and visible[1].mob.npcID or nil
        UI.selectedAbilityKey = nil
    end

    for index, entry in ipairs(visible) do
        local row = AcquireMobRow(index)
        row.mob = entry.mob
        row.name:SetText(entry.mob.name)
        local aggregatePriority = AU.GetAggregatePriority(BuildAbilityGroups(entry.mob.spells or {}), function(group)
            return MobGroupConfig(entry.mob, group)
        end)
        local aggregateColor = AU.GetPriorityColor(aggregatePriority)
        row.name:SetTextColor(aggregateColor[1], aggregateColor[2], aggregateColor[3], 1)
        row.leftBar:SetColorTexture(aggregateColor[1], aggregateColor[2], aggregateColor[3], 1)
        row.meta:SetText(string.format(
            "NPC %d • %d important • %d enabled • %d total",
            entry.mob.npcID,
            entry.recommended,
            entry.enabled,
            entry.total
        ))
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 0, -((index - 1) * 51))
        row:SetScript("OnClick", function(self)
            UI.selectedNPCID = self.mob.npcID
            UI.selectedAbilityKey = nil
            CT:RefreshDungeonMobPage()
        end)
        row:SetScript("OnEnter", function(self) self:SetBackdropColor(0.17, 0.025, 0.035, 0.92) end)
        row:SetScript("OnLeave", function(self)
            if self.mob and self.mob.npcID == UI.selectedNPCID then
                self:SetBackdropColor(0.25, 0.025, 0.035, 0.95)
            else
                self:SetBackdropColor(0.015, 0.008, 0.012, 0.52)
            end
        end)
        if entry.mob.npcID == UI.selectedNPCID then
            row:SetBackdropColor(0.25, 0.025, 0.035, 0.95)
        else
            row:SetBackdropColor(0.015, 0.008, 0.012, 0.52)
        end
        row:Show()
    end

    UI.mobChild:SetHeight(math.max(1, #visible * 51))
end

local function RefreshAbilityCards()
    for _, card in ipairs(UI.abilityCards) do card:Hide() end
    local mob = GetSelectedMob()

    if not mob then
        UI.rightTitle:SetText("Select a mob")
        UI.mobMeta:SetText("")
        UI.mobEnabled:Hide()
        UI.resetMob:Hide()
        UI.detail:SetContext(nil)
        UI.cardChild:SetHeight(1)
        return
    end

    UI.mobEnabled:Show()
    UI.resetMob:Show()
    UI.mobEnabled:SetChecked(CT:GetMobEffectiveEnabled(UI.selectedDungeonKey, mob.npcID))

    local allGroups = BuildAbilityGroups(mob.spells or {})
    local visibleGroups = {}
    local showOptional = CT:GetShowOptionalAbilities()
    local recommended = 0

    for _, group in ipairs(allGroups) do
        local cfg = GroupEffectiveConfig(group)
        if cfg and cfg.recommended then recommended = recommended + 1 end
        local matchesFilter = UI.filter == "ALL"
            or (UI.filter == "ENABLED" and cfg and cfg.enabled)
            or (UI.filter == "RECOMMENDED" and cfg and cfg.recommended)
        if matchesFilter or (not UI.filter and (showOptional or (cfg and (cfg.recommended or cfg.enabled)))) then
            visibleGroups[#visibleGroups + 1] = group
        end
    end

    local CLASS_RANK = { RECOMMENDED = 1, REVIEW = 2, CLUTTER = 3 }
    table.sort(visibleGroups, function(a, b)
        local ac = GroupEffectiveConfig(a)
        local bc = GroupEffectiveConfig(b)
        local aRank = CLASS_RANK[ClassifyGroupConfig(ac)] or 2
        local bRank = CLASS_RANK[ClassifyGroupConfig(bc)] or 2
        if aRank ~= bRank then return aRank < bRank end
        local ap = ac and tonumber(ac.priority) or 1
        local bp = bc and tonumber(bc.priority) or 1
        if ap ~= bp then return ap > bp end
        return string.lower(a.name or "") < string.lower(b.name or "")
    end)

    EnsureSelectedGroup(visibleGroups)
    UI.rightTitle:SetText(mob.name)
    UI.mobMeta:SetText(string.format(
        "NPC %d • Enemy forces %d • %d important • %d total abilities",
        mob.npcID,
        mob.count or 0,
        recommended,
        #allGroups
    ))

    local columns = 2
    local gap = 8
    local scrollWidth = (UI.cardScroll and UI.cardScroll:GetWidth()) or 430
    local cardW = math.max(160, math.floor((scrollWidth - gap) / columns) - 1)
    local cardH = 58
    UI.cardChild:SetWidth(math.max(1, scrollWidth))
    for index, group in ipairs(visibleGroups) do
        local cfg = GroupEffectiveConfig(group)
        local card = AcquireAbilityCard(index)
        local col = (index - 1) % columns
        local row = math.floor((index - 1) / columns)
        local primary = group.spells and group.spells[1]
        card:ClearAllPoints()
        card:SetPoint("TOPLEFT", col * (cardW + gap), -(row * (cardH + gap)))
        card:SetSize(cardW, cardH)
        card.group = group
        card:SetAbilityVisual(
            group.name,
            group.iconID,
            cfg and cfg.priority or 1,
            cfg and cfg.enabled or false,
            group.key == UI.selectedAbilityKey,
            primary and primary.id,
            ClassifyGroupConfig(cfg),
            cfg and cfg.mechanicType or "OTHER",
            cfg and (cfg.effectiveDisplayMode == "CIRCLE" or cfg.effectiveDisplayMode == "BOTH"),
            cfg and cfg.ttsEnabled == true
        )
        card:SetScript("OnClick", function(self)
            UI.selectedAbilityKey = self.group and self.group.key or nil
            CT:RefreshDungeonMobPage()
        end)
        card:Show()
    end

    local rows = math.max(1, math.ceil(#visibleGroups / columns))
    UI.cardChild:SetHeight(rows * (cardH + gap))

    UI.detail:SetContext(GroupContext(FindGroup(visibleGroups, UI.selectedAbilityKey)))
end

function CT:RefreshDungeonMobPage()
    if not UI.built then return end
    if not UI.selectedDungeonKey or not Data.dungeons[UI.selectedDungeonKey] then
        UI.selectedDungeonKey = CT:GetCurrentDungeonKey() or Data.order[1]
        UI.selectedNPCID = nil
        UI.selectedAbilityKey = nil
    end

    RefreshDungeonButtons()
    RefreshMobList()
    RefreshAbilityCards()

    local dungeon = GetDungeon()
    UI.dungeonTitle:SetText(dungeon and dungeon.name or "Dungeon")
    UI.showAll:SetText(CT:GetShowOptionalAbilities() and "Important Only" or "Show All")
    StyleStaticTab(UI.topButtons.currentDungeon, false)
    StyleStaticTab(UI.topButtons.showAll, CT:GetShowOptionalAbilities())
    for filter, button in pairs(UI.filterButtons) do
        ColorSelectedButton(button, filter == UI.filter)
    end
    UI.unknown:SetChecked(CT:GetTrackUnknownTrash())
    if UI.roleSelector then UI.roleSelector:Refresh() end
end

function CT:BuildDungeonMobPage(parent)
    if UI.built then
        if parent and UI.parent ~= parent then
            UI.root:SetParent(parent)
            UI.root:ClearAllPoints()
            UI.root:SetAllPoints(parent)
            UI.parent = parent
        end
        return
    end
    if not parent then return end

    UI.built = true
    UI.parent = parent
    UI.selectedDungeonKey = CT:GetCurrentDungeonKey() or Data.order[1]

    local root = CreateFrame("Frame", nil, parent)
    root:SetAllPoints()
    UI.root = root

    local title = CreateLabel(root, "Dungeon Trash", "GameFontNormalLarge")

    local help = CreateLabel(root,
        "Choose a dungeon, then a mob, then configure each ability.",
        "GameFontDisableSmall")
    help:SetWidth(700)
    help:SetJustifyH("LEFT")
    help:SetWordWrap(true)
    if help.SetMaxLines then help:SetMaxLines(2) end

    local legend = AU.CreateSeverityLegend(root)

    -- A simple vertical cursor derives each header row from the row above it
    -- instead of scattered magic Y offsets that can drift out of sync.
    local headerY = 0
    local function NextHeaderRow(height, gap)
        local rowTop = headerY
        headerY = rowTop - height - (gap or 10)
        return rowTop
    end

    title:SetPoint("TOPLEFT", 0, NextHeaderRow(22, 8))
    help:SetPoint("TOPLEFT", 0, NextHeaderRow(32, 8))
    legend:SetPoint("TOPLEFT", 0, NextHeaderRow(16, 8))
    local filterRowY = NextHeaderRow(22, 8)
    local roleRowY = NextHeaderRow(24, 10)
    local top = headerY

    local viewLabel = CreateLabel(root, "View:", "GameFontHighlightSmall")
    viewLabel:SetPoint("TOPLEFT", 0, filterRowY)

    local previousFilterButton
    for _, filter in ipairs({ "RECOMMENDED", "ENABLED", "ALL" }) do
        local button = CreateButton(root, filter:sub(1, 1) .. filter:sub(2):lower(), 92, 22)
        if previousFilterButton then
            button:SetPoint("LEFT", previousFilterButton, "RIGHT", 6, 0)
        else
            button:SetPoint("LEFT", viewLabel, "RIGHT", 8, 0)
        end
        button:SetScript("OnClick", function()
            UI.filter = filter
            CT:RefreshDungeonMobPage()
        end)
        UI.filterButtons[filter] = button
        previousFilterButton = button
    end

    UI.unknown = CreateFrame("CheckButton", nil, root, "UICheckButtonTemplate")
    UI.unknown:SetSize(22, 22)
    UI.unknown:SetPoint("TOPRIGHT", -5, filterRowY)
    local unknownText = CreateLabel(root, "Unknown casts", "GameFontHighlightSmall")
    unknownText:SetPoint("RIGHT", UI.unknown, "LEFT", -4, 0)
    UI.unknown:SetScript("OnClick", function(self)
        CT:SetTrackUnknownTrash(self:GetChecked() == true)
    end)
    UI.unknown:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Unknown trash casts", 1, 0.25, 0.25)
        GameTooltip:AddLine("Off by default. Enable only if you want uncatalogued casts to create circles.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    UI.unknown:SetScript("OnLeave", GameTooltip_Hide)

    UI.showAll = CreateButton(root, "Show All", 84, 22)
    UI.topButtons.showAll = UI.showAll
    StyleStaticTab(UI.showAll, false)
    UI.showAll:SetPoint("RIGHT", unknownText, "LEFT", -14, 0)
    UI.showAll:SetScript("OnClick", function()
        CT:SetShowOptionalAbilities(not CT:GetShowOptionalAbilities())
        CT:RefreshDungeonMobPage()
    end)
    UI.showAll:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Important Only / Show All", 1, 0.25, 0.25)
        GameTooltip:AddLine("Important Only shows role-relevant spells that Blizzard marks Important. A catalog/trait reference by itself does not make a trash ability important.", 1, 1, 1, true)
        GameTooltip:AddLine("Show All exposes optional catalog abilities only for manual opt-in.", 0.65, 0.9, 1, true)
        GameTooltip:Show()
    end)
    UI.showAll:SetScript("OnLeave", GameTooltip_Hide)

    local current = CreateButton(root, "Current Dungeon", 120, 22)
    UI.topButtons.currentDungeon = current
    StyleStaticTab(current, false)
    current:SetPoint("RIGHT", UI.showAll, "LEFT", -8, 0)
    current:SetScript("OnClick", function()
        local key = CT:GetCurrentDungeonKey()
        if key and Data.dungeons[key] then
            UI.selectedDungeonKey = key
            UI.selectedNPCID = nil
            UI.selectedAbilityKey = nil
            CT:RefreshDungeonMobPage()
        end
    end)

    UI.roleSelector = AU.CreateRoleSelector(root, function()
        CT:RefreshDungeonMobPage()
    end)
    UI.roleSelector:SetPoint("TOPRIGHT", -5, roleRowY)

    local dungeonPanel = CreateFrame("Frame", nil, root, "BackdropTemplate")
    dungeonPanel:SetPoint("TOPLEFT", 0, top)
    dungeonPanel:SetPoint("BOTTOMLEFT", 0, 0)
    dungeonPanel:SetWidth(174)
    MakeBackdrop(dungeonPanel, 0.72)

    local dHeader = CreateLabel(dungeonPanel, "Dungeons", "GameFontNormal")
    dHeader:SetPoint("TOPLEFT", 10, -9)

    local y = -34
    for _, key in ipairs(Data.order or {}) do
        local dungeonKey = key
        local dungeon = Data.dungeons[dungeonKey]
        local button = CreateButton(dungeonPanel, dungeon.name, 154, 26)
        button:SetPoint("TOPLEFT", 10, y)
        button:SetScript("OnClick", function()
            UI.selectedDungeonKey = dungeonKey
            UI.selectedNPCID = nil
            UI.selectedAbilityKey = nil
            if UI.search then UI.search:SetText("") end
            CT:RefreshDungeonMobPage()
        end)
        UI.dungeonButtons[dungeonKey] = button
        y = y - 31
    end

    local resetDungeon = CreateButton(dungeonPanel, "Reset Dungeon", 154, 24)
    resetDungeon:SetPoint("BOTTOMLEFT", 10, 10)
    resetDungeon:SetScript("OnClick", function()
        CT:ResetDungeonAbilities(UI.selectedDungeonKey)
        CT:RefreshDungeonMobPage()
    end)
    resetDungeon:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Reset dungeon abilities", 1, 0.25, 0.25)
        GameTooltip:AddLine("Removes your trash overrides for this dungeon and returns every mob ability to ChayAlert HUD's active role defaults.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    resetDungeon:SetScript("OnLeave", GameTooltip_Hide)

    local mobPanel = CreateFrame("Frame", nil, root, "BackdropTemplate")
    mobPanel:SetPoint("TOPLEFT", dungeonPanel, "TOPRIGHT", 8, 0)
    mobPanel:SetPoint("BOTTOMLEFT", dungeonPanel, "BOTTOMRIGHT", 8, 0)
    mobPanel:SetWidth(300)
    MakeBackdrop(mobPanel, 0.72)

    UI.dungeonTitle = CreateLabel(mobPanel, "Dungeon", "GameFontNormal")
    UI.dungeonTitle:SetPoint("TOPLEFT", 10, -9)
    UI.dungeonTitle:SetWidth(245)
    UI.dungeonTitle:SetJustifyH("LEFT")
    TruncateSingleLine(UI.dungeonTitle)

    UI.search = CreateFrame("EditBox", nil, mobPanel, "InputBoxTemplate")
    UI.search:SetSize(268, 24)
    UI.search:SetPoint("TOPLEFT", 12, -38)
    UI.search:SetAutoFocus(false)
    UI.search.Instructions = UI.search:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    UI.search.Instructions:SetPoint("LEFT", 5, 0)
    UI.search.Instructions:SetText("Search mob or NPC ID")
    UI.search:SetScript("OnTextChanged", function(self)
        self.Instructions:SetShown(self:GetText() == "")
        CT:RefreshDungeonMobPage()
    end)
    UI.search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

    local mobScroll = CreateFrame("ScrollFrame", nil, mobPanel, "UIPanelScrollFrameTemplate")
    mobScroll:SetPoint("TOPLEFT", 10, -70)
    mobScroll:SetPoint("BOTTOMRIGHT", -29, 10)
    UI.mobChild = CreateFrame("Frame", nil, mobScroll)
    UI.mobChild:SetSize(270, 1)
    UI.mobChild:ClearAllPoints()
    UI.mobChild:SetPoint("TOPLEFT", mobScroll, "TOPLEFT", 0, 0)
    mobScroll:SetScrollChild(UI.mobChild)
    AU.EnhanceScrollFrame(mobScroll)

    local right = CreateFrame("Frame", nil, root, "BackdropTemplate")
    right:SetPoint("TOPLEFT", mobPanel, "TOPRIGHT", 8, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)
    MakeBackdrop(right, 0.72)

    -- A local cursor keeps every selected-mob row derived from the row above
    -- it, instead of independent fixed offsets that can overlap.
    local rightY = -9
    local function NextRightRow(height, gap)
        local rowTop = rightY
        rightY = rowTop - height - (gap or 8)
        return rowTop
    end

    UI.rightTitle = CreateLabel(right, "Select a mob", "GameFontNormalLarge")
    UI.rightTitle:SetPoint("TOPLEFT", 12, NextRightRow(22, 3))
    UI.rightTitle:SetWidth(250)
    UI.rightTitle:SetJustifyH("LEFT")
    TruncateSingleLine(UI.rightTitle)

    UI.mobMeta = CreateLabel(right, "", "GameFontDisableSmall")
    UI.mobMeta:SetPoint("TOPLEFT", 12, NextRightRow(14, 8))
    UI.mobMeta:SetWidth(360)
    UI.mobMeta:SetJustifyH("LEFT")
    TruncateSingleLine(UI.mobMeta)

    local controlRow1Y = NextRightRow(22, 6)
    UI.mobEnabled = CreateFrame("CheckButton", nil, right, "UICheckButtonTemplate")
    UI.mobEnabled:SetSize(22, 22)
    UI.mobEnabled:SetPoint("TOPLEFT", 12, controlRow1Y)
    local enabledText = CreateLabel(right, "Mob Enabled", "GameFontHighlightSmall")
    enabledText:SetPoint("LEFT", UI.mobEnabled, "RIGHT", 4, 0)
    UI.mobEnabled:SetScript("OnClick", function(self)
        local mob = GetSelectedMob()
        if mob then
            CT:SetMobEnabled(UI.selectedDungeonKey, mob.npcID, self:GetChecked() == true)
            CT:RefreshDungeonMobPage()
        end
    end)

    UI.resetMob = CreateButton(right, "Reset Mob", 86, 20)
    UI.resetMob:SetPoint("TOPRIGHT", -10, controlRow1Y)
    UI.resetMob:SetScript("OnClick", function()
        local mob = GetSelectedMob()
        if mob then
            CT:ResetMobAbilities(UI.selectedDungeonKey, mob.npcID)
            CT:RefreshDungeonMobPage()
        end
    end)
    UI.resetMob:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Reset mob abilities", 1, 0.25, 0.25)
        GameTooltip:AddLine("Removes your overrides for this mob and returns its ability list to the active role defaults.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    UI.resetMob:SetScript("OnLeave", GameTooltip_Hide)

    local controlRow2Y = NextRightRow(20, 10)
    local disableAll = CreateButton(right, "Disable All", 82, 20)
    disableAll:SetPoint("TOPRIGHT", -10, controlRow2Y)
    disableAll:SetScript("OnClick", function()
        local mob = GetSelectedMob()
        if not mob then return end
        for _, spell in ipairs(mob.spells or {}) do
            CT:SetAbilityEnabled(UI.selectedDungeonKey, mob.npcID, spell.id, false)
        end
        CT:RefreshDungeonMobPage()
    end)

    local enableAll = CreateButton(right, "Enable All", 82, 20)
    enableAll:SetPoint("RIGHT", disableAll, "LEFT", -6, 0)
    enableAll:SetScript("OnClick", function()
        local mob = GetSelectedMob()
        if not mob then return end
        CT:SetMobEnabled(UI.selectedDungeonKey, mob.npcID, true)
        for _, spell in ipairs(mob.spells or {}) do
            CT:SetAbilityEnabled(UI.selectedDungeonKey, mob.npcID, spell.id, true)
        end
        CT:RefreshDungeonMobPage()
    end)

    local applyRecommendations = CreateButton(right, "Apply Recs", 94, 20)
    applyRecommendations:SetPoint("RIGHT", enableAll, "LEFT", -6, 0)
    applyRecommendations:SetScript("OnClick", function()
        local mob = GetSelectedMob()
        if not mob then return end
        for _, spell in ipairs(mob.spells or {}) do
            local cfg = CT:GetAbilityEffectiveConfig(UI.selectedDungeonKey, mob.npcID, spell.id)
            if cfg then
                CT:SetAbilityEnabled(UI.selectedDungeonKey, mob.npcID, spell.id, cfg.recommended == true)
            end
        end
        CT:RefreshDungeonMobPage()
    end)
    applyRecommendations:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Apply Recommendations", 1, 0.25, 0.25)
        GameTooltip:AddLine("Turns each ability for this mob on or off to match ChayAlert HUD's current recommendation for your active role. Labels, sounds, priorities, and role overrides you customized are left untouched.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    applyRecommendations:SetScript("OnLeave", GameTooltip_Hide)

    local abilitiesLabel = CreateLabel(right, "Abilities", "GameFontNormal")
    abilitiesLabel:SetPoint("TOPLEFT", 12, NextRightRow(16, 4))
    abilitiesLabel:SetTextColor(0.45, 0.95, 1.0, 1)

    local cardScrollY = NextRightRow(140, 10)
    local cardScroll = CreateFrame("ScrollFrame", nil, right, "UIPanelScrollFrameTemplate")
    cardScroll:SetPoint("TOPLEFT", 12, cardScrollY)
    cardScroll:SetPoint("TOPRIGHT", -29, cardScrollY)
    cardScroll:SetHeight(140)
    UI.cardScroll = cardScroll
    UI.cardChild = CreateFrame("Frame", nil, cardScroll)
    UI.cardChild:SetSize(430, 1)
    UI.cardChild:ClearAllPoints()
    UI.cardChild:SetPoint("TOPLEFT", cardScroll, "TOPLEFT", 0, 0)
    cardScroll:SetScrollChild(UI.cardChild)
    AU.EnhanceScrollFrame(cardScroll)

    UI.detail = AU.CreateDetailPanel(right)
    UI.detail:SetPoint("TOPLEFT", 12, rightY)
    UI.detail:SetPoint("BOTTOMRIGHT", -12, 10)

    CT:RefreshDungeonMobPage()
end
