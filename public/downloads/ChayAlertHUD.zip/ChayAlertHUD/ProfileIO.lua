-- ChayAlert HUD ProfileIO.lua
-- Safe, code-free profile import/export. The format is deliberately simple and
-- does not use loadstring or execute imported Lua.

local CT = _G.ChayAlertHUD
if type(CT) ~= "table" then return end

local ProfileIO = {}
CT.ProfileIO = ProfileIO
_G.ChayAlertHUDProfileIO = ProfileIO

local PROFILE_SCHEMA = 2
local LEGACY_PROFILE_SCHEMA = 1
local LEGACY_HEADER = "CHAYALERT_HUD_PROFILE|" .. tostring(LEGACY_PROFILE_SCHEMA)
local PROFILE_V2_PREFIX = "CHAYALERT_HUD_PROFILE2:"
local PROFILE_V3_PREFIX = "CHAYALERT_HUD_PROFILE3:"
local MAX_TEXT_BYTES = 1200000
local MAX_DECODED_BYTES = 4000000
local MAX_LINES = 25000
local MAX_DEPTH = 10
local MAX_PROFILE_VALUES = 100000

local ROOT_KEYS = {
    enabled = true,
    onlyInInstances = true,
    showMinimap = true,
    minimapX = true,
    minimapY = true,
    maxAlerts = true,
    leadTime = true,
    showName = true,
    showTenths = true,
    circleFlashOnStart = true,
    reverse = true,
    useTimeColor = true,
    ringThickness = true,
    ringBackgroundAlpha = true,
    color = true,
    warningColor = true,
    urgentColor = true,
    soundEnabled = true,
    allSoundSelectionsNone = true,
    alertSound = true,
    urgentSound = true,
    beepSound = true,
    playUrgentSound = true,
    countdownBeeps = true,
    beepAt = true,
    ttsEnabled = true,
    ttsRate = true,
    ttsVolume = true,
    ttsVoiceID = true,
    ttsVoiceKey = true,
    ttsPhraseMode = true,
    ttsCustomPhrase = true,
    voicePackSource = true,
    tankSwapVoice = true,
    mutedSpells = true,
    trackedSpells = true,
    trackOnlyCustom = true,
    trashCastsEnabled = true,
    importantAurasEnabled = true,
    suppressTrashDuringBoss = true,
    trashMinCastTime = true,
    showTrashMobName = true,
    trackUnknownTrash = true,
    trackUnknownBossTimeline = true,
    showOptionalAbilities = true,
    roleProfile = true,
    mobAbilityOverrides = true,
    bossAbilityOverrides = true,
    raidAbilityOverrides = true,
    displayMode = true,
    timeline = true,
    optionsWidth = true,
    optionsHeight = true,
    optionsBackgroundMode = true,
    optionsBackgroundColor = true,
    circles = true,
}

local LEGACY_IGNORED_ROOT_KEYS = {
    learningCaptureMode = true,
}

local exportFrame, editBox, scrollFrame, actionButton, modeLabel
local frameMode = "EXPORT"

local function GetDB()
    return type(CT.GetDB) == "function" and CT:GetDB() or nil
end

local function IsFiniteNumber(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function HexEncode(text)
    if type(text) ~= "string" then return "" end
    return (text:gsub(".", function(ch) return string.format("%02X", string.byte(ch)) end))
end

local function HexDecode(hex)
    if type(hex) ~= "string" or (#hex % 2) ~= 0 or hex:find("[^0-9A-Fa-f]") then return nil end
    if #hex > MAX_TEXT_BYTES * 2 then return nil end
    return (hex:gsub("..", function(pair) return string.char(tonumber(pair, 16)) end))
end

local function EncodeSegment(key)
    if type(key) == "number" and IsFiniteNumber(key) then
        return "n" .. string.format("%.17g", key)
    elseif type(key) == "string" then
        return "s" .. HexEncode(key)
    end
    return nil
end

local function DecodeSegment(segment)
    if type(segment) ~= "string" or #segment < 2 then return nil, "invalid path segment" end
    local kind = segment:sub(1, 1)
    local payload = segment:sub(2)
    if kind == "s" then
        local value = HexDecode(payload)
        if value == nil then return nil, "invalid string path segment" end
        return value
    elseif kind == "n" then
        local value = tonumber(payload)
        if not IsFiniteNumber(value) then return nil, "invalid numeric path segment" end
        return value
    end
    return nil, "unsupported path segment"
end

local function EncodeValue(value)
    local kind = type(value)
    if kind == "boolean" then return "b", value and "1" or "0" end
    if kind == "number" and IsFiniteNumber(value) then return "n", string.format("%.17g", value) end
    if kind == "string" then return "s", HexEncode(value) end
    return nil, nil
end

local function DecodeValue(kind, payload)
    if kind == "t" then
        if payload ~= "" then return nil, "invalid table marker" end
        return {}
    elseif kind == "b" then
        if payload == "1" then return true end
        if payload == "0" then return false end
        return nil, "invalid boolean"
    elseif kind == "n" then
        local value = tonumber(payload)
        if not IsFiniteNumber(value) then return nil, "invalid number" end
        return value
    elseif kind == "s" then
        local value = HexDecode(payload)
        if value == nil then return nil, "invalid string" end
        return value
    end
    return nil, "unsupported value type"
end

local function SortedKeys(tbl)
    local keys = {}
    for key in pairs(tbl or {}) do
        if type(key) == "string" or type(key) == "number" then keys[#keys + 1] = key end
    end
    table.sort(keys, function(a, b)
        if type(a) == type(b) then
            if type(a) == "number" then return a < b end
            return a < b
        end
        return type(a) == "number"
    end)
    return keys
end

local function ExportTable(tbl, path, lines, depth)
    if depth > MAX_DEPTH or type(tbl) ~= "table" then return end
    for _, key in ipairs(SortedKeys(tbl)) do
        local segment = EncodeSegment(key)
        if segment then
            local childPath = path == "" and segment or (path .. "/" .. segment)
            local value = tbl[key]
            if type(value) == "table" then
                lines[#lines + 1] = childPath .. "|t|"
                ExportTable(value, childPath, lines, depth + 1)
            else
                local kind, encoded = EncodeValue(value)
                if kind then lines[#lines + 1] = childPath .. "|" .. kind .. "|" .. encoded end
            end
        end
    end
end

local function BuildLegacyExportText()
    local db = GetDB()
    if type(db) ~= "table" then return LEGACY_HEADER .. "\n" end

    local lines = {
        LEGACY_HEADER,
        "# ChayAlert HUD settings only.",
    }

    for _, root in ipairs(SortedKeys(ROOT_KEYS)) do
        if ROOT_KEYS[root] and db[root] ~= nil then
            local segment = EncodeSegment(root)
            local value = db[root]
            if type(value) == "table" then
                lines[#lines + 1] = segment .. "|t|"
                ExportTable(value, segment, lines, 1)
            else
                local kind, encoded = EncodeValue(value)
                if kind then lines[#lines + 1] = segment .. "|" .. kind .. "|" .. encoded end
            end
        end
    end

    return table.concat(lines, "\n")
end

local function SplitPath(path)
    local out = {}
    for segment in tostring(path):gmatch("[^/]+") do
        local key, err = DecodeSegment(segment)
        if key == nil then return nil, err end
        out[#out + 1] = key
        if #out > MAX_DEPTH then return nil, "profile nesting is too deep" end
    end
    if #out == 0 then return nil, "empty path" end
    if type(out[1]) ~= "string" or (ROOT_KEYS[out[1]] ~= true and LEGACY_IGNORED_ROOT_KEYS[out[1]] ~= true) then
        return nil, "unsupported profile field"
    end
    return out
end

local function AssignPath(root, path, value)
    local cursor = root
    for i = 1, #path - 1 do
        local key = path[i]
        local child = cursor[key]
        if child == nil then
            child = {}
            cursor[key] = child
        elseif type(child) ~= "table" then
            return false, "path conflicts with an existing value"
        end
        cursor = child
    end
    cursor[path[#path]] = value
    return true
end

local function ParseLegacyProfile(text)
    if type(text) ~= "string" then return nil, "No profile text was provided." end
    if #text > MAX_TEXT_BYTES then return nil, "Profile text is too large." end

    local first
    local parsed = {}
    local lines = 0
    for line in text:gmatch("[^\r\n]+") do
        lines = lines + 1
        if lines > MAX_LINES then return nil, "Profile contains too many lines." end
        if not first then
            first = line
            if first ~= LEGACY_HEADER then return nil, "This is not a supported ChayAlert HUD profile." end
        elseif line:sub(1, 1) ~= "#" and line ~= "" then
            local pathText, kind, payload = line:match("^([^|]+)|([bnst])|(.*)$")
            if not pathText then return nil, "Malformed profile line " .. tostring(lines) .. "." end
            local path, pathErr = SplitPath(pathText)
            if not path then return nil, "Line " .. tostring(lines) .. ": " .. tostring(pathErr) end
            local value, valueErr = DecodeValue(kind, payload)
            if valueErr then return nil, "Line " .. tostring(lines) .. ": " .. tostring(valueErr) end
            local ok, assignErr = AssignPath(parsed, path, value)
            if not ok then return nil, "Line " .. tostring(lines) .. ": " .. tostring(assignErr) end
        end
    end

    if first ~= LEGACY_HEADER then return nil, "Profile header is missing." end
    return parsed
end

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value) or false
end

local function PublicString(value)
    if IsSecret(value) or type(value) ~= "string" or value == "" then return nil end
    return value
end

local function CloneProfileValue(value, depth)
    depth = depth or 0
    if depth > MAX_DEPTH or IsSecret(value) then return nil end
    local kind = type(value)
    if kind == "boolean" or kind == "string" then return value end
    if kind == "number" then return IsFiniteNumber(value) and value or nil end
    if kind ~= "table" then return nil end

    local copy = {}
    for key, child in pairs(value) do
        if (type(key) == "string" or type(key) == "number") and not IsSecret(key) then
            local cloned = CloneProfileValue(child, depth + 1)
            if cloned ~= nil then copy[key] = cloned end
        end
    end
    return copy
end

local function ProfileValuesEqual(a, b, depth)
    depth = depth or 0
    if depth > MAX_DEPTH then return false end
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end

    for key, value in pairs(a) do
        if b[key] == nil and value ~= nil then return false end
        if not ProfileValuesEqual(value, b[key], depth + 1) then return false end
    end
    for key, value in pairs(b) do
        if a[key] == nil and value ~= nil then return false end
    end
    return true
end

local function BuildProfileData()
    local db = GetDB()
    if type(db) ~= "table" then return {} end

    local data = {}
    for root in pairs(ROOT_KEYS) do
        if db[root] ~= nil then
            local cloned = CloneProfileValue(db[root], 0)
            if cloned ~= nil then data[root] = cloned end
        end
    end
    return data
end

local function EncodingAPIAvailable()
    return type(C_EncodingUtil) == "table"
        and type(C_EncodingUtil.SerializeCBOR) == "function"
        and type(C_EncodingUtil.DeserializeCBOR) == "function"
        and type(C_EncodingUtil.CompressString) == "function"
        and type(C_EncodingUtil.DecompressString) == "function"
        and type(C_EncodingUtil.EncodeBase64) == "function"
        and type(C_EncodingUtil.DecodeBase64) == "function"
end

local function CompressionMethod()
    return Enum and Enum.CompressionMethod and Enum.CompressionMethod.Deflate or nil
end

local function Base64VariantUrlSafe()
    return Enum and Enum.Base64Variant and Enum.Base64Variant.StandardUrlSafe or 1
end

local function Compress(source)
    local method = CompressionMethod()
    if method ~= nil then
        return C_EncodingUtil.CompressString(source, method)
    end
    return C_EncodingUtil.CompressString(source)
end

local function Decompress(source)
    local method = CompressionMethod()
    if method ~= nil then return C_EncodingUtil.DecompressString(source, method) end
    return C_EncodingUtil.DecompressString(source)
end

local function EncodeBase64Standard(source)
    -- Match Blizzard's own 12.1 Cooldown Viewer serializer exactly: the default
    -- Base64 variant is Standard. Keeping this call simple also avoids depending
    -- on enum fallback values during early addon load.
    return C_EncodingUtil.EncodeBase64(source)
end

local function DecodeBase64Standard(source)
    return C_EncodingUtil.DecodeBase64(source)
end

local function DecodeBase64UrlSafe(source)
    return C_EncodingUtil.DecodeBase64(source, Base64VariantUrlSafe())
end

local function ValidateProfileValue(value, depth, root, counter)
    if depth > MAX_DEPTH then return false, "Profile nesting is too deep." end
    if IsSecret(value) then return false, "Profile contains protected data." end

    local kind = type(value)
    if kind == "boolean" or kind == "string" then
        counter.count = counter.count + 1
        return counter.count <= MAX_PROFILE_VALUES, "Profile contains too many values."
    end
    if kind == "number" then
        counter.count = counter.count + 1
        if counter.count > MAX_PROFILE_VALUES then return false, "Profile contains too many values." end
        return IsFiniteNumber(value), "Profile contains an invalid number."
    end
    if kind ~= "table" then return false, "Profile contains an unsupported value type." end

    for key, child in pairs(value) do
        if IsSecret(key) or (type(key) ~= "string" and type(key) ~= "number") then
            return false, "Profile contains an unsupported table key."
        end
        if type(key) == "number" and not IsFiniteNumber(key) then
            return false, "Profile contains an invalid numeric key."
        end
        if root and (type(key) ~= "string" or (ROOT_KEYS[key] ~= true and LEGACY_IGNORED_ROOT_KEYS[key] ~= true)) then
            return false, "Profile contains an unsupported setting: " .. tostring(key)
        end
        counter.count = counter.count + 1
        if counter.count > MAX_PROFILE_VALUES then return false, "Profile contains too many values." end
        local ok, err = ValidateProfileValue(child, depth + 1, false, counter)
        if not ok then return false, err end
    end
    return true
end

local function ParseEncodedProfile(text, prefix, decodeFunc)
    if not EncodingAPIAvailable() then
        return nil, "This profile requires the Midnight 12.1 encoding APIs."
    end

    local payload = text:sub(#prefix + 1):gsub("%s+", "")
    if payload == "" then return nil, "Profile payload is empty." end

    local okDecode, compressed = pcall(decodeFunc, payload)
    if not okDecode or type(compressed) ~= "string" or compressed == "" then
        return nil, "Profile Base64 data is invalid or incomplete."
    end

    local okInflate, serialized = pcall(Decompress, compressed)
    if not okInflate or type(serialized) ~= "string" or serialized == "" then
        return nil, "Profile compression data is invalid or incomplete."
    end
    if #serialized > MAX_DECODED_BYTES then return nil, "Decoded profile is too large." end

    local okDeserialize, decoded = pcall(C_EncodingUtil.DeserializeCBOR, serialized)
    if not okDeserialize or type(decoded) ~= "table" then
        return nil, "Profile data could not be decoded."
    end

    local valid, validationErr = ValidateProfileValue(decoded, 0, true, { count = 0 })
    if not valid then return nil, validationErr end
    return decoded
end

local function ParseV3Profile(text)
    return ParseEncodedProfile(text, PROFILE_V3_PREFIX, DecodeBase64Standard)
end

local function ParseV2Profile(text)
    return ParseEncodedProfile(text, PROFILE_V2_PREFIX, DecodeBase64UrlSafe)
end

function ProfileIO:BuildExportText()
    if not EncodingAPIAvailable() then
        return nil, "Midnight 12.1 profile encoding APIs are unavailable."
    end

    local data = BuildProfileData()
    local valid, validationErr = ValidateProfileValue(data, 0, true, { count = 0 })
    if not valid then
        return nil, "Profile validation failed before export: " .. tostring(validationErr)
    end

    local okSerialize, serialized = pcall(C_EncodingUtil.SerializeCBOR, data)
    if not okSerialize or type(serialized) ~= "string" or serialized == "" then
        return nil, "Blizzard CBOR serialization failed."
    end

    local okCompress, compressed = pcall(Compress, serialized)
    if not okCompress or type(compressed) ~= "string" or compressed == "" then
        return nil, "Blizzard profile compression failed."
    end

    local okEncode, encoded = pcall(EncodeBase64Standard, compressed)
    if not okEncode or type(encoded) ~= "string" or encoded == "" then
        return nil, "Blizzard Base64 encoding failed."
    end

    local exportText = PROFILE_V3_PREFIX .. encoded

    -- Do not hand a user a share string unless this same client can immediately
    -- decode it back to an equivalent profile. This catches codec/runtime failures
    -- at export time instead of making the receiving player discover them later.
    local decoded, decodeErr = ParseV3Profile(exportText)
    if not decoded then
        return nil, "Profile export self-check failed: " .. tostring(decodeErr)
    end
    if not ProfileValuesEqual(data, decoded, 0) then
        return nil, "Profile export self-check failed: decoded settings did not match the source profile."
    end

    return exportText
end

function ProfileIO:ParseProfile(text)
    if type(text) ~= "string" then return nil, "No profile text was provided." end
    if #text > MAX_TEXT_BYTES then return nil, "Profile text is too large." end

    text = text:gsub("^\239\187\191", "")
    local trimmed = text:match("^%s*(.-)%s*$") or text
    local function ExtractEncodedCandidate(prefix, allowedPattern)
        local startPos = trimmed:find(prefix, 1, true)
        if not startPos then return nil end
        local candidate = trimmed:sub(startPos)
        local rawPayload = candidate:sub(#prefix + 1)
        local cleanPayload = rawPayload:match(allowedPattern)
        if not cleanPayload then return prefix end
        return prefix .. cleanPayload
    end

    local v3Candidate = ExtractEncodedCandidate(PROFILE_V3_PREFIX, "^([%w%+/%=%s]+)")
    if v3Candidate then return ParseV3Profile(v3Candidate) end

    local v2Candidate = ExtractEncodedCandidate(PROFILE_V2_PREFIX, "^([%w_%-%+=/%s]+)")
    if v2Candidate then return ParseV2Profile(v2Candidate) end

    -- 0.9.4 and earlier used a line-based pipe-delimited format. Keep that
    -- importer indefinitely so existing shared profiles do not become invalid.
    local legacy = text:gsub("||", "|"):gsub("\\\\", "\\")
    return ParseLegacyProfile(legacy)
end

local function ApplyProfileData(parsed)
    local db = GetDB()
    if type(db) ~= "table" then return false, "ChayAlert HUD settings are not initialized." end

    -- Clear every supported profile field first so nil/default selections from the
    -- source profile do not accidentally inherit the destination character's value.
    for root in pairs(ROOT_KEYS) do
        db[root] = nil
    end
    for root in pairs(LEGACY_IGNORED_ROOT_KEYS) do
        db[root] = nil
    end
    for root, value in pairs(parsed or {}) do
        if ROOT_KEYS[root] then
            db[root] = CloneProfileValue(value, 0)
        end
    end
    return true
end

local function GetProfileStore()
    local store = _G.ChayAlertHUDProfiles
    if type(store) ~= "table" then
        store = {}
        _G.ChayAlertHUDProfiles = store
    end
    if tonumber(store.schema) ~= PROFILE_SCHEMA then
        store.schema = PROFILE_SCHEMA
    end
    if type(store.characters) ~= "table" then
        store.characters = {}
    end
    return store
end

function ProfileIO:GetCurrentProfileName()
    local name, realm
    if type(UnitFullName) == "function" then
        local ok, valueName, valueRealm = pcall(UnitFullName, "player")
        if ok then
            name = PublicString(valueName)
            realm = PublicString(valueRealm)
        end
    end
    if not name and type(UnitName) == "function" then
        local ok, value = pcall(UnitName, "player")
        if ok then name = PublicString(value) end
    end
    if not realm and type(GetNormalizedRealmName) == "function" then
        local ok, value = pcall(GetNormalizedRealmName)
        if ok then realm = PublicString(value) end
    end
    if not realm and type(GetRealmName) == "function" then
        local ok, value = pcall(GetRealmName)
        if ok then realm = PublicString(value) end
    end
    if not name then return nil end
    return realm and (name .. " - " .. realm) or name
end

function ProfileIO:SnapshotCurrentCharacter()
    local profileName = self:GetCurrentProfileName()
    if not profileName then return false, "Current character name is unavailable." end

    local parsed = BuildProfileData()

    local store = GetProfileStore()
    store.characters[profileName] = {
        name = profileName,
        data = CloneProfileValue(parsed, 0) or {},
    }
    return true
end

function ProfileIO:GetCopyProfileNames()
    local store = GetProfileStore()
    local current = self:GetCurrentProfileName()
    local names = {}
    for key, record in pairs(store.characters) do
        if key ~= current and type(record) == "table" and type(record.data) == "table" then
            names[#names + 1] = tostring(record.name or key)
        end
    end
    table.sort(names)
    return names
end

function ProfileIO:CopyFromProfile(profileName)
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        return false, "Profiles cannot be copied during combat."
    end
    if type(profileName) ~= "string" or profileName == "" then
        return false, "Choose a character profile first."
    end

    local store = GetProfileStore()
    local record = store.characters[profileName]
    if type(record) ~= "table" or type(record.data) ~= "table" then
        return false, "That character profile is no longer available."
    end

    -- Preserve the destination character's current settings before replacing them.
    self:SnapshotCurrentCharacter()
    local ok, err = ApplyProfileData(record.data)
    if not ok then return false, err end

    if type(ReloadUI) == "function" then
        ReloadUI()
        return true
    end
    return true, "Profile copied. Type /reload to finish applying it."
end

function ProfileIO:ImportText(text)
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        return false, "Profiles cannot be imported during combat."
    end

    if type(text) == "string" then
        -- EditBox:GetText() escapes literal pipe and backslash characters.
        -- Profile data uses pipe delimiters, so restore the pasted text before parsing.
        text = text:gsub("||", "|"):gsub("\\\\", "\\")
    end

    local parsed, err = self:ParseProfile(text)
    if not parsed then return false, err end
    local ok, applyErr = ApplyProfileData(parsed)
    if not ok then return false, applyErr end

    if type(ReloadUI) == "function" then
        ReloadUI()
        return true
    end
    return true, "Profile imported. Type /reload to finish applying it."
end

local function BuildFrame()
    if exportFrame then return end
    exportFrame = CreateFrame("Frame", "ChayAlertHUDProfileIOFrame", UIParent, "BackdropTemplate")
    exportFrame:SetSize(840, 620)
    exportFrame:SetPoint("CENTER")
    exportFrame:SetFrameStrata("DIALOG")
    exportFrame:SetClampedToScreen(true)
    exportFrame:SetMovable(true)
    exportFrame:EnableMouse(true)
    exportFrame:RegisterForDrag("LeftButton")
    exportFrame:SetScript("OnDragStart", exportFrame.StartMoving)
    exportFrame:SetScript("OnDragStop", exportFrame.StopMovingOrSizing)
    exportFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    exportFrame:SetBackdropColor(0.025, 0.025, 0.03, 0.98)
    exportFrame:SetBackdropBorderColor(0.75, 0.08, 0.08, 1)

    local title = exportFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOPLEFT", 16, -14)
    title:SetText("ChayAlert HUD Profile Import / Export")

    modeLabel = exportFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    modeLabel:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -5)
    modeLabel:SetWidth(760)
    modeLabel:SetJustifyH("LEFT")

    local close = CreateFrame("Button", nil, exportFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    scrollFrame = CreateFrame("ScrollFrame", nil, exportFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 16, -66)
    scrollFrame:SetPoint("BOTTOMRIGHT", -34, 58)

    editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetAutoFocus(false)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(770)
    editBox:SetMaxBytes(0)
    if editBox.SetMaxLetters then editBox:SetMaxLetters(0) end
    editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scrollFrame:SetScrollChild(editBox)

    actionButton = CreateFrame("Button", nil, exportFrame, "UIPanelButtonTemplate")
    actionButton:SetSize(190, 28)
    actionButton:SetPoint("BOTTOMLEFT", 16, 16)
    actionButton:SetScript("OnClick", function()
        if frameMode == "EXPORT" then
            editBox:SetFocus()
            editBox:HighlightText()
        else
            local ok, message = ProfileIO:ImportText(editBox:GetText() or "")
            if not ok then
                print("|cffff3030ChayAlert HUD|r profile import failed: " .. tostring(message))
            elseif message then
                print("|cff44ff88ChayAlert HUD|r " .. tostring(message))
            end
        end
    end)

    exportFrame:Hide()
end

function ProfileIO:ShowExport()
    BuildFrame()
    frameMode = "EXPORT"
    local exportText, exportErr = self:BuildExportText()
    if not exportText then
        modeLabel:SetText("Export failed its local verification. No share string was generated. " .. tostring(exportErr or "Unknown export error."))
        actionButton:SetText("Close")
        editBox:SetText("")
        actionButton:SetScript("OnClick", function() exportFrame:Hide() end)
        exportFrame:Show()
        return
    end

    modeLabel:SetText("Export verified locally. Click Select All, then Ctrl+C. PROFILE3 uses Blizzard CBOR → Deflate → Standard Base64 and is decoded once before it is shown.")
    actionButton:SetText("Select All")
    actionButton:SetScript("OnClick", function()
        editBox:SetFocus()
        editBox:HighlightText()
    end)
    editBox:SetText(exportText)
    editBox:SetFocus()
    editBox:HighlightText()
    exportFrame:Show()
end

function ProfileIO:ShowImport()
    BuildFrame()
    frameMode = "IMPORT"
    modeLabel:SetText("Paste a complete ChayAlert HUD profile below, then Apply Import. PROFILE3, PROFILE2, and legacy 0.9.4 profiles are accepted. No Lua code is executed.")
    actionButton:SetText("Apply Import & Reload")
    actionButton:SetScript("OnClick", function()
        local ok, message = ProfileIO:ImportText(editBox:GetText() or "")
        if not ok then
            print("|cffff3030ChayAlert HUD|r profile import failed: " .. tostring(message))
        elseif message then
            print("|cff44ff88ChayAlert HUD|r " .. tostring(message))
        end
    end)
    editBox:SetText("")
    editBox:SetFocus()
    exportFrame:Show()
end

return ProfileIO
