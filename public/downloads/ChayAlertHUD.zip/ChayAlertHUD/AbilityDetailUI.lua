local CT = _G.ChayAlertHUD
if not CT then return end

local M = {}
_G.ChayAlertHUDAbilityUI = M

M.PRIORITY_LABELS = {
    [1] = "Optional",
    [2] = "High",
    [3] = "Critical",
}

M.PRIORITY_COLORS = {
    [1] = { 0.35, 0.90, 0.45 },
    [2] = { 1.00, 0.82, 0.18 },
    [3] = { 1.00, 0.18, 0.18 },
}

function M.GetPriorityColor(priority)
    if priority == nil then return { 0.68, 0.70, 0.76 } end
    priority = math.max(1, math.min(3, tonumber(priority) or 1))
    return M.PRIORITY_COLORS[priority] or M.PRIORITY_COLORS[1]
end

function M.GetAggregatePriority(groups, getConfig)
    local highest
    for _, group in ipairs(groups or {}) do
        local cfg = type(getConfig) == "function" and getConfig(group) or nil
        if cfg and (cfg.enabled == true or cfg.recommended == true or cfg.roleRelevant == true) then
            highest = math.max(highest or 0, tonumber(cfg.priority) or 1)
        end
    end
    return highest
end

-- Adds a stronger visible track and up/down "more content" indicators next to an
-- existing ScrollFrame. Purely observational (GetVerticalScroll/Range + HookScript);
-- it never replaces or interferes with the ScrollFrame's own scrolling behavior.
function M.EnhanceScrollFrame(scrollFrame)
    if type(scrollFrame) ~= "table" or scrollFrame._chayScrollEnhanced then return end
    scrollFrame._chayScrollEnhanced = true

    local track = scrollFrame:CreateTexture(nil, "BACKGROUND")
    track:SetPoint("TOPRIGHT", scrollFrame, "TOPRIGHT", 16, -14)
    track:SetPoint("BOTTOMRIGHT", scrollFrame, "BOTTOMRIGHT", 16, 14)
    track:SetWidth(14)
    track:SetColorTexture(0, 0, 0, 0.4)

    local trackBorder = scrollFrame:CreateTexture(nil, "BACKGROUND", nil, 1)
    trackBorder:SetPoint("TOPLEFT", track, "TOPLEFT", -1, 1)
    trackBorder:SetPoint("BOTTOMRIGHT", track, "BOTTOMRIGHT", 1, -1)
    trackBorder:SetColorTexture(0.5, 0.06, 0.08, 0.6)

    local upArrow = scrollFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    upArrow:SetPoint("BOTTOM", track, "TOP", 0, 1)
    upArrow:SetText("|TInterface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up:14:14|t")

    local downArrow = scrollFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    downArrow:SetPoint("TOP", track, "BOTTOM", 0, -1)
    downArrow:SetText("|TInterface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up:14:14|t")

    local function Refresh()
        local ok, range = pcall(scrollFrame.GetVerticalScrollRange, scrollFrame)
        range = (ok and tonumber(range)) or 0
        if range <= 1 then
            upArrow:Hide()
            downArrow:Hide()
            trackBorder:SetAlpha(0.25)
            return
        end
        trackBorder:SetAlpha(0.6)
        local okPos, pos = pcall(scrollFrame.GetVerticalScroll, scrollFrame)
        pos = (okPos and tonumber(pos)) or 0
        upArrow:SetShown(pos > 2)
        downArrow:SetShown(pos < range - 2)
    end

    scrollFrame:HookScript("OnVerticalScroll", Refresh)
    scrollFrame:HookScript("OnScrollRangeChanged", Refresh)
    scrollFrame:HookScript("OnSizeChanged", Refresh)
    scrollFrame:HookScript("OnShow", Refresh)
    Refresh()

    return Refresh
end

M.MECHANIC_LABELS = {
    INTERRUPT = "KICK",
    TANK = "TANK",
    AOE_DAMAGE = "AOE",
    UTILITY = "UTIL",
    OTHER = "OTHER",
}

M.MECHANIC_COLORS = {
    INTERRUPT = { 1.00, 0.62, 0.18 },
    TANK = { 1.00, 0.30, 0.25 },
    AOE_DAMAGE = { 1.00, 0.52, 0.12 },
    UTILITY = { 0.22, 0.88, 0.78 },
    OTHER = { 0.68, 0.70, 0.76 },
}

function M.GetMechanicLabel(mechanicType)
    mechanicType = type(mechanicType) == "string" and mechanicType:upper() or "OTHER"
    return M.MECHANIC_LABELS[mechanicType] or "OTHER"
end

function M.GetMechanicColor(mechanicType)
    mechanicType = type(mechanicType) == "string" and mechanicType:upper() or "OTHER"
    return M.MECHANIC_COLORS[mechanicType] or M.MECHANIC_COLORS.OTHER
end

local function PriorityHex(priority)
    local c = M.PRIORITY_COLORS[priority] or M.PRIORITY_COLORS[1]
    return string.format("%02x%02x%02x",
        math.floor((c[1] or 1) * 255 + 0.5),
        math.floor((c[2] or 1) * 255 + 0.5),
        math.floor((c[3] or 1) * 255 + 0.5))
end

-- Compact color-key legend shown near each ability manager's header. Display only;
-- does not change stored importance, enable state, or recommendation filtering.
function M.CreateSeverityLegend(parent)
    local legend = parent:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    legend:SetJustifyH("LEFT")
    legend:SetWordWrap(false)
    legend:SetText(
        "|cff" .. PriorityHex(3) .. "Critical / TTS Recommended|r   " ..
        "|cff" .. PriorityHex(2) .. "High|r   " ..
        "|cff" .. PriorityHex(1) .. "Optional|r"
    )
    return legend
end

local requestedSpells = {}
local descriptionCache = {}

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value) or false
end

local function Trim(value)
    if type(value) ~= "string" then return "" end
    return value:gsub("^%s+", ""):gsub("%s+$", "")
end

local function NormalizeTooltipText(value)
    if type(value) ~= "string" or value == "" then return nil end
    local text = value:gsub("\r\n", "\n")
    text = text:gsub("\r", "\n")
    return text
end

function M.GetSpellInfo(spellID)
    spellID = tonumber(spellID)
    if not spellID then return nil end

    local name, iconID
    if C_Spell and C_Spell.GetSpellInfo then
        local ok, info = pcall(C_Spell.GetSpellInfo, spellID)
        if ok and type(info) == "table" then
            if not IsSecret(info.name) and type(info.name) == "string" and info.name ~= "" then
                name = info.name
            end
            if not IsSecret(info.iconID) then
                iconID = info.iconID
            end
        end
    end

    if not name and C_Spell and C_Spell.GetSpellName then
        local ok, value = pcall(C_Spell.GetSpellName, spellID)
        if ok and not IsSecret(value) and type(value) == "string" and value ~= "" then
            name = value
        end
    end

    if not iconID and C_Spell and C_Spell.GetSpellTexture then
        local ok, value = pcall(C_Spell.GetSpellTexture, spellID)
        if ok and not IsSecret(value) then
            iconID = value
        end
    end

    if not name and C_Spell and C_Spell.RequestLoadSpellData and not requestedSpells[spellID] then
        requestedSpells[spellID] = true
        pcall(C_Spell.RequestLoadSpellData, spellID)
    end

    return {
        id = spellID,
        name = name or ("Spell " .. tostring(spellID)),
        iconID = iconID or "Interface\\Icons\\INV_Misc_QuestionMark",
    }
end

local function TooltipLinesBySpellID(spellID)
    if not spellID or not C_TooltipInfo or not C_TooltipInfo.GetSpellByID then
        return nil
    end

    local ok, tooltip = pcall(C_TooltipInfo.GetSpellByID, spellID)
    if not ok or type(tooltip) ~= "table" or type(tooltip.lines) ~= "table" then
        return nil
    end

    local lines = {}
    for index, line in ipairs(tooltip.lines) do
        if index > 1 and type(line) == "table" then
            local rawLeft = line.leftText
            local rawRight = line.rightText
            local left = not IsSecret(rawLeft) and NormalizeTooltipText(rawLeft) or nil
            local right = not IsSecret(rawRight) and NormalizeTooltipText(rawRight) or nil

            local combined
            if left and right and left ~= "" and right ~= "" then
                combined = left .. "    " .. right
            elseif left and left ~= "" then
                combined = left
            elseif right and right ~= "" then
                combined = right
            end

            if combined and combined ~= "" then
                lines[#lines + 1] = combined
            end
        end
    end

    return #lines > 0 and lines or nil
end

function M.GetSpellDescription(spellID)
    spellID = tonumber(spellID)
    if not spellID then return "No spell description is available." end

    if type(descriptionCache[spellID]) == "string" and descriptionCache[spellID] ~= "" then
        return descriptionCache[spellID]
    end

    local lines = TooltipLinesBySpellID(spellID)
    if lines then
        local description = table.concat(lines, "\n")
        descriptionCache[spellID] = description
        return description
    end

    if C_Spell and C_Spell.GetSpellDescription then
        local ok, description = pcall(C_Spell.GetSpellDescription, spellID)
        if ok and not IsSecret(description) and type(description) == "string" and description ~= "" then
            descriptionCache[spellID] = description
            return description
        end
    end

    if C_Spell and C_Spell.RequestLoadSpellData and not requestedSpells[spellID] then
        requestedSpells[spellID] = true
        pcall(C_Spell.RequestLoadSpellData, spellID)
    end

    -- Do not cache this fallback. SPELL_DATA_LOAD_RESULT may make the real
    -- Blizzard description available a moment later.
    return "Spell data is not loaded yet. ChayAlert HUD will refresh this page when Blizzard finishes loading it."
end

function M.ShowNativeSpellTooltip(owner, spellID, fallbackName)
    if not owner or not GameTooltip then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()

    local populated = false
    spellID = tonumber(spellID)
    if spellID and GameTooltip.SetSpellByID then
        local ok = pcall(GameTooltip.SetSpellByID, GameTooltip, spellID)
        if ok then
            local okLines, count = pcall(GameTooltip.NumLines, GameTooltip)
            populated = okLines and type(count) == "number" and count > 0
        end
    end

    if not populated then
        GameTooltip:AddLine(fallbackName or ("Spell " .. tostring(spellID or "?")), 1, 1, 1, true)
        local description = M.GetSpellDescription(spellID)
        if description and description ~= "" then
            GameTooltip:AddLine(description, 0.92, 0.92, 0.92, true)
        end
    end

    GameTooltip:Show()
end

local function MakeBackdrop(frame, alpha)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.015, 0.008, 0.012, alpha or 0.88)
    frame:SetBackdropBorderColor(0.42, 0.04, 0.055, 0.95)
end

local function CreateLabel(parent, text, template)
    local label = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    label:SetText(text or "")
    return label
end

local function CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width or 100, height or 22)
    button:SetText(text or "")
    if type(CT.ApplyClassButtonStyle) == "function" then
        CT:ApplyClassButtonStyle(button, false)
    end
    return button
end

-- Bounds a label to one line and truncates overflow instead of letting text
-- draw past its anchors or into a neighboring control.
local function TruncateSingleLine(fontString)
    fontString:SetWordWrap(true)
    if fontString.SetMaxLines then fontString:SetMaxLines(1) end
end

function M.CreateAbilityCard(parent)
    local card = CreateFrame("Button", nil, parent, "BackdropTemplate")
    card:SetSize(210, 58)
    MakeBackdrop(card, 0.76)

    card.leftBar = card:CreateTexture(nil, "ARTWORK")
    card.leftBar:SetWidth(4)
    card.leftBar:SetPoint("TOPLEFT", 0, 0)
    card.leftBar:SetPoint("BOTTOMLEFT", 0, 0)

    card.icon = card:CreateTexture(nil, "ARTWORK")
    card.icon:SetSize(30, 30)
    card.icon:SetPoint("LEFT", 10, 0)
    card.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    card.title = CreateLabel(card, "", "GameFontNormal")
    card.title:SetPoint("LEFT", card.icon, "RIGHT", 7, 6)
    card.title:SetPoint("RIGHT", -7, 6)
    card.title:SetJustifyH("LEFT")
    TruncateSingleLine(card.title)

    card.badge = CreateLabel(card, "", "GameFontDisableSmall")
    card.badge:SetPoint("LEFT", card.icon, "RIGHT", 7, -9)
    card.badge:SetWidth(54)
    card.badge:SetJustifyH("LEFT")
    card.badge:SetWordWrap(false)

    card.status = CreateLabel(card, "", "GameFontDisableSmall")
    card.status:SetPoint("LEFT", card.icon, "RIGHT", 64, -9)
    card.status:SetPoint("RIGHT", -7, -10)
    card.status:SetJustifyH("LEFT")
    TruncateSingleLine(card.status)

    card:SetScript("OnEnter", function(self)
        if self.spellID then
            M.ShowNativeSpellTooltip(self, self.spellID, self.abilityName)
        end
    end)
    card:SetScript("OnLeave", function() GameTooltip_Hide() end)

    function card:SetAbilityVisual(name, iconID, priority, enabled, selected, spellID, classification, mechanicType, circleEnabled, ttsEnabled)
        priority = tonumber(priority) or 1
        local color = M.PRIORITY_COLORS[priority] or M.PRIORITY_COLORS[1]
        local mechanicLabel = M.GetMechanicLabel(mechanicType)
        local mechanicColor = M.GetMechanicColor(mechanicType)
        self.abilityName = name or "Ability"
        self.spellID = spellID
        self.icon:SetTexture(iconID or "Interface\\Icons\\INV_Misc_QuestionMark")
        self.title:SetText(self.abilityName)
        self.title:SetTextColor(color[1], color[2], color[3], 1)
        self.leftBar:SetColorTexture(color[1], color[2], color[3], 1)
        self.badge:SetText("")
        self.badge:Hide()
        local statusText = enabled and "|cff55ff55TRACK|r" or "|cff888888OFF|r"
        statusText = statusText .. "  " .. (circleEnabled and "Circle" or "No Circle")
        statusText = statusText .. "  " .. (ttsEnabled and "TTS" or "No TTS")
        self.status:SetText(statusText)
        self:SetAlpha(classification == "CLUTTER" and 0.55 or 1)
        if selected then
            self:SetBackdropColor(0.20, 0.025, 0.035, 0.98)
            self:SetBackdropBorderColor(color[1], color[2], color[3], 1)
        else
            self:SetBackdropColor(0.015, 0.008, 0.012, 0.76)
            self:SetBackdropBorderColor(color[1] * 0.62, color[2] * 0.62, color[3] * 0.62, 0.95)
        end
    end

    return card
end

function M.CreateRoleSelector(parent, onChanged)
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(382, 24)

    holder.label = CreateLabel(holder, "Role:", "GameFontHighlightSmall")
    holder.label:SetPoint("LEFT", 0, 0)

    holder.buttons = {}
    local specs = {
        { profile = "AUTO", text = "Auto", width = 82 },
        { profile = "TANK", text = "Tank", width = 52 },
        { profile = "HEALER", text = "Healer", width = 58 },
        { profile = "DAMAGER", text = "DPS", width = 50 },
        { profile = "ALL", text = "All", width = 48 },
    }

    local previous
    for _, spec in ipairs(specs) do
        local button = CreateButton(holder, spec.text, spec.width, 22)
        if previous then
            button:SetPoint("LEFT", previous, "RIGHT", 4, 0)
        else
            button:SetPoint("LEFT", holder.label, "RIGHT", 7, 0)
        end
        button.profile = spec.profile
        holder.buttons[spec.profile] = button
        previous = button

        button:SetScript("OnClick", function(self)
            CT:SetRoleProfile(self.profile)
            holder:Refresh()
            if type(onChanged) == "function" then onChanged() end
        end)
        button:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:AddLine("Mechanic role profile", 1, 0.25, 0.25)
            GameTooltip:AddLine("Auto follows your current specialization. Tank, Healer, and DPS show only important mechanics relevant to that role by default.", 1, 1, 1, true)
            GameTooltip:AddLine("All enables every cataloged ability. Manual ability choices always override the profile.", 0.65, 0.9, 1, true)
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", GameTooltip_Hide)
    end

    function holder:Refresh()
        local saved = CT:GetRoleProfile()
        for profile, button in pairs(self.buttons) do
            if type(CT.ApplyClassTabStyle) == "function" then
                CT:ApplyClassTabStyle(button, profile == saved)
            elseif type(CT.ApplyClassButtonStyle) == "function" then
                CT:ApplyClassButtonStyle(button, profile == saved)
            end
        end

        local auto = self.buttons.AUTO
        if auto then
            local effective = CT:GetEffectiveRole()
            auto:SetText(effective and ("Auto: " .. CT:GetRoleLabel(effective)) or "Auto")
        end
    end

    holder:SetScript("OnShow", function(self) self:Refresh() end)
    holder:Refresh()
    return holder
end

function M.CreateDetailPanel(parent)
    local panel = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    MakeBackdrop(panel, 0.82)
    panel.context = nil

    panel.icon = panel:CreateTexture(nil, "ARTWORK")
    panel.icon:SetSize(52, 52)
    panel.icon:SetPoint("TOPLEFT", 12, -12)
    panel.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    panel.title = CreateLabel(panel, "Select an ability", "GameFontNormalHuge")
    panel.title:SetPoint("TOPLEFT", panel.icon, "TOPRIGHT", 10, 1)
    panel.title:SetPoint("RIGHT", -12, 0)
    panel.title:SetJustifyH("LEFT")
    TruncateSingleLine(panel.title)

    panel.owner = CreateLabel(panel, "", "GameFontHighlightSmall")
    panel.owner:SetPoint("TOPLEFT", panel.title, "BOTTOMLEFT", 0, -4)
    panel.owner:SetPoint("RIGHT", -12, 0)
    panel.owner:SetJustifyH("LEFT")
    TruncateSingleLine(panel.owner)

    -- Recommendation reasoning is not shown in the simplified panel; Spell ID
    -- (created below) uses this line's old position instead.
    panel.meta = CreateLabel(panel, "", "GameFontDisableSmall")
    panel.meta:SetPoint("TOPLEFT", panel.owner, "BOTTOMLEFT", 0, -3)
    panel.meta:SetPoint("RIGHT", -12, 0)
    panel.meta:SetJustifyH("LEFT")
    panel.meta:SetWordWrap(false)
    panel.meta:Hide()

    panel.badges = CreateLabel(panel, "", "GameFontHighlightSmall")
    panel.badges:SetPoint("TOPLEFT", panel.icon, "TOPRIGHT", 10, -31)
    panel.badges:SetPoint("RIGHT", -12, 0)
    panel.badges:SetJustifyH("LEFT")
    panel.badges:SetWordWrap(false)
    panel.badges:Hide()

    panel.whatTitle = CreateLabel(panel, "What it does (Blizzard)", "GameFontNormal")
    panel.whatTitle:SetPoint("TOPLEFT", 12, -96)
    panel.whatTitle:SetTextColor(1, 0.82, 0.25, 1)

    panel.descriptionScroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    panel.descriptionScroll:SetPoint("TOPLEFT", 12, -116)
    panel.descriptionScroll:SetPoint("BOTTOMRIGHT", -28, 188)

    panel.descriptionChild = CreateFrame("Frame", nil, panel.descriptionScroll)
    panel.descriptionChild:SetSize(1, 1)
    panel.descriptionScroll:SetScrollChild(panel.descriptionChild)
    M.EnhanceScrollFrame(panel.descriptionScroll)

    panel.description = CreateLabel(panel.descriptionChild, "", "GameFontHighlightSmall")
    panel.description:SetPoint("TOPLEFT", 0, 0)
    panel.description:SetJustifyH("LEFT")
    panel.description:SetJustifyV("TOP")
    panel.description:SetWordWrap(true)
    panel.description:SetSpacing(2)

    local function ResizeDescription()
        local width = panel.descriptionScroll:GetWidth()
        if not width or width <= 1 then width = 440 end
        width = math.max(80, width - 4)
        panel.descriptionChild:SetWidth(width)
        panel.description:SetWidth(width)
        local height = panel.description:GetStringHeight() or 1
        panel.descriptionChild:SetHeight(math.max(1, height + 8))
    end
    panel.descriptionScroll:SetScript("OnSizeChanged", ResizeDescription)

    panel.separator = panel:CreateTexture(nil, "ARTWORK")
    panel.separator:SetHeight(1)
    panel.separator:SetPoint("BOTTOMLEFT", 12, 178)
    panel.separator:SetPoint("BOTTOMRIGHT", -12, 178)
    panel.separator:SetColorTexture(0.55, 0.06, 0.08, 0.8)

    panel.settingsTitle = CreateLabel(panel, "Settings", "GameFontNormal")
    panel.settingsTitle:SetPoint("BOTTOMLEFT", 12, 168)
    panel.settingsTitle:SetTextColor(0.45, 0.95, 1.0, 1)

    panel.helpButton = CreateButton(panel, "?", 24, 22)
    panel.helpButton:SetPoint("LEFT", panel.settingsTitle, "RIGHT", 6, 0)
    panel.helpButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Ability settings help", 1, 0.25, 0.25)
        GameTooltip:AddLine("Output chooses Circle, Timeline, Both, or Disabled for this ability. Inherit follows the global ChayAlert HUD display setting.", 1, 1, 1, true)
        GameTooltip:AddLine("Type controls the timeline category. Auto uses ChayAlert HUD's conservative mechanic classification.", 1, 1, 1, true)
        GameTooltip:AddLine("Blank Action label uses Blizzard's spell name. You can enter short action text such as DODGE or FRONTAL.", 1, 1, 1, true)
        GameTooltip:AddLine("Lead is 3–30 seconds for predictive boss/raid timeline events. Trash uses the live cast or channel duration.", 1, 1, 1, true)
        GameTooltip:AddLine("T / H / D toggles which roles ChayAlert HUD treats this ability as relevant for. Reset Ability restores the Chay Recommended roles.", 1, 1, 1, true)
        GameTooltip:AddLine("Reset Ability removes only this ability's manual overrides and returns it to the active role profile.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.helpButton:SetScript("OnLeave", GameTooltip_Hide)

    local DISPLAY_ORDER = { "INHERIT", "CIRCLE", "NONE" }
    local DISPLAY_LABELS = {
        INHERIT = "Inherit",
        CIRCLE = "Circle",
        NONE = "Disabled",
    }
    local TYPE_ORDER = { "AUTO", "INTERRUPT", "TANK", "AOE_DAMAGE", "UTILITY", "OTHER" }
    local TYPE_LABELS = {
        AUTO = "Auto",
        INTERRUPT = "Interrupt",
        TANK = "Tank",
        AOE_DAMAGE = "AOE/Damage",
        UTILITY = "Utility",
        OTHER = "Other",
    }
    local TYPE_SHORT = {
        INTERRUPT = "Int",
        TANK = "Tank",
        AOE_DAMAGE = "AOE",
        UTILITY = "Util",
        OTHER = "Other",
    }

    local function NextValue(order, current)
        for index, value in ipairs(order) do
            if value == current then
                return order[(index % #order) + 1]
            end
        end
        return order[1]
    end

    panel.typeButton = CreateButton(panel, "Type: Auto", 118, 22)
    panel.typeButton:SetPoint("BOTTOMRIGHT", -12, 214)

    panel.displayButton = CreateButton(panel, "Output: Inherit", 110, 22)
    panel.displayButton:SetPoint("RIGHT", panel.typeButton, "LEFT", -5, 0)

    panel.displayButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Ability output", 1, 0.25, 0.25)
        GameTooltip:AddLine("Cycles Inherit, Circle, Timeline, Both, and Disabled. Inherit uses the global alert display setting.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.displayButton:SetScript("OnLeave", GameTooltip_Hide)

    panel.typeButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Timeline category", 1, 0.25, 0.25)
        GameTooltip:AddLine("Auto uses the mechanic type inferred from ChayAlert HUD's own metadata. Manual choices control the timeline lane/badge only.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.typeButton:SetScript("OnLeave", GameTooltip_Hide)

    local ROLE_BUTTON_ORDER = { "TANK", "HEALER", "DAMAGER" }
    local ROLE_BUTTON_LABELS = { TANK = "Tank", HEALER = "Healer", DAMAGER = "DPS" }

    panel.roleLabel = CreateLabel(panel, "Roles", "GameFontHighlightSmall")
    panel.roleLabel:SetPoint("BOTTOMLEFT", 12, 183)

    panel.roleButtons = {}
    local previousRoleButton
    for _, role in ipairs(ROLE_BUTTON_ORDER) do
        local button = CreateButton(panel, role:sub(1, 1), 24, 22)
        if previousRoleButton then
            button:SetPoint("LEFT", previousRoleButton, "RIGHT", 3, 0)
        else
            button:SetPoint("LEFT", panel.roleLabel, "RIGHT", 8, 0)
        end
        button.role = role
        button:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(ROLE_BUTTON_LABELS[self.role] or self.role, 1, 0.25, 0.25)
            GameTooltip:AddLine("Toggle whether ChayAlert HUD treats this ability as relevant for this role. Reset Ability restores the Chay Recommended roles.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", GameTooltip_Hide)
        panel.roleButtons[role] = button
        previousRoleButton = button
    end

    panel.roleStatus = CreateLabel(panel, "", "GameFontDisableSmall")
    panel.roleStatus:SetPoint("LEFT", previousRoleButton, "RIGHT", 10, 0)
    panel.roleStatus:SetPoint("RIGHT", -12, 0)
    panel.roleStatus:SetJustifyH("LEFT")
    panel.roleStatus:SetWordWrap(false)

    panel.track = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    panel.track:SetSize(24, 24)
    panel.track:SetPoint("BOTTOMLEFT", 10, 157)
    panel.trackText = CreateLabel(panel, "Enable ability", "GameFontHighlight")
    panel.trackText:SetPoint("LEFT", panel.track, "RIGHT", 0, 0)

    panel.sound = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    panel.sound:SetSize(24, 24)
    panel.sound:SetPoint("LEFT", panel.trackText, "RIGHT", 36, 0)
    panel.soundText = CreateLabel(panel, "Play sound", "GameFontHighlight")
    panel.soundText:SetPoint("LEFT", panel.sound, "RIGHT", 0, 0)

    panel.tts = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    panel.tts:SetSize(24, 24)
    panel.tts:SetPoint("LEFT", panel.soundText, "RIGHT", 36, 0)
    panel.ttsText = CreateLabel(panel, "TTS announce", "GameFontHighlight")
    panel.ttsText:SetPoint("LEFT", panel.tts, "RIGHT", 0, 0)

    panel.circle = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    panel.circle:SetSize(24, 24)
    panel.circle:SetPoint("BOTTOMLEFT", 10, 90)
    panel.circleText = CreateLabel(panel, "Show Circle", "GameFontHighlight")
    panel.circleText:SetPoint("LEFT", panel.circle, "RIGHT", 0, 0)

    panel.why = CreateLabel(panel, "", "GameFontDisableSmall")
    panel.why:SetPoint("BOTTOMLEFT", 12, 127)
    panel.why:SetPoint("BOTTOMRIGHT", -178, 127)
    panel.why:SetHeight(26)
    panel.why:SetJustifyH("LEFT")
    panel.why:SetJustifyV("MIDDLE")
    panel.why:SetWordWrap(true)

    panel.ttsPhraseEdit = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    panel.ttsPhraseEdit:SetSize(150, 24)
    panel.ttsPhraseEdit:SetPoint("BOTTOMRIGHT", -12, 127)
    panel.ttsPhraseEdit:SetAutoFocus(false)
    panel.ttsPhraseEdit:SetMaxLetters(64)
    panel.ttsPhraseEdit.Instructions = panel.ttsPhraseEdit:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    panel.ttsPhraseEdit.Instructions:SetPoint("LEFT", 5, 0)
    panel.ttsPhraseEdit.Instructions:SetText("TTS Callout")
    panel.ttsPhraseEdit:SetScript("OnTextChanged", function(self)
        self.Instructions:SetShown(self:GetText() == "")
    end)

    panel.importanceLabel = CreateLabel(panel, "Importance", "GameFontHighlightSmall")
    panel.importanceLabel:SetPoint("BOTTOMLEFT", 12, 104)

    panel.priorityButtons = {}
    local previousPriority
    for priority = 1, 3 do
        local button = CreateButton(panel, M.PRIORITY_LABELS[priority], 84, 22)
        if previousPriority then
            button:SetPoint("LEFT", previousPriority, "RIGHT", 4, 0)
        else
            button:SetPoint("LEFT", panel.importanceLabel, "RIGHT", 10, 0)
        end
        button.priority = priority
        panel.priorityButtons[priority] = button
        previousPriority = button
    end

    panel.labelTitle = CreateLabel(panel, "Action label", "GameFontHighlightSmall")
    panel.labelTitle:SetPoint("BOTTOMLEFT", 12, 72)

    panel.labelEdit = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    panel.labelEdit:SetSize(230, 24)
    panel.labelEdit:SetPoint("LEFT", panel.labelTitle, "RIGHT", 10, 0)
    panel.labelEdit:SetAutoFocus(false)
    panel.labelEdit:SetMaxLetters(48)

    panel.applyLabel = CreateButton(panel, "Apply", 54, 22)
    panel.applyLabel:SetPoint("LEFT", panel.labelEdit, "RIGHT", 6, 0)

    panel.ttsCalloutTitle = CreateLabel(panel, "TTS Callout", "GameFontHighlightSmall")
    panel.ttsCalloutTitle:SetPoint("BOTTOMLEFT", 12, 127)
    panel.ttsPhraseEdit:ClearAllPoints()
    panel.ttsPhraseEdit:SetPoint("LEFT", panel.ttsCalloutTitle, "RIGHT", 10, 0)
    panel.applyTTSCallout = CreateButton(panel, "Apply", 54, 22)
    panel.applyTTSCallout:SetPoint("LEFT", panel.ttsPhraseEdit, "RIGHT", 6, 0)

    panel.leadTitle = CreateLabel(panel, "Lead", "GameFontHighlightSmall")
    panel.leadTitle:SetPoint("BOTTOMLEFT", 12, 40)

    panel.leadEdit = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    panel.leadEdit:SetSize(44, 24)
    panel.leadEdit:SetPoint("LEFT", panel.leadTitle, "RIGHT", 8, 0)
    panel.leadEdit:SetAutoFocus(false)
    panel.leadEdit:SetNumeric(true)
    panel.leadEdit:SetMaxLetters(2)

    panel.leadSec = CreateLabel(panel, "sec", "GameFontDisableSmall")
    panel.leadSec:SetPoint("LEFT", panel.leadEdit, "RIGHT", 4, 0)

    panel.timingText = CreateLabel(panel, "Timing: live cast/channel", "GameFontDisableSmall")
    panel.timingText:SetPoint("BOTTOMLEFT", 12, 42)
    panel.timingText:SetWordWrap(false)

    panel.ids = CreateLabel(panel, "", "GameFontDisableSmall")
    panel.ids:SetPoint("TOPLEFT", panel.owner, "BOTTOMLEFT", 0, -3)
    panel.ids:SetPoint("RIGHT", -12, 0)
    panel.ids:SetJustifyH("LEFT")
    TruncateSingleLine(panel.ids)

    panel.preview = CreateButton(panel, "Preview Circle", 112, 24)
    panel.preview:SetPoint("BOTTOMLEFT", 12, 8)

    panel.previewTimeline = CreateButton(panel, "Preview Timeline", 122, 24)
    panel.previewTimeline:SetPoint("LEFT", panel.preview, "RIGHT", 8, 0)

    panel.reset = CreateButton(panel, "Reset Ability", 108, 24)
    panel.reset:SetPoint("LEFT", panel.previewTimeline, "RIGHT", 8, 0)

    panel.voicePreview = CreateLabel(panel, "Voice Preview: Unavailable", "GameFontDisableSmall")
    panel.voicePreview:SetPoint("BOTTOMLEFT", 12, 36)
    panel.voicePreview:SetPoint("RIGHT", -12, 0)
    panel.voicePreview:SetJustifyH("LEFT")
    panel.voicePreview:SetWordWrap(false)

    for _, control in ipairs({
        panel.displayButton, panel.typeButton, panel.roleLabel, panel.roleStatus,
        panel.sound, panel.soundText, panel.why, panel.ttsPhraseEdit,
        panel.ttsCalloutTitle, panel.applyTTSCallout, panel.importanceLabel,
        panel.labelTitle, panel.labelEdit, panel.applyLabel, panel.leadTitle,
        panel.leadEdit, panel.leadSec, panel.timingText,
        panel.voicePreview, panel.previewTimeline,
    }) do
        control:Hide()
    end
    for _, button in pairs(panel.roleButtons) do button:Hide() end
    for _, button in ipairs(panel.priorityButtons) do button:Hide() end
    panel.trackText:SetText("Track Ability")
    panel.track:ClearAllPoints()
    panel.track:SetPoint("BOTTOMLEFT", 10, 128)
    panel.ttsText:SetText("TTS - Spell Name")
    panel.tts:ClearAllPoints()
    panel.tts:SetPoint("BOTTOMLEFT", 10, 52)
    panel.ttsText:SetPoint("LEFT", panel.tts, "RIGHT", 0, 0)
    panel.preview:ClearAllPoints()
    panel.preview:SetPoint("BOTTOMLEFT", 12, 8)
    panel.reset:ClearAllPoints()
    panel.reset:SetPoint("LEFT", panel.preview, "RIGHT", 10, 0)

    panel.iconHit = CreateFrame("Button", nil, panel)
    panel.iconHit:SetAllPoints(panel.icon)
    panel.iconHit:SetScript("OnEnter", function(self)
        local ctx = panel.context
        if ctx and ctx.primarySpellID then
            M.ShowNativeSpellTooltip(self, ctx.primarySpellID, ctx.name)
        end
    end)
    panel.iconHit:SetScript("OnLeave", function() GameTooltip_Hide() end)

    panel.track:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Enable ability", 1, 0.25, 0.25)
        GameTooltip:AddLine("Manual choices override the active Tank, Healer, or DPS profile for this ability. Disabled abilities can still be observed internally for safe runtime sequencing, but they are not shown.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.track:SetScript("OnLeave", GameTooltip_Hide)

    panel.sound:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Play sound", 1, 0.25, 0.25)
        GameTooltip:AddLine("Controls ChayAlert HUD's alert/countdown sounds for this ability. It does not change Blizzard or other addons' sounds.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.sound:SetScript("OnLeave", GameTooltip_Hide)

    for _, priorityButton in ipairs(panel.priorityButtons) do
        priorityButton:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Alert importance", 1, 0.25, 0.25)
            GameTooltip:AddLine("Critical sorts ahead of High, which sorts ahead of Optional when more mechanics are active than the selected renderer can display.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        priorityButton:SetScript("OnLeave", GameTooltip_Hide)
    end

    panel.leadEdit:SetScript("OnEnter", function(self)
        if self:IsShown() then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Lead time", 1, 0.25, 0.25)
            GameTooltip:AddLine("How many seconds before a predictive boss/raid timeline event the circle may appear. Trash uses the mob's actual cast/channel time instead.", 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    panel.leadEdit:SetScript("OnLeave", GameTooltip_Hide)

    local function RefreshControls()
        local ctx = panel.context
        if not ctx then return end
        local cfg = type(ctx.getConfig) == "function" and ctx.getConfig() or nil
        local priority = cfg and tonumber(cfg.priority) or 1
        local color = M.PRIORITY_COLORS[priority] or M.PRIORITY_COLORS[1]
        local mechanicType = cfg and cfg.mechanicType or "OTHER"
        local mechanicLabel = M.GetMechanicLabel(mechanicType)
        local mechanicColor = M.GetMechanicColor(mechanicType)

        panel.track:SetChecked(cfg and cfg.enabled ~= false or false)
        panel.sound:SetChecked(cfg and cfg.sound ~= false or false)
        panel.tts:SetChecked(cfg and cfg.ttsEnabled == true or false)
        local effectiveDisplayMode = cfg and type(cfg.effectiveDisplayMode) == "string"
            and cfg.effectiveDisplayMode:upper() or "CIRCLE"
        panel.circle:SetChecked(effectiveDisplayMode == "CIRCLE" or effectiveDisplayMode == "BOTH")

        local displayMode = cfg and type(cfg.displayMode) == "string" and cfg.displayMode:upper() or "INHERIT"
        if not DISPLAY_LABELS[displayMode] then displayMode = "INHERIT" end
        panel.displayButton.displayMode = displayMode
        if displayMode == "INHERIT" then
            local effective = cfg and type(cfg.effectiveDisplayMode) == "string" and cfg.effectiveDisplayMode:upper() or nil
            local effectiveLabel = effective and DISPLAY_LABELS[effective]
            panel.displayButton:SetText(effectiveLabel and ("Output: Inherit (" .. effectiveLabel .. ")") or "Output: Inherit")
        else
            panel.displayButton:SetText("Output: " .. (DISPLAY_LABELS[displayMode] or "Circle"))
        end

        local mechanicOverride = cfg and type(cfg.mechanicTypeOverride) == "string" and cfg.mechanicTypeOverride:upper() or "AUTO"
        if not TYPE_LABELS[mechanicOverride] then mechanicOverride = "AUTO" end
        panel.typeButton.mechanicType = mechanicOverride
        local typeText = TYPE_LABELS[mechanicOverride] or "Auto"
        if mechanicOverride == "AUTO" and cfg and type(cfg.mechanicType) == "string" then
            typeText = "Auto: " .. (TYPE_SHORT[cfg.mechanicType] or "Other")
        end
        panel.typeButton:SetText("Type: " .. typeText)

        panel.title:SetTextColor(color[1], color[2], color[3], 1)
        panel.badges:SetText((M.PRIORITY_LABELS[priority] or "Optional") .. "  |  " .. mechanicLabel)
        panel.badges:SetTextColor(mechanicColor[1], mechanicColor[2], mechanicColor[3], 1)
        panel.whatTitle:SetTextColor(color[1], color[2], color[3], 1)

        for p, button in ipairs(panel.priorityButtons) do
            local c = M.PRIORITY_COLORS[p]
            local fs = button:GetFontString()
            if fs then
                if p == priority then
                    fs:SetTextColor(c[1], c[2], c[3], 1)
                else
                    fs:SetTextColor(0.72, 0.72, 0.72, 1)
                end
            end
        end

        local tank, healer, damager = CT:RoleOverrideFlags(cfg and cfg.roles)
        local roleFlagLookup = { TANK = tank, HEALER = healer, DAMAGER = damager }
        for role, button in pairs(panel.roleButtons) do
            local fs = button:GetFontString()
            if fs then
                if roleFlagLookup[role] then
                    fs:SetTextColor(1, 0.22, 0.22, 1)
                else
                    fs:SetTextColor(0.6, 0.6, 0.6, 1)
                end
            end
        end
        panel.roleStatus:SetText(cfg and cfg.rolesIsCustom and "Custom" or "Chay Recommended")

        panel.labelEdit:SetText(cfg and cfg.label or "")
        panel.ttsPhraseEdit:SetText(cfg and cfg.ttsPhrase or "")
        local previewPhrase
        if CT.TTS and type(CT.TTS.BuildAbilityCallout) == "function" then
            previewPhrase = CT.TTS:BuildAbilityCallout({
                catalogSpellID = ctx.primarySpellID,
                catalogSpellName = ctx.name,
                spellName = ctx.name,
            })
        end
        if panel.voicePreview then panel.voicePreview:SetText("Voice Preview: " .. (previewPhrase or "Unavailable")) end

        local roleText
        if cfg and cfg.important then
            local roles = CT:GetRolesLabel(cfg.roles)
            if cfg.roleRelevant == false and not cfg.hasEnabledOverride then
                roleText = "Important for: " .. roles .. "  •  hidden by " .. CT:GetRoleProfileLabel()
            else
                roleText = "Important for: " .. roles
                if cfg.reason and cfg.reason ~= "" then
                    roleText = roleText .. "  •  " .. cfg.reason
                end
            end
        else
            roleText = "Optional catalog ability  •  no automatic alert"
        end
        if cfg and cfg.hasEnabledOverride then
            roleText = roleText .. "  •  manual override"
        end
        panel.why:SetText(roleText)
        panel.why:SetTextColor(color[1], color[2], color[3], 1)

        -- Lead time / timing text belong to the retired detailed editor and
        -- must stay hidden permanently in the simplified panel.
    end

    panel.displayButton:SetScript("OnClick", function(self)
        local ctx = panel.context
        if not ctx or type(ctx.setDisplayMode) ~= "function" then return end
        local current = type(self.displayMode) == "string" and self.displayMode or "INHERIT"
        ctx.setDisplayMode(NextValue(DISPLAY_ORDER, current))
        if type(ctx.onChanged) == "function" then ctx.onChanged() end
        RefreshControls()
    end)

    panel.typeButton:SetScript("OnClick", function(self)
        local ctx = panel.context
        if not ctx or type(ctx.setMechanicType) ~= "function" then return end
        local current = type(self.mechanicType) == "string" and self.mechanicType or "AUTO"
        ctx.setMechanicType(NextValue(TYPE_ORDER, current))
        if type(ctx.onChanged) == "function" then ctx.onChanged() end
        RefreshControls()
    end)

    for role, button in pairs(panel.roleButtons) do
        button:SetScript("OnClick", function()
            local ctx = panel.context
            if not ctx or type(ctx.setRoles) ~= "function" then return end
            local cfg = type(ctx.getConfig) == "function" and ctx.getConfig() or nil
            local tank, healer, damager = CT:RoleOverrideFlags(cfg and cfg.roles)
            if role == "TANK" then tank = not tank
            elseif role == "HEALER" then healer = not healer
            else damager = not damager end
            ctx.setRoles(CT:BuildRoleOverrideFromFlags(tank, healer, damager))
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end)
    end

    panel.track:SetScript("OnClick", function(self)
        local ctx = panel.context
        if ctx and type(ctx.setEnabled) == "function" then
            ctx.setEnabled(self:GetChecked() == true)
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end)

    panel.circle:SetScript("OnClick", function(self)
        local ctx = panel.context
        if ctx and type(ctx.setDisplayMode) == "function" then
            ctx.setDisplayMode(self:GetChecked() == true and "CIRCLE" or "NONE")
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end)
    panel.circle:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Show Circle", 1, 0.25, 0.25)
        GameTooltip:AddLine("Shows this ability in the existing ChayAlert Circle renderer when Track Ability is enabled.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.circle:SetScript("OnLeave", GameTooltip_Hide)

    panel.sound:SetScript("OnClick", function(self)
        local ctx = panel.context
        if ctx and type(ctx.setSound) == "function" then
            ctx.setSound(self:GetChecked() == true)
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end)

    panel.tts:SetScript("OnClick", function(self)
        local ctx = panel.context
        if ctx and type(ctx.setTTS) == "function" then
            ctx.setTTS(self:GetChecked() == true)
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end)
    panel.tts:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("TTS announce", 1, 0.25, 0.25)
        GameTooltip:AddLine("Controls TTS for this ability only.", 1, 1, 1, true)
        GameTooltip:AddLine("The global Enable TTS option on Sounds & Media is the master mute switch.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.tts:SetScript("OnLeave", GameTooltip_Hide)
    panel.ttsPhraseEdit:SetScript("OnEnterPressed", function(self)
        local ctx = panel.context
        if ctx and type(ctx.setTTS) == "function" then
            -- Only the phrase changed here; leave the enabled override untouched.
            ctx.setTTS(nil, self:GetText())
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
        self:ClearFocus()
    end)

    local function ApplyTTSCallout(value)
        local ctx = panel.context
        if ctx and type(ctx.setTTS) == "function" then
            ctx.setTTS(nil, Trim(value))
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end

    panel.applyTTSCallout:SetScript("OnClick", function()
        ApplyTTSCallout(panel.ttsPhraseEdit:GetText())
        panel.ttsPhraseEdit:ClearFocus()
    end)
    panel.ttsPhraseEdit:SetScript("OnEditFocusLost", function(self)
        local ctx = panel.context
        if ctx and type(ctx.setTTS) == "function" then
            ctx.setTTS(nil, self:GetText())
        end
    end)

    for _, button in ipairs(panel.priorityButtons) do
        button:SetScript("OnClick", function(self)
            local ctx = panel.context
            if ctx and type(ctx.setPriority) == "function" then
                ctx.setPriority(self.priority)
                if type(ctx.onChanged) == "function" then ctx.onChanged() end
                RefreshControls()
            end
        end)
    end

    local function ApplyLabel(value)
        local ctx = panel.context
        if ctx and type(ctx.setLabel) == "function" then
            ctx.setLabel(Trim(value))
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end

    panel.applyLabel:SetScript("OnClick", function()
        ApplyLabel(panel.labelEdit:GetText())
        panel.labelEdit:ClearFocus()
    end)
    panel.labelEdit:SetScript("OnEnterPressed", function(self)
        ApplyLabel(self:GetText())
        self:ClearFocus()
    end)
    panel.labelEdit:SetScript("OnEscapePressed", function(self)
        RefreshControls()
        self:ClearFocus()
    end)

    local function ApplyLead(value)
        local ctx = panel.context
        if not ctx or type(ctx.setLeadTime) ~= "function" then return end
        local seconds = tonumber(value)
        if not seconds then
            RefreshControls()
            return
        end
        seconds = math.max(3, math.min(30, math.floor(seconds + 0.5)))
        ctx.setLeadTime(seconds)
        if type(ctx.onChanged) == "function" then ctx.onChanged() end
        RefreshControls()
    end

    panel.leadEdit:SetScript("OnEnterPressed", function(self)
        ApplyLead(self:GetText())
        self:ClearFocus()
    end)
    panel.leadEdit:SetScript("OnEscapePressed", function(self)
        RefreshControls()
        self:ClearFocus()
    end)
    panel.leadEdit:SetScript("OnEditFocusLost", function(self)
        if panel.context and type(panel.context.setLeadTime) == "function" then
            ApplyLead(self:GetText())
        end
    end)

    panel.preview:SetScript("OnClick", function()
        local ctx = panel.context
        if not ctx then return end
        if type(CT.PreviewAbility) == "function" then
            CT:PreviewAbility(ctx.name, 7)
        end
    end)

    panel.previewTimeline:SetText("Preview Voice")
    panel.previewTimeline:SetScript("OnClick", function()
        local ctx = panel.context
        if not ctx then return end
        local cfg = type(ctx.getConfig) == "function" and ctx.getConfig() or nil
        if CT.TTS and type(CT.TTS.PreviewAbility) == "function" then
            CT.TTS:PreviewAbility({
                catalogSpellID = ctx.primarySpellID,
                catalogSpellName = ctx.name,
                spellName = ctx.name,
            })
        end
    end)
    panel.previewTimeline:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Preview Voice", 1, 0.25, 0.25)
        GameTooltip:AddLine("Speaks the exact phrase currently resolved for this ability.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    panel.previewTimeline:SetScript("OnLeave", GameTooltip_Hide)

    panel.reset:SetScript("OnClick", function()
        local ctx = panel.context
        if ctx and type(ctx.reset) == "function" then
            ctx.reset()
            if type(ctx.onChanged) == "function" then ctx.onChanged() end
            RefreshControls()
        end
    end)

    function panel:SetContext(ctx)
        self.context = ctx
        if not ctx then
            self.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
            self.title:SetText("Select an ability")
            self.owner:SetText("")
            self.meta:SetText("")
            self.badges:SetText("")
            self.whatTitle:SetTextColor(1, 0.82, 0.25, 1)
            self.why:SetTextColor(0.75, 0.75, 0.75, 1)
            self.description:SetText("Select an ability above to see Blizzard's description and configure its ChayAlert HUD alerts.")
            self.ids:SetText("")
            self.why:SetText("")
            self.track:SetChecked(false)
            self.sound:SetChecked(false)
            self.tts:SetChecked(false)
            self.ttsPhraseEdit:SetText("")
            self.displayButton.displayMode = "INHERIT"
            self.displayButton:SetText("Output: Inherit")
            self.typeButton.mechanicType = "AUTO"
            self.typeButton:SetText("Type: Auto")
            for _, button in pairs(self.roleButtons) do
                local fs = button:GetFontString()
                if fs then fs:SetTextColor(0.6, 0.6, 0.6, 1) end
            end
            self.roleStatus:SetText("")
            self.labelEdit:SetText("")
            ResizeDescription()
            return
        end

        self.icon:SetTexture(ctx.iconID or "Interface\\Icons\\INV_Misc_QuestionMark")
        self.title:SetText(ctx.name or "Ability")
        self.owner:SetText(ctx.ownerText or "")
        self.meta:SetText(ctx.metaText or "")
        self.description:SetText(M.GetSpellDescription(ctx.primarySpellID))
        self.descriptionScroll:SetVerticalScroll(0)
        ResizeDescription()

        local ids = {}
        for _, spellID in ipairs(ctx.spellIDs or {}) do
            ids[#ids + 1] = tostring(spellID)
        end
        if #ids > 0 then
            self.ids:SetText("Spell ID" .. (#ids > 1 and "s" or "") .. ": " .. table.concat(ids, ", "))
        else
            self.ids:SetText("")
        end

        RefreshControls()
    end

    panel.RefreshControls = RefreshControls
    panel:SetContext(nil)
    return panel
end

return M
