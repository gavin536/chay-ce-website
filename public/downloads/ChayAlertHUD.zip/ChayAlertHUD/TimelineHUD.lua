local CT = _G.ChayAlertHUD
if not CT then return end

-- Thin Timeline HUD renderer.
-- Runtime mechanic discovery/timing stays in ChayAlertHUD.lua + MechanicRouter.
-- This file only renders the same normalized mechanics that feed the circles.
-- It does not maintain an independent combat timer model.
local HUD = {}
CT.TimelineHUD = HUD
_G.ChayAlertHUDTimelineHUD = HUD

local frame
local entries = {}
local railLines = {}
local railBackgrounds = {}
local lastMechanics
local previewActive = false
local previewData
local previewStartedAt = 0
local hasActiveMechanics = false

local LANE_ORDER = { "INTERRUPT", "TANK", "AOE_DAMAGE", "UTILITY", "OTHER" }
local LANE_LABELS = {
    INTERRUPT = "INTERRUPT",
    TANK = "TANK",
    AOE_DAMAGE = "AOE / DAMAGE",
    UTILITY = "UTILITY",
    OTHER = "OTHER",
}

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value) or false
end

local function HasValue(value)
    if IsSecret(value) then return true end
    return value ~= nil
end

local function PublicNumber(value)
    if IsSecret(value) or type(value) ~= "number" then return nil end
    return value
end

local function Clamp(value, lo, hi, fallback)
    value = tonumber(value)
    if value == nil then value = fallback or lo end
    if value < lo then value = lo end
    if value > hi then value = hi end
    return value
end

local function ResolveTrackTexture(name)
    if type(name) ~= "string" or name == "" then name = "Solid" end
    if name == "Solid" then return "Interface\\Buttons\\WHITE8x8" end

    local stub = _G.LibStub
    local lsm
    if type(stub) == "table" and getmetatable(stub) and getmetatable(stub).__call then
        lsm = stub("LibSharedMedia-3.0", true)
    elseif type(stub) == "function" then
        lsm = stub("LibSharedMedia-3.0", true)
    end
    if lsm and type(lsm.Fetch) == "function" then
        local ok, path = pcall(lsm.Fetch, lsm, "statusbar", name, true)
        if ok and type(path) == "string" and path ~= "" then return path end
    end
    return "Interface\\Buttons\\WHITE8x8"
end

local function ResolveFont(name)
    if type(name) ~= "string" or name == "" or name == "Default" then
        return STANDARD_TEXT_FONT
    end

    local stub = _G.LibStub
    local lsm
    if type(stub) == "table" and getmetatable(stub) and getmetatable(stub).__call then
        lsm = stub("LibSharedMedia-3.0", true)
    elseif type(stub) == "function" then
        lsm = stub("LibSharedMedia-3.0", true)
    end
    if lsm and type(lsm.Fetch) == "function" then
        local ok, path = pcall(lsm.Fetch, lsm, "font", name, true)
        if ok and type(path) == "string" and path ~= "" then return path end
    end
    return STANDARD_TEXT_FONT
end

local function Config()
    local db = type(CT.GetDB) == "function" and CT:GetDB() or nil
    if not db then return nil end
    if type(db.timeline) ~= "table" then db.timeline = {} end
    if type(db.timeline.lanes) ~= "table" then
        db.timeline.lanes = { INTERRUPT = true, TANK = true, AOE_DAMAGE = true, UTILITY = true, OTHER = true }
    end
    return db.timeline
end

local function GetIconDirection(cfg)
    if cfg.orientation == "HORIZONTAL" then
        if cfg.iconDirection == "LEFT_TO_RIGHT" or cfg.iconDirection == "RIGHT_TO_LEFT" then
            return cfg.iconDirection
        end
        return "RIGHT_TO_LEFT"
    end
    if cfg.iconDirection == "TOP_TO_BOTTOM" or cfg.iconDirection == "BOTTOM_TO_TOP" then
        return cfg.iconDirection
    end
    return "TOP_TO_BOTTOM"
end

local function FormatTime(seconds)
    seconds = PublicNumber(seconds)
    if not seconds then return "CAST" end
    if seconds < 0 then seconds = 0 end
    if seconds < 10 then return string.format("%.1f", seconds) end
    return tostring(math.ceil(seconds))
end

local function HideEntry(entry)
    if entry.timerBinding then entry.timerBinding:SetEnabled(false) end
    if entry.cooldown then entry.cooldown:Hide() end
    entry:Hide()
end

local function ApplyFrameConfig()
    if not frame then return end
    local cfg = Config()
    if not cfg then return end

    local width = Clamp(cfg.width, 180, 900, 300)
    local height = Clamp(cfg.height, 160, 900, 420)
    frame:SetSize(width, height)
    frame:SetAlpha(Clamp(cfg.alpha, 0.15, 1, 0.95))

    local unlocked = cfg.locked == false
    frame:EnableMouse(unlocked)
    frame:SetMovable(unlocked)

    if unlocked then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        frame:SetBackdropColor(0.01, 0.005, 0.008, 0.35)
        frame:SetBackdropBorderColor(0.48, 0.035, 0.055, 0.9)
    else
        frame:SetBackdrop(nil)
    end

    if not frame._dragging then
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "CENTER", tonumber(cfg.x) or 360, tonumber(cfg.y) or 0)
    end
end

local function AttachOffsetDrag(mover, xField, yField)
    mover:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        local cfg = Config()
        if not cfg or cfg.locked ~= false then return end

        local scale = UIParent:GetEffectiveScale() or 1
        local x, y = GetCursorPosition()
        self._startCursorX = x / scale
        self._startCursorY = y / scale
        self._startX = Clamp(cfg[xField], -400, 400, 0)
        self._startY = Clamp(cfg[yField], -400, 400, 0)
        self._draggingOffset = true
        self:SetScript("OnUpdate", function(driver)
            if not driver._draggingOffset then return end
            local active = Config()
            if not active or active.locked ~= false then
                driver._draggingOffset = false
                driver:SetScript("OnUpdate", nil)
                return
            end
            local activeScale = UIParent:GetEffectiveScale() or 1
            local cx, cy = GetCursorPosition()
            active[xField] = math.floor(Clamp(driver._startX + ((cx / activeScale) - driver._startCursorX), -400, 400, 0) + 0.5)
            active[yField] = math.floor(Clamp(driver._startY + ((cy / activeScale) - driver._startCursorY), -400, 400, 0) + 0.5)
            HUD:RefreshLayout()
        end)
    end)
    local function stop(self)
        if not self._draggingOffset then return end
        self._draggingOffset = false
        self:SetScript("OnUpdate", nil)
        HUD:RefreshLayout()
    end
    mover:SetScript("OnMouseUp", function(self, button) if button == "LeftButton" then stop(self) end end)
    mover:SetScript("OnHide", stop)
end

local function EnsureFrame()
    if frame then return frame end

    frame = CreateFrame("Frame", "ChayAlertHUDTimelineFrame", UIParent, "BackdropTemplate")
    frame:SetFrameStrata("MEDIUM")
    frame:SetClampedToScreen(true)

    frame.railBackground = frame:CreateTexture(nil, "BACKGROUND", nil, -1)
    frame.rail = frame:CreateTexture(nil, "BACKGROUND")
    for i = 1, 5 do
        railBackgrounds[i] = frame:CreateTexture(nil, "BACKGROUND", nil, -1)
        railLines[i] = frame:CreateTexture(nil, "BACKGROUND")
    end

    frame.laneLabels = {}
    frame.laneMovers = {}
    for _, lane in ipairs(LANE_ORDER) do
        local mover = CreateFrame("Frame", nil, frame)
        mover:SetSize(115, 18)
        mover:SetFrameLevel(frame:GetFrameLevel() + 5)
        AttachOffsetDrag(mover, "laneLabelX", "laneLabelY")
        local label = mover:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        label:SetAllPoints(mover)
        label:SetJustifyH("CENTER")
        label:SetText(LANE_LABELS[lane] or lane)
        frame.laneMovers[lane] = mover
        frame.laneLabels[lane] = label
    end

    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        local cfg = Config()
        if cfg and cfg.locked == false then
            self._dragging = true
            self:StartMoving()
        end
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        self._dragging = false
        local cfg = Config()
        if not cfg then return end
        local x, y = self:GetCenter()
        local px, py = UIParent:GetCenter()
        if type(x) == "number" and type(y) == "number" and type(px) == "number" and type(py) == "number" then
            cfg.x = math.floor((x - px) + 0.5)
            cfg.y = math.floor((y - py) + 0.5)
        end
    end)

    frame:EnableMouseWheel(true)
    frame:SetScript("OnMouseWheel", function(_, delta)
        local cfg = Config()
        if not cfg then return end
        local current = Clamp(cfg.window, 5, 60, 15)
        local nextValue = Clamp(current - delta, 5, 60, current)
        if nextValue ~= current then
            cfg.window = nextValue
            HUD:RefreshLayout()
        end
    end)

    -- Runtime mechanics are refreshed by ChayAlertHUD's existing driver. This
    -- OnUpdate is preview-only and therefore never becomes a second combat timer.
    frame:SetScript("OnUpdate", function()
        if not previewActive or type(previewData) ~= "table" then return end
        local elapsed = GetTime() - previewStartedAt
        if elapsed >= 8 then
            HUD:Clear()
            return
        end
        local moving = {}
        for _, demo in ipairs(previewData) do
            local remaining = math.max(0, demo.previewRemaining - elapsed)
            if remaining > 0 then
                local copy = {}
                for key, value in pairs(demo) do copy[key] = value end
                copy.remaining = remaining
                moving[#moving + 1] = copy
            end
        end
        local wasPreview = previewActive
        previewActive = false
        HUD:Render(moving)
        previewActive = wasPreview
    end)

    frame:Hide()
    ApplyFrameConfig()
    return frame
end

local function AcquireEntry(index)
    local entry = entries[index]
    if entry then return entry end

    local parent = EnsureFrame()
    entry = CreateFrame("Frame", nil, parent)
    entry:SetSize(48, 48)

    entry.icon = entry:CreateTexture(nil, "ARTWORK")
    entry.icon:SetPoint("CENTER")
    entry.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    entry.cooldown = CreateFrame("Cooldown", nil, entry, "CooldownFrameTemplate")
    entry.cooldown:SetPoint("CENTER", entry.icon, "CENTER")
    entry.cooldown:SetDrawEdge(false)
    entry.cooldown:SetDrawBling(false)
    entry.cooldown:SetHideCountdownNumbers(true)
    entry.cooldown:Hide()

    entry.timer = entry:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    entry.timer:SetJustifyH("CENTER")

    if type(C_DurationUtil) == "table" and type(C_DurationUtil.CreateDurationTextBinding) == "function" then
        local ok, binding = pcall(C_DurationUtil.CreateDurationTextBinding)
        if ok and binding then
            binding:SetFontString(entry.timer)
            binding:SetZeroDurationText("")
            binding:SetExpiredText("")
            binding:SetEnabled(false)
            entry.timerBinding = binding
        end
    end

    entry.nameMover = CreateFrame("Frame", nil, entry)
    entry.nameMover:SetSize(140, 18)
    entry.nameMover:SetFrameLevel(entry:GetFrameLevel() + 5)
    AttachOffsetDrag(entry.nameMover, "nameTextX", "nameTextY")

    entry.name = entry.nameMover:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    entry.name:SetAllPoints(entry.nameMover)
    entry.name:SetJustifyH("CENTER")
    entry.name:SetWordWrap(false)

    entries[index] = entry
    return entry
end

local function ActiveLanes(cfg)
    local lanes = {}
    if cfg.layout == "LANES" then
        for _, lane in ipairs(LANE_ORDER) do
            if cfg.lanes[lane] ~= false then lanes[#lanes + 1] = lane end
        end
    end
    if #lanes == 0 then lanes[1] = "OTHER" end
    return lanes
end

local function ConfigureAxis(cfg)
    local f = EnsureFrame()
    local width = Clamp(cfg.width, 180, 900, 300)
    local height = Clamp(cfg.height, 160, 900, 420)
    local trackTexture = ResolveTrackTexture(cfg.trackTexture)
    local thickness = Clamp(cfg.trackThickness, 1, 20, 2)
    local alpha = Clamp(cfg.trackAlpha, 0, 1, 0.72)
    local c = cfg.trackColor or { r = 0.9, g = 0.18, b = 0.12, a = 1 }
    local barFill = cfg.barFillEnabled == true
    local fillColor = barFill and (cfg.barFillColor or c) or c
    local backgroundColor = cfg.barBackgroundColor or { r = 0.05, g = 0.05, b = 0.05, a = 1 }
    local r = Clamp(fillColor.r, 0, 1, 0.9)
    local g = Clamp(fillColor.g, 0, 1, 0.18)
    local b = Clamp(fillColor.b, 0, 1, 0.12)
    local br = Clamp(backgroundColor.r, 0, 1, 0.05)
    local bg = Clamp(backgroundColor.g, 0, 1, 0.05)
    local bb = Clamp(backgroundColor.b, 0, 1, 0.05)
    local fillThickness = thickness
    local backgroundThickness = math.min(24, thickness + 2)

    f.rail:Hide()
    f.railBackground:Hide()
    for i = 1, #railLines do
        railLines[i]:Hide()
        railBackgrounds[i]:Hide()
    end
    for _, mover in pairs(f.laneMovers) do mover:Hide() end

    local orientation = cfg.orientation == "HORIZONTAL" and "HORIZONTAL" or "VERTICAL"
    local lanes = ActiveLanes(cfg)
    local laneMode = cfg.layout == "LANES"
    local railCount = laneMode and #lanes or 1

    local function ConfigureRail(line, background, isVertical, x, y, railLength, leftPad, rightPad)
        line:ClearAllPoints()
        line:SetTexture(trackTexture)
        line:SetTexCoord(0, 1, 0, 1)
        line:SetVertexColor(r, g, b, 1)
        line:SetAlpha(alpha)

        background:ClearAllPoints()
        background:SetTexture("Interface\\Buttons\\WHITE8x8")
        background:SetTexCoord(0, 1, 0, 1)
        background:SetVertexColor(br, bg, bb, 1)
        background:SetAlpha(alpha)

        if isVertical then
            line:SetRotation(math.pi / 2)
            line:SetSize(railLength, fillThickness)
            line:SetPoint("CENTER", f, "TOPLEFT", x, y)
            background:SetRotation(math.pi / 2)
            background:SetSize(railLength, backgroundThickness)
            background:SetPoint("CENTER", f, "TOPLEFT", x, y)
        else
            line:SetRotation(0)
            line:SetPoint("LEFT", f, "BOTTOMLEFT", leftPad, y)
            line:SetPoint("RIGHT", f, "BOTTOMRIGHT", -rightPad, y)
            line:SetHeight(fillThickness)
            background:SetRotation(0)
            background:SetPoint("LEFT", f, "BOTTOMLEFT", leftPad, y)
            background:SetPoint("RIGHT", f, "BOTTOMRIGHT", -rightPad, y)
            background:SetHeight(backgroundThickness)
        end

        background:SetShown(barFill)
        line:Show()
    end

    if orientation == "VERTICAL" then
        local leftPad, rightPad, topPad, bottomPad = 32, 18, 16, 22
        local usableW = math.max(60, width - leftPad - rightPad)
        local railLength = math.max(40, height - topPad - bottomPad)
        for i = 1, railCount do
            local line = railCount == 1 and f.rail or railLines[i]
            local background = railCount == 1 and f.railBackground or railBackgrounds[i]
            local x = railCount == 1 and (leftPad + usableW * 0.5) or (leftPad + ((i - 0.5) / railCount) * usableW)
            ConfigureRail(line, background, true, x, -(topPad + railLength * 0.5), railLength)
        end
    else
        local leftPad, rightPad, topPad, bottomPad = 38, 20, 20, 34
        local usableH = math.max(50, height - topPad - bottomPad)
        for i = 1, railCount do
            local line = railCount == 1 and f.rail or railLines[i]
            local background = railCount == 1 and f.railBackground or railBackgrounds[i]
            local y = railCount == 1 and (bottomPad + usableH * 0.5) or (bottomPad + ((i - 0.5) / railCount) * usableH)
            ConfigureRail(line, background, false, nil, y, nil, leftPad, rightPad)
        end
    end

    if laneMode then
        local labelSize = Clamp(cfg.laneLabelSize, 6, 40, 10)
        local font = ResolveFont(cfg.laneLabelFont)
        local lc = cfg.laneLabelColor or { r = 0.78, g = 0.78, b = 0.78, a = 0.92 }
        local ox = Clamp(cfg.laneLabelX, -400, 400, 0)
        local oy = Clamp(cfg.laneLabelY, -400, 400, 0)
        for i, lane in ipairs(lanes) do
            local mover = f.laneMovers[lane]
            local label = f.laneLabels[lane]
            label:SetFont(font, labelSize, "OUTLINE")
            label:SetTextColor(Clamp(lc.r,0,1,0.78), Clamp(lc.g,0,1,0.78), Clamp(lc.b,0,1,0.78), Clamp(lc.a,0,1,0.92))
            mover:ClearAllPoints()
            if orientation == "VERTICAL" then
                local leftPad, rightPad = 32, 18
                local usableW = math.max(60, width - leftPad - rightPad)
                local x = leftPad + ((i - 0.5) / #lanes) * usableW
                mover:SetPoint("TOP", f, "TOPLEFT", x + ox, -2 + oy)
            else
                local topPad, bottomPad = 20, 34
                local usableH = math.max(50, height - topPad - bottomPad)
                local y = bottomPad + ((i - 0.5) / #lanes) * usableH
                mover:SetPoint("RIGHT", f, "BOTTOMLEFT", 34 + ox, y + oy)
            end
            mover:EnableMouse(cfg.locked == false)
            mover:Show()
        end
    end
end

local function SafeMechanicType(mechanic)
    local kind = type(mechanic.mechanicType) == "string" and mechanic.mechanicType:upper() or "OTHER"
    if kind ~= "INTERRUPT" and kind ~= "TANK" and kind ~= "AOE_DAMAGE" and kind ~= "UTILITY" then
        kind = "OTHER"
    end
    return kind
end

local function SortMechanics(mechanics)
    table.sort(mechanics, function(a, b)
        local ar = PublicNumber(a.remaining)
        local br = PublicNumber(b.remaining)
        if ar ~= nil and br ~= nil and ar ~= br then return ar < br end
        if ar ~= nil and br == nil then return true end
        if ar == nil and br ~= nil then return false end
        local ap = PublicNumber(a.priority) or 1
        local bp = PublicNumber(b.priority) or 1
        return ap > bp
    end)
end

local function SetEntryIcon(entry, mechanic, iconSize)
    entry:SetSize(iconSize, iconSize)
    entry.icon:SetSize(iconSize, iconSize)
    entry.cooldown:SetSize(iconSize, iconSize)

    if mechanic.iconPresent and HasValue(mechanic.icon) then
        -- SetTexture is allowed to consume a protected texture value. Never read
        -- geometry or perform arithmetic on that texture/region afterwards.
        entry.icon:SetTexture(mechanic.icon)
    elseif mechanic.catalogSpellID and C_Spell and type(C_Spell.GetSpellTexture) == "function" then
        local ok, texture = pcall(C_Spell.GetSpellTexture, mechanic.catalogSpellID)
        if ok and HasValue(texture) then entry.icon:SetTexture(texture) else entry.icon:SetTexture(134400) end
    else
        entry.icon:SetTexture(134400)
    end
end

local function SetEntryText(entry, mechanic, cfg, iconSize)
    local timerSize = Clamp(cfg.timerTextSize, 6, 40, 12)
    local nameSize = Clamp(cfg.nameTextSize, 6, 40, 11)
    local timerFont = ResolveFont(cfg.timerFont)
    local nameFont = ResolveFont(cfg.nameFont)
    local tc = cfg.timerTextColor or { r = 1, g = 0.82, b = 0.12, a = 1 }
    local nc = cfg.nameTextColor or { r = 1, g = 1, b = 1, a = 1 }

    entry.timer:SetFont(timerFont, timerSize, "OUTLINE")
    entry.timer:SetTextColor(Clamp(tc.r,0,1,1), Clamp(tc.g,0,1,0.82), Clamp(tc.b,0,1,0.12), Clamp(tc.a,0,1,1))
    entry.name:SetFont(nameFont, nameSize, "OUTLINE")
    entry.name:SetTextColor(Clamp(nc.r,0,1,1), Clamp(nc.g,0,1,1), Clamp(nc.b,0,1,1), Clamp(nc.a,0,1,1))

    local useProtectedTimer = cfg.showTimers ~= false
        and mechanic.protectedTiming == true
        and HasValue(mechanic.durationObject)
        and entry.timerBinding ~= nil

    if cfg.showTimers ~= false then
        if useProtectedTimer then
            entry.timerBinding:SetDuration(mechanic.durationObject)
            entry.timerBinding:SetEnabled(true)
        else
            if entry.timerBinding then entry.timerBinding:SetEnabled(false) end
            entry.timer:SetText(FormatTime(mechanic.remaining))
        end
    else
        if entry.timerBinding then entry.timerBinding:SetEnabled(false) end
        entry.timer:SetText("")
    end

    if cfg.showNames ~= false and mechanic.displayNamePresent then
        entry.name:SetText(mechanic.displayName)
    else
        entry.name:SetText("")
    end

    entry.timer:ClearAllPoints()
    entry.timer:SetPoint("CENTER", entry, "CENTER", Clamp(cfg.timerTextX, -100, 100, 0), Clamp(cfg.timerTextY, -100, 100, 0))

    entry.nameMover:ClearAllPoints()
    entry.nameMover:SetSize(math.max(120, iconSize * 3), 18)
    entry.nameMover:SetPoint("TOP", entry, "BOTTOM", Clamp(cfg.nameTextX, -400, 400, 0), -2 + Clamp(cfg.nameTextY, -400, 400, 0))
    entry.nameMover:EnableMouse(cfg.locked == false)
    if cfg.showNames ~= false then entry.nameMover:Show() else entry.nameMover:Hide() end
end

local function BindProtectedCooldown(entry, mechanic)
    entry.cooldown:Hide()
    if mechanic.protectedTiming == true and HasValue(mechanic.durationObject) then
        local ok = pcall(entry.cooldown.SetCooldownFromDurationObject, entry.cooldown, mechanic.durationObject, true)
        if ok then entry.cooldown:Show() end
    end
end

local function BuildLaneMap(cfg)
    local laneMap = {}
    local lanes = ActiveLanes(cfg)
    if cfg.layout == "LANES" then
        for i, lane in ipairs(lanes) do laneMap[lane] = i end
    else
        for _, lane in ipairs(LANE_ORDER) do laneMap[lane] = 1 end
    end
    return laneMap, cfg.layout == "LANES" and #lanes or 1
end

local function LayoutEntry(entry, mechanic, laneIndex, laneCount, cfg, packState)
    local width = Clamp(cfg.width, 180, 900, 300)
    local height = Clamp(cfg.height, 160, 900, 420)
    local iconSize = Clamp(cfg.iconSize, 20, 96, 38)
    local window = Clamp(cfg.window, 5, 60, 15)
    local remaining = PublicNumber(mechanic.remaining)
    local pct = remaining and Clamp(remaining / window, 0, 1, 0) or 0
    local direction = GetIconDirection(cfg)
    local orientation = cfg.orientation == "HORIZONTAL" and "HORIZONTAL" or "VERTICAL"

    entry:ClearAllPoints()

    if orientation == "VERTICAL" then
        local leftPad, rightPad, topPad, bottomPad = 32, 18, 16, 22
        local usableW = math.max(60, width - leftPad - rightPad)
        local usableH = math.max(60, height - topPad - bottomPad)
        local x = cfg.layout == "LANES"
            and (leftPad + ((laneIndex - 0.5) / math.max(1, laneCount)) * usableW)
            or (leftPad + usableW * 0.5)
        local y
        if direction == "BOTTOM_TO_TOP" then
            y = bottomPad + (pct * usableH)
        else
            y = height - topPad - (pct * usableH)
        end

        local bucket = math.floor((y / math.max(1, iconSize + 6)) + 0.5)
        local key = tostring(laneIndex) .. ":" .. tostring(bucket)
        local packed = packState[key] or 0
        packState[key] = packed + 1
        local crossOffset = packed * (iconSize + 4)
        if packed % 2 == 1 then crossOffset = -crossOffset end
        x = Clamp(x + crossOffset, leftPad + iconSize * 0.5, width - rightPad - iconSize * 0.5, x)
        y = Clamp(y, bottomPad + iconSize * 0.5, height - topPad - iconSize * 0.5, y)
        entry:SetPoint("CENTER", frame, "BOTTOMLEFT", x, y)
    else
        local leftPad, rightPad, topPad, bottomPad = 38, 20, 20, 34
        local usableW = math.max(60, width - leftPad - rightPad)
        local usableH = math.max(50, height - topPad - bottomPad)
        local x
        if direction == "LEFT_TO_RIGHT" then
            x = leftPad + ((1 - pct) * usableW)
        else
            x = leftPad + (pct * usableW)
        end
        local y = cfg.layout == "LANES"
            and (bottomPad + ((laneIndex - 0.5) / math.max(1, laneCount)) * usableH)
            or (bottomPad + usableH * 0.5)

        local bucket = math.floor((x / math.max(1, iconSize + 6)) + 0.5)
        local key = tostring(laneIndex) .. ":" .. tostring(bucket)
        local packed = packState[key] or 0
        packState[key] = packed + 1
        local crossOffset = packed * (iconSize + 4)
        if packed % 2 == 1 then crossOffset = -crossOffset end
        x = Clamp(x, leftPad + iconSize * 0.5, width - rightPad - iconSize * 0.5, x)
        y = Clamp(y + crossOffset, bottomPad + iconSize * 0.5, height - topPad - iconSize * 0.5, y)
        entry:SetPoint("CENTER", frame, "BOTTOMLEFT", x, y)
    end
end

function HUD:Clear()
    previewActive = false
    previewData = nil
    previewStartedAt = 0
    lastMechanics = nil
    hasActiveMechanics = false
    if not frame then return end

    local cfg = Config()
    for _, entry in ipairs(entries) do HideEntry(entry) end

    -- Keep the empty rail visible while the HUD is explicitly unlocked so the
    -- user can still drag/place it with no live mechanics. Runtime clearing must
    -- not make an unlocked Timeline HUD disappear.
    if cfg and cfg.locked == false then
        ApplyFrameConfig()
        ConfigureAxis(cfg)
        frame:Show()
        return
    end

    frame.rail:Hide()
    frame.railBackground:Hide()
    for i = 1, #railLines do
        railLines[i]:Hide()
        railBackgrounds[i]:Hide()
    end
    for _, mover in pairs(frame.laneMovers or {}) do mover:Hide() end
    frame:Hide()
end

function HUD:GetIconDirectionLabel()
    local cfg = Config()
    if not cfg then return "Top -> Bottom" end
    local direction = GetIconDirection(cfg)
    if direction == "LEFT_TO_RIGHT" then return "Left -> Right" end
    if direction == "RIGHT_TO_LEFT" then return "Right -> Left" end
    if direction == "BOTTOM_TO_TOP" then return "Bottom -> Top" end
    return "Top -> Bottom"
end

function HUD:SetIconDirection(label)
    local cfg = Config()
    if not cfg then return end
    local values = {
        ["Top -> Bottom"] = "TOP_TO_BOTTOM",
        ["Bottom -> Top"] = "BOTTOM_TO_TOP",
        ["Left -> Right"] = "LEFT_TO_RIGHT",
        ["Right -> Left"] = "RIGHT_TO_LEFT",
    }
    if values[label] then
        cfg.iconDirection = values[label]
        self:RefreshLayout()
    end
end

function HUD:Render(mechanics)
    local cfg = Config()
    if not cfg then
        self:Clear()
        return
    end

    -- A live empty update can arrive while the user is running the Timeline
    -- preview. The preview owns the renderer until its eight-second test ends.
    if previewActive then return end

    if type(mechanics) ~= "table" or #mechanics == 0 then
        self:Clear()
        return
    end

    local f = EnsureFrame()
    ApplyFrameConfig()
    ConfigureAxis(cfg)

    lastMechanics = mechanics

    local filtered = {}
    for i = 1, #mechanics do
        local mechanic = mechanics[i]
        local kind = SafeMechanicType(mechanic)
        if cfg.lanes[kind] ~= false then filtered[#filtered + 1] = mechanic end
    end
    SortMechanics(filtered)

    local maxEntries = math.floor(Clamp(cfg.maxEntries, 1, 16, 8))
    while #filtered > maxEntries do table.remove(filtered) end
    if #filtered == 0 then
        self:Clear()
        return
    end

    local laneMap, laneCount = BuildLaneMap(cfg)
    local packState = {}
    local iconSize = Clamp(cfg.iconSize, 20, 96, 38)

    for i = 1, maxEntries do
        local entry = AcquireEntry(i)
        local mechanic = filtered[i]
        if not mechanic then
            HideEntry(entry)
        else
            local kind = SafeMechanicType(mechanic)
            SetEntryIcon(entry, mechanic, iconSize)
            SetEntryText(entry, mechanic, cfg, iconSize)
            BindProtectedCooldown(entry, mechanic)
            LayoutEntry(entry, mechanic, laneMap[kind] or 1, laneCount, cfg, packState)
            entry:Show()
        end
    end
    for i = maxEntries + 1, #entries do HideEntry(entries[i]) end

    hasActiveMechanics = true
    f:Show()
end

function HUD:SetUnlocked(unlocked)
    local cfg = Config()
    if not cfg then return end
    cfg.locked = not (unlocked == true)
    EnsureFrame()
    ApplyFrameConfig()
    ConfigureAxis(cfg)
    if unlocked or hasActiveMechanics or previewActive then frame:Show() else frame:Hide() end
end

function HUD:IsUnlocked()
    local cfg = Config()
    return cfg and cfg.locked == false or false
end

function HUD:ResetPosition()
    local cfg = Config()
    if not cfg then return end
    cfg.x, cfg.y = 360, 0
    EnsureFrame()
    ApplyFrameConfig()
    ConfigureAxis(cfg)
end

function HUD:RefreshLayout()
    local cfg = Config()
    if not cfg then return end
    EnsureFrame()
    ApplyFrameConfig()
    ConfigureAxis(cfg)
    if lastMechanics then
        local wasPreview = previewActive
        previewActive = false
        self:Render(lastMechanics)
        previewActive = wasPreview
    elseif cfg.locked == false then
        frame:Show()
    end
end

local function BuildPreviewData(entry)
    if type(entry) == "table" then
        local duration = tonumber(entry.duration) or 7
        duration = math.max(3, math.min(15, duration))
        return {
            {
                displayName = (type(entry.name) == "string" and entry.name ~= "" and entry.name) or "ABILITY",
                displayNamePresent = true,
                mechanicType = type(entry.mechanicType) == "string" and entry.mechanicType or "OTHER",
                remaining = duration,
                previewRemaining = duration,
                priority = tonumber(entry.priority) or 3,
                icon = entry.icon,
                iconPresent = entry.icon ~= nil,
            },
        }
    end

    return {
        { displayName = "Interrupt", displayNamePresent = true, mechanicType = "INTERRUPT", remaining = 2.4, previewRemaining = 2.4, priority = 3, icon = 136243, iconPresent = true },
        { displayName = "Tank Buster", displayNamePresent = true, mechanicType = "TANK", remaining = 5.8, previewRemaining = 5.8, priority = 3, icon = 132337, iconPresent = true },
        { displayName = "AoE Damage", displayNamePresent = true, mechanicType = "AOE_DAMAGE", remaining = 9.2, previewRemaining = 9.2, priority = 2, icon = 135826, iconPresent = true },
        { displayName = "Utility", displayNamePresent = true, mechanicType = "UTILITY", remaining = 12.6, previewRemaining = 12.6, priority = 2, icon = 136116, iconPresent = true },
    }
end

function HUD:Preview()
    local cfg = Config()
    if not cfg then return end
    local demo = BuildPreviewData(nil)
    previewData = demo
    previewStartedAt = GetTime()
    previewActive = false
    self:Render(demo)
    previewActive = true
end

function HUD:PreviewSelected(entry)
    local cfg = Config()
    if not cfg or type(entry) ~= "table" then return end
    local demo = BuildPreviewData(entry)
    previewData = demo
    previewStartedAt = GetTime()
    previewActive = false
    self:Render(demo)
    previewActive = true
end
