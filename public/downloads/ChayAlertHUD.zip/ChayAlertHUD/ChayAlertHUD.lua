local addonName = ...
local build = select(4, GetBuildInfo()) or 0
if build < 120100 then
    print("|cffff3333ChayAlert HUD:|r This build requires Retail Midnight 12.1+.")
    return
end

local CT = {}
_G.ChayAlertHUD = CT

local DungeonData = _G.ChayAlertHUDDungeonData
local DungeonBossData = _G.ChayAlertHUDDungeonBossData
local RaidData = _G.ChayAlertHUDRaidData
local RoleData = _G.ChayAlertHUDRoleData
local TimelineData = _G.ChayAlertHUDTimelineData
local TrashRuntimeData = _G.ChayAlertHUDTrashRuntimeData

local MEDIA = "Interface\\AddOns\\" .. addonName .. "\\Media\\"
local GUI_BG = MEDIA .. "ChayDragon.png"
local MINIMAP_ICON = MEDIA .. "MinimapIcon.png"
local RING_TEXTURE = MEDIA .. "RingBW.png"
local RING_PLAIN_TEXTURE = MEDIA .. "RingPlain.png"
local RING_FLAT_TEXTURE = MEDIA .. "RingFlat.png"
local SOUND_ALERT = MEDIA .. "Alert.wav"
local SOUND_URGENT = MEDIA .. "Urgent.wav"
local SOUND_BEEP = MEDIA .. "Beep.wav"
local MAX_CIRCLES = 3
local SEGMENTS = 360
local TWO_PI = math.pi * 2

local SEASON2_DUNGEONS = {
    "Altar of Fangs", "Murder Row", "Den of Nalorakk", "The Blinding Vale",
    "Voidscar Arena", "Kings' Rest", "Temple of Sethraliss", "Ruby Life Pools",
}

local function CircleDefaults(index)
    local offsets = { -360, 0, 360 }
    return {
        enabled = true,
        x = offsets[index] or ((index - 3) * 180),
        y = 145,
        size = 164,
        alpha = 1,
        timerX = 0,
        timerY = 10,
        nameX = 0,
        nameY = -26,
        timerFontSize = 34,
        nameFontSize = 15,
        timerFont = "Default",
        nameFont = "Default",
        timerColor = { r = 1, g = 0.82, b = 0.05, a = 1 },
        nameColor = { r = 1, g = 1, b = 1, a = 1 },
        ringMode = "Textured Ring",
        sound = true,
    }
end

local defaults = {
    enabled = true,
    onlyInInstances = true,
    showMinimap = true,
    maxAlerts = 3,
    leadTime = 10,
    showName = true,
    showTenths = true,
    circleFlashOnStart = false,
    reverse = false,
    useTimeColor = true,
    ringThickness = 10,
    ringBackgroundAlpha = 0.20,
    color = { r = 0.15, g = 0.85, b = 0.20, a = 1 },
    warningColor = { r = 1.00, g = 0.74, b = 0.08, a = 1 },
    urgentColor = { r = 0.95, g = 0.10, b = 0.10, a = 1 },
    soundEnabled = true,
    allSoundSelectionsNone = false,
    ttsEnabled = false,
    ttsRate = 0,
    ttsVolume = 100,
    ttsVoiceID = nil,
    ttsVoiceKey = nil,
    ttsPhraseMode = "ABILITY_ONLY",
    ttsCustomPhrase = "",
    voicePackSource = "NATIVE_TTS",
    tankSwapVoice = "FOLLOW_TTS",
    voiceSettingsVersion = 0,
    alertSound = "ChayAlert HUD Alert",
    urgentSound = "ChayAlert HUD Urgent",
    beepSound = "ChayAlert HUD Beep",
    playUrgentSound = true,
    countdownBeeps = true,
    beepAt = 3,
    mutedSpells = {},
    trackedSpells = {},
    trackOnlyCustom = false,
    trashCastsEnabled = true,
    importantAurasEnabled = true,
    suppressTrashDuringBoss = true,
    trashMinCastTime = 1.5,
    showTrashMobName = true,
    trackUnknownTrash = false,
    trackUnknownBossTimeline = false,
    showOptionalAbilities = false,
    roleProfile = "AUTO",
    recommendationDefaultsVersion = 0,
    mobAbilityOverrides = {},
    bossAbilityOverrides = {},
    raidAbilityOverrides = {},
    displayMode = "CIRCLE",
    timeline = {
        orientation = "VERTICAL",
        layout = "SINGLE",
        texture = "Blizzard Dialog Background",
        backgroundEnabled = false,
        backgroundAlpha = 0.18,
        trackTexture = "Solid",
        iconDirection = "LEGACY",
        trackColor = { r = 0.90, g = 0.18, b = 0.12, a = 1 },
        barFillEnabled = false,
        barBackgroundColor = { r = 0.05, g = 0.05, b = 0.05, a = 1 },
        barFillColor = { r = 0.90, g = 0.18, b = 0.12, a = 1 },
        trackAlpha = 0.72,
        trackThickness = 2,
        window = 15,
        width = 300,
        height = 420,
        iconSize = 38,
        maxEntries = 8,
        alpha = 0.95,
        timerTextSize = 12,
        timerFont = "Default",
        nameTextSize = 11,
        nameFont = "Default",
        timerTextColor = { r = 1, g = 0.82, b = 0.12, a = 1 },
        nameTextColor = { r = 1, g = 1, b = 1, a = 1 },
        actionLabelSize = 10,
        actionLabelColor = { r = 1, g = 0.62, b = 0.18, a = 1 },
        laneLabelSize = 10,
        laneLabelFont = "Default",
        laneLabelColor = { r = 0.78, g = 0.78, b = 0.78, a = 0.92 },
        timerTextX = 0,
        timerTextY = 0,
        nameTextX = 0,
        nameTextY = 0,
        actionLabelX = 0,
        actionLabelY = 0,
        laneLabelX = 0,
        laneLabelY = 0,
        entryTextAnchor = "AUTO",
        x = 360,
        y = 0,
        locked = true,
        showNames = true,
        showTimers = true,
        lanes = { INTERRUPT = true, TANK = true, AOE_DAMAGE = true, UTILITY = true, OTHER = true },
    },
    optionsWidth = 1240,
    optionsHeight = 820,
    optionsBackgroundMode = "DRAGON",
    optionsBackgroundColor = { r = 0.012, g = 0.008, b = 0.01, a = 1 },
    layoutSubTab = "CIRCLES",
    circles = {},
}
for i = 1, MAX_CIRCLES do defaults.circles[i] = CircleDefaults(i) end

local db
local options
local minimapButton
local activeSlots = {}
local testTimers = {}
local seenSpells = {}
local currentEncounterID = nil
local timelineMeta = {}
local timelineRuntime = {}
local timelinePending = {}
local trashCasts = {}
local trashRetryToken = {}
local TIMELINE_CONFIRM_DELAY = 0.20
local TIMELINE_MAX_DURATION = 120
local STATE_ACTIVE = Enum and Enum.EncounterTimelineEventState and Enum.EncounterTimelineEventState.Active or 0
local STATE_PAUSED = Enum and Enum.EncounterTimelineEventState and Enum.EncounterTimelineEventState.Paused or 1
local STATE_FINISHED = Enum and Enum.EncounterTimelineEventState and Enum.EncounterTimelineEventState.Finished or 2
local STATE_CANCELED = Enum and Enum.EncounterTimelineEventState and Enum.EncounterTimelineEventState.Canceled or 3
local TIMELINE_SOURCE_ENCOUNTER = Enum and Enum.EncounterTimelineEventSource and Enum.EncounterTimelineEventSource.Encounter or 0
local driver = CreateFrame("Frame", nil, WorldFrame)
local driverAccum = 0
local testMode = false
local testForceCircle = false
local unlockMode = false
local selectedCircle = 1
local openDropdownMenu
local importantSpellCache = {}
local UpdateLiveAlerts
local ttsStateByIdentity = {}

local TTS_PHRASE_MODES = {
    ACTION_ONLY = "Action Only",
    ACTION_ABILITY = "Action + Ability",
    ABILITY_ONLY = "Ability Only",
    CUSTOM = "Custom",
}

local function GetTTSVoices()
    if not (C_VoiceChat and type(C_VoiceChat.GetTtsVoices) == "function") then return {} end
    local ok, voices = pcall(C_VoiceChat.GetTtsVoices)
    return ok and type(voices) == "table" and voices or {}
end

local function GetTTSVoiceID()
    local requested = tonumber(db and db.ttsVoiceID)
    for _, voice in ipairs(GetTTSVoices()) do
        local id = tonumber(voice.voiceID)
        if id and id == requested then return id end
    end
    return nil
end

local function TTSAction(mechanicType)
    local actions = {
        INTERRUPT = "Kick",
        TANK = "Tank buster",
        AOE_DAMAGE = "AOE incoming",
        UTILITY = "Utility",
        OTHER = "Watch",
    }
    mechanicType = type(mechanicType) == "string" and mechanicType:upper() or "OTHER"
    return actions[mechanicType]
end

local function DeepCopyDefaults(src, dst)
    for k, v in pairs(src) do
        if dst[k] == nil then
            if type(v) == "table" then
                dst[k] = {}
                DeepCopyDefaults(v, dst[k])
            else
                dst[k] = v
            end
        elseif type(v) == "table" and type(dst[k]) == "table" then
            DeepCopyDefaults(v, dst[k])
        end
    end
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) or false
end

local function PublicValueOrNil(v)
    if IsSecret(v) then return nil end
    return v
end

local function HasValueWithoutInspectingSecret(v)
    if IsSecret(v) then return true end
    return v ~= nil
end

local DISPLAY_MODES = { INHERIT = true, CIRCLE = true, TIMELINE = true, BOTH = true, NONE = true }
local GLOBAL_DISPLAY_MODES = { CIRCLE = true, TIMELINE = true, BOTH = true, NONE = true }
local MECHANIC_TYPES = { INTERRUPT = true, TANK = true, AOE_DAMAGE = true, UTILITY = true, OTHER = true }

local function NormalizeDisplayMode(value, allowInherit)
    if type(value) ~= "string" then return allowInherit and "INHERIT" or "CIRCLE" end
    value = value:upper()
    if allowInherit and value == "INHERIT" then return value end
    if GLOBAL_DISPLAY_MODES[value] then return value end
    return allowInherit and "INHERIT" or "CIRCLE"
end

local function ResolveDisplayMode(override)
    local mode = NormalizeDisplayMode(override, true)
    if mode ~= "INHERIT" then return mode end
    return NormalizeDisplayMode(db and db.displayMode, false)
end

local function DisplayModeAllows(mode, target)
    mode = NormalizeDisplayMode(mode, false)
    if mode == "NONE" then return false end
    if mode == "BOTH" then return true end
    return mode == target
end

local function NormalizeMechanicType(value)
    if type(value) == "string" then
        value = value:upper()
        if MECHANIC_TYPES[value] then return value end
    end
    return "OTHER"
end

local function NormalizeMechanicOverride(value)
    if type(value) ~= "string" then return nil end
    value = value:upper()
    if value == "AUTO" then return nil end
    if MECHANIC_TYPES[value] then return value end
    return nil
end

local ROLE_OVERRIDE_TOKENS = { "TANK", "HEALER", "DAMAGER" }

-- nil means "use Chay Recommended"; any other valid return is a Custom per-ability role choice.
local function NormalizeRoleOverride(value)
    if type(value) ~= "string" or value == "" or value == "AUTO" then return nil end
    value = value:upper()
    if value == "ALL" then return "ALL" end
    local present = {}
    for _, token in ipairs(ROLE_OVERRIDE_TOKENS) do
        if ("_" .. value .. "_"):find("_" .. token .. "_", 1, true) then
            present[#present + 1] = token
        end
    end
    if #present == 0 then return nil end
    if #present == 3 then return "ALL" end
    return table.concat(present, "_")
end

local function BuildRoleOverrideFromFlags(tank, healer, damager)
    if tank and healer and damager then return "ALL" end
    local present = {}
    if tank then present[#present + 1] = "TANK" end
    if healer then present[#present + 1] = "HEALER" end
    if damager then present[#present + 1] = "DAMAGER" end
    if #present == 0 then return nil end
    return table.concat(present, "_")
end

local function InferMechanicType(spellMeta, roles, overrideType)
    if type(overrideType) == "string" and MECHANIC_TYPES[overrideType:upper()] then
        return overrideType:upper()
    end
    if type(spellMeta) == "table" then
        if type(spellMeta.mechanicType) == "string" then
            local declaredType = spellMeta.mechanicType:upper()
            if MECHANIC_TYPES[declaredType] then return declaredType end
        end
        if spellMeta.interruptible == true or spellMeta.interrupt == true then return "INTERRUPT" end
        if spellMeta.tank == true then return "TANK" end
        if spellMeta.aoe == true or spellMeta.groupDamage == true then return "AOE_DAMAGE" end
        if spellMeta.magic == true or spellMeta.curse == true or spellMeta.poison == true
            or spellMeta.disease == true or spellMeta.enrage == true then
            return "UTILITY"
        end
    end
    if type(roles) == "string" and roles:find("TANK", 1, true) then
        return "TANK"
    end
    return "OTHER"
end

function CT:GetDB() return db end
function CT:GetDisplayMode() return ResolveDisplayMode(nil) end
function CT:SetDisplayMode(value)
    if not db then return end
    db.displayMode = NormalizeDisplayMode(value, false)
    if CT.RefreshTrackingState then CT:RefreshTrackingState() end
end
function CT:ResolveDisplayMode(value) return ResolveDisplayMode(value) end
function CT:NormalizeMechanicType(value) return NormalizeMechanicType(value) end
function CT:NormalizeMechanicOverride(value) return NormalizeMechanicOverride(value) end
function CT:NormalizeRoleOverride(value) return NormalizeRoleOverride(value) end
function CT:BuildRoleOverrideFromFlags(tank, healer, damager) return BuildRoleOverrideFromFlags(tank, healer, damager) end
function CT:RoleOverrideFlags(roleString)
    if type(roleString) ~= "string" or roleString == "" or roleString == "ALL" then
        return true, true, true
    end
    local padded = "_" .. roleString .. "_"
    return padded:find("_TANK_", 1, true) ~= nil,
        padded:find("_HEALER_", 1, true) ~= nil,
        padded:find("_DAMAGER_", 1, true) ~= nil
end


local function GetLSM()
    local stub = _G.LibStub
    if type(stub) == "table" and getmetatable(stub) and getmetatable(stub).__call then
        return stub("LibSharedMedia-3.0", true)
    elseif type(stub) == "function" then
        return stub("LibSharedMedia-3.0", true)
    end
    return nil
end

local BUILTIN_MEDIA = {
    font = { Default = STANDARD_TEXT_FONT },
    background = {
        ["Blizzard Dialog Background"] = "Interface\\DialogFrame\\UI-DialogBox-Background",
        ["Blizzard Tooltip"] = "Interface\\Tooltips\\UI-Tooltip-Background",
        ["Solid"] = "Interface\\Buttons\\WHITE8x8",
    },
    statusbar = {
        ["Solid"] = "Interface\\Buttons\\WHITE8x8",
    },
    sound = {
        ["ChayAlert HUD Alert"] = SOUND_ALERT,
        ["ChayAlert HUD Urgent"] = SOUND_URGENT,
        ["ChayAlert HUD Beep"] = SOUND_BEEP,
        ["Blizzard Encounter Warning - High"] = 7670697,
        ["Blizzard Encounter Warning - Medium"] = 7670701,
        ["Blizzard Encounter Warning - Low"] = 7670699,
        ["Blizzard Raid Warning"] = 567397,
        ["Blizzard Beware"] = 543587,
        ["Blizzard Run Away"] = 552035,
        ["Blizzard Destruction"] = 553193,
        ["Blizzard Flag Taken"] = 569200,
        ["None"] = false,
    },
}

local function GetMediaNames(kind)
    local seen, names = {}, {}
    local builtin = BUILTIN_MEDIA[kind] or {}
    for name in pairs(builtin) do
        seen[name] = true
        names[#names + 1] = name
    end
    local lsm = GetLSM()
    if lsm and lsm.HashTable then
        local ok, media = pcall(lsm.HashTable, lsm, kind)
        if ok and type(media) == "table" then
            for name in pairs(media) do
                if type(name) == "string" and not seen[name] then
                    seen[name] = true
                    names[#names + 1] = name
                end
            end
        end
    end
    table.sort(names, function(a, b) return string.lower(a) < string.lower(b) end)
    return names
end

local function FetchMedia(kind, name, fallback)
    local builtin = BUILTIN_MEDIA[kind] or {}
    if builtin[name] ~= nil then
        return builtin[name] or nil
    end
    local lsm = GetLSM()
    if lsm and lsm.Fetch then
        local ok, path = pcall(lsm.Fetch, lsm, kind, name, true)
        if ok and path then return path end
    end
    return fallback
end

local function IsInSupportedInstance()
    if not db.onlyInInstances then return true end
    local inInstance, instanceType = IsInInstance()
    return inInstance and (instanceType == "party" or instanceType == "raid")
end

local function FormatTime(seconds)
    if db.showTenths and seconds < 10 then
        return string.format("%.1f", math.max(0, seconds))
    end
    return tostring(math.ceil(math.max(0, seconds) - 0.001))
end

local function GetRingColor(remaining, duration)
    if not db.useTimeColor then
        local c = db.color
        return c.r, c.g, c.b, c.a
    end
    local p = duration > 0 and remaining / duration or 0
    local c
    if p <= 0.25 then c = db.urgentColor
    elseif p <= 0.55 then c = db.warningColor
    else c = db.color end
    return c.r, c.g, c.b, c.a
end

local function CreateAlertSlot(index)
    local f = CreateFrame("Frame", nil, WorldFrame)
    f:SetFrameStrata("MEDIUM")
    f:SetSize(164, 164)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f.index = index
    f.segments = {}
    f.bgSegments = {}

    f.baseTexture = f:CreateTexture(nil, "BACKGROUND")
    f.baseTexture:SetAllPoints()
    f.baseTexture:SetTexture(RING_TEXTURE)
    f.baseTexture:SetBlendMode("BLEND")
    f.baseTexture:SetVertexColor(1, 1, 1, 0.16)

    f.flashOverlay = f:CreateTexture(nil, "OVERLAY")
    f.flashOverlay:SetAllPoints()
    f.flashOverlay:SetTexture(RING_PLAIN_TEXTURE)
    f.flashOverlay:SetBlendMode("ADD")
    f.flashOverlay:SetVertexColor(1, 1, 1, 1)
    f.flashOverlay:SetAlpha(0)
    f.flashOverlay:Hide()

    f.flashGroup = f.flashOverlay:CreateAnimationGroup()
    for pulseIndex = 1, 8 do
        local pulse = f.flashGroup:CreateAnimation("Alpha")
        pulse:SetDuration(0.25)
        pulse:SetOrder(pulseIndex)
        if (pulseIndex % 2) == 1 then
            pulse:SetFromAlpha(0)
            pulse:SetToAlpha(1)
        else
            pulse:SetFromAlpha(1)
            pulse:SetToAlpha(0)
        end
    end
    f.flashGroup:SetScript("OnPlay", function()
        f.flashOverlay:SetAlpha(0)
        f.flashOverlay:Show()
    end)
    local function FinishFlash()
        f.flashOverlay:SetAlpha(0)
        f.flashOverlay:Hide()
    end
    f.flashGroup:SetScript("OnFinished", FinishFlash)
    f.flashGroup:SetScript("OnStop", FinishFlash)

    f.progress = CreateFrame("Frame", nil, f)
    f.progress:SetAllPoints()

    -- Midnight 12.1 can protect cast start/end times for hostile units in combat.
    -- A native Cooldown frame can consume Blizzard's LuaDurationObject directly
    -- without exposing protected timing values to addon Lua. This is used only
    -- for trash casts whose numeric timing cannot legally be inspected.
    f.protectedCooldown = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
    f.protectedCooldown:SetAllPoints()
    f.protectedCooldown:SetFrameLevel(f:GetFrameLevel() + 8)
    f.protectedCooldown:SetDrawEdge(false)
    f.protectedCooldown:SetDrawBling(false)
    f.protectedCooldown:SetDrawSwipe(true)
    f.protectedCooldown:SetSwipeTexture(RING_TEXTURE, 1, 1, 1, 1)
    f.protectedCooldown:SetSwipeColor(0.95, 0.10, 0.10, 0.96)
    f.protectedCooldown:SetHideCountdownNumbers(false)
    f.protectedCooldown:EnableMouse(false)
    f.protectedCooldown:SetScript("OnCooldownDone", function(cooldown)
        local owner = cooldown:GetParent()
        if owner and type(owner._protectedSoundState) == "table" then
            owner._protectedSoundState.protectedFinished = true
        end
    end)
    f.protectedCooldown:Hide()

    for i = 1, SEGMENTS do
        local bg = f.progress:CreateTexture(nil, "BACKGROUND")
        bg:SetTexture("Interface\\Buttons\\WHITE8x8")
        bg:SetBlendMode("BLEND")
        bg:SetMouseClickEnabled(false)
        f.bgSegments[i] = bg

        local seg = f.progress:CreateTexture(nil, "ARTWORK")
        seg:SetTexture("Interface\\Buttons\\WHITE8x8")
        seg:SetBlendMode("ADD")
        seg:SetMouseClickEnabled(false)
        f.segments[i] = seg
    end

    f.timer = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.timer:SetJustifyH("CENTER")
    f.timer:SetShadowColor(0, 0, 0, 1)
    f.timer:SetShadowOffset(2, -2)
    f.timer:SetMouseClickEnabled(false)

    f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.name:SetJustifyH("CENTER")
    f.name:SetWordWrap(false)
    f.name:SetShadowColor(0, 0, 0, 1)
    f.name:SetShadowOffset(1, -1)
    f.name:SetMouseClickEnabled(false)

    f.dragLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.dragLabel:SetPoint("CENTER", 0, -2)
    f.dragLabel:SetText("Drag Circle " .. index)
    f.dragLabel:SetTextColor(1, 0.25, 0.25, 1)
    f.dragLabel:SetShadowColor(0, 0, 0, 1)
    f.dragLabel:SetShadowOffset(2, -2)
    f.dragLabel:Hide()

    -- Queue overflow badge: how many active mechanics exceed this circle's slot cap.
    f.overflowText = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.overflowText:SetPoint("TOPRIGHT", f, "TOPRIGHT", -10, -10)
    f.overflowText:SetTextColor(1, 0.6, 0.1, 1)
    f.overflowText:SetShadowColor(0, 0, 0, 1)
    f.overflowText:SetShadowOffset(1, -1)
    f.overflowText:SetMouseClickEnabled(false)
    f.overflowText:Hide()

    f:SetScript("OnDragStart", function(self)
        if unlockMode then self:StartMoving() end
    end)
    f:SetScript("OnDragStop", function(self)
        if not unlockMode then return end
        self:StopMovingOrSizing()
        local cx, cy = self:GetCenter()
        local ux, uy = WorldFrame:GetCenter()
        if cx and cy and ux and uy then
            db.circles[index].x = math.floor((cx - ux) + 0.5)
            db.circles[index].y = math.floor((cy - uy) + 0.5)
        end
        CT:LayoutAlerts()
    end)

    f:EnableMouse(false)
    f:Hide()
    activeSlots[index] = f
end

for i = 1, MAX_CIRCLES do CreateAlertSlot(i) end

local function LayoutSegments(f)
    local cfg = db.circles[f.index]
    local size = cfg.size
    local mode = cfg.ringMode or "Textured Ring"
    local textured = mode == "Textured Ring"
    local flatFull = mode == "Flat Full Ring"
    local userThicknessScale = math.max(0.20, math.min(3.60, (db.ringThickness or 10) / 10))

    local thickness
    local radius
    local lengthMultiplier

    if textured then
        thickness = math.max(5, size * 0.040) * userThicknessScale
        radius = math.max(18, (size * 0.5) - (thickness * 0.72))
        lengthMultiplier = 1.35
    elseif flatFull then
        thickness = math.max(5, size * 0.048) * userThicknessScale
        radius = math.max(18, (size * 0.5) - (thickness * 0.90))
        -- Slight overlap closes pixel seams; 360 one-degree segments keep the ring visually flat/continuous.
        lengthMultiplier = 1.18
    else
        thickness = math.max(5, size * 0.044) * userThicknessScale
        radius = math.max(18, (size * 0.5) - (thickness * 0.95))
        lengthMultiplier = 1.55
    end

    thickness = math.min(thickness, size * 0.18)
    local circumferenceStep = (TWO_PI * radius) / SEGMENTS
    local length = math.max(2, circumferenceStep * lengthMultiplier)

    f.baseTexture:SetShown(textured)
    if textured then
        f.baseTexture:SetVertexColor(1, 1, 1, 0.20 * cfg.alpha)
    else
        f.baseTexture:SetVertexColor(1, 1, 1, 0)
    end

    -- Protected hostile-cast timers must stay inside Blizzard's native Cooldown
    -- frame, but their swipe mask can still follow the user's selected ring style.
    -- These are ChayAlert-owned masks; no third-party texture is redistributed.
    if f.protectedCooldown then
        local protectedTexture = textured and RING_TEXTURE or (flatFull and RING_FLAT_TEXTURE or RING_PLAIN_TEXTURE)
        f.protectedCooldown:SetSwipeTexture(protectedTexture, 1, 1, 1, 1)
        f.protectedCooldown:SetReverse(db.reverse == true)
    end

    for i = 1, SEGMENTS do
        local visualIndex = db.reverse and (SEGMENTS - i + 1) or i
        local angle = math.rad(90 - ((visualIndex - 1) / SEGMENTS) * 360)
        local x = math.cos(angle) * radius
        local y = math.sin(angle) * radius
        local bg = f.bgSegments[i]
        local seg = f.segments[i]

        bg:ClearAllPoints()
        bg:SetPoint("CENTER", f.progress, "CENTER", x, y)
        bg:SetSize(length, thickness)
        bg:SetRotation(angle + (math.pi * 0.5))
        bg:SetBlendMode("BLEND")

        seg:ClearAllPoints()
        seg:SetPoint("CENTER", f.progress, "CENTER", x, y)
        seg:SetSize(length, thickness)
        seg:SetRotation(angle + (math.pi * 0.5))
        seg:SetBlendMode(textured and "ADD" or "BLEND")
    end

    -- Force one complete visual refresh after a layout/style change. Subsequent
    -- countdown updates only touch segments whose visibility/color changed.
    f._ringFilled = nil
    f._ringBgAlpha = nil
    f._ringFillR, f._ringFillG, f._ringFillB, f._ringFillA = nil, nil, nil, nil
end

local function SetRingProgress(f, progress, r, g, b, a)
    local cfg = db.circles[f.index]
    local mode = cfg.ringMode or "Textured Ring"
    local textured = mode == "Textured Ring"
    local flatFull = mode == "Flat Full Ring"
    local clamped = math.max(0, math.min(1, progress or 0))
    local filled = math.floor((clamped * SEGMENTS) + 0.5)
    local bgAlpha = math.max(0, math.min(1, db.ringBackgroundAlpha or 0.20)) * cfg.alpha
    local fillAlpha

    if flatFull then
        fillAlpha = math.max(0, math.min(1, (a or 1) * cfg.alpha))
    elseif textured then
        fillAlpha = 0.92 * (a or 1) * cfg.alpha
    else
        fillAlpha = 0.98 * (a or 1) * cfg.alpha
    end

    if f._ringBgAlpha ~= bgAlpha then
        for i = 1, SEGMENTS do
            local bg = f.bgSegments[i]
            bg:SetVertexColor(1, 1, 1, bgAlpha)
            bg:Show()
        end
        f._ringBgAlpha = bgAlpha
    end

    local previousFilled = f._ringFilled
    local colorChanged =
        f._ringFillR ~= r
        or f._ringFillG ~= g
        or f._ringFillB ~= b
        or f._ringFillA ~= fillAlpha

    if previousFilled == nil then
        for i = 1, SEGMENTS do
            local seg = f.segments[i]
            if i <= filled then
                seg:SetVertexColor(r, g, b, fillAlpha)
                seg:Show()
            else
                seg:Hide()
            end
        end
    else
        if colorChanged then
            local visibleEnd = math.min(previousFilled, filled)
            for i = 1, visibleEnd do
                f.segments[i]:SetVertexColor(r, g, b, fillAlpha)
            end
        end

        if filled > previousFilled then
            for i = previousFilled + 1, filled do
                local seg = f.segments[i]
                seg:SetVertexColor(r, g, b, fillAlpha)
                seg:Show()
            end
        elseif filled < previousFilled then
            for i = filled + 1, previousFilled do
                f.segments[i]:Hide()
            end
        end
    end

    f._ringFilled = filled
    f._ringFillR, f._ringFillG, f._ringFillB, f._ringFillA = r, g, b, fillAlpha
end

local function SetProtectedRingBackground(f)
    local cfg = db.circles[f.index]
    local bgAlpha = math.max(0, math.min(1, db.ringBackgroundAlpha or 0.20)) * cfg.alpha
    for i = 1, SEGMENTS do
        local bg = f.bgSegments[i]
        bg:SetVertexColor(1, 1, 1, bgAlpha)
        bg:Show()
        f.segments[i]:Hide()
    end
    f._ringFilled = nil
    f._ringBgAlpha = bgAlpha
    f._ringFillR, f._ringFillG, f._ringFillB, f._ringFillA = nil, nil, nil, nil
end

function CT:LayoutAlerts()
    if not db then return end
    for i = 1, MAX_CIRCLES do
        local f = activeSlots[i]
        local cfg = db.circles[i]
        f:SetSize(cfg.size, cfg.size)
        f:ClearAllPoints()
        f:SetPoint("CENTER", WorldFrame, "CENTER", cfg.x, cfg.y)
        f:SetAlpha(1)
        LayoutSegments(f)

        f.timer:ClearAllPoints()
        f.timer:SetPoint("CENTER", f, "CENTER", cfg.timerX, cfg.timerY)
        f.timer:SetFont(FetchMedia("font", cfg.timerFont, STANDARD_TEXT_FONT) or STANDARD_TEXT_FONT, cfg.timerFontSize, "OUTLINE")
        f.timer:SetTextColor(cfg.timerColor.r, cfg.timerColor.g, cfg.timerColor.b, cfg.timerColor.a or 1)

        f.name:ClearAllPoints()
        f.name:SetPoint("CENTER", f, "CENTER", cfg.nameX, cfg.nameY)
        f.name:SetFont(FetchMedia("font", cfg.nameFont, STANDARD_TEXT_FONT) or STANDARD_TEXT_FONT, cfg.nameFontSize, "OUTLINE")
        f.name:SetTextColor(cfg.nameColor.r, cfg.nameColor.g, cfg.nameColor.b, cfg.nameColor.a or 1)
        f.name:SetWidth(math.max(100, cfg.size * 1.45))

        local movable = unlockMode and i <= db.maxAlerts and cfg.enabled
        f:EnableMouse(movable)
        f.dragLabel:SetShown(movable)
        if i > db.maxAlerts or not cfg.enabled then f:Hide() end
    end

    if self.RefreshAuraContainerLayout then
        self:RefreshAuraContainerLayout()
    end
end

function CT:SetUnlocked(value)
    local requested = value and true or false
    if requested and type(InCombatLockdown) == "function" and InCombatLockdown() then
        print("|cffff3030ChayAlert HUD|r cannot unlock/test circles during combat.")
        return
    end

    unlockMode = requested
    CT:LayoutAlerts()
    if unlockMode then
        CT:StartTest(true)
    elseif CT.StopTest then
        CT:StopTest()
    end
end

local function CanInspectSpellID(spellID)
    if IsSecret(spellID) then return false end
    return spellID ~= nil
end

local function IsMuted(info)
    if not info then return false end
    local sid = info.spellID
    if CanInspectSpellID(sid) then
        local spellName = info.spellName
        if not IsSecret(spellName) and spellName ~= nil then
            seenSpells[sid] = spellName
        end
        return db.mutedSpells[sid] == true
    end
    return false
end

local function IsExplicitlyTracked(info)
    if not info then return false, false end
    local sid = info.spellID
    if not CanInspectSpellID(sid) then
        return false, false
    end

    local spellName = info.spellName
    if not IsSecret(spellName) and spellName ~= nil then
        seenSpells[sid] = spellName
    end

    return db.trackedSpells[sid] == true, true
end

local function ShouldTrackInfo(info)
    if not info or IsMuted(info) then
        return false
    end

    local tracked, inspectable = IsExplicitlyTracked(info)

    if db.trackOnlyCustom then
        if not inspectable then
            return false
        end
        return tracked
    end

    return true
end

local function ResolveTimelineFallbackSpellID(eventInfo)
    if type(eventInfo) ~= "table" or not currentEncounterID then return nil end
    if not TimelineData or type(TimelineData.encounters) ~= "table" then return nil end

    local source = eventInfo.source
    if source == nil then return nil end
    local okSource, numericSource = pcall(tonumber, source)
    if not okSource or numericSource == nil or numericSource ~= TIMELINE_SOURCE_ENCOUNTER then
        return nil
    end

    local okDuration, duration = pcall(tonumber, eventInfo.duration)
    if not okDuration or type(duration) ~= "number" or duration < 0 then return nil end

    local encounter = TimelineData.encounters[tonumber(currentEncounterID)]
    if type(encounter) ~= "table" then return nil end

    local difficultyID
    if type(GetInstanceInfo) == "function" then
        local okInfo, _, _, rawDifficultyID = pcall(GetInstanceInfo)
        if okInfo and not IsSecret(rawDifficultyID) then
            difficultyID = tonumber(rawDifficultyID)
        end
    end

    -- Some 12.1 encounters reuse the same readable timeline duration for a
    -- different protected mechanic on different difficulties. Resolve through
    -- a difficulty-specific fingerprint table first and fail closed when that
    -- encounter explicitly requires one but the difficulty cannot be verified.
    if type(encounter.byDifficulty) == "table" then
        local scoped = difficultyID and encounter.byDifficulty[difficultyID] or nil
        if type(scoped) ~= "table" then return nil end
        encounter = scoped
    end

    -- Some protected timeline fingerprints are only verified on specific raid
    -- difficulties. Fail closed rather than applying an Easy/Heroic dispatch
    -- table to Mythic data that uses different or currently unknown timings.
    if type(encounter.difficulties) == "table" then
        if not difficultyID or encounter.difficulties[difficultyID] ~= true then
            return nil
        end
    end

    -- Some encounter-duration dispatches deliberately use one-decimal matching
    -- for values such as 14.8 or 22.5. Check those exact fingerprints first.
    if type(encounter.one) == "table" then
        local rounded1 = math.floor((duration * 10) + 0.5) / 10
        local spellID = encounter.one[rounded1]
        if spellID then
            return tonumber(spellID)
        end
    end

    if type(encounter.zero) == "table" then
        local rounded0 = math.floor(duration + 0.5)
        local spellID = encounter.zero[rounded0]
        if spellID then
            return tonumber(spellID)
        end
    end

    return nil
end

local function SafeNumber(value)
    if IsSecret(value) then return nil end
    local ok, result = pcall(tonumber, value)
    if ok and not IsSecret(result) then return result end
    return nil
end

local function TimelineFeatureAvailable()
    if not C_EncounterTimeline then return false end
    if C_EncounterTimeline.IsFeatureAvailable then
        local ok, available = pcall(C_EncounterTimeline.IsFeatureAvailable)
        if ok and not IsSecret(available) and available == false then return false end
    end
    return true
end

local function GetTimelineState(eventID)
    if not (C_EncounterTimeline and C_EncounterTimeline.GetEventState) then return nil end
    local ok, state = pcall(C_EncounterTimeline.GetEventState, eventID)
    if ok and not IsSecret(state) then return state end
    return nil
end

local function GetTimelineRemaining(eventID, fallback)
    if C_EncounterTimeline and C_EncounterTimeline.GetEventTimeRemaining then
        local ok, remaining = pcall(C_EncounterTimeline.GetEventTimeRemaining, eventID)
        if ok and not IsSecret(remaining) and type(remaining) == "number" then
            return remaining
        end
    end
    return fallback
end

local function IsEncounterTimelineSource(source)
    -- EncounterTimelineEventInfo.source is NeverSecret in Retail 12.1. Accept
    -- only Blizzard encounter events here; script/other sources must not be
    -- allowed to masquerade as boss mechanics.
    if source == nil then return false end
    local numeric = SafeNumber(source)
    return numeric ~= nil and numeric == TIMELINE_SOURCE_ENCOUNTER
end

local function IsTimelineDurationAllowed(duration)
    local numeric = SafeNumber(duration)
    return numeric ~= nil and numeric >= 0 and numeric <= TIMELINE_MAX_DURATION
end


local function ResolveKnownBossSpellIDByName(encounterID, spellName)
    encounterID = tonumber(encounterID)
    if not encounterID then return nil end
    if IsSecret(spellName) or type(spellName) ~= "string" or spellName == "" then return nil end

    local candidates = {}

    local dungeonEntry = DungeonBossData
        and DungeonBossData.byEncounterID
        and DungeonBossData.byEncounterID[encounterID]
    local dungeonBoss = dungeonEntry and dungeonEntry.boss
    if dungeonBoss and type(dungeonBoss.spells) == "table" then
        for _, spell in ipairs(dungeonBoss.spells) do
            candidates[#candidates + 1] = spell.id
        end
    end

    local raidEntry = RaidData
        and RaidData.byEncounterID
        and RaidData.byEncounterID[encounterID]
    local raidBoss = raidEntry and raidEntry.boss
    if raidBoss and type(raidBoss.spells) == "table" then
        for _, spell in ipairs(raidBoss.spells) do
            candidates[#candidates + 1] = spell.id
        end
    end

    local firstMatch
    for _, spellID in ipairs(candidates) do
        spellID = tonumber(spellID)
        if spellID and C_Spell and C_Spell.GetSpellName then
            local ok, knownName = pcall(C_Spell.GetSpellName, spellID)
            if ok and not IsSecret(knownName)
                and type(knownName) == "string"
                and knownName == spellName then
                -- Same-name IDs are intentionally configured together in the GUI.
                -- Keeping the first exact static ID is sufficient for retrieving
                -- the synchronized Track/Sound/Priority configuration.
                firstMatch = firstMatch or spellID
            end
        end
    end

    return firstMatch
end

local function CaptureSafeTimelineMeta(eventInfo)
    if type(eventInfo) ~= "table" then return nil end

    local eventID = SafeNumber(eventInfo.id)
    local duration = SafeNumber(eventInfo.duration)
    if not eventID or not IsTimelineDurationAllowed(duration) then
        return nil
    end

    if not IsEncounterTimelineSource(eventInfo.source) then
        return nil
    end

    local meta = {
        id = eventID,
        duration = duration,
        source = SafeNumber(eventInfo.source),
        name = nil,
        severity = nil,
    }

    local rawSeverity = eventInfo.severity
    if not IsSecret(rawSeverity) then
        local severity = SafeNumber(rawSeverity)
        if severity ~= nil and severity >= 0 and severity <= 2 then
            meta.severity = severity
        end
    end

    -- Prefer Blizzard's actual readable identity. Midnight can independently
    -- protect spellName and spellID, so each field is handled on its own.
    local rawName = eventInfo.spellName
    if IsSecret(rawName) then
        -- A secret string cannot be inspected in Lua, but Blizzard FontString
        -- display APIs can consume it directly. Preserve it only for display;
        -- never concatenate, compare, sort, or use it as a table key.
        meta.displayName = rawName
        meta.displayNamePresent = true
    elseif type(rawName) == "string" and rawName ~= "" then
        meta.name = rawName
        meta.displayName = rawName
        meta.displayNamePresent = true
    end

    local rawSpellID = eventInfo.spellID
    if not IsSecret(rawSpellID) then
        local spellID = SafeNumber(rawSpellID)
        if spellID then
            meta.spellID = spellID
            meta.publicSpellID = spellID

            if not meta.name and C_Spell and C_Spell.GetSpellName then
                local okName, resolvedName = pcall(C_Spell.GetSpellName, spellID)
                if okName and not IsSecret(resolvedName)
                    and type(resolvedName) == "string" and resolvedName ~= "" then
                    meta.name = resolvedName
                end
            end

            if meta.name then
                seenSpells[spellID] = meta.name
            end
        end
    end

    -- If Blizzard exposes only the name, map it back to the exact known static
    -- encounter spell before using any duration fallback.
    if not meta.spellID and meta.name and currentEncounterID then
        meta.knownSpellID = ResolveKnownBossSpellIDByName(currentEncounterID, meta.name)
    end

    -- Midnight 12.1 may protect both spellID and spellName while leaving the
    -- encounter event's duration readable. Current encounter-timeline consumers use that
    -- duration as a dispatch fingerprint. ChayAlertHUD mirrors only the
    -- unambiguous role-important fingerprints; ambiguous values are omitted.
    if not meta.spellID and not meta.knownSpellID then
        local fallbackSpellID = ResolveTimelineFallbackSpellID(eventInfo)
        if fallbackSpellID then
            meta.spellID = fallbackSpellID
            meta.knownSpellID = fallbackSpellID

            if C_Spell and C_Spell.GetSpellName then
                local okName, resolvedName = pcall(C_Spell.GetSpellName, fallbackSpellID)
                if okName and not IsSecret(resolvedName)
                    and type(resolvedName) == "string" and resolvedName ~= "" then
                    meta.name = resolvedName
                    meta.displayName = resolvedName
                    meta.displayNamePresent = true
                    seenSpells[fallbackSpellID] = resolvedName
                end
            end
        end
    end

    -- Do not invent an ability name when Blizzard withholds the identity and
    -- no unambiguous current-source fallback exists.
    if not meta.name then
        meta.name = "Boss Ability"
    end
    if not meta.displayNamePresent then
        meta.displayName = meta.name
        meta.displayNamePresent = true
    end

    timelineMeta[eventID] = meta
    return meta
end

local function RemoveTimelineEvent(eventID)
    local id = SafeNumber(eventID)
    if not id then return end
    timelinePending[id] = nil
    timelineRuntime[id] = nil
    timelineMeta[id] = nil
end

local function AttachTimelineEvent(eventID, fallbackDuration)
    local id = SafeNumber(eventID)
    if not id then return false end

    local meta = timelineMeta[id]
    if not meta and C_EncounterTimeline and C_EncounterTimeline.GetEventInfo then
        local ok, info = pcall(C_EncounterTimeline.GetEventInfo, id)
        if ok and type(info) == "table" then
            meta = CaptureSafeTimelineMeta(info)
        end
    end
    if not meta then return false end

    local state = GetTimelineState(id)
    if state ~= STATE_ACTIVE then
        return false
    end

    local remaining = GetTimelineRemaining(id, fallbackDuration or meta.duration)
    if type(remaining) ~= "number" or remaining < 0 then
        return false
    end

    local blocked = false
    if C_EncounterTimeline and C_EncounterTimeline.IsEventBlocked then
        local ok, value = pcall(C_EncounterTimeline.IsEventBlocked, id)
        blocked = ok and not IsSecret(value) and value == true
    end
    if blocked then
        return false
    end

    local previous = timelineRuntime[id]
    timelineRuntime[id] = {
        id = id,
        duration = meta.duration,
        name = meta.name or "Boss Ability",
        displayName = meta.displayName,
        displayNamePresent = meta.displayNamePresent == true,
        spellID = meta.spellID,
        knownSpellID = meta.knownSpellID,
        severity = meta.severity,
        state = STATE_ACTIVE,
        expiresAt = GetTime() + remaining,
        alertPlayed = previous and previous.alertPlayed or false,
        urgentPlayed = previous and previous.urgentPlayed or false,
        lastBeep = previous and previous.lastBeep or nil,
        -- Preserve the TTS one-shot across timeline metadata/state refreshes.
        -- Without this, the same Blizzard event can be rebuilt and spoken twice.
        ttsPlayed = previous and previous.ttsPlayed or false,
        circleFlashPlayed = previous and previous.circleFlashPlayed or false,
    }
    return true
end

local function QueueTimelineAdded(eventInfo)
    local meta = CaptureSafeTimelineMeta(eventInfo)
    if not meta then return false end

    local now = GetTime()
    timelinePending[meta.id] = {
        eventID = meta.id,
        duration = meta.duration,
        readyAt = now + TIMELINE_CONFIRM_DELAY,
    }
    driver:Show()
    return true
end

local function ProcessTimelinePending()
    if not next(timelinePending) then return end

    local now = GetTime()
    for eventID, pending in pairs(timelinePending) do
        if now >= (pending.readyAt or 0) then
            timelinePending[eventID] = nil
            AttachTimelineEvent(eventID, pending.duration)
        end
    end
end

local function RecoverTimelineEvents()
    if not TimelineFeatureAvailable() then return end
    if not (C_EncounterTimeline and C_EncounterTimeline.GetEventList) then return end

    local ok, events = pcall(C_EncounterTimeline.GetEventList)
    if not ok or type(events) ~= "table" then return end

    for _, eventID in ipairs(events) do
        local id = SafeNumber(eventID)
        if id then
            local state = GetTimelineState(id)
            if state == STATE_ACTIVE then
                if not timelineMeta[id] and C_EncounterTimeline.GetEventInfo then
                    local okInfo, info = pcall(C_EncounterTimeline.GetEventInfo, id)
                    if okInfo and type(info) == "table" then
                        CaptureSafeTimelineMeta(info)
                    end
                end
                AttachTimelineEvent(id, 0)
            elseif state == STATE_FINISHED or state == STATE_CANCELED then
                RemoveTimelineEvent(id)
            end
        end
    end
end

local function SyncTimelineState(eventID)
    local id = SafeNumber(eventID)
    if not id then return end

    local state = GetTimelineState(id)
    if state == STATE_ACTIVE then
        timelinePending[id] = nil
        if not AttachTimelineEvent(id, 0) then
            RecoverTimelineEvents()
        end
    elseif state == STATE_PAUSED then
        local runtime = timelineRuntime[id]
        if runtime then
            runtime.state = STATE_PAUSED
            runtime.expiresAt = nil
        end
    elseif state == STATE_FINISHED or state == STATE_CANCELED then
        RemoveTimelineEvent(id)
    end
end



local function GetSafeNPCID(unit)
    if type(unit) ~= "string" then return nil end

    -- Current Retail API: prefer the direct creature-ID lookup.
    if type(UnitCreatureID) == "function" then
        local ok, creatureID = pcall(UnitCreatureID, unit)
        if ok and not IsSecret(creatureID) then
            creatureID = tonumber(creatureID)
            if creatureID then
                return creatureID
            end
        end
    end

    -- Conservative fallback for clients/environments where UnitCreatureID
    -- yields no readable result.
    if type(UnitGUID) ~= "function" then return nil end
    local ok, guid = pcall(UnitGUID, unit)
    if not ok or IsSecret(guid) or type(guid) ~= "string" then return nil end

    local unitType, _, _, _, _, npcID
    if type(strsplit) == "function" then
        unitType, _, _, _, _, npcID = strsplit("-", guid)
    else
        unitType, npcID = guid:match("^([^-]+)%-%d+%-%d+%-%d+%-%d+%-(%d+)")
    end

    if unitType ~= "Creature" and unitType ~= "Vehicle" then return nil end
    return tonumber(npcID)
end

local function IsBlizzardImportantSpell(spellID)
    spellID = tonumber(spellID)
    if not spellID then return false end

    local cached = importantSpellCache[spellID]
    if cached ~= nil then return cached end

    if not (C_Spell and C_Spell.IsSpellImportant) then
        return false
    end

    local ok, value = pcall(C_Spell.IsSpellImportant, spellID)
    -- Midnight can return a secret boolean from otherwise callable APIs. A
    -- secret boolean cannot be branched on, compared, cached, or otherwise
    -- inspected by addon Lua, so only consume an explicitly non-secret result.
    if not ok or IsSecret(value) or type(value) ~= "boolean" then
        return false
    end

    importantSpellCache[spellID] = value
    return value
end

local function IsBlizzardImportantIdentifier(spellIdentifier)
    if not (C_Spell and C_Spell.IsSpellImportant) then
        return false
    end

    -- A secret hostile-cast identifier may be accepted by
    -- C_Spell.IsSpellImportant, but the returned boolean is secret as well.
    -- That result cannot legally drive Lua control flow. Protected casts are
    -- therefore classified by the bundled protected-cast inference path, which
    -- works from public castBarID and static candidate data instead.
    if IsSecret(spellIdentifier) then
        return false
    end

    if spellIdentifier == nil then
        return false
    end

    local numericID = tonumber(spellIdentifier)
    if numericID then
        return IsBlizzardImportantSpell(numericID)
    end

    local ok, value = pcall(C_Spell.IsSpellImportant, spellIdentifier)
    if not ok or IsSecret(value) or type(value) ~= "boolean" then
        return false
    end
    return value
end

local VALID_ROLE_PROFILES = { AUTO = true, TANK = true, HEALER = true, DAMAGER = true, ALL = true }
local ROLE_LABELS = { TANK = "Tank", HEALER = "Healer", DAMAGER = "DPS" }

local function NormalizeRoleToken(role)
    if role == "DPS" then role = "DAMAGER" end
    if role == "TANK" or role == "HEALER" or role == "DAMAGER" then
        return role
    end
    return nil
end

local function GetAutomaticRole()
    if type(GetSpecialization) == "function" and type(GetSpecializationRole) == "function" then
        local okSpec, specIndex = pcall(GetSpecialization)
        if okSpec and type(specIndex) == "number" and specIndex > 0 then
            local okRole, role = pcall(GetSpecializationRole, specIndex)
            if okRole then
                role = NormalizeRoleToken(role)
                if role then return role end
            end
        end
    end

    if type(UnitGroupRolesAssigned) == "function" then
        local ok, role = pcall(UnitGroupRolesAssigned, "player")
        if ok then
            role = NormalizeRoleToken(role)
            if role then return role end
        end
    end

    return nil
end

local function RoleStringAllows(roles, role)
    if type(roles) ~= "string" or roles == "" or roles == "ALL" then
        return true
    end
    role = NormalizeRoleToken(role)
    if not role then return false end
    local padded = "_" .. roles .. "_"
    return padded:find("_" .. role .. "_", 1, true) ~= nil
end

local function RoleStringLabel(roles)
    if type(roles) ~= "string" or roles == "" or roles == "ALL" then
        return "All roles"
    end
    local labels = {}
    for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
        if RoleStringAllows(roles, role) then
            labels[#labels + 1] = ROLE_LABELS[role]
        end
    end
    return #labels > 0 and table.concat(labels, " + ") or "Other role"
end

function CT:GetRoleProfile()
    if not db or not VALID_ROLE_PROFILES[db.roleProfile] then return "AUTO" end
    return db.roleProfile
end

function CT:GetEffectiveRole()
    local profile = self:GetRoleProfile()
    if profile == "AUTO" then
        return GetAutomaticRole()
    end
    return NormalizeRoleToken(profile)
end

-- Display profile must never replace the player's actual role for mechanics
-- whose eligibility is based on specialization, such as a tank-only swap.
function CT:GetActualRole()
    return GetAutomaticRole()
end

function CT:GetRoleProfileLabel()
    local profile = self:GetRoleProfile()
    if profile == "AUTO" then
        local role = self:GetEffectiveRole()
        return role and ("Auto: " .. ROLE_LABELS[role]) or "Auto"
    end
    if profile == "ALL" then return "All Abilities" end
    return ROLE_LABELS[profile] or "Auto"
end

function CT:GetRoleLabel(role)
    return ROLE_LABELS[NormalizeRoleToken(role)] or "Unknown"
end

function CT:GetRolesLabel(roles)
    return RoleStringLabel(roles)
end

function CT:IsRoleRelevant(roles)
    if self:GetRoleProfile() == "ALL" then return true end
    return RoleStringAllows(roles, self:GetEffectiveRole())
end

function CT:SetRoleProfile(profile)
    if not db then return end
    if profile == "DPS" then profile = "DAMAGER" end
    if not VALID_ROLE_PROFILES[profile] then return end
    if db.roleProfile == profile then return end

    db.roleProfile = profile
    wipe(trashCasts)
    wipe(trashRetryToken)
    UpdateLiveAlerts()

    if self.RefreshDungeonMobPage then self:RefreshDungeonMobPage() end
    if self.RefreshDungeonBossPage then self:RefreshDungeonBossPage() end
    if self.RefreshRaidPage then self:RefreshRaidPage() end
end

function CT:GetImportantAurasEnabled()
    return db and db.importantAurasEnabled == true or false
end

function CT:SetImportantAurasEnabled(value)
    if not db then return end
    db.importantAurasEnabled = value and true or false
    if self.RefreshAuraContainerState then
        self:RefreshAuraContainerState()
    end
end

function CT:ShouldEnableImportantAuraContainer()
    return db ~= nil
        and db.enabled == true
        and db.importantAurasEnabled == true
        and IsInSupportedInstance()
end

function CT:GetAuraContainerLayout()
    if not db then
        return { x = 0, y = -58, size = 132, spacing = 14, maxAlerts = 3 }
    end

    local anchor = db.circles[math.min(3, MAX_CIRCLES)] or db.circles[1]
    local anchorX = anchor and tonumber(anchor.x) or 0
    local anchorY = anchor and tonumber(anchor.y) or 145
    local anchorSize = anchor and tonumber(anchor.size) or 164
    local auraSize = math.max(112, math.min(144, math.floor((anchorSize * 0.80) + 0.5)))

    return {
        x = anchorX,
        y = anchorY - math.max(anchorSize, auraSize) - 34,
        size = auraSize,
        spacing = 14,
        maxAlerts = math.max(1, math.min(MAX_CIRCLES, tonumber(db.maxAlerts) or 3)),
    }
end

local function BuildTrashRoleString(spellMeta)
    if not spellMeta then return "ALL" end
    local tank, healer, damager = false, false, false

    if spellMeta.interruptible or spellMeta.enrage then
        tank, damager = true, true
    end
    if spellMeta.magic or spellMeta.curse or spellMeta.poison or spellMeta.disease then
        healer = true
    end

    local roles = {}
    if tank then roles[#roles + 1] = "TANK" end
    if healer then roles[#roles + 1] = "HEALER" end
    if damager then roles[#roles + 1] = "DAMAGER" end
    return #roles > 0 and table.concat(roles, "_") or "ALL"
end

local function GetTrashImportanceInfo(spellMeta)
    if not spellMeta then
        return false, "ALL", 1, "Catalog only"
    end

    local roles = BuildTrashRoleString(spellMeta)
    if IsBlizzardImportantSpell(spellMeta.id) then
        return true, roles, 3, "Blizzard Important"
    end

    -- The bundled runtime model carries ChayAlert HUD's curated default-enabled
    -- state for modeled trash mechanics. Runtime inference, role filtering,
    -- rendering, and manual overrides remain owned by ChayAlert HUD.
    local runtimeRef
    local mob = spellMeta.mob
    if TrashRuntimeData and mob and TrashRuntimeData.GetSpell then
        runtimeRef = TrashRuntimeData:GetSpell(mob.dungeonKey, mob.npcID, spellMeta.id)
    end
    if runtimeRef and runtimeRef.enabled == true then
        return true, roles, 3, "Chay curated important mechanic"
    end
    if runtimeRef and runtimeRef.enabled == false then
        return false, roles, 1, "Chay curated optional mechanic"
    end
    if spellMeta.curated == true then
        return true, roles, 3, "Chay curated important mechanic"
    end

    -- No generic interruptible fallback. Abilities without Blizzard importance,
    -- runtime-model classification, or an explicit curated flag remain optional.
    return false, roles, 1, "Catalog only"
end

local function GetStaticRoleReference(kind, encounterID, spellID)
    if not RoleData or type(RoleData[kind]) ~= "table" then return nil end
    local encounter = RoleData[kind][tonumber(encounterID)]
    return type(encounter) == "table" and encounter[tonumber(spellID)] or nil
end

local function GetBossImportanceInfo(kind, encounterID, spell)
    if not spell then
        return false, "ALL", 1, "Catalog only"
    end

    local ref = GetStaticRoleReference(kind, encounterID, spell.id)
    local blizzardImportant = IsBlizzardImportantSpell(spell.id)
    if ref then
        local priority = math.max(tonumber(ref.priority) or 2, blizzardImportant and 3 or 1)
        local reason = blizzardImportant and ("Blizzard Important + " .. (ref.reason or "ChayAlert priority warning"))
            or (ref.reason or "High-priority ChayAlert warning")
        return true, ref.roles or "ALL", priority, reason
    end

    if blizzardImportant then
        return true, "ALL", 3, "Blizzard Important"
    end

    if spell.defaultAlert == false then
        return false, "ALL", 1, "Catalog only"
    end

    -- The dungeon-boss and raid catalogs are the current, verified encounter
    -- alert sets. RoleData still narrows role-specific mechanics above, while
    -- catalog mechanics without a role restriction remain relevant to all roles.
    return true, "ALL", 2, "Tracked encounter mechanic"
end

local function GetMobOverride(dungeonKey, npcID, create)
    if not db or type(dungeonKey) ~= "string" or type(npcID) ~= "number" then return nil end
    if type(db.mobAbilityOverrides) ~= "table" then
        if not create then return nil end
        db.mobAbilityOverrides = {}
    end

    local dungeon = db.mobAbilityOverrides[dungeonKey]
    if type(dungeon) ~= "table" then
        if not create then return nil end
        dungeon = {}
        db.mobAbilityOverrides[dungeonKey] = dungeon
    end

    local mob = dungeon[npcID]
    if type(mob) ~= "table" then
        if not create then return nil end
        mob = { spells = {} }
        dungeon[npcID] = mob
    elseif type(mob.spells) ~= "table" then
        mob.spells = {}
    end
    return mob
end

local function GetAbilityOverride(dungeonKey, npcID, spellID, create)
    local mob = GetMobOverride(dungeonKey, npcID, create)
    if not mob or type(spellID) ~= "number" then return nil end

    local row = mob.spells[spellID]
    if type(row) ~= "table" then
        if not create then return nil end
        row = {}
        mob.spells[spellID] = row
    end
    return row
end

local function GetStaticSpellMeta(dungeonKey, npcID, spellID)
    if not DungeonData or not DungeonData.dungeons then return nil, nil end
    local dungeon = DungeonData.dungeons[dungeonKey]
    local mob = dungeon and dungeon.mobByID and dungeon.mobByID[npcID]
    if not mob then return nil, nil end
    return mob, mob.spellByID and mob.spellByID[spellID] or nil
end

local function IsRecommendedTrashAbility(spellMeta)
    local important, roles = GetTrashImportanceInfo(spellMeta)
    return important and CT:IsRoleRelevant(roles)
end

local function GetDefaultAbilityPriority(spellMeta)
    local _, _, priority = GetTrashImportanceInfo(spellMeta)
    return priority or 1
end

local function GetDefaultTTSEnabled(override, enabled)
    if override and type(override.ttsEnabled) == "boolean" then
        return override.ttsEnabled
    end
    return enabled == true
end

local function GetKnownAbilityConfig(dungeonKey, mobDef, spellID)
    if not dungeonKey or not mobDef or not spellID then
        return nil
    end

    local spellMeta = mobDef.spellByID and mobDef.spellByID[spellID] or nil
    if not spellMeta then
        return {
            knownMob = true,
            knownAbility = false,
            enabled = db.trackUnknownTrash == true,
            sound = true,
            ttsEnabled = false,
            ttsPhrase = nil,
            priority = 1,
            recommended = false,
            important = false,
            roleRelevant = true,
            roles = "ALL",
            reason = "Unknown ability",
        }
    end

    local important, recommendedRoles, defaultPriority, reason = GetTrashImportanceInfo(spellMeta)
    local abilityOverride = GetAbilityOverride(dungeonKey, mobDef.npcID, spellID, false)
    local roleOverride = abilityOverride and NormalizeRoleOverride(abilityOverride.roleOverride) or nil
    local roles = roleOverride or recommendedRoles
    local allAbilities = CT:GetRoleProfile() == "ALL"
    local roleRelevant = CT:IsRoleRelevant(roles)
    local recommended = important and roleRelevant

    local mobOverride = GetMobOverride(dungeonKey, mobDef.npcID, false)
    if mobOverride and mobOverride.enabled == false then
        return {
            knownMob = true,
            knownAbility = true,
            enabled = false,
            sound = false,
            priority = defaultPriority or 1,
            recommended = recommended,
            important = important,
            roleRelevant = roleRelevant,
            roles = roles,
            recommendedRoles = recommendedRoles,
            rolesIsCustom = roleOverride ~= nil,
            reason = reason,
            spellMeta = spellMeta,
        }
    end

    local enabled
    if abilityOverride and type(abilityOverride.enabled) == "boolean" then
        enabled = abilityOverride.enabled
    else
        enabled = allAbilities or recommended
    end

    local sound = not (abilityOverride and abilityOverride.sound == false)
    local priority = abilityOverride and tonumber(abilityOverride.priority) or defaultPriority or 1
    priority = math.max(1, math.min(3, priority or 1))

    local label
    if abilityOverride and type(abilityOverride.label) == "string" then
        local trimmed = abilityOverride.label:gsub("^%s+", ""):gsub("%s+$", "")
        if trimmed ~= "" then label = trimmed end
    end

    return {
        knownMob = true,
        knownAbility = true,
        enabled = enabled,
        sound = sound,
        ttsEnabled = GetDefaultTTSEnabled(abilityOverride, enabled),
        ttsPhrase = abilityOverride and abilityOverride.ttsPhrase or nil,
        priority = priority,
        label = label,
        recommended = recommended,
        important = important,
        roleRelevant = roleRelevant,
        roles = roles,
        recommendedRoles = recommendedRoles,
        rolesIsCustom = roleOverride ~= nil,
        reason = reason,
        hasEnabledOverride = abilityOverride and type(abilityOverride.enabled) == "boolean" or false,
        hasTTSOverride = abilityOverride and type(abilityOverride.ttsEnabled) == "boolean" or false,
        displayMode = abilityOverride and NormalizeDisplayMode(abilityOverride.displayMode, true) or "INHERIT",
        effectiveDisplayMode = ResolveDisplayMode(abilityOverride and abilityOverride.displayMode),
        mechanicType = InferMechanicType(spellMeta, roles, abilityOverride and abilityOverride.mechanicType),
        mechanicTypeOverride = abilityOverride and NormalizeMechanicOverride(abilityOverride.mechanicType) or nil,
        spellMeta = spellMeta,
    }
end

function CT:GetDungeonData()
    return DungeonData
end

function CT:GetCurrentDungeonKey()
    return DungeonData and DungeonData.GetCurrentDungeonKey and DungeonData:GetCurrentDungeonKey() or nil
end

function CT:GetMobEffectiveEnabled(dungeonKey, npcID)
    local ov = GetMobOverride(dungeonKey, tonumber(npcID), false)
    return not (ov and ov.enabled == false)
end

function CT:SetMobEnabled(dungeonKey, npcID, enabled)
    npcID = tonumber(npcID)
    if not npcID then return end
    local ov = GetMobOverride(dungeonKey, npcID, true)
    ov.enabled = enabled ~= false
    UpdateLiveAlerts()
end

function CT:GetAbilityEffectiveConfig(dungeonKey, npcID, spellID)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    local mob, spellMeta = GetStaticSpellMeta(dungeonKey, npcID, spellID)
    if not mob or not spellMeta then return nil end
    return GetKnownAbilityConfig(dungeonKey, mob, spellID)
end

function CT:IsRuntimeAbilityEnabled(dungeonKey, npcID, spellID)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not db or not npcID or not spellID then return false end
    if db.mutedSpells[spellID] == true then return false end

    local explicitlyTracked = db.trackedSpells[spellID] == true
    if db.trackOnlyCustom then
        return explicitlyTracked
    end
    if explicitlyTracked then
        return true
    end

    local cfg = self:GetAbilityEffectiveConfig(dungeonKey, npcID, spellID)
    return cfg ~= nil and cfg.enabled ~= false
end

function CT:SetAbilityEnabled(dungeonKey, npcID, spellID, enabled)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    ov.enabled = enabled ~= false
    UpdateLiveAlerts()
end

function CT:SetAbilitySound(dungeonKey, npcID, spellID, enabled)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    ov.sound = enabled ~= false
end

function CT:SetAbilityTTS(dungeonKey, npcID, spellID, enabled, phrase)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    if enabled ~= nil then ov.ttsEnabled = enabled == true end
    if phrase ~= nil then
        local text = type(phrase) == "string" and phrase:gsub("^%s+", ""):gsub("%s+$", "") or ""
        ov.ttsPhrase = text ~= "" and text or nil
    end
    UpdateLiveAlerts()
end

function CT:SetAbilityPriority(dungeonKey, npcID, spellID, priority)
    npcID, spellID, priority = tonumber(npcID), tonumber(spellID), tonumber(priority)
    if not npcID or not spellID or not priority then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    ov.priority = math.max(1, math.min(3, math.floor(priority + 0.5)))
    UpdateLiveAlerts()
end

function CT:SetAbilityLabel(dungeonKey, npcID, spellID, label)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    local text = type(label) == "string" and label:gsub("^%s+", ""):gsub("%s+$", "") or ""
    ov.label = text ~= "" and text or nil
    UpdateLiveAlerts()
end

function CT:SetAbilityDisplayMode(dungeonKey, npcID, spellID, mode)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    ov.displayMode = NormalizeDisplayMode(mode, true)
    UpdateLiveAlerts()
end

function CT:SetAbilityMechanicType(dungeonKey, npcID, spellID, mechanicType)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    ov.mechanicType = NormalizeMechanicOverride(mechanicType)
    UpdateLiveAlerts()
end

function CT:SetAbilityRoleOverride(dungeonKey, npcID, spellID, roles)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    if not npcID or not spellID then return end
    local ov = GetAbilityOverride(dungeonKey, npcID, spellID, true)
    ov.roleOverride = NormalizeRoleOverride(roles)
    UpdateLiveAlerts()
end

function CT:ResetAbility(dungeonKey, npcID, spellID)
    npcID, spellID = tonumber(npcID), tonumber(spellID)
    local mob = GetMobOverride(dungeonKey, npcID, false)
    if mob and type(mob.spells) == "table" and spellID then
        mob.spells[spellID] = nil
    end
    UpdateLiveAlerts()
end

function CT:ResetMobAbilities(dungeonKey, npcID)
    npcID = tonumber(npcID)
    local dungeon = db and db.mobAbilityOverrides and db.mobAbilityOverrides[dungeonKey]
    if dungeon and npcID then
        dungeon[npcID] = nil
        if not next(dungeon) then
            db.mobAbilityOverrides[dungeonKey] = nil
        end
    end
    UpdateLiveAlerts()
end

function CT:ResetDungeonAbilities(dungeonKey)
    if db and db.mobAbilityOverrides then
        db.mobAbilityOverrides[dungeonKey] = nil
    end
    UpdateLiveAlerts()
end

function CT:GetTrackUnknownTrash()
    return db and db.trackUnknownTrash == true
end

function CT:SetTrackUnknownTrash(value)
    if db then
        db.trackUnknownTrash = value == true
        UpdateLiveAlerts()
    end
end

function CT:IsSpellBlizzardImportant(spellID)
    return IsBlizzardImportantSpell(spellID)
end

function CT:GetShowOptionalAbilities()
    return db and db.showOptionalAbilities == true
end

function CT:SetShowOptionalAbilities(value)
    if db then
        db.showOptionalAbilities = value == true
    end
end

function CT:GetTrackUnknownBossTimeline()
    return db and db.trackUnknownBossTimeline == true
end

function CT:SetTrackUnknownBossTimeline(value)
    if db then
        db.trackUnknownBossTimeline = value == true
        UpdateLiveAlerts()
    end
end

function CT:GetDungeonBossData()
    return DungeonBossData
end

function CT:GetRaidData()
    return RaidData
end


local function GetBossAbilityOverride(encounterID, spellID, create)
    encounterID, spellID = tonumber(encounterID), tonumber(spellID)
    if not db or not encounterID or not spellID then return nil end

    if type(db.bossAbilityOverrides) ~= "table" then
        if not create then return nil end
        db.bossAbilityOverrides = {}
    end

    local encounter = db.bossAbilityOverrides[encounterID]
    if type(encounter) ~= "table" then
        if not create then return nil end
        encounter = {}
        db.bossAbilityOverrides[encounterID] = encounter
    end

    local ability = encounter[spellID]
    if type(ability) ~= "table" then
        if not create then return nil end
        ability = {}
        encounter[spellID] = ability
    end
    return ability
end

local function GetDungeonBossStaticSpell(encounterID, spellID)
    if not DungeonBossData or not DungeonBossData.byEncounterID then return nil, nil end
    local entry = DungeonBossData.byEncounterID[tonumber(encounterID)]
    local boss = entry and entry.boss
    local spell = boss and boss.spellByID and boss.spellByID[tonumber(spellID)]
    return boss, spell
end

function CT:GetBossAbilityEffectiveConfig(encounterID, spellID)
    encounterID, spellID = tonumber(encounterID), tonumber(spellID)
    local boss, spell = GetDungeonBossStaticSpell(encounterID, spellID)
    if not boss or not spell then return nil end

    local ov = GetBossAbilityOverride(encounterID, spellID, false)
    local important, recommendedRoles, defaultPriority, reason = GetBossImportanceInfo("boss", encounterID, spell)
    local roleOverride = ov and NormalizeRoleOverride(ov.roleOverride) or nil
    local roles = roleOverride or recommendedRoles
    local allAbilities = CT:GetRoleProfile() == "ALL"
    local roleRelevant = allAbilities or (important and CT:IsRoleRelevant(roles)) or false
    local recommended = important and CT:IsRoleRelevant(roles)
    local hasEnabledOverride = ov and type(ov.enabled) == "boolean" or false

    local enabled
    if hasEnabledOverride then
        enabled = ov.enabled
    else
        enabled = allAbilities or recommended
    end

    local sound = not (ov and ov.sound == false)
    local priority = ov and tonumber(ov.priority) or defaultPriority
    priority = math.max(1, math.min(3, priority or 1))
    local leadTime = ov and tonumber(ov.leadTime) or tonumber(db.leadTime) or 10
    leadTime = math.max(3, math.min(30, leadTime))

    local label
    if ov and type(ov.label) == "string" then
        local trimmed = ov.label:gsub("^%s+", ""):gsub("%s+$", "")
        if trimmed ~= "" then label = trimmed end
    end

    return {
        boss = boss,
        spell = spell,
        enabled = enabled,
        sound = sound,
        ttsEnabled = GetDefaultTTSEnabled(ov, enabled),
        ttsPhrase = ov and ov.ttsPhrase or nil,
        priority = priority,
        leadTime = leadTime,
        label = label,
        important = important,
        roleRelevant = roleRelevant,
        roles = roles,
        recommendedRoles = recommendedRoles,
        rolesIsCustom = roleOverride ~= nil,
        reason = reason,
        recommended = recommended,
        hasEnabledOverride = hasEnabledOverride,
        hasTTSOverride = ov and type(ov.ttsEnabled) == "boolean" or false,
        displayMode = ov and NormalizeDisplayMode(ov.displayMode, true) or "INHERIT",
        effectiveDisplayMode = ResolveDisplayMode(ov and ov.displayMode),
        mechanicType = InferMechanicType(spell, roles, ov and ov.mechanicType),
        mechanicTypeOverride = ov and NormalizeMechanicOverride(ov.mechanicType) or nil,
    }
end

function CT:SetBossAbilityEnabled(encounterID, spellID, enabled)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.enabled = enabled ~= false
    UpdateLiveAlerts()
end

function CT:SetBossAbilitySound(encounterID, spellID, enabled)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.sound = enabled ~= false
end

function CT:SetBossAbilityTTS(encounterID, spellID, enabled, phrase)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    if enabled ~= nil then ov.ttsEnabled = enabled == true end
    if phrase ~= nil then
        local text = type(phrase) == "string" and phrase:gsub("^%s+", ""):gsub("%s+$", "") or ""
        ov.ttsPhrase = text ~= "" and text or nil
    end
    UpdateLiveAlerts()
end

function CT:SetBossAbilityPriority(encounterID, spellID, priority)
    priority = tonumber(priority)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov or not priority then return end
    ov.priority = math.max(1, math.min(3, math.floor(priority + 0.5)))
    UpdateLiveAlerts()
end

function CT:SetBossAbilityLabel(encounterID, spellID, label)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    local text = type(label) == "string" and label:gsub("^%s+", ""):gsub("%s+$", "") or ""
    ov.label = text ~= "" and text or nil
    UpdateLiveAlerts()
end

function CT:SetBossAbilityDisplayMode(encounterID, spellID, mode)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.displayMode = NormalizeDisplayMode(mode, true)
    UpdateLiveAlerts()
end

function CT:SetBossAbilityMechanicType(encounterID, spellID, mechanicType)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.mechanicType = NormalizeMechanicOverride(mechanicType)
    UpdateLiveAlerts()
end

function CT:SetBossAbilityRoleOverride(encounterID, spellID, roles)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.roleOverride = NormalizeRoleOverride(roles)
    UpdateLiveAlerts()
end

function CT:SetBossAbilityLeadTime(encounterID, spellID, seconds)
    local ov = GetBossAbilityOverride(encounterID, spellID, true)
    local value = tonumber(seconds)
    if not ov or not value then return end
    ov.leadTime = math.max(3, math.min(30, math.floor(value + 0.5)))
    UpdateLiveAlerts()
end

function CT:ResetBossAbility(encounterID, spellID)
    encounterID, spellID = tonumber(encounterID), tonumber(spellID)
    local encounter = db and db.bossAbilityOverrides and db.bossAbilityOverrides[encounterID]
    if type(encounter) == "table" and spellID then
        encounter[spellID] = nil
        if not next(encounter) then db.bossAbilityOverrides[encounterID] = nil end
    end
    UpdateLiveAlerts()
end

function CT:ResetDungeonBossAbilities(encounterID)
    encounterID = tonumber(encounterID)
    if db and db.bossAbilityOverrides and encounterID then
        db.bossAbilityOverrides[encounterID] = nil
    end
    UpdateLiveAlerts()
end

local function GetRaidAbilityOverride(encounterID, spellID, create)
    encounterID, spellID = tonumber(encounterID), tonumber(spellID)
    if not db or not encounterID or not spellID then return nil end

    if type(db.raidAbilityOverrides) ~= "table" then
        if not create then return nil end
        db.raidAbilityOverrides = {}
    end

    local encounter = db.raidAbilityOverrides[encounterID]
    if type(encounter) ~= "table" then
        if not create then return nil end
        encounter = {}
        db.raidAbilityOverrides[encounterID] = encounter
    end

    local ability = encounter[spellID]
    if type(ability) ~= "table" then
        if not create then return nil end
        ability = {}
        encounter[spellID] = ability
    end
    return ability
end

local function GetRaidStaticSpell(encounterID, spellID)
    if not RaidData or not RaidData.byEncounterID then return nil, nil end
    local entry = RaidData.byEncounterID[tonumber(encounterID)]
    local boss = entry and entry.boss
    local spell = boss and boss.spellByID and boss.spellByID[tonumber(spellID)]
    return boss, spell
end

function CT:GetRaidAbilityEffectiveConfig(encounterID, spellID)
    encounterID, spellID = tonumber(encounterID), tonumber(spellID)
    local boss, spell = GetRaidStaticSpell(encounterID, spellID)
    if not boss or not spell then return nil end

    local ov = GetRaidAbilityOverride(encounterID, spellID, false)
    local important, recommendedRoles, defaultPriority, reason = GetBossImportanceInfo("raid", encounterID, spell)
    local roleOverride = ov and NormalizeRoleOverride(ov.roleOverride) or nil
    local roles = roleOverride or recommendedRoles
    local allAbilities = CT:GetRoleProfile() == "ALL"
    local roleRelevant = allAbilities or (important and CT:IsRoleRelevant(roles)) or false
    local recommended = important and CT:IsRoleRelevant(roles)
    local hasEnabledOverride = ov and type(ov.enabled) == "boolean" or false

    local enabled
    if hasEnabledOverride then
        enabled = ov.enabled
    else
        enabled = allAbilities or recommended
    end

    local sound = not (ov and ov.sound == false)
    local priority = ov and tonumber(ov.priority) or defaultPriority
    priority = math.max(1, math.min(3, priority or 1))
    local leadTime = ov and tonumber(ov.leadTime) or tonumber(db.leadTime) or 10
    leadTime = math.max(3, math.min(30, leadTime))

    local label
    if ov and type(ov.label) == "string" then
        local trimmed = ov.label:gsub("^%s+", ""):gsub("%s+$", "")
        if trimmed ~= "" then label = trimmed end
    end

    return {
        boss = boss,
        spell = spell,
        enabled = enabled,
        sound = sound,
        ttsEnabled = GetDefaultTTSEnabled(ov, enabled),
        ttsPhrase = ov and ov.ttsPhrase or nil,
        priority = priority,
        leadTime = leadTime,
        label = label,
        important = important,
        roleRelevant = roleRelevant,
        roles = roles,
        recommendedRoles = recommendedRoles,
        rolesIsCustom = roleOverride ~= nil,
        reason = reason,
        recommended = recommended,
        hasEnabledOverride = hasEnabledOverride,
        hasTTSOverride = ov and type(ov.ttsEnabled) == "boolean" or false,
        displayMode = ov and NormalizeDisplayMode(ov.displayMode, true) or "INHERIT",
        effectiveDisplayMode = ResolveDisplayMode(ov and ov.displayMode),
        mechanicType = InferMechanicType(spell, roles, ov and ov.mechanicType),
        mechanicTypeOverride = ov and NormalizeMechanicOverride(ov.mechanicType) or nil,
    }
end

function CT:SetRaidAbilityEnabled(encounterID, spellID, enabled)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.enabled = enabled ~= false
    UpdateLiveAlerts()
end

function CT:SetRaidAbilitySound(encounterID, spellID, enabled)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.sound = enabled ~= false
end

function CT:SetRaidAbilityTTS(encounterID, spellID, enabled, phrase)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    if enabled ~= nil then ov.ttsEnabled = enabled == true end
    if phrase ~= nil then
        local text = type(phrase) == "string" and phrase:gsub("^%s+", ""):gsub("%s+$", "") or ""
        ov.ttsPhrase = text ~= "" and text or nil
    end
    UpdateLiveAlerts()
end

function CT:SetRaidAbilityPriority(encounterID, spellID, priority)
    priority = tonumber(priority)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov or not priority then return end
    ov.priority = math.max(1, math.min(3, math.floor(priority + 0.5)))
    UpdateLiveAlerts()
end

function CT:SetRaidAbilityLabel(encounterID, spellID, label)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    local text = type(label) == "string" and label:gsub("^%s+", ""):gsub("%s+$", "") or ""
    ov.label = text ~= "" and text or nil
    UpdateLiveAlerts()
end

function CT:SetRaidAbilityDisplayMode(encounterID, spellID, mode)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.displayMode = NormalizeDisplayMode(mode, true)
    UpdateLiveAlerts()
end

function CT:SetRaidAbilityMechanicType(encounterID, spellID, mechanicType)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.mechanicType = NormalizeMechanicOverride(mechanicType)
    UpdateLiveAlerts()
end

function CT:SetRaidAbilityRoleOverride(encounterID, spellID, roles)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    if not ov then return end
    ov.roleOverride = NormalizeRoleOverride(roles)
    UpdateLiveAlerts()
end

function CT:SetRaidAbilityLeadTime(encounterID, spellID, seconds)
    local ov = GetRaidAbilityOverride(encounterID, spellID, true)
    local value = tonumber(seconds)
    if not ov or not value then return end
    ov.leadTime = math.max(3, math.min(30, math.floor(value + 0.5)))
    UpdateLiveAlerts()
end

function CT:ResetRaidAbility(encounterID, spellID)
    encounterID, spellID = tonumber(encounterID), tonumber(spellID)
    local encounter = db and db.raidAbilityOverrides and db.raidAbilityOverrides[encounterID]
    if type(encounter) == "table" and spellID then
        encounter[spellID] = nil
        if not next(encounter) then db.raidAbilityOverrides[encounterID] = nil end
    end
    UpdateLiveAlerts()
end

function CT:ResetRaidBossAbilities(encounterID)
    encounterID = tonumber(encounterID)
    if db and db.raidAbilityOverrides and encounterID then
        db.raidAbilityOverrides[encounterID] = nil
    end
    UpdateLiveAlerts()
end


local function IsNameplateUnit(unit)
    return type(unit) == "string" and unit:match("^nameplate%d+$") ~= nil
end

local function IsHostileNameplateUnit(unit)
    if not IsNameplateUnit(unit) then return false end

    if type(UnitExists) == "function" then
        local ok, exists = pcall(UnitExists, unit)
        if not ok then return false end
        if not IsSecret(exists) and exists ~= true then return false end
    end

    if type(UnitCanAttack) == "function" then
        local ok, canAttack = pcall(UnitCanAttack, "player", unit)
        if not ok then return false end
        -- Midnight can protect hostility on hostile nameplates. Never compare a
        -- secret boolean in Lua. A protected nameplate is treated as potentially
        -- hostile; protected cast classification is deferred to the public
        -- castBarID/static-candidate runtime path before an automatic circle is
        -- created.
        if not IsSecret(canAttack) and canAttack ~= true then return false end
    end
    return true
end

local function SafeUnitName(unit)
    if not IsNameplateUnit(unit) or type(UnitName) ~= "function" then return nil end
    local ok, name = pcall(UnitName, unit)
    if ok and not IsSecret(name) and type(name) == "string" and name ~= "" then
        return name
    end
    return nil
end

local function GetSafeSpellName(spellID)
    if type(spellID) ~= "number" then
        return nil
    end
    if C_Spell and C_Spell.GetSpellName then
        local ok, name = pcall(C_Spell.GetSpellName, spellID)
        if ok and not IsSecret(name) and type(name) == "string" and name ~= "" then
            return name
        end
    end
    return nil
end

local trashSpellResolutionCache = {}

local function ResolveKnownTrashAbilityBySpellID(spellID)
    spellID = tonumber(spellID)
    if not spellID or not DungeonData or type(DungeonData.dungeons) ~= "table" then
        return nil, nil
    end

    local currentKey = DungeonData.GetCurrentDungeonKey and DungeonData:GetCurrentDungeonKey() or nil
    local cacheKey = tostring(currentKey or "*") .. ":" .. tostring(spellID)
    local cached = trashSpellResolutionCache[cacheKey]
    if cached ~= nil then
        if cached == false then return nil, nil end
        return cached.dungeonKey, cached.mob
    end

    local foundKey, foundMob
    local function ScanDungeon(dungeonKey, dungeon)
        if type(dungeon) ~= "table" or type(dungeon.mobs) ~= "table" then return false end
        for _, mob in ipairs(dungeon.mobs) do
            if type(mob) == "table" and type(mob.spellByID) == "table" and mob.spellByID[spellID] then
                if foundMob and foundMob ~= mob then
                    -- The same spell can legitimately be shared by multiple mobs.
                    -- Prefer the current dungeon; within it, either definition is
                    -- sufficient because the spell metadata drives importance/role.
                    return true
                end
                foundKey, foundMob = dungeonKey, mob
            end
        end
        return false
    end

    if currentKey and DungeonData.dungeons[currentKey] then
        ScanDungeon(currentKey, DungeonData.dungeons[currentKey])
    else
        for dungeonKey, dungeon in pairs(DungeonData.dungeons) do
            if ScanDungeon(dungeonKey, dungeon) then break end
        end
    end

    if foundMob then
        trashSpellResolutionCache[cacheKey] = { dungeonKey = foundKey, mob = foundMob }
        return foundKey, foundMob
    end

    trashSpellResolutionCache[cacheKey] = false
    return nil, nil
end

local function ResolveKnownTrashSpellIDByName(dungeonKey, mobDef, spellName)
    if type(dungeonKey) ~= "string" or type(mobDef) ~= "table" then return nil end
    if IsSecret(spellName) or type(spellName) ~= "string" or spellName == "" then return nil end

    local firstMatch
    for _, spell in ipairs(mobDef.spells or {}) do
        local spellID = tonumber(spell.id)
        if spellID and C_Spell and C_Spell.GetSpellName then
            local ok, knownName = pcall(C_Spell.GetSpellName, spellID)
            if ok and not IsSecret(knownName) and type(knownName) == "string" and knownName == spellName then
                firstMatch = firstMatch or spellID
            end
        end
    end
    return firstMatch
end

local function ReadNameplateCast(unit, isChannel)
    if not IsHostileNameplateUnit(unit) then return nil end

    local ok
    local name, displayName, textureID, startTimeMS, endTimeMS
    local isTradeskill, notInterruptible, rawSpellID, rawCastBarID
    local castID

    if isChannel then
        if type(UnitChannelInfo) ~= "function" then return nil end

        -- Current Retail UnitChannelInfo:
        -- name, displayName, textureID, startTimeMs, endTimeMs,
        -- isTradeskill, notInterruptible, spellID, isEmpowered,
        -- numEmpowerStages, castBarID
        local isEmpowered, numEmpowerStages
        ok, name, displayName, textureID, startTimeMS, endTimeMS,
            isTradeskill, notInterruptible, rawSpellID,
            isEmpowered, numEmpowerStages, rawCastBarID =
            pcall(UnitChannelInfo, unit)
    else
        if type(UnitCastingInfo) ~= "function" then return nil end

        -- Current Retail UnitCastingInfo:
        -- name, displayName, textureID, startTimeMs, endTimeMs,
        -- isTradeskill, castID, notInterruptible, castingSpellID,
        -- castBarID, delayTimeMs
        local delayTimeMs
        ok, name, displayName, textureID, startTimeMS, endTimeMS,
            isTradeskill, castID, notInterruptible, rawSpellID,
            rawCastBarID, delayTimeMs =
            pcall(UnitCastingInfo, unit)
    end

    if not ok then return nil end
    if IsSecret(startTimeMS) or IsSecret(endTimeMS) then return nil end
    if type(startTimeMS) ~= "number" or type(endTimeMS) ~= "number" then return nil end

    local duration = math.max(0, (endTimeMS - startTimeMS) / 1000)
    local remaining = math.max(0, (endTimeMS / 1000) - GetTime())
    if remaining <= 0 then return nil end

    local safeName
    if not IsSecret(name) and type(name) == "string" and name ~= "" then
        safeName = name
    end

    local spellID
    if not IsSecret(rawSpellID) then
        spellID = tonumber(rawSpellID)
    end

    local castBarID
    if not IsSecret(rawCastBarID) then
        castBarID = tonumber(rawCastBarID) or rawCastBarID
    end

    local safeCastID
    if not IsSecret(castID) and castID ~= nil then
        safeCastID = castID
    end

    return {
        duration = duration,
        remaining = remaining,
        expiresAt = endTimeMS / 1000,
        name = safeName,
        spellID = spellID,
        castBarID = castBarID,
        castID = safeCastID,
        mobName = SafeUnitName(unit),
        npcID = GetSafeNPCID(unit),
        isChannel = isChannel == true,
    }
end

local function ReadProtectedCastDuration(unit, isChannel)
    if not IsHostileNameplateUnit(unit) then return nil end

    local func = isChannel and UnitChannelDuration or UnitCastingDuration
    if type(func) ~= "function" then return nil end

    local ok, durationObject = pcall(func, unit)
    if not ok then return nil end
    return durationObject
end

local function ReadProtectedCastIdentifier(unit, isChannel)
    if not IsHostileNameplateUnit(unit) then return nil, nil end

    -- These identifiers may themselves be secret. Assignment is safe, but a
    -- secret identifier must never be compared, converted, indexed, or used to
    -- drive Lua control flow. Classification is deferred to TrashRuntime when
    -- the identifier remains protected.
    if isChannel then
        if type(UnitChannelInfo) ~= "function" then return nil, nil end
        local ok, _, _, _, _, _, _, _, rawSpellID, _, _, rawCastBarID = pcall(UnitChannelInfo, unit)
        if not ok then return nil, nil end
        return rawSpellID, rawCastBarID
    end

    if type(UnitCastingInfo) ~= "function" then return nil, nil end
    local ok, _, _, _, _, _, _, _, _, rawSpellID, rawCastBarID = pcall(UnitCastingInfo, unit)
    if not ok then return nil, nil end
    return rawSpellID, rawCastBarID
end

-- Midnight can protect hostile cast names even when Blizzard still allows that
-- text to be displayed by a FontString. Preserve the raw name only as a
-- display value: never concatenate, compare, format, sort, or index with it.
local function ReadProtectedCastDisplayName(unit, isChannel)
    if not IsHostileNameplateUnit(unit) then return nil, false, nil, false end
    local func = isChannel and UnitChannelInfo or UnitCastingInfo
    if type(func) ~= "function" then return nil, false, nil, false end

    local ok, rawName, rawDisplayName, rawTexture = pcall(func, unit)
    if not ok then return nil, false, nil, false end

    local texture, texturePresent
    if IsSecret(rawTexture) then
        texture, texturePresent = rawTexture, true
    elseif rawTexture ~= nil then
        texture, texturePresent = rawTexture, true
    end

    if IsSecret(rawDisplayName) then
        return rawDisplayName, true, texture, texturePresent
    end
    if type(rawDisplayName) == "string" and rawDisplayName ~= "" then
        return rawDisplayName, true, texture, texturePresent
    end
    if IsSecret(rawName) then
        return rawName, true, texture, texturePresent
    end
    if type(rawName) == "string" and rawName ~= "" then
        return rawName, true, texture, texturePresent
    end
    return nil, false, texture, texturePresent
end

local function TrashCastMatches(existing, castGUID, spellID, castBarID)
    if not existing then return false end

    if not IsSecret(castBarID) and castBarID ~= nil
        and existing.castBarID ~= nil and castBarID ~= existing.castBarID then
        return false
    end

    if not IsSecret(castGUID) and castGUID ~= nil
        and existing.castGUID ~= nil and castGUID ~= existing.castGUID then
        return false
    end

    if not IsSecret(spellID) and spellID ~= nil
        and existing.spellID ~= nil and tonumber(spellID) ~= existing.spellID then
        return false
    end

    return true
end

local function RemoveTrashCast(unit, castGUID, spellID, castBarID)
    if not IsNameplateUnit(unit) then return end
    local existing = trashCasts[unit]
    if not existing then return end

    -- NAME_PLATE_UNIT_REMOVED has no cast identity and should always clear.
    -- Do not compare a protected spell/cast payload with nil.
    local hasSecretIdentity = IsSecret(castGUID) or IsSecret(spellID) or IsSecret(castBarID)
    if not hasSecretIdentity and castGUID == nil and spellID == nil and castBarID == nil then
        trashCasts[unit] = nil
        trashRetryToken[unit] = nil
        return
    end

    if TrashCastMatches(existing, castGUID, spellID, castBarID) then
        trashCasts[unit] = nil
    end
end

local function BuildTrashDisplayName(cast, spellID, labelOverride)
    local spellName = type(labelOverride) == "string" and labelOverride ~= "" and labelOverride
        or cast.name
        or GetSafeSpellName(spellID)
        or (spellID and ("Spell " .. tostring(spellID)))
        or "TRASH CAST"
    if db.showTrashMobName and cast.mobName then
        return spellName .. " |cffaaaaaa— " .. cast.mobName .. "|r"
    end
    return spellName
end

local function CommitProtectedTrashCast(unit, eventSpellID, castGUID, eventCastBarID, isChannel, inferredNPCID)
    if not db or db.trashCastsEnabled ~= true then return false end
    if db.suppressTrashDuringBoss == true and currentEncounterID ~= nil then return true end
    if not IsHostileNameplateUnit(unit) or not IsInSupportedInstance() then return false end
    if not IsSecret(eventSpellID) and eventSpellID == nil then return false end

    local readableSpellID
    if not IsSecret(eventSpellID) then
        readableSpellID = tonumber(eventSpellID)
    end

    local mobName = SafeUnitName(unit)
    local npcID = GetSafeNPCID(unit)
    if not npcID and type(inferredNPCID) == "number" then
        npcID = inferredNPCID
    end
    local dungeonKey, mobDef
    if DungeonData and DungeonData.ResolveMob and npcID then
        dungeonKey, mobDef = DungeonData:ResolveMob(npcID, mobName)
    end
    -- Hostile NPC identity can be secret in Midnight combat. The UNIT_SPELLCAST
    -- spell ID is enough to resolve a known ability from the current dungeon, so
    -- never require a readable creature ID just to classify an important cast.
    if not mobDef and readableSpellID then
        dungeonKey, mobDef = ResolveKnownTrashAbilityBySpellID(readableSpellID)
    end

    local explicitlyTracked = readableSpellID and db.trackedSpells[readableSpellID] == true or false
    local knownConfig
    if mobDef and readableSpellID then
        knownConfig = GetKnownAbilityConfig(dungeonKey, mobDef, readableSpellID)
        if knownConfig and knownConfig.enabled == false then
            return true
        end
    end

    if readableSpellID and db.mutedSpells[readableSpellID] == true then
        return true
    end
    if db.trackOnlyCustom and not explicitlyTracked then
        return true
    end

    local managerTracked = knownConfig and knownConfig.enabled ~= false or false
    local blizzardImportant = IsBlizzardImportantIdentifier(eventSpellID)

    -- Protected spell identifiers cannot legally be used as Lua table keys or
    -- compared with static role data. This direct path therefore never guesses
    -- identity from a secret spell value. Public castBarID/nameplate inference is
    -- handled by TrashRuntime; this path only proceeds when a readable/manual
    -- classification is available.
    if not explicitlyTracked and not managerTracked and not blizzardImportant then
        return true
    end

    local durationObject = ReadProtectedCastDuration(unit, isChannel)
    local safeCastGUID = PublicValueOrNil(castGUID)
    local safeEventCastBarID = PublicValueOrNil(eventCastBarID)
    local protectedDisplayName, protectedDisplayNamePresent, protectedDisplayIcon, protectedDisplayIconPresent = ReadProtectedCastDisplayName(unit, isChannel)

    local label
    local labelPresent = false
    if knownConfig and knownConfig.label then
        label = knownConfig.label
        labelPresent = true
    elseif readableSpellID then
        label = GetSafeSpellName(readableSpellID)
        labelPresent = label ~= nil
    elseif protectedDisplayNamePresent then
        -- This may be a secret Blizzard string. It is stored only for direct
        -- FontString:SetText display and must never be inspected in Lua.
        label = protectedDisplayName
        labelPresent = true
    end
    if not labelPresent then
        label = blizzardImportant and "IMPORTANT TRASH CAST" or "TRACKED TRASH CAST"
        labelPresent = true
    end
    if db.showTrashMobName and mobName and not IsSecret(label) then
        label = label .. " |cffaaaaaa— " .. mobName .. "|r"
    end

    trashCasts[unit] = {
        id = "trash:" .. unit .. ":" .. tostring(safeEventCastBarID or safeCastGUID or GetTime()),
        unit = unit,
        spellID = readableSpellID,
        name = label,
        displayNamePresent = labelPresent,
        rawSpellName = readableSpellID and GetSafeSpellName(readableSpellID) or nil,
        labelOverride = knownConfig and knownConfig.label or nil,
        mobName = mobName,
        npcID = npcID,
        dungeonKey = dungeonKey,
        knownMob = mobDef ~= nil,
        knownAbility = knownConfig and knownConfig.knownAbility == true or false,
        roleRelevant = knownConfig and knownConfig.roleRelevant == true or blizzardImportant,
        important = knownConfig and knownConfig.important == true or blizzardImportant,
        priority = knownConfig and knownConfig.priority or (blizzardImportant and 3 or 1),
        soundEnabled = not (knownConfig and knownConfig.sound == false),
        ttsEnabled = knownConfig and knownConfig.ttsEnabled == true or false,
        ttsPhrase = knownConfig and knownConfig.ttsPhrase,
        displayMode = knownConfig and knownConfig.effectiveDisplayMode or ResolveDisplayMode(nil),
        mechanicType = knownConfig and knownConfig.mechanicType or "OTHER",
        displayIcon = protectedDisplayIcon,
        displayIconPresent = protectedDisplayIconPresent,
        protectedTiming = true,
        durationObject = durationObject,
        durationRevision = HasValueWithoutInspectingSecret(durationObject) and 1 or 0,
        startedAt = GetTime(),
        castGUID = safeCastGUID,
        castBarID = safeEventCastBarID,
        isChannel = isChannel == true,
    }

    if readableSpellID and trashCasts[unit].rawSpellName then
        seenSpells[readableSpellID] = trashCasts[unit].rawSpellName
    end

    driver:Show()
    UpdateLiveAlerts()
    return true
end

-- Bridge used by TrashRuntime.lua. The runtime module only supplies public,
-- static IDs it has resolved from ChayAlert HUD's bundled Season 2 model.
function CT:CommitRuntimeTrashCast(unit, spellID, castBarID, isChannel, npcID)
    spellID = tonumber(spellID)
    if not spellID or not IsNameplateUnit(unit) then return false end

    local publicCastBarID = PublicValueOrNil(castBarID)
    local existing = trashCasts[unit]
    if existing and publicCastBarID ~= nil and existing.castBarID == publicCastBarID
        and existing.spellID == spellID then
        return true
    end

    return CommitProtectedTrashCast(unit, spellID, nil, publicCastBarID, isChannel == true, tonumber(npcID))
end

-- If protected combat data leaves several possible spells but every remaining
-- possibility is important for the active profile, keep the visual warning but
-- do not emit generic audio. The ability identity is unresolved, so speaking a
-- repeated generic phrase would be noisy and could obscure identified callouts.
function CT:CommitRuntimeGenericTrashCast(unit, castBarID, isChannel, npcID, mechanicType, ttsEnabled)
    if not IsNameplateUnit(unit) or not db or db.trackOnlyCustom then return false end
    if not self:IsRuntimeTrashTrackingEnabled() then return false end

    local publicCastBarID = PublicValueOrNil(castBarID)
    local existing = trashCasts[unit]
    if existing and publicCastBarID ~= nil and existing.castBarID == publicCastBarID then
        return true
    end

    local safeNPCID = tonumber(npcID)
    local mobName = SafeUnitName(unit)
    local dungeonKey, mobDef
    if safeNPCID and DungeonData and DungeonData.ResolveMob then
        dungeonKey, mobDef = DungeonData:ResolveMob(safeNPCID, mobName)
        if not mobName and mobDef then mobName = mobDef.name end
    end

    local durationObject = ReadProtectedCastDuration(unit, isChannel == true)
    local protectedDisplayName, protectedDisplayNamePresent, protectedDisplayIcon, protectedDisplayIconPresent = ReadProtectedCastDisplayName(unit, isChannel == true)
    local label
    if protectedDisplayNamePresent then
        label = protectedDisplayName
    else
        label = "IMPORTANT TRASH CAST"
    end
    if db.showTrashMobName and mobName and not IsSecret(label) then
        label = label .. " |cffaaaaaa— " .. mobName .. "|r"
    end

    trashCasts[unit] = {
        id = "trash:" .. unit .. ":" .. tostring(publicCastBarID or GetTime()),
        unit = unit,
        spellID = nil,
        name = label,
        displayNamePresent = true,
        rawSpellName = nil,
        mobName = mobName,
        npcID = safeNPCID,
        dungeonKey = dungeonKey,
        knownMob = mobDef ~= nil,
        knownAbility = false,
        roleRelevant = true,
        important = true,
        priority = 3,
        soundEnabled = false,
        ttsEnabled = false,
        ttsPhrase = nil,
        displayMode = ResolveDisplayMode(nil),
        mechanicType = NormalizeMechanicType(mechanicType),
        displayIcon = protectedDisplayIcon,
        displayIconPresent = protectedDisplayIconPresent,
        protectedTiming = true,
        durationObject = durationObject,
        durationRevision = HasValueWithoutInspectingSecret(durationObject) and 1 or 0,
        startedAt = GetTime(),
        castBarID = publicCastBarID,
        isChannel = isChannel == true,
        runtimeGeneric = true,
    }

    driver:Show()
    UpdateLiveAlerts()
    return true
end

function CT:RemoveRuntimeTrashCast(unit, castBarID)
    if not IsNameplateUnit(unit) then return end
    trashRetryToken[unit] = nil
    RemoveTrashCast(unit, nil, nil, PublicValueOrNil(castBarID))
    UpdateLiveAlerts()
end

function CT:IsRuntimeTrashTrackingEnabled()
    return db ~= nil
        and db.enabled == true
        and db.trashCastsEnabled == true
        and IsInSupportedInstance()
        and not (db.suppressTrashDuringBoss == true and currentEncounterID ~= nil)
end

local function CommitTrashCast(unit, eventSpellID, castGUID, eventCastBarID, isChannel)
    if not db or db.trashCastsEnabled ~= true then return false end
    if db.suppressTrashDuringBoss == true and currentEncounterID ~= nil then return true end
    if not IsHostileNameplateUnit(unit) then return false end
    if not IsInSupportedInstance() then return false end

    local eventID
    if not IsSecret(eventSpellID) then
        eventID = tonumber(eventSpellID)
    end

    local cast = ReadNameplateCast(unit, isChannel)
    if not cast then
        -- In Midnight combat, hostile UnitCastingInfo/UnitChannelInfo timing can
        -- be protected. Fall back to Blizzard's protected identifier plus the
        -- native DurationObject API instead of dropping the cast. This also
        -- handles a nameplate that appears while an important cast is already
        -- in progress and therefore has no cast-start event for ChayAlertHUD.
        local protectedSpellID = eventSpellID
        local protectedCastBarID = eventCastBarID
        if not IsSecret(protectedSpellID) and protectedSpellID == nil then
            protectedSpellID, protectedCastBarID = ReadProtectedCastIdentifier(unit, isChannel)
        end
        return CommitProtectedTrashCast(unit, protectedSpellID, castGUID, protectedCastBarID, isChannel)
    end

    local spellID = cast.spellID or eventID

    local dungeonKey, mobDef
    if DungeonData and DungeonData.ResolveMob and cast.npcID then
        dungeonKey, mobDef = DungeonData:ResolveMob(cast.npcID, cast.mobName)
    end
    if not mobDef and spellID then
        dungeonKey, mobDef = ResolveKnownTrashAbilityBySpellID(spellID)
    end

    if not spellID and mobDef and cast.name then
        spellID = ResolveKnownTrashSpellIDByName(dungeonKey, mobDef, cast.name)
    end

    local explicitlyTracked = spellID and db.trackedSpells[spellID] == true or false
    local knownConfig
    if mobDef and spellID then
        knownConfig = GetKnownAbilityConfig(dungeonKey, mobDef, spellID)
        if knownConfig and knownConfig.enabled == false then
            return true
        end
    elseif mobDef and not spellID and db.trackUnknownTrash == false then
        return true
    elseif not mobDef and db.trackUnknownTrash == false and not explicitlyTracked then
        return true
    end

    local managerTracked = knownConfig and knownConfig.enabled ~= false or false
    if not explicitlyTracked and not managerTracked and cast.duration < (tonumber(db.trashMinCastTime) or 1.5) then
        return true
    end
    if spellID and db.mutedSpells[spellID] == true then
        return true
    end
    if db.trackOnlyCustom and not explicitlyTracked then
        return true
    end

    local safeCastGUID = PublicValueOrNil(castGUID)
    local safeEventCastBarID = PublicValueOrNil(eventCastBarID)
    local finalCastBarID = cast.castBarID or safeEventCastBarID or cast.castID

    trashCasts[unit] = {
        id = "trash:" .. unit .. ":" .. tostring(finalCastBarID or safeCastGUID or GetTime()),
        unit = unit,
        spellID = spellID,
        name = BuildTrashDisplayName(cast, spellID, knownConfig and knownConfig.label),
        rawSpellName = cast.name,
        labelOverride = knownConfig and knownConfig.label or nil,
        mobName = cast.mobName,
        npcID = cast.npcID,
        dungeonKey = dungeonKey,
        knownMob = mobDef ~= nil,
        knownAbility = knownConfig and knownConfig.knownAbility == true or false,
        roleRelevant = knownConfig and knownConfig.roleRelevant == true or false,
        important = knownConfig and knownConfig.important == true or false,
        priority = knownConfig and knownConfig.priority or 1,
        soundEnabled = not (knownConfig and knownConfig.sound == false),
        ttsEnabled = knownConfig and knownConfig.ttsEnabled == true or false,
        ttsPhrase = knownConfig and knownConfig.ttsPhrase,
        displayMode = knownConfig and knownConfig.effectiveDisplayMode or ResolveDisplayMode(nil),
        mechanicType = knownConfig and knownConfig.mechanicType or InferMechanicType(nil, nil, nil),
        duration = math.max(cast.duration, 0.1),
        expiresAt = cast.expiresAt,
        castGUID = safeCastGUID,
        castBarID = finalCastBarID,
        isChannel = isChannel == true,
    }

    if spellID and cast.name then
        seenSpells[spellID] = cast.name
    end

    driver:Show()
    UpdateLiveAlerts()
    return true
end

local function StartTrashCast(unit, eventSpellID, castGUID, castBarID, isChannel)
    if not IsHostileNameplateUnit(unit) then return end

    -- Both the global event frame and the per-nameplate RegisterUnitEvent
    -- watcher may receive the same cast. castBarID is NeverSecret, so use it
    -- as the authoritative duplicate key without touching protected payloads.
    local publicCastBarID = PublicValueOrNil(castBarID)
    local existing = trashCasts[unit]
    if existing and publicCastBarID ~= nil and existing.castBarID == publicCastBarID then
        return
    end

    -- Most casts are readable immediately. If Blizzard has not populated
    -- UnitCastingInfo/UnitChannelInfo on this exact event frame, retry once
    -- on the next frame instead of silently losing the cast.
    if CommitTrashCast(unit, eventSpellID, castGUID, castBarID, isChannel) then
        return
    end

    local token = (trashRetryToken[unit] or 0) + 1
    trashRetryToken[unit] = token

    local retrySpellID = PublicValueOrNil(eventSpellID)
    local retryCastGUID = PublicValueOrNil(castGUID)
    local retryCastBarID = PublicValueOrNil(castBarID)

    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            if trashRetryToken[unit] ~= token then return end
            CommitTrashCast(unit, retrySpellID, retryCastGUID, retryCastBarID, isChannel)
        end)
    end
end

local function RefreshTrashCastFromUnit(unit)
    if not IsHostileNameplateUnit(unit) then return end
    local existing = trashCasts[unit]
    if not existing then return end

    if existing.protectedTiming then
        -- Delay/channel-update events may fire while the timing values remain
        -- protected. Refresh only the native DurationObject; STOP/INTERRUPTED
        -- events remain authoritative for removing the cast.
        local durationObject = ReadProtectedCastDuration(unit, existing.isChannel)
        if HasValueWithoutInspectingSecret(durationObject) then
            existing.durationObject = durationObject
            existing.durationRevision = (existing.durationRevision or 0) + 1
        end
        return
    end

    local cast = ReadNameplateCast(unit, existing.isChannel)
    if not cast then
        cast = ReadNameplateCast(unit, not existing.isChannel)
    end

    if not cast or cast.remaining <= 0 then
        trashCasts[unit] = nil
        return
    end

    existing.expiresAt = cast.expiresAt
    existing.duration = math.max(cast.duration, 0.1)

    if cast.spellID then
        existing.spellID = cast.spellID
    end
    if cast.npcID then
        existing.npcID = cast.npcID
    end
    if cast.castBarID then
        existing.castBarID = cast.castBarID
    end
    if cast.mobName then
        existing.mobName = cast.mobName
    end
    if cast.name then
        existing.rawSpellName = cast.name
        if existing.spellID then
            seenSpells[existing.spellID] = cast.name
        end
    end

    if DungeonData and DungeonData.ResolveMob and existing.npcID then
        local dungeonKey, mobDef = DungeonData:ResolveMob(existing.npcID, existing.mobName)
        existing.dungeonKey = dungeonKey
        existing.knownMob = mobDef ~= nil
        if mobDef and existing.spellID then
            local cfg = GetKnownAbilityConfig(dungeonKey, mobDef, existing.spellID)
            if cfg then
                if cfg.enabled == false then
                    trashCasts[unit] = nil
                    return
                end
                existing.knownAbility = cfg.knownAbility == true
                existing.roleRelevant = cfg.roleRelevant == true
                existing.important = cfg.important == true
                existing.priority = cfg.priority or 1
                existing.soundEnabled = cfg.sound ~= false
                existing.ttsEnabled = cfg.ttsEnabled == true
                existing.ttsPhrase = cfg.ttsPhrase
                existing.labelOverride = cfg.label
                existing.displayMode = cfg.effectiveDisplayMode or ResolveDisplayMode(nil)
                existing.mechanicType = cfg.mechanicType or "OTHER"
            end
        end
    end

    existing.name = BuildTrashDisplayName(cast, existing.spellID, existing.labelOverride)
end

-- Midnight can protect the payload of hostile UNIT_SPELLCAST events. A generic
-- event listener would then have to inspect a potentially protected unit token.
-- Instead, each visible hostile nameplate owns a RegisterUnitEvent watcher and
-- uses the already-known nameplate unit token stored on the watcher itself.
local NAMEPLATE_CAST_EVENTS = {
    "UNIT_SPELLCAST_START",
    "UNIT_SPELLCAST_CHANNEL_START",
    "UNIT_SPELLCAST_DELAYED",
    "UNIT_SPELLCAST_CHANNEL_UPDATE",
    "UNIT_SPELLCAST_SUCCEEDED",
    "UNIT_SPELLCAST_STOP",
    "UNIT_SPELLCAST_CHANNEL_STOP",
    "UNIT_SPELLCAST_INTERRUPTED",
    "UNIT_SPELLCAST_FAILED",
    "UNIT_SPELLCAST_FAILED_QUIET",
}
local nameplateCastWatchers = {}

-- castBarID is explicitly NeverSecret in Midnight. When the global hostile
-- spellcast event protects unitTarget/spellID, match that public cast-bar ID
-- back to one of the nameplate tokens we already own. This keeps the working
-- global-listener architecture used by current nameplate cast observers while never
-- inspecting a protected unit token.
local function GetUnitCastBarID(unit, isChannel)
    local func = isChannel and UnitChannelInfo or UnitCastingInfo
    if type(func) ~= "function" then return nil end

    -- UnitChannelInfo's castBarID is return #11; UnitCastingInfo's castBarID is
    -- return #10 (delayTimeMs follows at #11). Per Patch 12.0.0/12.0.1 API docs.
    if isChannel then
        local ok, _, _, _, _, _, _, _, _, _, _, rawCastBarID = pcall(func, unit)
        if ok and not IsSecret(rawCastBarID) then
            return tonumber(rawCastBarID) or rawCastBarID
        end
    else
        local ok, _, _, _, _, _, _, _, _, _, rawCastBarID = pcall(func, unit)
        if ok and not IsSecret(rawCastBarID) then
            return tonumber(rawCastBarID) or rawCastBarID
        end
    end
    return nil
end

local function FindNameplateByCastBarID(castBarID, isChannel)
    if IsSecret(castBarID) or castBarID == nil then return nil end
    castBarID = tonumber(castBarID) or castBarID

    for unit, watcher in pairs(nameplateCastWatchers) do
        if watcher.unitToken == unit and IsNameplateUnit(unit) then
            local unitCastBarID = GetUnitCastBarID(unit, isChannel)
            if unitCastBarID ~= nil and unitCastBarID == castBarID then
                return unit
            end
        end
    end
    return nil
end

local function FindTrackedTrashByCastBarID(castBarID)
    if IsSecret(castBarID) or castBarID == nil then return nil end
    castBarID = tonumber(castBarID) or castBarID
    for unit, cast in pairs(trashCasts) do
        if cast.castBarID ~= nil and cast.castBarID == castBarID then
            return unit
        end
    end
    return nil
end

local function NameplateCastWatcher_OnEvent(self, event, ...)
    local unit = self.unitToken
    if not unit or not IsNameplateUnit(unit) then return end

    if event == "UNIT_SPELLCAST_START" then
        local _, castGUID, spellID, castBarID = ...
        StartTrashCast(unit, spellID, castGUID, castBarID, false)
    elseif event == "UNIT_SPELLCAST_CHANNEL_START" then
        local _, castGUID, spellID, castBarID = ...
        StartTrashCast(unit, spellID, castGUID, castBarID, true)
    elseif event == "UNIT_SPELLCAST_DELAYED" or event == "UNIT_SPELLCAST_CHANNEL_UPDATE" then
        RefreshTrashCastFromUnit(unit)
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        -- Runtime outcome history consumes this from the per-nameplate watcher.
        -- The legacy circle path deliberately does not remove a cast until STOP.
        return
    elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" or event == "UNIT_SPELLCAST_INTERRUPTED" then
        local _, castGUID, spellID, _, castBarID = ...
        trashRetryToken[unit] = nil
        RemoveTrashCast(unit, castGUID, spellID, castBarID)
        UpdateLiveAlerts()
    elseif event == "UNIT_SPELLCAST_STOP"
        or event == "UNIT_SPELLCAST_FAILED"
        or event == "UNIT_SPELLCAST_FAILED_QUIET" then
        local _, castGUID, spellID, castBarID = ...
        trashRetryToken[unit] = nil
        RemoveTrashCast(unit, castGUID, spellID, castBarID)
        UpdateLiveAlerts()
    end
end

local function AttachNameplateCastWatcher(unit, skipInitialScan)
    if not IsNameplateUnit(unit) then return end

    local watcher = nameplateCastWatchers[unit]
    if not watcher then
        watcher = CreateFrame("Frame")
        watcher:SetScript("OnEvent", NameplateCastWatcher_OnEvent)
        nameplateCastWatchers[unit] = watcher
    else
        watcher:UnregisterAllEvents()
    end

    watcher.unitToken = unit

    -- Midnight can protect the unitTarget payload on global hostile
    -- UNIT_SPELLCAST_* events. Register the same events directly for this
    -- already-known public nameplate token so the watcher can use its stable
    -- self.unitToken without inspecting the protected event unit value.
    -- RegisterUnitEvent is current Retail API and each watcher owns exactly one
    -- nameplate token, so registrations stay narrow and event-driven.
    if watcher.RegisterUnitEvent then
        for _, eventName in ipairs(NAMEPLATE_CAST_EVENTS) do
            watcher:RegisterUnitEvent(eventName, unit)
        end
    end

    -- The global listener remains as a fast path when its unitTarget is public.
    -- This per-nameplate listener is the protected-combat fallback and also lets
    -- us scan a cast that began before NAME_PLATE_UNIT_ADDED reached ChayAlertHUD.

    if skipInitialScan then return end

    -- A nameplate may appear after a cast has already started. First use the
    -- readable path, then the protected identifier/DurationObject path.
    if ReadNameplateCast(unit, false) then
        StartTrashCast(unit, nil, nil, nil, false)
    elseif ReadNameplateCast(unit, true) then
        StartTrashCast(unit, nil, nil, nil, true)
    elseif not CommitTrashCast(unit, nil, nil, nil, false) then
        CommitTrashCast(unit, nil, nil, nil, true)
    end
end

local function DetachNameplateCastWatcher(unit)
    local watcher = nameplateCastWatchers[unit]
    if watcher then
        watcher:UnregisterAllEvents()
        watcher.unitToken = nil
    end
end

local function ResetNameplateCastWatchers()
    for _, watcher in pairs(nameplateCastWatchers) do
        watcher:UnregisterAllEvents()
        watcher.unitToken = nil
    end
end

-- One-shot recovery for /reload, phasing, and zone transitions where a visible
-- nameplate may already exist before ChayAlertHUD receives NAME_PLATE_UNIT_ADDED.
-- C_NamePlate.GetNamePlates is current Retail API; only public nameplate unit
-- tokens are accepted before binding the normal per-unit watcher.
function CT:RehydrateNameplateCastWatchers()
    if not C_NamePlate or type(C_NamePlate.GetNamePlates) ~= "function" then return 0 end
    local ok, plates = pcall(C_NamePlate.GetNamePlates)
    if not ok or type(plates) ~= "table" then return 0 end

    local attached = 0
    for _, plate in ipairs(plates) do
        local unit
        if type(plate) == "table" or type(plate) == "userdata" then
            unit = plate.unitToken
                or plate.namePlateUnitToken
                or (plate.UnitFrame and plate.UnitFrame.unit)
                or (plate.unitFrame and plate.unitFrame.unit)
        end
        if IsNameplateUnit(unit) then
            AttachNameplateCastWatcher(unit)
            attached = attached + 1
        end
    end
    return attached
end

local function GetTrashCandidates()
    local result = {}
    if not db or db.trashCastsEnabled ~= true or not IsInSupportedInstance() then
        return result
    end

    local now = GetTime()
    for unit, cast in pairs(trashCasts) do
        if cast.protectedTiming then
            if cast.protectedFinished or not IsHostileNameplateUnit(unit) then
                trashCasts[unit] = nil
            else
                local candidateName
                if cast.displayNamePresent then
                    candidateName = cast.name
                else
                    candidateName = "IMPORTANT TRASH CAST"
                end
                result[#result + 1] = {
                    id = cast.id,
                    protectedTiming = true,
                    durationObject = cast.durationObject,
                    durationRevision = cast.durationRevision or 0,
                    startedAt = cast.startedAt or now,
                    name = candidateName,
                    namePresent = true,
                    spellID = cast.spellID,
                    catalogSpellID = cast.spellID,
                    catalogSpellName = cast.rawSpellName,
                    spellName = cast.rawSpellName,
                    ttsText = cast.rawSpellName,
                    ttsCustomText = cast.ttsPhrase,
                    actionLabel = cast.labelOverride,
                    source = "trash",
                    sourceType = "TRASH",
                    displayMode = cast.displayMode or ResolveDisplayMode(nil),
                    mechanicType = cast.mechanicType or "OTHER",
                    roleRelevant = cast.roleRelevant == true,
                    important = cast.important == true,
                    safeFallbackAbilityName = nil,
                    icon = cast.displayIcon,
                    iconPresent = cast.displayIconPresent == true,
                    isActiveCast = true,
                    isFutureEvent = false,
                    confidence = cast.runtimeGeneric and "ACTIVE_GENERIC" or "ACTIVE",
                    castBarID = cast.castBarID,
                    priority = cast.priority or 3,
                                soundEnabled = cast.soundEnabled ~= false,
                                ttsEnabled = cast.ttsEnabled == true,
                                tts = cast.ttsEnabled == true,
                                ttsPhrase = cast.ttsPhrase,
                    soundState = cast,
                }
            end
        else
            local remaining = type(cast.expiresAt) == "number" and (cast.expiresAt - now) or 0
            if remaining <= 0 or not IsHostileNameplateUnit(unit) then
                trashCasts[unit] = nil
            elseif remaining <= db.leadTime then
                result[#result + 1] = {
                    id = cast.id,
                    remaining = remaining,
                    duration = math.min(cast.duration, tonumber(db.leadTime) or cast.duration),
                    name = cast.name or "TRASH CAST",
                    spellID = cast.spellID,
                    catalogSpellID = cast.spellID,
                    catalogSpellName = cast.rawSpellName,
                    spellName = cast.rawSpellName,
                    ttsText = cast.rawSpellName,
                    ttsCustomText = cast.ttsPhrase,
                    actionLabel = cast.labelOverride,
                    source = "trash",
                    sourceType = "TRASH",
                    displayMode = cast.displayMode or ResolveDisplayMode(nil),
                    mechanicType = cast.mechanicType or "OTHER",
                    roleRelevant = cast.roleRelevant == true,
                    important = cast.important == true,
                    isActiveCast = true,
                    isFutureEvent = false,
                    confidence = "ACTIVE",
                    castBarID = cast.castBarID,
                    priority = cast.priority or 1,
                    soundEnabled = cast.soundEnabled ~= false,
                    ttsEnabled = cast.ttsEnabled == true,
                    tts = cast.ttsEnabled == true,
                    ttsPhrase = cast.ttsPhrase,
                    soundState = cast,
                }
            end
        end
    end

    return result
end

local function GetCandidates()
    if not db.enabled or not IsInSupportedInstance() then return {} end

    local result = {}
    local now = GetTime()

    if TimelineFeatureAvailable() then
        for eventID, runtime in pairs(timelineRuntime) do
            if runtime.state == STATE_ACTIVE and runtime.expiresAt then
                local remaining = math.max(0, runtime.expiresAt - now)

                if remaining <= 0 then
                    timelineRuntime[eventID] = nil
                else
                    local filterInfo = {
                        spellID = runtime.spellID or runtime.knownSpellID,
                        spellName = runtime.name,
                        duration = runtime.duration,
                    }

                    if ShouldTrackInfo(filterInfo) then
                        local blizzardHighSeverity = runtime.severity == 2
                        local bossPriority = blizzardHighSeverity and 3 or 1

                        if runtime.spellID and IsBlizzardImportantSpell(runtime.spellID) then
                            bossPriority = 3
                            blizzardHighSeverity = true
                        end

                        local bossSoundEnabled = true
                        local bossTTSEnabled
                        local bossTTSPhrase
                        local bossRoleRelevant = false
                        local bossImportant = blizzardHighSeverity
                        local bossEnabled = blizzardHighSeverity or db.trackUnknownBossTimeline == true
                        bossTTSEnabled = bossEnabled
                        local bossLabel = nil
                        local bossLeadTime = tonumber(db.leadTime) or 10
                        local bossDisplayMode = ResolveDisplayMode(nil)
                        local bossMechanicType = "OTHER"
                        local bossSpellName = runtime.name

                        local configSpellID = runtime.spellID or runtime.knownSpellID
                        if currentEncounterID and configSpellID then
                            local dungeonBossCfg = CT:GetBossAbilityEffectiveConfig(currentEncounterID, configSpellID)
                            if dungeonBossCfg then
                                if dungeonBossCfg.hasEnabledOverride then
                                    -- A user choice always wins, including explicitly enabling
                                    -- an off-role mechanic or disabling an important mechanic.
                                    bossEnabled = dungeonBossCfg.enabled ~= false
                                    bossPriority = dungeonBossCfg.priority or bossPriority
                                elseif dungeonBossCfg.important and dungeonBossCfg.roleRelevant == false then
                                    -- Known mechanics scoped to another role stay hidden even
                                    -- when Blizzard marks the live event high severity.
                                    bossEnabled = false
                                    bossPriority = dungeonBossCfg.priority or bossPriority
                                elseif blizzardHighSeverity then
                                    bossEnabled = true
                                    bossPriority = 3
                                else
                                    bossEnabled = dungeonBossCfg.enabled ~= false
                                    bossPriority = dungeonBossCfg.priority or bossPriority
                                end
                                bossSoundEnabled = dungeonBossCfg.sound ~= false
                                bossRoleRelevant = dungeonBossCfg.roleRelevant == true
                                bossImportant = dungeonBossCfg.important == true
                                if dungeonBossCfg.hasTTSOverride then
                                    bossTTSEnabled = dungeonBossCfg.ttsEnabled == true
                                else
                                    bossTTSEnabled = bossEnabled
                                end
                                bossTTSPhrase = dungeonBossCfg.ttsPhrase
                                bossLabel = dungeonBossCfg.label
                                bossLeadTime = dungeonBossCfg.leadTime or bossLeadTime
                                bossDisplayMode = dungeonBossCfg.effectiveDisplayMode or bossDisplayMode
                                bossMechanicType = dungeonBossCfg.mechanicType or bossMechanicType
                                bossSpellName = dungeonBossCfg.spell and dungeonBossCfg.spell.name or bossSpellName
                            else
                                local raidCfg = CT:GetRaidAbilityEffectiveConfig(currentEncounterID, configSpellID)
                                if raidCfg then
                                    if raidCfg.hasEnabledOverride then
                                        bossEnabled = raidCfg.enabled ~= false
                                        bossPriority = raidCfg.priority or bossPriority
                                    elseif raidCfg.important and raidCfg.roleRelevant == false then
                                        bossEnabled = false
                                        bossPriority = raidCfg.priority or bossPriority
                                    elseif blizzardHighSeverity then
                                        bossEnabled = true
                                        bossPriority = 3
                                    else
                                        bossEnabled = raidCfg.enabled ~= false
                                        bossPriority = raidCfg.priority or bossPriority
                                    end
                                    bossSoundEnabled = raidCfg.sound ~= false
                                    bossRoleRelevant = raidCfg.roleRelevant == true
                                    bossImportant = raidCfg.important == true
                                    if raidCfg.hasTTSOverride then
                                        bossTTSEnabled = raidCfg.ttsEnabled == true
                                    else
                                        bossTTSEnabled = bossEnabled
                                    end
                                    bossTTSPhrase = raidCfg.ttsPhrase
                                    bossLabel = raidCfg.label
                                    bossLeadTime = raidCfg.leadTime or bossLeadTime
                                    bossDisplayMode = raidCfg.effectiveDisplayMode or bossDisplayMode
                                    bossMechanicType = raidCfg.mechanicType or bossMechanicType
                                    bossSpellName = raidCfg.spell and raidCfg.spell.name or bossSpellName
                                end
                            end
                        end

                        local bossCandidateWindow = bossLeadTime
                        if DisplayModeAllows(bossDisplayMode, "TIMELINE") then
                            local timelineWindow = tonumber(db.timeline and db.timeline.window) or 15
                            bossCandidateWindow = math.max(bossCandidateWindow, math.max(5, math.min(60, timelineWindow)))
                        end

                        if bossEnabled and remaining <= bossCandidateWindow then
                            local candidateName
                            if bossLabel then
                                candidateName = bossLabel
                            elseif runtime.displayNamePresent then
                                -- May be a secret Blizzard string. Assignment is safe and the
                                -- FontString consumes it directly; do not inspect it in Lua.
                                candidateName = runtime.displayName
                            else
                                candidateName = runtime.name or "Boss Ability"
                            end
                            result[#result + 1] = {
                                id = eventID,
                                remaining = remaining,
                                duration = math.min(runtime.duration or remaining, bossLeadTime),
                                name = candidateName,
                                spellID = runtime.spellID or runtime.knownSpellID,
                                catalogSpellID = runtime.spellID or runtime.knownSpellID,
                                spellName = bossSpellName,
                                catalogSpellName = bossSpellName,
                                ttsText = bossSpellName,
                                ttsCustomText = bossTTSPhrase,
                                actionLabel = bossLabel,
                                source = "boss",
                                sourceType = (RaidData and RaidData.byEncounterID and RaidData.byEncounterID[tonumber(currentEncounterID)]) and "RAID" or "DUNGEON_BOSS",
                                displayMode = bossDisplayMode,
                                mechanicType = bossMechanicType,
                                circleLeadTime = bossLeadTime,
                                isActiveCast = false,
                                isFutureEvent = true,
                                confidence = runtime.spellID and "CONFIRMED" or (runtime.knownSpellID and "INFERRED" or "TIMELINE"),
                                severity = runtime.severity,
                                priority = bossPriority,
                                roleRelevant = bossRoleRelevant,
                                important = bossImportant,
                                soundEnabled = bossSoundEnabled,
                                ttsEnabled = bossTTSEnabled,
                                tts = bossTTSEnabled,
                                ttsPhrase = bossTTSPhrase,
                                soundState = runtime,
                            }
                        end
                    end
                end
            end
        end
    end

    local trash = GetTrashCandidates()
    for i = 1, #trash do
        result[#result + 1] = trash[i]
    end

    table.sort(result, function(a, b)
        local aRole = a.roleRelevant == true
        local bRole = b.roleRelevant == true
        if aRole ~= bRole then
            return aRole
        end

        local aImportant = a.important == true
        local bImportant = b.important == true
        if aImportant ~= bImportant then
            return aImportant
        end

        local ap = tonumber(a.priority) or 1
        local bp = tonumber(b.priority) or 1
        if ap ~= bp then
            return ap > bp
        end

        if type(a.remaining) == "number" and type(b.remaining) == "number" then
            return a.remaining < b.remaining
        elseif type(a.remaining) == "number" then
            return true
        elseif type(b.remaining) == "number" then
            return false
        end
        return (tonumber(a.startedAt) or 0) < (tonumber(b.startedAt) or 0)
    end)

    -- Keep the visible slots player-focused: role-relevant, high-priority
    -- mechanics are assigned to Circle 1 before lower-impact queued mechanics.
    -- The actual sound and countdown state stays tied to the mechanic identity,
    -- not the slot index when mechanics promote between visible circles.
    return result
end

local function PlaySelectedSound(name)
    if db and db.allSoundSelectionsNone == true then return end
    local media = FetchMedia("sound", name, nil)
    if type(media) == "number" then
        PlaySoundFile(media, "Master")
    elseif type(media) == "string" and media ~= "" then
        PlaySoundFile(media, "Master")
    end
end

local function PlayConfiguredSound(slot, remaining, candidateSoundEnabled, soundState)
    if candidateSoundEnabled == false then return end
    if not db.soundEnabled or not slot or not db.circles[slot].sound then return end
    if type(soundState) ~= "table" then return end

    if db.playUrgentSound and remaining <= db.beepAt and remaining > 0 and not soundState.urgentPlayed then
        soundState.urgentPlayed = true
        PlaySelectedSound(db.urgentSound)
    end

    local whole = math.ceil(remaining)
    if db.countdownBeeps and remaining <= db.beepAt and remaining > 0 and soundState.lastBeep ~= whole then
        soundState.lastBeep = whole
        PlaySelectedSound(db.beepSound)
    end
end

local function StartAlertSound(slot, candidateSoundEnabled, soundState)
    if candidateSoundEnabled == false then return end
    if not db.soundEnabled or not db.circles[slot].sound then return end
    if type(soundState) ~= "table" or soundState.alertPlayed then return end
    soundState.alertPlayed = true
    PlaySelectedSound(db.alertSound)
end

local function StartCircleFlash(slot, soundState)
    if not db.circleFlashOnStart then return end
    if type(soundState) ~= "table" or soundState.circleFlashPlayed then return end
    local frame = activeSlots[slot]
    if not frame or not frame.flashGroup then return end
    soundState.circleFlashPlayed = true
    if frame.flashGroup:IsPlaying() then frame.flashGroup:Stop() end
    frame.flashGroup:Play()
end

local function BuildCircleDisplayName(name, mechanicType)
    local action = TTSAction(mechanicType)
    if IsSecret(name) then return name end
    if type(name) ~= "string" or name == "" then return action or "" end
    if type(action) ~= "string" or action == "" then return name end
    return action .. "  " .. name
end

local function RenderSlot(slot, remaining, duration, spellName, eventID, candidateSoundEnabled, soundState, ttsEnabled, ttsPhrase, mechanicType, actionLabel, publicSpellName, spellID)
    local f = activeSlots[slot]
    local cfg = db.circles[slot]
    local explicitPreview = testForceCircle and eventID == "TEST1"
    if not f or (not cfg.enabled and not explicitPreview) then
        if f then f:Hide() end
        return
    end

    if f.protectedCooldown then
        f.protectedCooldown:Hide()
        f._protectedDurationRevision = nil
        f._protectedSoundState = nil
    end

    duration = math.max(0.01, tonumber(duration) or tonumber(db.leadTime) or 10)
    local r, g, b, a = GetRingColor(remaining, duration)
    SetRingProgress(f, remaining / duration, r, g, b, a)
    f.timer:SetText(FormatTime(remaining))
    local spellNamePresent
    if IsSecret(spellName) then
        spellNamePresent = true
    else
        spellNamePresent = spellName ~= nil
    end
    if db.showName and spellNamePresent then
        f.name:SetText(BuildCircleDisplayName(spellName, mechanicType))
    else
        f.name:SetText("")
    end

    f.eventID = eventID
    StartAlertSound(slot, candidateSoundEnabled, soundState)
    PlayConfiguredSound(slot, remaining, candidateSoundEnabled, soundState)
    f:Show()
    StartCircleFlash(slot, soundState)
end

local function RenderProtectedTrashSlot(slot, candidate)
    local f = activeSlots[slot]
    local cfg = db.circles[slot]
    if not f or not cfg.enabled then
        if f then f:Hide() end
        return
    end

    SetProtectedRingBackground(f)
    f.timer:SetText("")
    if db.showName and candidate.namePresent then
        -- candidate.name may be protected Blizzard text. SetText is permitted
        -- to consume secret text; do not inspect the value in Lua.
        f.name:SetText(candidate.name)
    else
        f.name:SetText("")
    end

    local cooldown = f.protectedCooldown
    if cooldown then
        local c = db.urgentColor
        cooldown:SetSwipeColor(c.r, c.g, c.b, math.max(0.15, (c.a or 1) * cfg.alpha))
        cooldown:SetHideCountdownNumbers(false)
        if HasValueWithoutInspectingSecret(candidate.durationObject) then
            local revision = tonumber(candidate.durationRevision) or 0
            if f.eventID ~= candidate.id or f._protectedDurationRevision ~= revision then
                local ok = pcall(cooldown.SetCooldownFromDurationObject, cooldown, candidate.durationObject, true)
                if not ok then
                    cooldown:Hide()
                else
                    cooldown:Show()
                end
                f._protectedDurationRevision = revision
            else
                cooldown:Show()
            end
        else
            cooldown:Hide()
            f.timer:SetText("CAST")
        end
    else
        f.timer:SetText("CAST")
    end

    f._protectedSoundState = candidate.soundState
    f.eventID = candidate.id
    StartAlertSound(slot, candidate.soundEnabled, candidate.soundState)
    f:Show()
    StartCircleFlash(slot, candidate.soundState)
end

UpdateLiveAlerts = function()
    if testMode then return end
    local candidates = GetCandidates()
    if CT.TTS and type(CT.TTS.SpeakAbility) == "function" then
        for _, candidate in ipairs(candidates) do
            CT.TTS:SpeakAbility(candidate)
        end
    end
    local circleCandidates = candidates
    if CT.MechanicRouter and type(CT.MechanicRouter.Publish) == "function" then
        circleCandidates = CT.MechanicRouter:Publish(candidates)
    elseif CT.TimelineHUD and type(CT.TimelineHUD.Render) == "function" then
        CT.TimelineHUD:Render({})
    end

    -- Circles beyond the active cap are never dropped silently: the last
    -- visible slot surfaces a "+N" badge for whatever else is still queued.
    local activeCap = math.max(1, math.min(3, tonumber(db.maxAlerts) or 2))
    local overflowCount = math.max(0, #circleCandidates - activeCap)
    local lastShown = math.min(activeCap, #circleCandidates)

    for i = 1, MAX_CIRCLES do
        local f = activeSlots[i]
        local c = circleCandidates[i]
        if i <= activeCap and c then
            if c.protectedTiming then
                RenderProtectedTrashSlot(i, c)
            else
                RenderSlot(i, c.remaining, c.duration, c.name, c.id, c.soundEnabled, c.soundState, c.ttsEnabled, c.ttsPhrase, c.mechanicType, c.actionLabel, c.spellName, c.spellID)
            end
        else
            f.eventID = nil
            f.lastBeep = nil
            f.urgentPlayed = false
            f._protectedDurationRevision = nil
            f._protectedSoundState = nil
            if f.protectedCooldown then f.protectedCooldown:Hide() end
            f:Hide()
        end

        if i == lastShown and overflowCount > 0 then
            f.overflowText:SetText("+" .. overflowCount)
            f.overflowText:Show()
        else
            f.overflowText:Hide()
        end
    end
end

local function UpdateTestAlerts()
    if not testMode then return false end
    local now = GetTime()
    local ordered = {}
    for i = 1, MAX_CIRCLES + 2 do
        local t = testTimers[i]
        if t then ordered[#ordered + 1] = { index = i, data = t } end
    end

    local activeCap = math.max(1, math.min(MAX_CIRCLES, tonumber(db.maxAlerts) or MAX_CIRCLES))
    local visibleCount = math.min(activeCap, #ordered)
    local overflowCount = math.max(0, #ordered - visibleCount)
    local any = false

    local circleTestEnabled = testForceCircle or DisplayModeAllows(ResolveDisplayMode(nil), "CIRCLE")
    for i = 1, MAX_CIRCLES do
        local visible = ordered[i]
        if circleTestEnabled and i <= visibleCount and visible then
            local t = visible.data
            local remaining = t.expires - now
            if remaining <= 0 and unlockMode then
                t.expires = now + t.duration
                remaining = t.duration
            end
            if remaining > 0 then
                any = true
                RenderSlot(i, remaining, t.duration, t.name, "TEST" .. visible.index, nil, t, t.ttsEnabled, t.ttsPhrase, t.mechanicType)
            else
                activeSlots[i]:Hide()
            end
        else
            activeSlots[i]:Hide()
        end

        if circleTestEnabled and i == visibleCount and overflowCount > 0 then
            activeSlots[i].overflowText:SetText("+" .. overflowCount)
            activeSlots[i].overflowText:Show()
        else
            activeSlots[i].overflowText:Hide()
        end
    end

    if not any and not unlockMode then
        testMode = false
        testForceCircle = false
        wipe(testTimers)
        CT:RefreshTrackingState()
    end

    if CT.TimelineHUD and type(CT.TimelineHUD.Render) == "function" then
        local timelineMode = ResolveDisplayMode(nil)
        local timelineEntries = {}
        for i = 1, MAX_CIRCLES + 2 do
            local t = testTimers[i]
            if t then
                local remaining = t.expires - now
                if remaining <= 0 and unlockMode then
                    t.expires = now + t.duration
                    remaining = t.duration
                end
                if remaining > 0 then
                    local mechanicType = "OTHER"
                    if i == 1 then
                        mechanicType = "TANK"
                    elseif i == 2 then
                        mechanicType = "INTERRUPT"
                    elseif i == 3 then
                        mechanicType = "AOE_DAMAGE"
                    elseif i == 4 then
                        mechanicType = "UTILITY"
                    end
                    timelineEntries[#timelineEntries + 1] = {
                        displayName = t.name or "TEST",
                        displayNamePresent = true,
                        mechanicType = mechanicType,
                        remaining = remaining,
                        duration = t.duration or remaining,
                        priority = 3,
                        icon = 136243,
                        iconPresent = true,
                    }
                end
            end
        end

        if DisplayModeAllows(timelineMode, "TIMELINE") then
            CT.TimelineHUD:Render(timelineEntries)
        else
            CT.TimelineHUD:Render({})
        end
    end

    return true
end

driver:Hide()
driver:SetScript("OnUpdate", function(_, elapsed)
    driverAccum = driverAccum + elapsed
    if driverAccum < 0.05 then return end
    driverAccum = 0

    if not UpdateTestAlerts() then
        ProcessTimelinePending()
        UpdateLiveAlerts()

        local keepRunning = next(timelinePending) ~= nil
        if not keepRunning then
            for _, runtime in pairs(timelineRuntime) do
                if runtime.state == STATE_ACTIVE then
                    keepRunning = true
                    break
                end
            end
        end
        if not keepRunning and next(trashCasts) ~= nil then
            keepRunning = true
        end

        if not keepRunning then
            driver:Hide()
        end
    end
end)

function CT:RefreshTrackingState()
    if not db then return end

    if self.RefreshAuraContainerState then
        self:RefreshAuraContainerState()
    end

    if testMode then
        driver:Show()
        return
    end

    if not db.enabled or not IsInSupportedInstance() then
        driver:Hide()
        for _, f in ipairs(activeSlots) do f:Hide() end
        if CT.TimelineHUD and type(CT.TimelineHUD.Render) == "function" then CT.TimelineHUD:Render({}) end
        return
    end

    if TimelineFeatureAvailable() then
        ProcessTimelinePending()
    end

    local anyActive = next(trashCasts) ~= nil

    if not anyActive and TimelineFeatureAvailable() then
        anyActive = next(timelinePending) ~= nil
        if not anyActive then
            for _, runtime in pairs(timelineRuntime) do
                if runtime.state == STATE_ACTIVE then
                    anyActive = true
                    break
                end
            end
        end
    end

    if anyActive then
        driver:Show()
        UpdateLiveAlerts()
    else
        driver:Hide()
        for _, f in ipairs(activeSlots) do f:Hide() end
        if CT.TimelineHUD and type(CT.TimelineHUD.Render) == "function" then CT.TimelineHUD:Render({}) end
    end
end

local function GetTestAbilityNames()
    local names = {}
    if DungeonData and type(DungeonData.order) == "table" then
        for _, dungeonKey in ipairs(DungeonData.order) do
            local dungeon = DungeonData.dungeons and DungeonData.dungeons[dungeonKey]
            for _, mob in ipairs(dungeon and dungeon.mobs or {}) do
                for _, spell in ipairs(mob.spells or {}) do
                    local name = GetSafeSpellName(spell.id)
                    if name then
                        names[#names + 1] = name
                        if #names >= 5 then return names end
                    end
                end
            end
        end
    end
    return names
end

function CT:StartTest(keepRunning)
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        print("|cffff3030ChayAlert HUD|r test mode is unavailable during combat.")
        return false
    end
    wipe(testTimers)
    wipe(ttsStateByIdentity)
    testMode = true
    testForceCircle = false
    local now = GetTime()
    local names = GetTestAbilityNames()
    local mechanicTypes = { "TANK", "INTERRUPT", "AOE_DAMAGE", "UTILITY", "OTHER" }
    for i = 1, db.maxAlerts do
        local duration = keepRunning and 60 or math.max(4, 10 - ((i - 1) * 1.2))
        testTimers[i] = { expires = now + duration, duration = duration, name = names[i] or ("Ability " .. i), ttsEnabled = true, mechanicType = mechanicTypes[i] }
        activeSlots[i].eventID = nil
        activeSlots[i].lastBeep = nil
    end
    driver:Show()
end

function CT:StartTestHeavy()
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        print("|cffff3030ChayAlert HUD|r test heavy is unavailable during combat.")
        return false
    end
    wipe(testTimers)
    wipe(ttsStateByIdentity)
    testMode = true
    testForceCircle = false
    local now = GetTime()
    local names = GetTestAbilityNames()
    local mechanicTypes = { "TANK", "INTERRUPT", "AOE_DAMAGE", "UTILITY", "OTHER" }
    for i = 1, 5 do
        local duration = math.max(6, 12 - ((i - 1) * 1.5))
        testTimers[i] = { expires = now + duration, duration = duration, name = names[i] or ("Ability " .. i), ttsEnabled = true, mechanicType = mechanicTypes[i] }
        activeSlots[i].eventID = nil
        activeSlots[i].lastBeep = nil
    end
    driver:Show()
    return true
end

function CT:PreviewAbility(name, duration)
    if not db then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        print("|cffff3030ChayAlert HUD|r ability preview is unavailable during combat so live alerts are not interrupted.")
        return false
    end
    if currentEncounterID ~= nil
        or next(timelinePending) ~= nil
        or next(timelineRuntime) ~= nil
        or next(trashCasts) ~= nil then
        print("|cffff3030ChayAlert HUD|r ability preview is unavailable while live mechanics are active.")
        return false
    end
    wipe(testTimers)
    wipe(ttsStateByIdentity)
    testMode = true
    testForceCircle = true
    local d = tonumber(duration) or 7
    d = math.max(3, math.min(15, d))
    local now = GetTime()
    testTimers[1] = {
        expires = now + d,
        duration = d,
        name = type(name) == "string" and name ~= "" and name or "ABILITY",
    }
    for i = 1, MAX_CIRCLES do
        activeSlots[i].eventID = nil
        activeSlots[i].lastBeep = nil
        activeSlots[i].urgentPlayed = false
        if i > 1 then activeSlots[i]:Hide() end
    end
    driver:Show()
end

function CT:StopTest()
    testMode = false
    testForceCircle = false
    wipe(testTimers)
    wipe(ttsStateByIdentity)
    for _, f in ipairs(activeSlots) do f:Hide() end
    if CT.TimelineHUD and type(CT.TimelineHUD.Render) == "function" then
        CT.TimelineHUD:Render({})
    end
    CT:RefreshTrackingState()
end

local function StopTestForLiveCombat()
    if not testMode and not unlockMode then return end
    testMode = false
    testForceCircle = false
    unlockMode = false
    wipe(testTimers)
    for _, f in ipairs(activeSlots) do f:Hide() end
    CT:LayoutAlerts()
end

local function MakeBackdrop(frame, alpha)
    frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    frame:SetBackdropColor(0.012, 0.008, 0.01, alpha or 0.94)
    frame:SetBackdropBorderColor(0.58, 0.04, 0.06, 1)
end

local function GetPlayerClassColorRGB()
    -- Options chrome uses a fixed ChayAlert red rather than player class colors.
    return 0.36, 0.008, 0.012
end

function CT:GetClassColorRGB()
    return GetPlayerClassColorRGB()
end

function CT:ApplyClassButtonStyle(button, selected)
    if not button then return end
    local r, g, b = GetPlayerClassColorRGB()
    local fs = button.GetFontString and button:GetFontString() or nil
    if fs then
        fs:SetTextColor(1, 1, 1, 1)
        fs:SetShadowColor(0, 0, 0, 1)
        fs:SetShadowOffset(1, -1)
    end

    if not button._chayClassEdges and button.CreateTexture then
        local edges = {}
        local top = button:CreateTexture(nil, "OVERLAY")
        top:SetColorTexture(r, g, b, 1)
        top:SetPoint("TOPLEFT", 2, -1)
        top:SetPoint("TOPRIGHT", -2, -1)
        top:SetHeight(1)
        edges[#edges + 1] = top

        local bottom = button:CreateTexture(nil, "OVERLAY")
        bottom:SetColorTexture(r, g, b, 1)
        bottom:SetPoint("BOTTOMLEFT", 2, 1)
        bottom:SetPoint("BOTTOMRIGHT", -2, 1)
        bottom:SetHeight(1)
        edges[#edges + 1] = bottom

        local left = button:CreateTexture(nil, "OVERLAY")
        left:SetColorTexture(r, g, b, 1)
        left:SetPoint("TOPLEFT", 1, -2)
        left:SetPoint("BOTTOMLEFT", 1, 2)
        left:SetWidth(1)
        edges[#edges + 1] = left

        local right = button:CreateTexture(nil, "OVERLAY")
        right:SetColorTexture(r, g, b, 1)
        right:SetPoint("TOPRIGHT", -1, -2)
        right:SetPoint("BOTTOMRIGHT", -1, 2)
        right:SetWidth(1)
        edges[#edges + 1] = right
        button._chayClassEdges = edges
    end

    for _, edge in ipairs(button._chayClassEdges or {}) do
        edge:SetColorTexture(r, g, b, selected and 1 or 0.58)
    end
end

function CT:ApplyClassTabStyle(button, selected)
    if not button then return end
    local r, g, b = GetPlayerClassColorRGB()

    -- Tab buttons use one ChayAlert renderer everywhere. Hide Blizzard's native
    -- UIPanelButton textures so small selector tabs and large navigation tabs
    -- have the same red/black 3D treatment instead of layering two skins.
    if not button._chayNativeTabTexturesHidden then
        local textureGetters = { "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture", "GetHighlightTexture" }
        for _, getterName in ipairs(textureGetters) do
            local getter = button[getterName]
            if type(getter) == "function" then
                local texture = getter(button)
                if texture and type(texture.SetAlpha) == "function" then texture:SetAlpha(0) end
            end
        end
        button._chayNativeTabTexturesHidden = true
    end

    if not button._chayClassTabFill and button.CreateTexture then
        local fill = button:CreateTexture(nil, "ARTWORK", nil, 1)
        fill:SetPoint("TOPLEFT", 3, -3)
        fill:SetPoint("BOTTOMRIGHT", -3, 3)
        button._chayClassTabFill = fill

        local upper = button:CreateTexture(nil, "ARTWORK", nil, 2)
        upper:SetPoint("TOPLEFT", 4, -4)
        upper:SetPoint("TOPRIGHT", -4, -4)
        upper:SetHeight(7)
        button._chayClassTabUpper = upper

        local lower = button:CreateTexture(nil, "ARTWORK", nil, 2)
        lower:SetPoint("BOTTOMLEFT", 4, 4)
        lower:SetPoint("BOTTOMRIGHT", -4, 4)
        lower:SetHeight(6)
        button._chayClassTabLower = lower

        local topHighlight = button:CreateTexture(nil, "OVERLAY", nil, 1)
        topHighlight:SetColorTexture(1, 1, 1, 1)
        topHighlight:SetPoint("TOPLEFT", 4, -3)
        topHighlight:SetPoint("TOPRIGHT", -4, -3)
        topHighlight:SetHeight(1)
        button._chayClassTabTopHighlight = topHighlight

        local bottomShadow = button:CreateTexture(nil, "OVERLAY", nil, 1)
        bottomShadow:SetColorTexture(0, 0, 0, 1)
        bottomShadow:SetPoint("BOTTOMLEFT", 4, 3)
        bottomShadow:SetPoint("BOTTOMRIGHT", -4, 3)
        bottomShadow:SetHeight(2)
        button._chayClassTabBottomShadow = bottomShadow
    end

    local baseAlpha = selected and 0.94 or 0.88
    local upperBlend = selected and 0.20 or 0.12
    local lowerScale = selected and 0.12 or 0.08

    if button._chayClassTabFill then
        button._chayClassTabFill:SetColorTexture(r, g, b, baseAlpha)
        button._chayClassTabFill:Show()
    end
    if button._chayClassTabUpper then
        button._chayClassTabUpper:SetColorTexture(
            r + ((1 - r) * upperBlend),
            g + ((1 - g) * upperBlend),
            b + ((1 - b) * upperBlend),
            selected and 0.82 or 0.70
        )
        button._chayClassTabUpper:Show()
    end
    if button._chayClassTabLower then
        button._chayClassTabLower:SetColorTexture(r * lowerScale, g * lowerScale, b * lowerScale, 0.96)
        button._chayClassTabLower:Show()
    end
    if button._chayClassTabTopHighlight then
        button._chayClassTabTopHighlight:SetAlpha(selected and 0.44 or 0.26)
        button._chayClassTabTopHighlight:Show()
    end
    if button._chayClassTabBottomShadow then
        button._chayClassTabBottomShadow:SetAlpha(selected and 0.98 or 0.94)
        button._chayClassTabBottomShadow:Show()
    end

    local fs = button.GetFontString and button:GetFontString() or nil
    if fs then
        fs:SetTextColor(1, 1, 1, 1)
        fs:SetShadowColor(0, 0, 0, 1)
        fs:SetShadowOffset(1, -1)
    end

    if button._chayClassEdges then
        local edgeAlpha = selected and 1 or 0.92
        local top = button._chayClassEdges[1]
        local bottom = button._chayClassEdges[2]
        local left = button._chayClassEdges[3]
        local right = button._chayClassEdges[4]

        if top then
            top:SetColorTexture(
                r + ((1 - r) * 0.22),
                g + ((1 - g) * 0.22),
                b + ((1 - b) * 0.22),
                edgeAlpha
            )
        end
        if bottom then bottom:SetColorTexture(r * 0.10, g * 0.10, b * 0.10, edgeAlpha) end
        if left then
            left:SetColorTexture(
                r + ((1 - r) * 0.10),
                g + ((1 - g) * 0.10),
                b + ((1 - b) * 0.10),
                edgeAlpha
            )
        end
        if right then right:SetColorTexture(r * 0.16, g * 0.16, b * 0.16, edgeAlpha) end
    end
end

local function CreateButton(parent, text, width, callback)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width or 110, 24)
    b:SetText(text)
    b:SetScript("OnClick", callback)
    CT:ApplyClassButtonStyle(b, false)
    return b
end

local function CreateCheck(parent, text, x, y, getter, setter)
    local c = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    c:SetPoint("TOPLEFT", x, y)
    local label = c.Text or c.text
    if label then label:SetText(text) end
    c:SetScript("OnShow", function(self) self:SetChecked(getter()) end)
    c:SetScript("OnClick", function(self)
        setter(self:GetChecked())
        CT:LayoutAlerts()
        CT:RefreshTrackingState()
    end)
    return c
end

local function CreateSlider(parent, label, x, y, minVal, maxVal, step, getter, setter, width)
    local s = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
    s:SetPoint("TOPLEFT", x, y)
    s:SetSize(width or 220, 18)
    s:SetMinMaxValues(minVal, maxVal)
    s:SetValueStep(step)
    s:SetObeyStepOnDrag(true)
    if s.Low then s.Low:SetText(tostring(minVal)) end
    if s.High then s.High:SetText(tostring(maxVal)) end
    s:SetScript("OnShow", function(self)
        self:SetValue(getter())
        if self.Text then self.Text:SetText(label .. ": " .. tostring(getter())) end
    end)
    s:SetScript("OnValueChanged", function(self, value)
        value = math.floor((value / step) + 0.5) * step
        setter(value)
        if self.Text then self.Text:SetText(label .. ": " .. tostring(value)) end
        CT:LayoutAlerts()
    end)
    return s
end

local function CreateColorButton(parent, label, x, y, key, width)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width or 170, 26)
    b:SetPoint("TOPLEFT", x, y)
    MakeBackdrop(b, 0.82)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.label:SetPoint("LEFT", 8, 0)
    b.label:SetText(label)
    CT:ApplyClassButtonStyle(b, false)
    b.swatch = b:CreateTexture(nil, "ARTWORK")
    b.swatch:SetSize(18, 18)
    b.swatch:SetPoint("RIGHT", -5, 0)
    local function Refresh()
        local c = db[key]
        b.swatch:SetColorTexture(c.r, c.g, c.b, 1)
    end
    b:SetScript("OnShow", Refresh)
    b:SetScript("OnClick", function()
        local c = db[key]
        local old = { r = c.r, g = c.g, b = c.b }
        local function Apply()
            c.r, c.g, c.b = ColorPickerFrame:GetColorRGB()
            Refresh()
        end
        ColorPickerFrame:SetupColorPickerAndShow({
            r = c.r, g = c.g, b = c.b,
            swatchFunc = Apply,
            cancelFunc = function()
                c.r, c.g, c.b = old.r, old.g, old.b
                Refresh()
            end,
        })
    end)
    return b
end

local function CreateDynamicColorButton(parent, label, x, y, getter, onChanged)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(170, 26)
    b:SetPoint("TOPLEFT", x, y)
    MakeBackdrop(b, 0.82)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.label:SetPoint("LEFT", 8, 0)
    b.label:SetText(label)
    CT:ApplyClassButtonStyle(b, false)
    b.swatch = b:CreateTexture(nil, "ARTWORK")
    b.swatch:SetSize(18, 18)
    b.swatch:SetPoint("RIGHT", -5, 0)
    function b:Refresh()
        local c = getter()
        self.swatch:SetColorTexture(c.r, c.g, c.b, 1)
    end
    b:SetScript("OnShow", function(self) self:Refresh() end)
    b:SetScript("OnClick", function(self)
        local c = getter()
        local old = { r = c.r, g = c.g, b = c.b, a = c.a }
        local function Apply()
            c.r, c.g, c.b = ColorPickerFrame:GetColorRGB()
            self:Refresh()
            CT:LayoutAlerts()
            if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end
            if type(onChanged) == "function" then onChanged() end
        end
        ColorPickerFrame:SetupColorPickerAndShow({
            r = c.r, g = c.g, b = c.b,
            swatchFunc = Apply,
            cancelFunc = function()
                c.r, c.g, c.b, c.a = old.r, old.g, old.b, old.a
                self:Refresh()
                CT:LayoutAlerts()
                if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end
                if type(onChanged) == "function" then onChanged() end
            end,
        })
    end)
    return b
end

local function CreateDropdown(parent, label, x, y, width, valuesGetter, getter, setter)
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(width or 220, 48)
    holder:SetPoint("TOPLEFT", x, y)

    local title = holder:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 0, 0)
    title:SetText(label)

    local button = CreateFrame("Button", nil, holder, "BackdropTemplate")
    button:SetSize(width or 220, 24)
    button:SetPoint("TOPLEFT", 0, -20)
    MakeBackdrop(button, 0.94)
    button.text = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    button.text:SetPoint("LEFT", 8, 0)
    button.text:SetPoint("RIGHT", -26, 0)
    button.text:SetJustifyH("LEFT")
    button.arrow = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.arrow:SetPoint("RIGHT", -8, 0)
    button.arrow:SetText("▼")
    CT:ApplyClassButtonStyle(button, false)
    button.text:SetTextColor(1, 1, 1, 1)
    button.text:SetShadowColor(0, 0, 0, 1)
    button.text:SetShadowOffset(1, -1)
    button.arrow:SetTextColor(1, 1, 1, 1)
    button.arrow:SetShadowColor(0, 0, 0, 1)
    button.arrow:SetShadowOffset(1, -1)

    local menu = CreateFrame("Frame", nil, button, "BackdropTemplate")
    menu:SetFrameStrata("TOOLTIP")
    menu:SetSize(width or 220, 246)
    menu:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -2)
    MakeBackdrop(menu, 0.98)
    menu:EnableMouse(true)
    menu:EnableMouseWheel(true)
    menu:Hide()
    menu.offset = 0
    menu.rows = {}
    menu.values = {}

    local visibleRows = 10
    local rowHeight = 24
    for i = 1, visibleRows do
        local row = CreateFrame("Button", nil, menu, "BackdropTemplate")
        row:SetPoint("TOPLEFT", 4, -4 - ((i - 1) * rowHeight))
        row:SetPoint("TOPRIGHT", -4, -4 - ((i - 1) * rowHeight))
        row:SetHeight(rowHeight - 1)
        row:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
        row:SetBackdropColor(0.08, 0.01, 0.015, 0.78)
        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.text:SetTextColor(1, 1, 1, 1)
        row.text:SetShadowColor(0, 0, 0, 1)
        row.text:SetShadowOffset(1, -1)
        row.text:SetPoint("LEFT", 6, 0)
        row.text:SetPoint("RIGHT", -6, 0)
        row.text:SetJustifyH("LEFT")
        row:SetScript("OnEnter", function(self) self:SetBackdropColor(0.38, 0.03, 0.05, 0.95) end)
        row:SetScript("OnLeave", function(self) self:SetBackdropColor(0.08, 0.01, 0.015, 0.78) end)
        row:SetScript("OnClick", function(self)
            if self.value ~= nil then
                setter(self.value)
                button.text:SetText(tostring(getter() or ""))
                menu:Hide()
                CT:LayoutAlerts()
            end
        end)
        menu.rows[i] = row
    end

    function menu:RefreshRows()
        local maxOffset = math.max(0, #self.values - visibleRows)
        self.offset = math.max(0, math.min(self.offset, maxOffset))
        for i = 1, visibleRows do
            local row = self.rows[i]
            local value = self.values[self.offset + i]
            row.value = value
            if value ~= nil then
                row.text:SetText(tostring(value))
                row:Show()
            else
                row:Hide()
            end
        end
    end

    menu:SetScript("OnMouseWheel", function(self, delta)
        if delta < 0 then self.offset = self.offset + 1 else self.offset = self.offset - 1 end
        self:RefreshRows()
    end)

    button:SetScript("OnClick", function()
        if menu:IsShown() then
            menu:Hide()
            if openDropdownMenu == menu then openDropdownMenu = nil end
        else
            if openDropdownMenu and openDropdownMenu ~= menu then openDropdownMenu:Hide() end
            menu.values = valuesGetter() or {}
            menu.offset = 0
            menu:RefreshRows()
            menu:Show()
            openDropdownMenu = menu
        end
    end)

    function holder:Refresh()
        button.text:SetText(tostring(getter() or ""))
        if menu:IsShown() then
            menu.values = valuesGetter() or {}
            menu:RefreshRows()
        end
    end
    holder:SetScript("OnShow", function(self) self:Refresh() end)
    holder.button = button
    holder.menu = menu
    return holder
end

local function ResetCircle(i)
    db.circles[i] = CircleDefaults(i)
    CT:LayoutAlerts()
end

local function BuildOptions()
    if options then return end
    options = CreateFrame("Frame", "ChayAlertHUDOptions", UIParent, "BackdropTemplate")
    options:SetSize(db.optionsWidth or 1240, db.optionsHeight or 820)
    options:SetPoint("CENTER")
    options:SetFrameStrata("DIALOG")
    options:SetClampedToScreen(true)
    options:EnableMouse(true)
    options:SetMovable(true)
    options:SetResizable(true)
    -- Width and height are intentionally independent. The content canvas scales
    -- only when the window is narrower than the native design width; vertical
    -- space is handled separately so the frame can be short/tall without being
    -- forced back into the original aspect ratio.
    options:SetResizeBounds(820, 520, 1700, 1200)
    options:RegisterForDrag("LeftButton")
    options:SetScript("OnDragStart", options.StartMoving)
    options:SetScript("OnDragStop", options.StopMovingOrSizing)
    MakeBackdrop(options, 0.48)
    options:Hide()

    local bg = options:CreateTexture(nil, "BACKGROUND", nil, -2)
    bg:SetPoint("TOPLEFT", 1, -1)
    bg:SetPoint("BOTTOMRIGHT", -1, 1)
    local function RefreshOptionsBackground()
        if db.optionsBackgroundMode == "SOLID" then
            local c = db.optionsBackgroundColor or defaults.optionsBackgroundColor
            bg:SetTexture("Interface\\Buttons\\WHITE8x8")
            bg:SetTexCoord(0, 1, 0, 1)
            bg:SetVertexColor(c.r or 0.012, c.g or 0.008, c.b or 0.01, 1)
        else
            db.optionsBackgroundMode = "DRAGON"
            bg:SetTexture(GUI_BG)
            bg:SetTexCoord(0, 1, 0.04, 0.96)
            bg:SetVertexColor(1, 1, 1, 1)
        end
        bg:SetAlpha(0.96)
    end
    options.RefreshBackground = RefreshOptionsBackground
    RefreshOptionsBackground()

    local shade = options:CreateTexture(nil, "BACKGROUND", nil, -1)
    shade:SetAllPoints()
    shade:SetColorTexture(0.01, 0.005, 0.008, 0.18)

    local BASE_OPTIONS_WIDTH = 1240
    local content = CreateFrame("Frame", nil, options)
    content:SetPoint("TOPLEFT", options, "TOPLEFT", 0, 0)

    local function ApplyOptionsContentScale()
        local width = math.max(1, options:GetWidth())
        local height = math.max(1, options:GetHeight())

        -- Keep controls readable when the window is wide, but scale the design
        -- down to fit when the user makes the GUI thinner. Height is converted
        -- back into the content coordinate space independently, which allows
        -- true thin/tall and wide/short window shapes instead of aspect-locking.
        local scale = math.min(1, width / BASE_OPTIONS_WIDTH)
        scale = math.max(0.66, scale)
        content:SetScale(scale)
        content:SetSize(width / scale, height / scale)
    end

    options:SetScript("OnSizeChanged", function(self)
        ApplyOptionsContentScale()
        db.optionsWidth = math.floor(self:GetWidth() + 0.5)
        db.optionsHeight = math.floor(self:GetHeight() + 0.5)
    end)
    ApplyOptionsContentScale()

    local resizeGrip = CreateFrame("Button", nil, options, "BackdropTemplate")
    resizeGrip:SetSize(30, 30)
    resizeGrip:SetPoint("BOTTOMRIGHT", -3, 3)
    resizeGrip:SetFrameLevel(options:GetFrameLevel() + 20)
    resizeGrip:EnableMouse(true)
    MakeBackdrop(resizeGrip, 0.88)

    for i = 0, 2 do
        local line = resizeGrip:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(0.95, 0.12, 0.12, 1)
        line:SetSize(14 - (i * 4), 2)
        line:SetPoint("BOTTOMRIGHT", -4, 5 + (i * 5))
        line:SetRotation(math.rad(-45))
    end

    resizeGrip:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then
            options:StartSizing("BOTTOMRIGHT")
        end
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        options:StopMovingOrSizing()
        db.optionsWidth = math.floor(options:GetWidth() + 0.5)
        db.optionsHeight = math.floor(options:GetHeight() + 0.5)
        ApplyOptionsContentScale()
    end)
    resizeGrip:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:AddLine("Resize ChayAlert HUD", 1, 0.25, 0.25)
        GameTooltip:AddLine("Drag horizontally, vertically, or diagonally.", 1, 1, 1)
        GameTooltip:AddLine("Width and height resize independently. Short pages can scroll.", 0.75, 0.85, 1, true)
        GameTooltip:Show()
    end)
    resizeGrip:SetScript("OnLeave", GameTooltip_Hide)

    local title = content:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("|cffff3030ChayAlert|r |cffffffffHUD|r")

    local sub = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sub:SetPoint("TOP", title, "BOTTOM", 0, -5)
    sub:SetText("Midnight 12.1+ mechanic circles and alerts")

    local close = CreateButton(content, "Close", 72, function() options:Hide() end)
    close:SetPoint("TOPRIGHT", -14, -14)

    local tabs, pages = {}, {}
    local tabNames = {
        "Quick Setup",
        "Circles / Timeline",
        "Sounds & TTS",
        "Dungeon Trash",
        "Dungeon Bosses",
        "Raid Bosses",
        "Profiles",
        "Advanced Settings",
    }
    local tabHelp = {
        "Start with the recommended role-aware alert setup, then use Circles / Timeline and Sounds & TTS for previews and detailed changes.",
        "Switch between Circles and Timeline. Customize circle layout or timeline bars, fonts, colors, sizes, placement, preview, unlock and reset controls.",
        "Alert sounds, urgent warnings, countdown beeps, and SharedMedia sound selection.",
        "Choose a dungeon, then a trash mob, then configure each individual spell ID independently.",
        "Choose a dungeon and boss, then enable, disable and customize each individual boss spell ID.",
        "Choose a raid and boss, then enable, disable and customize each individual raid spell ID.",
        "Copy settings from another character profile, or safely import/export ChayAlert HUD settings.",
        "Global tracker behavior, manual spell filters, and other technical settings for users who want finer control.",
    }

    local navHint = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    navHint:SetPoint("TOPLEFT", 24, -66)
    navHint:SetWidth(180)
    navHint:SetJustifyH("LEFT")
    navHint:SetText("Choose a section. ChayAlert HUD remembers the last page you used.")

    local sectionTitle = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    sectionTitle:SetPoint("TOPLEFT", 230, -66)

    local sectionHelp = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sectionHelp:SetPoint("TOPLEFT", 230, -94)
    sectionHelp:SetWidth(940)
    sectionHelp:SetJustifyH("LEFT")

    local quickPage
    local pageTargets
    local function ShowPage(n)
        n = math.max(1, math.min(#tabNames, tonumber(n) or 1))
        db.optionsTab = n
        for _, p in ipairs(pages) do p:Hide() end
        if quickPage then quickPage:Hide() end
        local target = pageTargets and pageTargets[n]
        if target then target:Show() end
        for i, t in ipairs(tabs) do
            t:SetEnabled(true)
            CT:ApplyClassTabStyle(t, i == n)
        end
        sectionTitle:SetText(tabNames[n])
        sectionHelp:SetText(tabHelp[n])
    end

    local function ShowInternalPage(target, label, help)
        for _, p in ipairs(pages) do p:Hide() end
        if quickPage then quickPage:Hide() end
        target:Show()
        sectionTitle:SetText(label)
        sectionHelp:SetText(help or "")
    end

    local tabDisplaySlot = {
        [1] = 1,
        [2] = 2,
        [3] = 3,
        [4] = 4,
        [5] = 5,
        [6] = 6,
        [7] = 7,
        [8] = 8,
        [9] = 9,
    }

    for i, name in ipairs(tabNames) do
        local t = CreateButton(content, name, 180, function() ShowPage(i) end)
        local displaySlot = tabDisplaySlot[i] or i
        t:SetPoint("TOPLEFT", 24, -108 - ((displaySlot - 1) * 44))
        t:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:AddLine(name, 1, 0.25, 0.25)
            GameTooltip:AddLine(tabHelp[i], 1, 1, 1, true)
            GameTooltip:Show()
        end)
        t:SetScript("OnLeave", GameTooltip_Hide)
        tabs[i] = t
    end

    for i = 1, 9 do
        local p = CreateFrame("Frame", nil, content)
        p:SetPoint("TOPLEFT", 230, -130)
        p:SetPoint("BOTTOMRIGHT", -30, 58)
        p:Hide()
        pages[i] = p
    end

    quickPage = CreateFrame("Frame", nil, content)
    quickPage:SetPoint("TOPLEFT", 230, -130)
    quickPage:SetPoint("BOTTOMRIGHT", -30, 58)
    quickPage:Hide()
    pageTargets = {
        quickPage,
        pages[1],
        pages[3],
        pages[5],
        pages[6],
        pages[7],
        pages[9],
        pages[2],
    }

    local quickTitle = quickPage:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    quickTitle:SetPoint("TOPLEFT", 0, 0)
    quickTitle:SetText("ChayAlert HUD")
    local quickInfo = quickPage:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    quickInfo:SetPoint("TOPLEFT", 0, -38)
    quickInfo:SetWidth(820)
    quickInfo:SetJustifyH("LEFT")
    quickInfo:SetText("Recommended setup tracks important mechanics for your current role. You can customize any ability individually.")

    local roleText = quickPage:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    roleText:SetPoint("TOPLEFT", 0, -92)
    roleText:SetText("Current role: " .. (CT:GetRoleProfileLabel() or "Auto"))
    local specText = quickPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    specText:SetPoint("TOPLEFT", 0, -112)
    local function RefreshQuickSpecialization()
        local specIndex = type(GetSpecialization) == "function" and GetSpecialization() or nil
        local specName
        if specIndex and type(GetSpecializationInfo) == "function" then
            local _, name = GetSpecializationInfo(specIndex)
            specName = name
        end
        specText:SetText("Current specialization: " .. (specName or "Unavailable"))
    end
    RefreshQuickSpecialization()
    local roleDrop = CreateDropdown(quickPage, "Role profile", 0, -122, 250,
        function() return { "Auto", "Tank", "Healer", "DPS", "All Abilities" } end,
        function()
            local labels = { AUTO = "Auto", TANK = "Tank", HEALER = "Healer", DAMAGER = "DPS", ALL = "All Abilities" }
            return labels[CT:GetRoleProfile()] or "Auto"
        end,
        function(value)
            local modes = { Auto = "AUTO", Tank = "TANK", Healer = "HEALER", DPS = "DAMAGER", ["All Abilities"] = "ALL" }
            CT:SetRoleProfile(modes[value] or "AUTO")
            roleText:SetText("Current role: " .. (CT:GetRoleProfileLabel() or "Auto"))
        end)

    local statusText = quickPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    statusText:SetPoint("TOPLEFT", 0, -196)
    statusText:SetWidth(820)
    statusText:SetJustifyH("LEFT")
    local function RefreshQuickStatus()
        local role = CT:GetRoleProfileLabel() or "Auto"
        statusText:SetText(db.enabled and ("READY\nRecommended " .. role .. " setup active") or "ChayAlert HUD is currently disabled")
        roleText:SetText("Current role: " .. role)
        RefreshQuickSpecialization()
    end

    local recommended = CreateButton(quickPage, "Use Recommended Setup", 220, function()
        db.enabled = true
        db.soundEnabled = true
        db.ttsEnabled = true
        if CT.TankSwap and type(CT.TankSwap.Refresh) == "function" then CT.TankSwap:Refresh() end
        db.maxAlerts = math.max(1, math.min(3, tonumber(db.maxAlerts) or 3))
        db.leadTime = math.max(3, math.min(30, tonumber(db.leadTime) or 10))
        if db.displayMode ~= "TIMELINE" and db.displayMode ~= "BOTH" then db.displayMode = "CIRCLE" end
        UpdateLiveAlerts()
        RefreshQuickStatus()
    end)
    recommended:SetPoint("TOPLEFT", 0, -240)
    recommended:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Recommended", 1, 0.25, 0.25)
        GameTooltip:AddLine("Uses ChayAlert's curated mechanic settings for the selected role without clearing ability overrides.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    recommended:SetScript("OnLeave", GameTooltip_Hide)

    local quickEnabled = CreateCheck(quickPage, "Enable ChayAlert HUD", 0, -292,
        function() return db.enabled end,
        function(v) db.enabled = v; UpdateLiveAlerts(); RefreshQuickStatus() end)
    local quickSounds = CreateCheck(quickPage, "Enable Sounds", 220, -292,
        function() return db.soundEnabled end,
        function(v) db.soundEnabled = v end)
    local quickVoice = CreateCheck(quickPage, "Enable Voice Warnings", 440, -292,
        function() return db.ttsEnabled end,
        function(v)
            db.ttsEnabled = v == true
            if CT.TankSwap and type(CT.TankSwap.Refresh) == "function" then CT.TankSwap:Refresh() end
        end)
    local quickMinimap = CreateCheck(quickPage, "Show Minimap Icon", 0, -330,
        function() return db.showMinimap end,
        function(v) db.showMinimap = v; CT:UpdateMinimapButton() end)

    -- Preview/test actions live on their dedicated pages to avoid duplicate controls:
    -- Circles -> Test Circle / Stop Test; Timeline -> Test Timeline;
    -- Sounds & TTS -> sound and voice previews.
    quickPage:SetScript("OnShow", RefreshQuickStatus)

    -- Circle editor and global tracker options are separate pages so the most
    -- frequently adjusted visual controls have room to breathe.
    local circlePage = pages[1]

    -- Circles and Timeline share one sidebar section. The top-level buttons below
    -- switch only the visual editor; runtime mechanic routing remains unchanged.
    local circleView = CreateFrame("Frame", nil, circlePage)
    circleView:SetPoint("TOPLEFT", 0, -42)
    circleView:SetPoint("BOTTOMRIGHT", 0, 0)

    local timelineView = CreateFrame("Frame", nil, circlePage)
    timelineView:SetPoint("TOPLEFT", 0, -42)
    timelineView:SetPoint("BOTTOMRIGHT", 0, 0)
    timelineView:Hide()

    local circleTabButton
    local timelineTabButton
    local c
    local function RefreshLayoutSubTabs()
        local mode = db.layoutSubTab == "TIMELINE" and "TIMELINE" or "CIRCLES"
        db.layoutSubTab = mode

        if mode == "TIMELINE" then
            circleView:Hide()
            timelineView:Show()
        else
            timelineView:Hide()
            circleView:Show()
        end

        if circleTabButton then CT:ApplyClassTabStyle(circleTabButton, mode == "CIRCLES") end
        if timelineTabButton then CT:ApplyClassTabStyle(timelineTabButton, mode == "TIMELINE") end

        if mode == "TIMELINE" then
            if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end
        elseif c and c.RefreshCirclePage then
            c:RefreshCirclePage()
        end
    end

    circleTabButton = CreateButton(circlePage, "Circles", 150, function()
        db.layoutSubTab = "CIRCLES"
        RefreshLayoutSubTabs()
    end)
    circleTabButton:SetPoint("TOPLEFT", 0, 0)

    timelineTabButton = CreateButton(circlePage, "Timeline", 150, function()
        db.layoutSubTab = "TIMELINE"
        RefreshLayoutSubTabs()
    end)
    timelineTabButton:SetPoint("LEFT", circleTabButton, "RIGHT", 10, 0)

    local circleScroll = CreateFrame("ScrollFrame", nil, circleView, "UIPanelScrollFrameTemplate")
    circleScroll:SetPoint("TOPLEFT", 0, 0)
    circleScroll:SetPoint("BOTTOMRIGHT", -24, 0)

    c = CreateFrame("Frame", nil, circleScroll)
    c:SetSize(900, 1200)
    circleScroll:SetScrollChild(c)
    if _G.ChayAlertHUDAbilityUI and _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame then _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame(circleScroll) end

    local function RefreshCircleCanvasSize()
        local pageWidth = math.max(900, (circleView:GetWidth() or 900) - 30)
        local pageHeight = math.max(1200, circleView:GetHeight() or 1200)
        c:SetSize(pageWidth, pageHeight)
    end
    circleView:SetScript("OnSizeChanged", RefreshCircleCanvasSize)
    circleView:SetScript("OnShow", function()
        RefreshCircleCanvasSize()
        if c.RefreshCirclePage then c:RefreshCirclePage() end
    end)
    circlePage:SetScript("OnShow", RefreshLayoutSubTabs)
    RefreshCircleCanvasSize()

    local g = pages[2]

    local globalHeader = g:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    globalHeader:SetPoint("TOPLEFT", 0, 0)
    globalHeader:SetText("Tracker Options")

    local globalInfo = g:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    globalInfo:SetPoint("TOPLEFT", 0, -30)
    globalInfo:SetWidth(900)
    globalInfo:SetJustifyH("LEFT")
    globalInfo:SetText("These settings control when ChayAlert HUD appears and how all alerts behave globally. Circle and timeline appearance stays on Circles / Timeline.")

    CreateCheck(g, "Enable ChayAlert HUD", 0, -72,
        function() return db.enabled end,
        function(v) db.enabled = v; UpdateLiveAlerts() end)

    CreateCheck(g, "Only show in party/raid instances", 0, -108,
        function() return db.onlyInInstances end,
        function(v) db.onlyInInstances = v; UpdateLiveAlerts() end)

    CreateCheck(g, "Show minimap icon", 0, -144,
        function() return db.showMinimap end,
        function(v) db.showMinimap = v; CT:UpdateMinimapButton() end)

    CreateSlider(g, "Lead time", 420, -84, 3, 30, 1,
        function() return db.leadTime end,
        function(v) db.leadTime = v; UpdateLiveAlerts() end, 300)

    CreateSlider(g, "Maximum circles", 420, -154, 1, 3, 1,
        function() return db.maxAlerts end,
        function(v) db.maxAlerts = v; UpdateLiveAlerts() end, 300)

    local DISPLAY_LABEL_TO_MODE = {
        ["Circles Only"] = "CIRCLE",
        ["Timeline Only"] = "TIMELINE",
        ["Circles + Timeline"] = "BOTH",
        ["Off"] = "NONE",
    }
    local DISPLAY_MODE_TO_LABEL = { CIRCLE = "Circles Only", TIMELINE = "Timeline Only", BOTH = "Circles + Timeline", NONE = "Off" }
    CreateDropdown(g, "Global alert display", 0, -190, 300,
        function() return { "Circles Only", "Timeline Only", "Circles + Timeline", "Off" } end,
        function() return DISPLAY_MODE_TO_LABEL[ResolveDisplayMode(nil)] or "Circles + Timeline" end,
        function(value) CT:SetDisplayMode(DISPLAY_LABEL_TO_MODE[value] or "BOTH") end)

    local spellOverridesLink = CreateButton(g, "Open Spell Overrides", 180, function()
        ShowInternalPage(pages[4], "Spell Overrides", "Manual track/ignore spell lists and advanced spell-filter behavior.")
    end)
    spellOverridesLink:SetPoint("TOPLEFT", 0, -244)

    local optionsAppearanceTitle = g:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    optionsAppearanceTitle:SetPoint("TOPLEFT", 0, -310)
    optionsAppearanceTitle:SetText("Options Window Appearance")

    local OPTIONS_BG_LABEL_TO_MODE = { ["Dragon Artwork"] = "DRAGON", ["Solid Color"] = "SOLID" }
    local OPTIONS_BG_MODE_TO_LABEL = { DRAGON = "Dragon Artwork", SOLID = "Solid Color" }
    CreateDropdown(g, "Options background", 0, -346, 240,
        function() return { "Dragon Artwork", "Solid Color" } end,
        function() return OPTIONS_BG_MODE_TO_LABEL[db.optionsBackgroundMode] or "Dragon Artwork" end,
        function(value)
            db.optionsBackgroundMode = OPTIONS_BG_LABEL_TO_MODE[value] or "DRAGON"
            if options and options.RefreshBackground then options:RefreshBackground() end
        end)

    CreateDynamicColorButton(g, "Solid background color", 280, -366,
        function() return db.optionsBackgroundColor end,
        function()
            if options and options.RefreshBackground then options:RefreshBackground() end
        end)

    local optionsAppearanceInfo = g:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    optionsAppearanceInfo:SetPoint("TOPLEFT", 0, -416)
    optionsAppearanceInfo:SetWidth(760)
    optionsAppearanceInfo:SetJustifyH("LEFT")
    optionsAppearanceInfo:SetText("Solid Color replaces the dragon artwork only in the ChayAlert HUD options window. Alert circles and timeline visuals are unchanged.")

    local selectorLabel = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    selectorLabel:SetPoint("TOPLEFT", 0, 0)
    selectorLabel:SetText("Edit Circle")
    local circleButtons = {}
    local circleControls = {}

    local function RefreshCirclePage()
        for i, b in ipairs(circleButtons) do
            b:SetEnabled(true)
            CT:ApplyClassTabStyle(b, i == selectedCircle)
        end
        for _, ctl in ipairs(circleControls) do
            if ctl.Refresh then ctl:Refresh() end
        end
        CT:LayoutAlerts()
    end

    for i = 1, MAX_CIRCLES do
        local b = CreateButton(c, tostring(i), 44, function() selectedCircle = i; RefreshCirclePage() end)
        b:SetPoint("TOPLEFT", 105 + (i - 1) * 50, 4)
        circleButtons[i] = b
    end

    local enableCircle = CreateCheck(c, "Enable selected circle", 0, -52,
        function() return db.circles[selectedCircle].enabled end,
        function(v) db.circles[selectedCircle].enabled = v end)
    function enableCircle:Refresh() self:SetChecked(db.circles[selectedCircle].enabled) end
    circleControls[#circleControls + 1] = enableCircle

    local soundCircle = CreateCheck(c, "Sound on selected circle", 0, -86,
        function() return db.circles[selectedCircle].sound end,
        function(v) db.circles[selectedCircle].sound = v end)
    function soundCircle:Refresh() self:SetChecked(db.circles[selectedCircle].sound) end
    circleControls[#circleControls + 1] = soundCircle

    CreateCheck(c, "Flash new circle for 2 seconds", 0, -120,
        function() return db.circleFlashOnStart == true end,
        function(v)
            db.circleFlashOnStart = v == true
            if not db.circleFlashOnStart then
                for _, frame in ipairs(activeSlots) do
                    if frame.flashGroup and frame.flashGroup:IsPlaying() then frame.flashGroup:Stop() end
                    if frame.flashOverlay then frame.flashOverlay:Hide() end
                end
            end
        end)

    local function AddCircleSlider(label, x, y, minv, maxv, step, field, width)
        local sld = CreateSlider(c, label, x, y, minv, maxv, step,
            function() return db.circles[selectedCircle][field] end,
            function(v) db.circles[selectedCircle][field] = v end, width)
        function sld:Refresh()
            local value = db.circles[selectedCircle][field]
            self:SetValue(value)
            if self.Text then self.Text:SetText(label .. ": " .. tostring(value)) end
        end
        circleControls[#circleControls + 1] = sld
        return sld
    end

    AddCircleSlider("Circle size", 18, -170, 50, 360, 2, "size", 260)
    AddCircleSlider("Circle opacity", 18, -242, 0.02, 1.00, 0.01, "alpha", 260)
    AddCircleSlider("Circle X", 365, -72, -1000, 1000, 1, "x", 270)
    AddCircleSlider("Circle Y", 365, -144, -700, 700, 1, "y", 270)

    -- Global ring thickness is intentionally kept near the basic circle controls
    -- so it is visible without scrolling down into advanced appearance options.
    CreateSlider(c, "Ring thickness (all circles)", 365, -217, 2, 36, 1,
        function() return db.ringThickness end,
        function(v)
            db.ringThickness = v
            CT:LayoutAlerts()
        end, 270)

    -- Ring Appearance
    local ringHeader = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    ringHeader:SetPoint("TOPLEFT", 0, -320)
    ringHeader:SetText("Ring Appearance")

    local ringDrop = CreateDropdown(c, "Ring style", 0, -356, 245,
        function() return { "Textured Ring", "Plain Circle", "Flat Full Ring" } end,
        function() return db.circles[selectedCircle].ringMode end,
        function(v) db.circles[selectedCircle].ringMode = v end)
    circleControls[#circleControls + 1] = ringDrop

    CreateCheck(c, "Reverse ring direction", 0, -428,
        function() return db.reverse end,
        function(v)
            db.reverse = v
            CT:LayoutAlerts()
        end)

    CreateSlider(c, "Empty ring opacity", 365, -428, 0.00, 1.00, 0.01,
        function() return db.ringBackgroundAlpha end,
        function(v) db.ringBackgroundAlpha = v end, 270)

    CreateCheck(c, "Time-based ring colors", 0, -478,
        function() return db.useTimeColor end,
        function(v) db.useTimeColor = v end)

    CreateColorButton(c, "Normal ring", 0, -514, "color", 155)
    CreateColorButton(c, "Warning ring", 165, -514, "warningColor", 155)
    CreateColorButton(c, "Urgent ring", 330, -514, "urgentColor", 155)

    -- Timer Appearance
    local timerHeader = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    timerHeader:SetPoint("TOPLEFT", 0, -570)
    timerHeader:SetText("Timer Appearance")

    AddCircleSlider("Timer size", 18, -606, 8, 72, 1, "timerFontSize", 260)

    local timerFontDrop = CreateDropdown(c, "Timer font (SharedMedia)", 365, -606, 245,
        function() return GetMediaNames("font") end,
        function() return db.circles[selectedCircle].timerFont end,
        function(v) db.circles[selectedCircle].timerFont = v end)
    circleControls[#circleControls + 1] = timerFontDrop

    local timerColor = CreateDynamicColorButton(c, "Timer color", 0, -678,
        function() return db.circles[selectedCircle].timerColor end)
    circleControls[#circleControls + 1] = timerColor

    CreateCheck(c, "Show tenths below 10 sec", 365, -678,
        function() return db.showTenths end,
        function(v) db.showTenths = v end)

    AddCircleSlider("Timer X", 18, -728, -300, 300, 1, "timerX", 260)
    AddCircleSlider("Timer Y", 365, -728, -300, 300, 1, "timerY", 270)

    -- Mechanic / Spell Name
    local nameHeader = c:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    nameHeader:SetPoint("TOPLEFT", 0, -800)
    nameHeader:SetText("Mechanic / Spell Name")

    CreateCheck(c, "Show mechanic/spell name", 0, -836,
        function() return db.showName end,
        function(v) db.showName = v end)

    AddCircleSlider("Name size", 18, -886, 8, 36, 1, "nameFontSize", 260)

    local nameFontDrop = CreateDropdown(c, "Name font (SharedMedia)", 365, -886, 245,
        function() return GetMediaNames("font") end,
        function() return db.circles[selectedCircle].nameFont end,
        function(v) db.circles[selectedCircle].nameFont = v end)
    circleControls[#circleControls + 1] = nameFontDrop

    local nameColor = CreateDynamicColorButton(c, "Name color", 0, -958,
        function() return db.circles[selectedCircle].nameColor end)
    circleControls[#circleControls + 1] = nameColor

    AddCircleSlider("Name X", 18, -994, -300, 300, 1, "nameX", 260)
    AddCircleSlider("Name Y", 365, -994, -300, 300, 1, "nameY", 270)

    local startTest = CreateButton(c, "Test Circle", 110, function() CT:StartTest(false) end)
    CT:ApplyClassTabStyle(startTest, false)
    startTest:SetPoint("TOPLEFT", 365, 4)
    local stopTest = CreateButton(c, "Stop Test", 105, function() CT:StopTest() end)
    CT:ApplyClassTabStyle(stopTest, false)
    stopTest:SetPoint("LEFT", startTest, "RIGHT", 8, 0)
    local unlock = CreateButton(c, "Unlock Circles", 125, function() CT:SetUnlocked(true) end)
    CT:ApplyClassTabStyle(unlock, false)
    unlock:SetPoint("LEFT", stopTest, "RIGHT", 8, 0)
    local lock = CreateButton(c, "Lock Circles", 115, function() CT:SetUnlocked(false) end)
    CT:ApplyClassTabStyle(lock, false)
    lock:SetPoint("LEFT", unlock, "RIGHT", 8, 0)
    local resetSelected = CreateButton(c, "Reset Selected", 125, function() ResetCircle(selectedCircle); RefreshCirclePage() end)
    CT:ApplyClassTabStyle(resetSelected, false)
    resetSelected:SetPoint("TOPLEFT", 365, -28)
    local resetAll = CreateButton(c, "Reset All", 105, function()
        for i = 1, MAX_CIRCLES do db.circles[i] = CircleDefaults(i) end
        CT:LayoutAlerts(); RefreshCirclePage()
    end)
    CT:ApplyClassTabStyle(resetAll, false)
    resetAll:SetPoint("LEFT", resetSelected, "RIGHT", 8, 0)

    local copyLayout = CreateButton(c, "Sync Layout", 120, function()
        local source = db.circles[selectedCircle]
        if not source then return end

        local fields = {
            "size", "alpha", "timerFontSize", "nameFontSize",
            "timerX", "timerY", "nameX", "nameY",
            "ringMode", "timerFont", "nameFont",
        }

        for i = 1, MAX_CIRCLES do
            if i ~= selectedCircle then
                local target = db.circles[i]
                for _, field in ipairs(fields) do
                    target[field] = source[field]
                end
            end
        end

        CT:LayoutAlerts()
        RefreshCirclePage()
        print("|cffff3030ChayAlert HUD|r copied Circle " .. tostring(selectedCircle) .. " visual layout to the active circles. Screen positions were preserved.")
    end)
    CT:ApplyClassTabStyle(copyLayout, false)
    copyLayout:SetPoint("LEFT", resetAll, "RIGHT", 8, 0)
    copyLayout:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Sync selected circle layout", 1, 0.25, 0.25)
        GameTooltip:AddLine("Copies size, opacity, ring style, timer/name sizes, timer/name X/Y offsets and fonts to the active circles.", 1, 1, 1, true)
        GameTooltip:AddLine("Each circle keeps its own screen X/Y position, enable/sound state and timer/name colors.", 0.72, 0.72, 0.72, true)
        GameTooltip:Show()
    end)
    copyLayout:SetScript("OnLeave", GameTooltip_Hide)

    local moveHint = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    moveHint:SetPoint("BOTTOMLEFT", 0, 38)
    moveHint:SetWidth(900)
    moveHint:SetJustifyH("LEFT")
    moveHint:SetJustifyV("BOTTOM")
    moveHint:SetText("Unlock = drag the circle itself. Timer/name placement uses X/Y sliders only. Sync Layout keeps each circle screen position while matching size, ring style, fonts, and timer/name placement.")

    -- Expose the refresh callback to the page wrapper because the circle editor
    -- now lives inside a scroll canvas for short-window support.
    c.RefreshCirclePage = RefreshCirclePage
    c:SetScript("OnShow", RefreshCirclePage)

    -- Audio
    local a = pages[3]
    CreateCheck(a, "Enable audible alerts", 0, 0, function() return db.soundEnabled end, function(v) db.soundEnabled = v end)
    CreateCheck(a, "Play urgent warning sound", 0, -38, function() return db.playUrgentSound end, function(v) db.playUrgentSound = v end)
    CreateCheck(a, "Countdown beeps", 0, -76, function() return db.countdownBeeps end, function(v) db.countdownBeeps = v end)
    CreateSlider(a, "Urgent / beep final seconds", 18, -140, 1, 5, 1, function() return db.beepAt end, function(v) db.beepAt = v end, 275)

    local alertDrop = CreateDropdown(a, "Alert sound (SharedMedia)", 370, 0, 300,
        function() return GetMediaNames("sound") end,
        function() return db.allSoundSelectionsNone and "None" or db.alertSound end,
        function(v) db.alertSound = v; db.allSoundSelectionsNone = false end)
    local urgentDrop = CreateDropdown(a, "Urgent sound (SharedMedia)", 370, -75, 300,
        function() return GetMediaNames("sound") end,
        function() return db.allSoundSelectionsNone and "None" or db.urgentSound end,
        function(v) db.urgentSound = v; db.allSoundSelectionsNone = false end)
    local beepDrop = CreateDropdown(a, "Countdown beep (SharedMedia)", 370, -150, 300,
        function() return GetMediaNames("sound") end,
        function() return db.allSoundSelectionsNone and "None" or db.beepSound end,
        function(v) db.beepSound = v; db.allSoundSelectionsNone = false end)

    local allSoundsNone = CreateCheck(a, "Set all alert sounds to None", 370, -205,
        function() return db.allSoundSelectionsNone == true end,
        function(v)
            db.allSoundSelectionsNone = v == true
            alertDrop:Refresh()
            urgentDrop:Refresh()
            beepDrop:Refresh()
        end)
    allSoundsNone:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Set all alert sounds to None", 1, 0.25, 0.25)
        GameTooltip:AddLine("Temporarily forces Alert, Urgent, and Countdown Beep to None without deleting the individual sound selections. Uncheck it to restore those selections.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    allSoundsNone:SetScript("OnLeave", GameTooltip_Hide)

    local function VoiceChoices()
        if CT.TTS and type(CT.TTS.GetVoiceChoices) == "function" then
            return CT.TTS:GetVoiceChoices()
        end
        local names = { "System Default" }
        for _, voice in ipairs(GetTTSVoices()) do
            local name = voice.name
            local id = tonumber(voice.voiceID)
            if type(name) == "string" and name ~= "" and id then
                names[#names + 1] = string.format("%s [%d]", name, id)
            end
        end
        table.sort(names, function(left, right)
            if left == "System Default" then return true end
            if right == "System Default" then return false end
            return left < right
        end)
        return names
    end

    local function SelectedVoiceName()
        if CT.TTS and type(CT.TTS.GetSelectedVoiceLabel) == "function" then
            return CT.TTS:GetSelectedVoiceLabel()
        end
        return "System Default"
    end

    CreateCheck(a, "Enable TTS", 0, -225,
        function() return db.ttsEnabled == true end,
        function(v)
            db.ttsEnabled = v == true
            if CT.TankSwap and type(CT.TankSwap.Refresh) == "function" then CT.TankSwap:Refresh() end
        end)
    CreateSlider(a, "TTS rate", 0, -275, -10, 10, 1,
        function() return db.ttsRate end,
        function(v) db.ttsRate = v end, 260)
    CreateSlider(a, "TTS volume", 320, -275, 0, 100, 1,
        function() return db.ttsVolume end,
        function(v) db.ttsVolume = v end, 260)
    local voiceDrop = CreateDropdown(a, "TTS voice (all callouts)", 0, -330, 300,
        VoiceChoices,
        SelectedVoiceName,
        function(value)
            if CT.TTS and type(CT.TTS.SetSelectedVoiceLabel) == "function" then
                CT.TTS:SetSelectedVoiceLabel(value)
            end
        end)
    voiceDrop.button:SetEnabled(#GetTTSVoices() > 0)

    local PHRASE_LABELS = {
        ["Ability Name"] = "ABILITY_ONLY",
        ["Custom"] = "CUSTOM",
    }
    local PHRASE_MODES = { "Ability Name", "Custom" }
    local customTTS
    local function RefreshCustomTTSVisibility()
        if customTTS then customTTS:SetShown(db.ttsPhraseMode == "CUSTOM") end
    end
    local phraseDrop = CreateDropdown(a, "TTS phrase mode", 320, -330, 260,
        function() return PHRASE_MODES end,
        function()
            if db.ttsPhraseMode == "CUSTOM" then return "Custom" end
            return "Ability Name"
        end,
        function(value)
            db.ttsPhraseMode = PHRASE_LABELS[value] or "ABILITY_ONLY"
            RefreshCustomTTSVisibility()
        end)

    local previewTTS = CreateButton(a, "Preview Voice", 125, function()
        if CT.TTS and type(CT.TTS.Preview) == "function" then
            CT.TTS:Preview()
        end
    end)
    previewTTS:SetPoint("TOPLEFT", 620, -350)

    customTTS = CreateFrame("EditBox", nil, a, "InputBoxTemplate")
    customTTS:SetSize(300, 24)
    customTTS:SetPoint("TOPLEFT", 320, -390)
    customTTS:SetAutoFocus(false)
    customTTS:SetMaxLetters(96)
    customTTS.Instructions = customTTS:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    customTTS.Instructions:SetPoint("LEFT", 5, 0)
    customTTS.Instructions:SetText("Custom phrase (Custom mode)")
    customTTS:SetScript("OnTextChanged", function(self)
        self.Instructions:SetShown(self:GetText() == "")
    end)
    customTTS:SetText(db.ttsCustomPhrase or "")
    customTTS:SetScript("OnEnterPressed", function(self)
        db.ttsCustomPhrase = self:GetText() or ""
        self:ClearFocus()
    end)
    customTTS:SetScript("OnEditFocusLost", function(self)
        db.ttsCustomPhrase = self:GetText() or ""
    end)
    RefreshCustomTTSVisibility()

    local tankSwapVoiceDrop = CreateDropdown(a, "Protected tank-swap voice", 0, -450, 300,
        function()
            if CT.TankSwap and type(CT.TankSwap.GetVoiceChoices) == "function" then
                return CT.TankSwap:GetVoiceChoices()
            end
            return { "Same as TTS voice", "Zira (Female)", "David (Male)" }
        end,
        function()
            if CT.TankSwap and type(CT.TankSwap.GetSelectedVoiceLabel) == "function" then
                return CT.TankSwap:GetSelectedVoiceLabel()
            end
            return "Same as TTS voice"
        end,
        function(value)
            if CT.TankSwap and type(CT.TankSwap.SetSelectedVoiceLabel) == "function" then
                CT.TankSwap:SetSelectedVoiceLabel(value)
            end
        end)

    local previewTaunt = CreateButton(a, "Preview Taunt Swap", 145, function()
        if CT.TankSwap and type(CT.TankSwap.PreviewActualTaunt) == "function" then
            CT.TankSwap:PreviewActualTaunt()
        end
    end)
    previewTaunt:SetPoint("TOPLEFT", 320, -470)

    local previewAlert = CreateButton(a, "Preview Alert", 125, function() PlaySelectedSound(db.alertSound) end)
    previewAlert:SetPoint("TOPLEFT", 690, -20)
    local previewUrgent = CreateButton(a, "Preview Urgent", 125, function() PlaySelectedSound(db.urgentSound) end)
    previewUrgent:SetPoint("TOPLEFT", 690, -95)
    local previewBeep = CreateButton(a, "Preview Beep", 125, function() PlaySelectedSound(db.beepSound) end)
    previewBeep:SetPoint("TOPLEFT", 690, -170)

    local audioInfo = a:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    audioInfo:SetPoint("TOPLEFT", 0, -535)
    audioInfo:SetWidth(850)
    audioInfo:SetJustifyH("LEFT")
    audioInfo:SetText("All spoken boss, raid, dungeon, trash, interrupt, tank-buster, AOE, utility, custom, and preview callouts use the TTS voice selected above. Zira (Female) and David (Male) are shown first when WoW reports those Windows voices as installed. Protected automatic tank swaps use C_UnitAuras.AddAuraSound, so they use the bundled matching Zira/David Taunt now WAV instead of a live TTS voice ID. Leave Protected tank-swap voice on Same as TTS voice to keep every callout on the same voice. The protected WAVs are loudness-boosted and play on Master; the TTS volume slider controls dynamic spoken callouts only.")

    -- Spells
    local sp = pages[4]

    local explain = sp:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    explain:SetPoint("TOPLEFT", 0, 0)
    explain:SetWidth(860)
    explain:SetJustifyH("LEFT")
    explain:SetText("Add spell IDs you specifically want ChayAlert HUD to track, or ignore IDs you never want shown. Custom tracking applies to Blizzard Encounter Timeline mechanics whose spell identity is exposed to addons; Midnight can protect live spell IDs.")

    CreateCheck(
        sp,
        "Track regular mob casts",
        0,
        -44,
        function() return db.trashCastsEnabled end,
        function(v)
            db.trashCastsEnabled = v
            if not v then
                wipe(trashCasts)
                wipe(trashRetryToken)
            end
            UpdateLiveAlerts()
        end
    )

    CreateCheck(
        sp,
        "Show mob name with trash spell",
        300,
        -44,
        function() return db.showTrashMobName end,
        function(v)
            db.showTrashMobName = v
            for _, cast in pairs(trashCasts) do
                local fake = {
                    name = cast.rawSpellName,
                    mobName = cast.mobName,
                }
                cast.name = BuildTrashDisplayName(fake, cast.spellID, cast.labelOverride)
            end
            UpdateLiveAlerts()
        end
    )

    local auraCheck = CreateCheck(
        sp,
        "Important player debuff circles (12.1)",
        600,
        -44,
        function() return CT:GetImportantAurasEnabled() end,
        function(v) CT:SetImportantAurasEnabled(v) end
    )
    auraCheck:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Important player debuff circles", 1, 0.82, 0, 1)
        GameTooltip:AddLine("Uses Blizzard's Midnight 12.1 CustomAuraContainer system and Blizzard's priority-aura filter. ChayAlert HUD does not read protected UNIT_AURA payloads or identify secret player debuffs itself.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    auraCheck:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local suppressBossTrash = CreateCheck(
        sp,
        "Suppress trash circles during boss encounters",
        0,
        -82,
        function() return db.suppressTrashDuringBoss end,
        function(v)
            db.suppressTrashDuringBoss = v
            if v and currentEncounterID ~= nil then
                wipe(trashCasts)
                wipe(trashRetryToken)
            end
            UpdateLiveAlerts()
        end
    )
    suppressBossTrash:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Suppress trash during boss encounters", 1, 0.25, 0.25)
        GameTooltip:AddLine("Recommended. Prevents nameplate trash-cast circles from duplicating or competing with boss Encounter Timeline circles while an encounter is active.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    suppressBossTrash:SetScript("OnLeave", GameTooltip_Hide)

    CreateSlider(
        sp,
        "Minimum regular mob cast time",
        28,
        -143,
        0.5,
        5.0,
        0.1,
        function() return db.trashMinCastTime end,
        function(v) db.trashMinCastTime = v end,
        300
    )

    CreateCheck(
        sp,
        "Track only my added spells",
        0,
        -203,
        function() return db.trackOnlyCustom end,
        function(v)
            db.trackOnlyCustom = v
            UpdateLiveAlerts()
        end
    )

    local modeHelp = sp:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    modeHelp:SetPoint("TOPLEFT", 26, -229)
    modeHelp:SetWidth(820)
    modeHelp:SetJustifyH("LEFT")
    modeHelp:SetText("Off: normal ChayAlert HUD behavior + your ignored list.  On: only IDs in Tracked Spells are shown when Blizzard exposes a usable spell ID.")

    local edit = CreateFrame("EditBox", nil, sp, "InputBoxTemplate")
    edit:SetSize(180, 24)
    edit:SetPoint("TOPLEFT", 4, -271)
    edit:SetAutoFocus(false)
    edit:SetNumeric(true)
    edit:SetMaxLetters(10)

    local addTrack = CreateButton(sp, "Add Track", 105, function()
        local id = tonumber(edit:GetText())
        if id and id > 0 then
            db.trackedSpells[id] = true
            db.mutedSpells[id] = nil
            edit:SetText("")
            CT:RefreshSpellLists()
            UpdateLiveAlerts()
        end
    end)
    addTrack:SetPoint("LEFT", edit, "RIGHT", 10, 0)

    local addIgnore = CreateButton(sp, "Add Ignore", 105, function()
        local id = tonumber(edit:GetText())
        if id and id > 0 then
            db.mutedSpells[id] = true
            db.trackedSpells[id] = nil
            edit:SetText("")
            CT:RefreshSpellLists()
            UpdateLiveAlerts()
        end
    end)
    addIgnore:SetPoint("LEFT", addTrack, "RIGHT", 10, 0)

    local clearTracked = CreateButton(sp, "Clear Tracked", 110, function()
        wipe(db.trackedSpells)
        CT:RefreshSpellLists()
        UpdateLiveAlerts()
    end)
    clearTracked:SetPoint("LEFT", addIgnore, "RIGHT", 18, 0)

    local clearIgnored = CreateButton(sp, "Clear Ignored", 110, function()
        wipe(db.mutedSpells)
        CT:RefreshSpellLists()
        UpdateLiveAlerts()
    end)
    clearIgnored:SetPoint("LEFT", clearTracked, "RIGHT", 10, 0)

    local trackedTitle = sp:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    trackedTitle:SetPoint("TOPLEFT", 0, -319)
    trackedTitle:SetText("|cff55ff55Tracked Spells|r")

    local ignoredTitle = sp:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    ignoredTitle:SetPoint("TOPLEFT", 440, -319)
    ignoredTitle:SetText("|cffff5555Ignored Spells|r")

    local trackedScroll = CreateFrame("ScrollFrame", nil, sp, "UIPanelScrollFrameTemplate")
    trackedScroll:SetPoint("TOPLEFT", 0, -347)
    trackedScroll:SetPoint("BOTTOMRIGHT", sp, "BOTTOM", -15, 0)

    local trackedChild = CreateFrame("Frame", nil, trackedScroll)
    trackedChild:SetSize(395, 360)
    trackedScroll:SetScrollChild(trackedChild)
    if _G.ChayAlertHUDAbilityUI and _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame then _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame(trackedScroll) end

    local ignoredScroll = CreateFrame("ScrollFrame", nil, sp, "UIPanelScrollFrameTemplate")
    ignoredScroll:SetPoint("TOPLEFT", 440, -347)
    ignoredScroll:SetPoint("BOTTOMRIGHT", -30, 0)

    local ignoredChild = CreateFrame("Frame", nil, ignoredScroll)
    ignoredChild:SetSize(395, 360)
    ignoredScroll:SetScrollChild(ignoredChild)
    if _G.ChayAlertHUDAbilityUI and _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame then _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame(ignoredScroll) end

    sp.trackedRows = {}
    sp.ignoredRows = {}

    local function SpellDisplayName(id)
        if C_Spell and C_Spell.GetSpellName then
            local ok, name = pcall(C_Spell.GetSpellName, id)
            if ok and not IsSecret(name) and type(name) == "string" and name ~= "" then
                return name
            end
        end
        return seenSpells[id] or "Unknown spell"
    end

    local function SortedSpellIDs(tbl)
        local ids = {}
        for id in pairs(tbl) do
            if type(id) == "number" then
                ids[#ids + 1] = id
            end
        end
        table.sort(ids)
        return ids
    end

    local function AcquireSpellRow(rows, parent, index, buttonText, onRemove)
        local row = rows[index]
        if row then
            return row
        end

        row = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        row:SetSize(365, 30)
        MakeBackdrop(row, 0.72)

        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.text:SetPoint("LEFT", 8, 0)
        row.text:SetPoint("RIGHT", -88, 0)
        row.text:SetJustifyH("LEFT")

        row.remove = CreateButton(row, buttonText, 74, function(self)
            onRemove(self:GetParent().spellID)
        end)
        row.remove:SetPoint("RIGHT", -4, 0)

        rows[index] = row
        return row
    end

    function CT:RefreshSpellLists()
        for _, row in ipairs(sp.trackedRows) do row:Hide() end
        for _, row in ipairs(sp.ignoredRows) do row:Hide() end

        local trackedIDs = SortedSpellIDs(db.trackedSpells)
        for i, id in ipairs(trackedIDs) do
            local row = AcquireSpellRow(sp.trackedRows, trackedChild, i, "Delete", function(spellID)
                db.trackedSpells[spellID] = nil
                CT:RefreshSpellLists()
                UpdateLiveAlerts()
            end)
            row.spellID = id
            row.text:SetText(SpellDisplayName(id) .. "  |cff888888[" .. id .. "]|r")
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 0, -(i - 1) * 33)
            row:Show()
        end
        trackedChild:SetHeight(math.max(360, #trackedIDs * 33))

        local ignoredIDs = SortedSpellIDs(db.mutedSpells)
        for i, id in ipairs(ignoredIDs) do
            local row = AcquireSpellRow(sp.ignoredRows, ignoredChild, i, "Delete", function(spellID)
                db.mutedSpells[spellID] = nil
                CT:RefreshSpellLists()
                UpdateLiveAlerts()
            end)
            row.spellID = id
            row.text:SetText(SpellDisplayName(id) .. "  |cff888888[" .. id .. "]|r")
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 0, -(i - 1) * 33)
            row:Show()
        end
        ignoredChild:SetHeight(math.max(360, #ignoredIDs * 33))
    end

    edit:SetScript("OnEnterPressed", function(self)
        local id = tonumber(self:GetText())
        if id and id > 0 then
            db.trackedSpells[id] = true
            db.mutedSpells[id] = nil
            self:SetText("")
            self:ClearFocus()
            CT:RefreshSpellLists()
            UpdateLiveAlerts()
        end
    end)

    sp:SetScript("OnShow", function()
        CT:RefreshSpellLists()
    end)

    -- Trash, dungeon bosses and raid pages are implemented in files loaded after this core.
    local dm = pages[5]
    dm:SetScript("OnShow", function(self)
        if CT.BuildDungeonMobPage then CT:BuildDungeonMobPage(self) end
        if CT.RefreshDungeonMobPage then CT:RefreshDungeonMobPage() end
    end)

    local bp = pages[6]
    bp:SetScript("OnShow", function(self)
        if CT.BuildDungeonBossPage then CT:BuildDungeonBossPage(self) end
        if CT.RefreshDungeonBossPage then CT:RefreshDungeonBossPage() end
    end)

    local rp = pages[7]
    rp:SetScript("OnShow", function(self)
        if CT.BuildRaidPage then CT:BuildRaidPage(self) end
        if CT.RefreshRaidPage then CT:RefreshRaidPage() end
    end)

    local timelineHost = timelineView
    local timelineScroll = CreateFrame("ScrollFrame", nil, timelineHost, "UIPanelScrollFrameTemplate")
    timelineScroll:SetPoint("TOPLEFT", 0, 0)
    timelineScroll:SetPoint("BOTTOMRIGHT", -24, 0)
    local timelinePage = CreateFrame("Frame", nil, timelineScroll)
    timelinePage:SetSize(600, 1380)
    timelineScroll:SetScrollChild(timelinePage)
    if _G.ChayAlertHUDAbilityUI and _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame then _G.ChayAlertHUDAbilityUI.EnhanceScrollFrame(timelineScroll) end
    local function RefreshTimelineCanvasSize()
        local width = math.max(540, (timelineHost:GetWidth() or 570) - 30)
        local height = math.max(1380, timelineHost:GetHeight() or 1380)
        timelinePage:SetSize(width, height)
    end
    timelineHost:SetScript("OnSizeChanged", RefreshTimelineCanvasSize)
    timelineHost:SetScript("OnShow", RefreshTimelineCanvasSize)
    RefreshTimelineCanvasSize()

    local timelineTitle = timelinePage:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    timelineTitle:SetPoint("TOPLEFT", 0, 0)
    timelineTitle:SetText("Mini Timeline HUD")

    local timelineInfo = timelinePage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    timelineInfo:SetPoint("TOPLEFT", 0, -30)
    timelineInfo:SetPoint("RIGHT", timelinePage, "RIGHT", -10, 0)
    timelineInfo:SetJustifyH("LEFT")
    timelineInfo:SetWordWrap(true)
    if timelineInfo.SetMaxLines then timelineInfo:SetMaxLines(2) end
    timelineInfo:SetText("The timeline is an independent renderer fed by the same mechanic router as the circles. Boss/raid events can appear as future mechanics; trash casts enter as active mechanics. No separate polling ticker is used.")

    local ORIENT_LABEL_TO_MODE = { Vertical = "VERTICAL", Horizontal = "HORIZONTAL" }
    local ORIENT_MODE_TO_LABEL = { VERTICAL = "Vertical", HORIZONTAL = "Horizontal" }
    local orientationDrop = CreateDropdown(timelinePage, "Orientation", 0, -124, 165,
        function() return { "Vertical", "Horizontal" } end,
        function() return ORIENT_MODE_TO_LABEL[db.timeline.orientation] or "Vertical" end,
        function(value) db.timeline.orientation = ORIENT_LABEL_TO_MODE[value] or "VERTICAL"; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)

    local LAYOUT_LABEL_TO_MODE = { ["Single Track"] = "SINGLE", ["Category Lanes"] = "LANES" }
    local LAYOUT_MODE_TO_LABEL = { SINGLE = "Single Track", LANES = "Category Lanes" }
    CreateDropdown(timelinePage, "Layout", 175, -124, 165,
        function() return { "Single Track", "Category Lanes" } end,
        function() return LAYOUT_MODE_TO_LABEL[db.timeline.layout] or "Single Track" end,
        function(value) db.timeline.layout = LAYOUT_LABEL_TO_MODE[value] or "SINGLE"; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)

    CreateDropdown(timelinePage, "Icon Direction", 350, -124, 160,
        function()
            if db.timeline.orientation == "HORIZONTAL" then
                return { "Left -> Right", "Right -> Left" }
            end
            return { "Top -> Bottom", "Bottom -> Top" }
        end,
        function()
            if CT.TimelineHUD and type(CT.TimelineHUD.GetIconDirectionLabel) == "function" then
                return CT.TimelineHUD:GetIconDirectionLabel()
            end
            return db.timeline.orientation == "HORIZONTAL" and "Right -> Left" or "Top -> Bottom"
        end,
        function(value)
            if CT.TimelineHUD and type(CT.TimelineHUD.SetIconDirection) == "function" then
                CT.TimelineHUD:SetIconDirection(value)
            end
        end)

    CreateDropdown(timelinePage, "Track texture (SharedMedia)", 0, -170, 510,
        function() return GetMediaNames("statusbar") end,
        function() return db.timeline.trackTexture or "Solid" end,
        function(value) db.timeline.trackTexture = value; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)

    CreateDynamicColorButton(timelinePage, "Track color", 0, -234,
        function() return db.timeline.trackColor end)

    CreateSlider(timelinePage, "Track alpha", 320, -234, 0.00, 1.00, 0.05,
        function() return db.timeline.trackAlpha end,
        function(v) db.timeline.trackAlpha = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)

    CreateCheck(timelinePage, "Filled timeline bar", 0, -274,
        function() return db.timeline.barFillEnabled == true end,
        function(v) db.timeline.barFillEnabled = v == true; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)
    CreateDynamicColorButton(timelinePage, "Bar background color", 180, -280,
        function() return db.timeline.barBackgroundColor end)
    CreateDynamicColorButton(timelinePage, "Bar fill color", 370, -280,
        function() return db.timeline.barFillColor end)

    CreateSlider(timelinePage, "Track thickness", 0, -330, 1, 20, 1,
        function() return db.timeline.trackThickness end,
        function(v) db.timeline.trackThickness = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)
    CreateSlider(timelinePage, "Icon size", 320, -330, 22, 72, 1,
        function() return db.timeline.iconSize end,
        function(v) db.timeline.iconSize = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)

    CreateSlider(timelinePage, "Timeline window (sec)", 0, -394, 5, 60, 1,
        function() return db.timeline.window end,
        function(v) db.timeline.window = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)
    CreateSlider(timelinePage, "Maximum entries", 320, -394, 1, 16, 1,
        function() return db.timeline.maxEntries end,
        function(v) db.timeline.maxEntries = v end, 260)

    CreateSlider(timelinePage, "HUD width", 0, -458, 180, 900, 10,
        function() return db.timeline.width end,
        function(v) db.timeline.width = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)
    CreateSlider(timelinePage, "HUD height", 320, -458, 160, 900, 10,
        function() return db.timeline.height end,
        function(v) db.timeline.height = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)

    CreateSlider(timelinePage, "HUD opacity", 0, -522, 0.15, 1.00, 0.05,
        function() return db.timeline.alpha end,
        function(v) db.timeline.alpha = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end, 260)

    local function TimelineSlider(label, x, y, minValue, maxValue, step, field)
        return CreateSlider(timelinePage, label, x, y, minValue, maxValue, step,
            function() return db.timeline[field] end,
            function(value)
                db.timeline[field] = value
                if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end
            end, 245)
    end
    local function TimelineColor(label, x, y, field)
        return CreateDynamicColorButton(timelinePage, label, x, y,
            function() return db.timeline[field] end)
    end

    local textTitle = timelinePage:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    textTitle:SetPoint("TOPLEFT", 0, -586)
    textTitle:SetText("Timeline Text")

    local textInfo = timelinePage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    textInfo:SetPoint("TOPLEFT", 0, -612)
    textInfo:SetWidth(540)
    textInfo:SetJustifyH("LEFT")
    textInfo:SetText("Lane titles are INTERRUPT / TANK / AOE / DAMAGE / UTILITY / OTHER. Unlock the timeline to drag any lane title or spell name directly.")

    CreateDropdown(timelinePage, "Lane title font (SharedMedia)", 0, -646, 245,
        function() return GetMediaNames("font") end,
        function() return db.timeline.laneLabelFont or "Default" end,
        function(value) db.timeline.laneLabelFont = value; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)
    CreateDropdown(timelinePage, "Spell name font (SharedMedia)", 270, -646, 245,
        function() return GetMediaNames("font") end,
        function() return db.timeline.nameFont or "Default" end,
        function(value) db.timeline.nameFont = value; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)

    TimelineSlider("Lane title size", 0, -706, 6, 40, 1, "laneLabelSize")
    TimelineSlider("Spell name size", 270, -706, 6, 40, 1, "nameTextSize")
    TimelineColor("Lane title color", 0, -762, "laneLabelColor")
    TimelineColor("Spell name color", 270, -762, "nameTextColor")
    TimelineSlider("Lane title X", 0, -818, -400, 400, 1, "laneLabelX")
    TimelineSlider("Spell name X", 270, -818, -400, 400, 1, "nameTextX")
    TimelineSlider("Lane title Y", 0, -874, -400, 400, 1, "laneLabelY")
    TimelineSlider("Spell name Y", 270, -874, -400, 400, 1, "nameTextY")

    local laneTitle = timelinePage:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    laneTitle:SetPoint("TOPLEFT", 0, -936)
    laneTitle:SetText("Category lanes")
    local laneDefs = {
        { "Interrupt / Stop", "INTERRUPT", 0, -964 },
        { "Tank", "TANK", 180, -964 },
        { "AOE / Damage", "AOE_DAMAGE", 320, -964 },
        { "Utility", "UTILITY", 0, -998 },
        { "Other", "OTHER", 180, -998 },
    }
    for _, def in ipairs(laneDefs) do
        local laneLabel, laneKey, laneX, laneY = def[1], def[2], def[3], def[4]
        CreateCheck(timelinePage, laneLabel, laneX, laneY,
            function() return db.timeline.lanes[laneKey] ~= false end,
            function(v) db.timeline.lanes[laneKey] = v end)
    end

    CreateCheck(timelinePage, "Show spell names", 0, -1032,
        function() return db.timeline.showNames ~= false end,
        function(v) db.timeline.showNames = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)
    CreateCheck(timelinePage, "Show countdown text", 260, -1032,
        function() return db.timeline.showTimers ~= false end,
        function(v) db.timeline.showTimers = v; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)

    local previewTimeline = CreateButton(timelinePage, "Test Timeline", 120, function()
        if CT.TimelineHUD then CT.TimelineHUD:Preview() end
    end)
    CT:ApplyClassTabStyle(previewTimeline, false)
    previewTimeline:SetPoint("TOPLEFT", 0, -78)

    local unlockTimeline = CreateButton(timelinePage, "Unlock Timeline", 125, function()
        if CT.TimelineHUD then CT.TimelineHUD:SetUnlocked(true) end
    end)
    CT:ApplyClassTabStyle(unlockTimeline, false)
    unlockTimeline:SetPoint("LEFT", previewTimeline, "RIGHT", 8, 0)

    local lockTimeline = CreateButton(timelinePage, "Lock Timeline", 115, function()
        if CT.TimelineHUD then CT.TimelineHUD:SetUnlocked(false) end
    end)
    CT:ApplyClassTabStyle(lockTimeline, false)
    lockTimeline:SetPoint("LEFT", unlockTimeline, "RIGHT", 8, 0)

    local resetTimeline = CreateButton(timelinePage, "Reset Position", 120, function()
        if CT.TimelineHUD then CT.TimelineHUD:ResetPosition() end
    end)
    CT:ApplyClassTabStyle(resetTimeline, false)
    resetTimeline:SetPoint("LEFT", lockTimeline, "RIGHT", 8, 0)

    local placementTitle = timelinePage:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    placementTitle:SetPoint("TOPLEFT", 0, -1144)
    placementTitle:SetText("Countdown & Text Placement")

    local textAnchorLabel = { ["AUTO"] = "Auto", ["RIGHT"] = "Right of Icon", ["LEFT"] = "Left of Icon", ["ABOVE"] = "Above Icon", ["BELOW"] = "Below Icon" }
    local textAnchorMode = { ["Auto"] = "AUTO", ["Right of Icon"] = "RIGHT", ["Left of Icon"] = "LEFT", ["Above Icon"] = "ABOVE", ["Below Icon"] = "BELOW" }
    CreateDropdown(timelinePage, "Entry text position", 0, -1176, 245,
        function() return { "Auto", "Right of Icon", "Left of Icon", "Above Icon", "Below Icon" } end,
        function() return textAnchorLabel[db.timeline.entryTextAnchor] or "Auto" end,
        function(value)
            db.timeline.entryTextAnchor = textAnchorMode[value] or "AUTO"
            if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end
        end)

    TimelineSlider("Countdown size", 270, -1176, 6, 40, 1, "timerTextSize")
    CreateDropdown(timelinePage, "Countdown font (SharedMedia)", 0, -1234, 245,
        function() return GetMediaNames("font") end,
        function() return db.timeline.timerFont or "Default" end,
        function(value) db.timeline.timerFont = value; if CT.TimelineHUD then CT.TimelineHUD:RefreshLayout() end end)
    TimelineColor("Countdown color", 270, -1234, "timerTextColor")
    TimelineSlider("Countdown X", 0, -1290, -100, 100, 1, "timerTextX")
    TimelineSlider("Countdown Y", 270, -1290, -100, 100, 1, "timerTextY")

    local dataPage = pages[9]
    local dataTitle = dataPage:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    dataTitle:SetPoint("TOPLEFT", 0, 0)
    dataTitle:SetText("Profiles")

    local dataInfo = dataPage:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    dataInfo:SetPoint("TOPLEFT", 0, -36)
    dataInfo:SetWidth(900)
    dataInfo:SetJustifyH("LEFT")
    dataInfo:SetText("ChayAlert HUD settings are per character. Copy From Profile uses account-wide snapshots of characters that have loaded this release, while Import / Export remains available for sharing settings manually.")

    local currentProfile = dataPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    currentProfile:SetPoint("TOPLEFT", 0, -84)
    currentProfile:SetWidth(900)
    currentProfile:SetJustifyH("LEFT")

    local selectedCopyProfile
    local copyProfileDrop = CreateDropdown(dataPage, "Copy From Profile", 0, -116, 360,
        function()
            if CT.ProfileIO and CT.ProfileIO.GetCopyProfileNames then
                return CT.ProfileIO:GetCopyProfileNames()
            end
            return {}
        end,
        function()
            return selectedCopyProfile or "Choose a character profile"
        end,
        function(value)
            selectedCopyProfile = value
        end)

    local copyProfileButton = CreateButton(dataPage, "Copy Profile & Reload", 180, function()
        if not selectedCopyProfile then
            print("|cffff3030ChayAlert HUD|r choose a character profile first.")
            return
        end
        if not (CT.ProfileIO and CT.ProfileIO.CopyFromProfile) then
            print("|cffff3030ChayAlert HUD|r profile copy is unavailable.")
            return
        end
        local ok, message = CT.ProfileIO:CopyFromProfile(selectedCopyProfile)
        if not ok then
            print("|cffff3030ChayAlert HUD|r profile copy failed: " .. tostring(message))
        elseif message then
            print("|cff44ff88ChayAlert HUD|r " .. tostring(message))
        end
    end)
    copyProfileButton:SetPoint("TOPLEFT", 390, -136)

    local copyHint = dataPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    copyHint:SetPoint("TOPLEFT", 0, -188)
    copyHint:SetWidth(900)
    copyHint:SetJustifyH("LEFT")
    copyHint:SetText("A character appears here after ChayAlert HUD has loaded on that character. The snapshot is refreshed on login, reload, and logout. Copying replaces the current character's ChayAlert settings and reloads the UI.")

    local profileHeader = dataPage:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    profileHeader:SetPoint("TOPLEFT", 0, -246)
    profileHeader:SetText("Profile Import / Export")

    local profileInfo = dataPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    profileInfo:SetPoint("TOPLEFT", 0, -276)
    profileInfo:SetWidth(900)
    profileInfo:SetJustifyH("LEFT")
    profileInfo:SetText("Profiles include HUD settings, circle/timeline layouts, sounds, TTS configuration, and per-spell overrides. Export uses a one-line PROFILE3 share string; PROFILE2 and older ChayAlert profiles remain importable. Imported text is parsed as data only; no Lua code is executed.")

    local exportProfile = CreateButton(dataPage, "Export Profile", 160, function()
        if CT.ProfileIO and CT.ProfileIO.ShowExport then CT.ProfileIO:ShowExport() end
    end)
    exportProfile:SetPoint("TOPLEFT", 0, -324)

    local importProfileLabel = dataPage:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    importProfileLabel:SetPoint("TOPLEFT", 190, -324)
    importProfileLabel:SetText("Import profile text")

    local importProfileBox = CreateFrame("Frame", nil, dataPage, "BackdropTemplate")
    importProfileBox:SetPoint("TOPLEFT", 190, -346)
    importProfileBox:SetSize(680, 82)
    importProfileBox:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    importProfileBox:SetBackdropColor(0.02, 0.02, 0.025, 0.95)
    importProfileBox:SetBackdropBorderColor(0.35, 0.35, 0.4, 1)

    local importProfileScroll = CreateFrame("ScrollFrame", nil, importProfileBox, "UIPanelScrollFrameTemplate")
    importProfileScroll:SetPoint("TOPLEFT", 8, -8)
    importProfileScroll:SetPoint("BOTTOMRIGHT", -30, 8)

    local importProfileText = CreateFrame("EditBox", nil, importProfileScroll)
    importProfileText:SetMultiLine(true)
    importProfileText:SetAutoFocus(false)
    importProfileText:SetFontObject(ChatFontNormal)
    importProfileText:SetSize(628, 64)
    importProfileText:SetMaxBytes(0)
    if importProfileText.SetMaxLetters then importProfileText:SetMaxLetters(0) end
    importProfileText:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    importProfileScroll:SetScrollChild(importProfileText)

    local importProfile = CreateButton(dataPage, "Import Profile", 160, function()
        if not (CT.ProfileIO and CT.ProfileIO.ImportText) then return end
        local ok, message = CT.ProfileIO:ImportText(importProfileText:GetText() or "")
        if not ok then
            print("|cffff3030ChayAlert HUD|r profile import failed: " .. tostring(message))
        elseif message then
            print("|cff44ff88ChayAlert HUD|r " .. tostring(message))
        end
    end)
    importProfile:SetPoint("TOPLEFT", 0, -440)

    local dataHint = dataPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    dataHint:SetPoint("TOPLEFT", 0, -488)
    dataHint:SetWidth(900)
    dataHint:SetJustifyH("LEFT")
    dataHint:SetText("Copy From Profile and text import copy only user settings. Runtime combat state, timers, and temporary encounter data are never stored in a profile.")

    dataPage:SetScript("OnShow", function()
        if CT.ProfileIO and CT.ProfileIO.SnapshotCurrentCharacter then
            CT.ProfileIO:SnapshotCurrentCharacter()
        end
        if CT.ProfileIO and CT.ProfileIO.GetCurrentProfileName then
            currentProfile:SetText("Current character profile: " .. tostring(CT.ProfileIO:GetCurrentProfileName() or "Unknown"))
        else
            currentProfile:SetText("Current character profile: Unknown")
        end
        selectedCopyProfile = nil
        copyProfileDrop:Refresh()
    end)

    ShowPage(db.optionsTab or 1)
end

function CT:OpenOptions()
    BuildOptions()
    options:Show()
end

function CT:ToggleOptions()
    BuildOptions()
    options:SetShown(not options:IsShown())
end

function CT:UpdateMinimapButton()
    if minimapButton and db then minimapButton:SetShown(db.showMinimap == true) end
end

local function CreateMinimapButton()
    if minimapButton then return end
    minimapButton = CreateFrame("Button", "ChayAlertHUDMinimapButton", Minimap)
    minimapButton:SetSize(32, 32)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel(Minimap:GetFrameLevel() + 8)
    if type(db.minimapX) == "number" and type(db.minimapY) == "number" then
        minimapButton:SetPoint("CENTER", Minimap, "CENTER", db.minimapX, db.minimapY)
    else
        minimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -4, 4)
    end
    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    minimapButton:RegisterForDrag("LeftButton")

    local border = minimapButton:CreateTexture(nil, "BACKGROUND")
    border:SetAllPoints()
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    local icon = minimapButton:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture(MINIMAP_ICON)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    minimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton:SetScript("OnClick", function() CT:ToggleOptions() end)
    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("ChayAlert HUD", 1, 0.2, 0.2)
        GameTooltip:AddLine("Left click: Options", 1, 1, 1)
        GameTooltip:AddLine("Drag: Move icon", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("/ct status: timer status", 0.65, 0.65, 0.65)
        GameTooltip:Show()
    end)
    minimapButton:SetScript("OnLeave", GameTooltip_Hide)
    minimapButton:SetScript("OnDragStart", function(self) self:SetMovable(true); self:StartMoving() end)
    minimapButton:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        local mx, my = Minimap:GetCenter()
        if x and y and mx and my then
            db.minimapX = x - mx
            db.minimapY = y - my
            self:ClearAllPoints()
            self:SetPoint("CENTER", Minimap, "CENTER", db.minimapX, db.minimapY)
        end
    end)
    CT:UpdateMinimapButton()
end

SLASH_CHAYALERTHUD1 = "/chayalert"
SLASH_CHAYALERTHUD2 = "/cah"
SLASH_CHAYALERTHUD3 = "/ct"
SLASH_CHAYALERTHUD4 = "/chaytracker"
SlashCmdList.CHAYALERTHUD = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if msg == "test" then CT:StartTest(false)
    elseif msg == "test heavy" then CT:StartTestHeavy()
    elseif msg == "stop" then CT:StopTest()
    elseif msg == "unlock" then CT:SetUnlocked(true)
    elseif msg == "lock" then CT:SetUnlocked(false)
    elseif msg == "reset" then
        for i = 1, MAX_CIRCLES do db.circles[i] = CircleDefaults(i) end
        CT:LayoutAlerts()
    elseif msg == "minimap" then
        db.showMinimap = not db.showMinimap
        CT:UpdateMinimapButton()
    elseif msg == "profile export" then
        if CT.ProfileIO and CT.ProfileIO.ShowExport then CT.ProfileIO:ShowExport() end
    elseif msg == "profile import" then
        if CT.ProfileIO and CT.ProfileIO.ShowImport then CT.ProfileIO:ShowImport() end
    elseif msg == "status" then
        local bossActive, trashActive, pending = 0, 0, 0
        local bossNames, trashNames = {}, {}

        for _, runtime in pairs(timelineRuntime) do
            if runtime.state == STATE_ACTIVE then
                bossActive = bossActive + 1
                if type(runtime.name) == "string" then
                    bossNames[#bossNames + 1] = runtime.name
                end
            end
        end

        for _, cast in pairs(trashCasts) do
            trashActive = trashActive + 1
            if type(cast.name) == "string" then
                trashNames[#trashNames + 1] = cast.name
            end
        end

        for _ in pairs(timelinePending) do pending = pending + 1 end

        print(string.format(
            "|cffff3030ChayAlert HUD|r status: enabled=%s instance=%s timeline=%s boss=%d pending=%d trash=%d",
            tostring(db.enabled),
            tostring(IsInSupportedInstance()),
            tostring(TimelineFeatureAvailable()),
            bossActive,
            pending,
            trashActive
        ))

        if #bossNames > 0 then
            print("|cffffaa33Boss names:|r " .. table.concat(bossNames, ", "))
        end
        if #trashNames > 0 then
            print("|cff55ff55Trash names:|r " .. table.concat(trashNames, ", "))
        end
    else CT:ToggleOptions() end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_LOGOUT")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
events:RegisterEvent("ENCOUNTER_TIMELINE_EVENT_ADDED")
events:RegisterEvent("ENCOUNTER_TIMELINE_EVENT_BLOCK_STATE_CHANGED")
events:RegisterEvent("ENCOUNTER_TIMELINE_EVENT_STATE_CHANGED")
events:RegisterEvent("ENCOUNTER_TIMELINE_EVENT_REMOVED")
events:RegisterEvent("ENCOUNTER_TIMELINE_STATE_UPDATED")
events:RegisterEvent("ENCOUNTER_TIMELINE_VIEW_ACTIVATED")
events:RegisterEvent("ENCOUNTER_TIMELINE_VIEW_DEACTIVATED")
events:RegisterEvent("ENCOUNTER_START")
events:RegisterEvent("ENCOUNTER_END")
events:RegisterEvent("CHALLENGE_MODE_COMPLETED")
events:RegisterEvent("NAME_PLATE_UNIT_ADDED")
events:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
events:RegisterEvent("SPELL_DATA_LOAD_RESULT")
-- Use a Midnight-safe common-trash architecture: listen to
-- spellcast events globally, then accept only public nameplate unit tokens.
-- Per-nameplate watchers remain useful for scanning a cast already in progress,
-- but are not the sole source of live trash cast starts.
for _, eventName in ipairs(NAMEPLATE_CAST_EVENTS) do
    events:RegisterEvent(eventName)
end
events:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        -- One-time namespace migration from ChayTracker. The legacy SavedVariable
        -- remains declared so existing per-character
        -- settings can be carried forward without forcing users to reconfigure.
        if type(ChayAlertHUDDB) ~= "table" and type(ChayTrackerDB) == "table" then
            ChayAlertHUDDB = ChayTrackerDB
        end
        ChayAlertHUDDB = ChayAlertHUDDB or {}
        db = ChayAlertHUDDB
        -- Remove development-only capture state from older dev builds.
        db.learningCaptureEnabled = nil
        db.learningCaptureMode = nil
        db.learningData = nil
        DeepCopyDefaults(defaults, db)
        if db.tankSwapVoice ~= "FOLLOW_TTS" and db.tankSwapVoice ~= "ZIRA" and db.tankSwapVoice ~= "DAVID" then
            db.tankSwapVoice = defaults.tankSwapVoice
        end
        local voiceSettingsVersion = tonumber(db.voiceSettingsVersion) or 0
        if voiceSettingsVersion < 1 then
            if db.tankSwapVoice == "AUTO" then
                db.tankSwapVoice = "FOLLOW_TTS"
            end
            voiceSettingsVersion = 1
        end
        if voiceSettingsVersion < 2 then
            -- 0.9.13 removes the dead voice-source selector and guarantees that
            -- every dynamic spoken mechanic uses the selected WoW TTS voice.
            -- Preserve a stable Zira/David preference across voice-ID changes.
            db.voicePackSource = "NATIVE_TTS"
            if db.ttsVoiceKey ~= "ZIRA" and db.ttsVoiceKey ~= "DAVID" then
                db.ttsVoiceKey = nil
            end
            voiceSettingsVersion = 2
        end
        if voiceSettingsVersion < 3 then
            -- 0.9.20 normal mechanic TTS speaks the resolved ability name only.
            -- Keep explicit Custom mode, but retire action/category-prefixed modes.
            if db.ttsPhraseMode ~= "CUSTOM" then
                db.ttsPhraseMode = "ABILITY_ONLY"
            end
            voiceSettingsVersion = 3
        end
        db.voiceSettingsVersion = voiceSettingsVersion
        if type(db.ttsVolume) ~= "number" then
            db.ttsVolume = defaults.ttsVolume
        elseif db.ttsVolume >= 0 and db.ttsVolume <= 1 then
            db.ttsVolume = db.ttsVolume * 100
        end
        db.ttsVolume = math.max(0, math.min(100, math.floor(db.ttsVolume + 0.5)))

        -- Normalize the new renderer settings after migrating older profiles.
        db.displayMode = NormalizeDisplayMode(db.displayMode, false)
        if type(db.timeline) ~= "table" then db.timeline = {} end
        DeepCopyDefaults(defaults.timeline, db.timeline)
        db.timeline.orientation = db.timeline.orientation == "HORIZONTAL" and "HORIZONTAL" or "VERTICAL"
        db.timeline.layout = db.timeline.layout == "LANES" and "LANES" or "SINGLE"
        if db.timeline.trackTexture == "Blizzard Dialog Background" or db.timeline.trackTexture == "Blizzard Tooltip" then
            db.timeline.trackTexture = "Solid"
        end
        if type(db.timeline.lanes) ~= "table" then db.timeline.lanes = {} end
        DeepCopyDefaults(defaults.timeline.lanes, db.timeline.lanes)

        -- 3.0.8 moved the old top tabs into a left sidebar and split Tracker
        -- Options away from the circle editor. Migrate only the last selected
        -- page; 3.0.9 deliberately preserves the user's saved width/height so
        -- the GUI can remain thin, wide, tall, or short.
        local sidebarVersion = tonumber(db.sidebarLayoutVersion) or 0
        if sidebarVersion < 1 then
            local oldTab = tonumber(db.optionsTab)
            if oldTab and oldTab >= 2 and oldTab <= 6 then
                db.optionsTab = oldTab + 1
            end
            sidebarVersion = 1
        end
        if sidebarVersion < 2 then
            -- Historical sidebar migration: Mini Timeline shifted the old last page.
            if tonumber(db.optionsTab) == 8 then
                db.optionsTab = 9
            end
            sidebarVersion = 2
        end
        if sidebarVersion < 3 then
            -- Historical sidebar migration: Profiles & Data shifted the old last page.
            if tonumber(db.optionsTab) == 9 then
                db.optionsTab = 10
            end
            sidebarVersion = 3
        end
        if sidebarVersion < 4 then
            -- Release layout removes the former development-only last page and
            -- keeps Profiles as a normal user-facing section.
            local savedTab = tonumber(db.optionsTab)
            if savedTab == 9 or savedTab == 10 then
                db.optionsTab = 8
            end
            sidebarVersion = 4
        end
        db.sidebarLayoutVersion = sidebarVersion
        if type(db.optionsTab) ~= "number" or db.optionsTab < 1 or db.optionsTab > 8 then
            db.optionsTab = 1
        end

        -- Do not write global Blizzard CVars here. ChayAlertHUD must never alter
        -- party/raid-frame or other account-wide UI behavior.


        -- Migrate settings from the 1.1.x audio model without discarding user positions.
        if type(db.allSoundSelectionsNone) ~= "boolean" then db.allSoundSelectionsNone = false end
        if type(db.alertSound) ~= "string" then db.alertSound = defaults.alertSound end
        if type(db.urgentSound) ~= "string" then db.urgentSound = defaults.urgentSound end
        if type(db.beepSound) ~= "string" then db.beepSound = defaults.beepSound end
        if db.alertSound == "ChayTracker Alert" or db.alertSound == "ChayAlertHUD Alert" then db.alertSound = "ChayAlert HUD Alert" end
        if db.urgentSound == "ChayTracker Urgent" or db.urgentSound == "ChayAlertHUD Urgent" then db.urgentSound = "ChayAlert HUD Urgent" end
        if db.beepSound == "ChayTracker Beep" or db.beepSound == "ChayAlertHUD Beep" then db.beepSound = "ChayAlert HUD Beep" end
        if type(db.playUrgentSound) ~= "boolean" then db.playUrgentSound = defaults.playUrgentSound end
        if type(db.optionsWidth) ~= "number" or db.optionsWidth < 820 then db.optionsWidth = defaults.optionsWidth end
        if type(db.optionsHeight) ~= "number" or db.optionsHeight < 520 then db.optionsHeight = defaults.optionsHeight end
        db.optionsWidth = math.min(1700, db.optionsWidth)
        db.optionsHeight = math.min(1200, db.optionsHeight)
        db.ringBackgroundAlpha = math.max(0, math.min(1, tonumber(db.ringBackgroundAlpha) or defaults.ringBackgroundAlpha))
        if type(db.mutedSpells) ~= "table" then db.mutedSpells = {} end
        if type(db.trackedSpells) ~= "table" then db.trackedSpells = {} end
        if type(db.trackOnlyCustom) ~= "boolean" then db.trackOnlyCustom = false end
        if type(db.trashCastsEnabled) ~= "boolean" then db.trashCastsEnabled = true end
        if type(db.importantAurasEnabled) ~= "boolean" then db.importantAurasEnabled = true end
        if type(db.suppressTrashDuringBoss) ~= "boolean" then db.suppressTrashDuringBoss = true end
        if type(db.showTrashMobName) ~= "boolean" then db.showTrashMobName = true end
        if type(db.trackUnknownTrash) ~= "boolean" then db.trackUnknownTrash = false end
        if type(db.trackUnknownBossTimeline) ~= "boolean" then db.trackUnknownBossTimeline = false end
        if type(db.showOptionalAbilities) ~= "boolean" then db.showOptionalAbilities = false end
        if not VALID_ROLE_PROFILES[db.roleProfile] then db.roleProfile = "AUTO" end
        if tonumber(db.recommendationDefaultsVersion) ~= 2 then
            -- Version 2 narrows automatic tracking to important mechanics for
            -- the active role. Existing per-ability overrides are preserved.
            db.trackUnknownTrash = false
            db.trackUnknownBossTimeline = false
            db.showOptionalAbilities = false
            db.recommendationDefaultsVersion = 2
        end
        if type(db.mobAbilityOverrides) ~= "table" then db.mobAbilityOverrides = {} end
        if type(db.bossAbilityOverrides) ~= "table" then db.bossAbilityOverrides = {} end
        if type(db.raidAbilityOverrides) ~= "table" then db.raidAbilityOverrides = {} end
        db.trashMinCastTime = math.max(0.5, math.min(5, tonumber(db.trashMinCastTime) or 1.5))
        db.maxAlerts = math.max(1, math.min(3, tonumber(db.maxAlerts) or defaults.maxAlerts))
        for i = 1, MAX_CIRCLES do
            local circle = db.circles[i]
            circle.alpha = math.max(0.02, math.min(1, tonumber(circle.alpha) or 1))
        end
        db.soundChoice = nil

        CT:LayoutAlerts()
        CreateMinimapButton()
        CT:RefreshTrackingState()
        if CT.ProfileIO and CT.ProfileIO.SnapshotCurrentCharacter then
            CT.ProfileIO:SnapshotCurrentCharacter()
        end
        print("|cffff3030ChayAlert HUD|r loaded. Type |cffffffff/cah|r for options. |cffaaaaaa(/ct also works)|r")
    elseif event == "PLAYER_LOGOUT" then
        if CT.ProfileIO and CT.ProfileIO.SnapshotCurrentCharacter then
            CT.ProfileIO:SnapshotCurrentCharacter()
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        if not unlockMode then CT:StopTest() end
        wipe(timelineMeta)
        wipe(timelineRuntime)
        wipe(timelinePending)
        wipe(trashCasts)
        wipe(trashRetryToken)
        wipe(trashSpellResolutionCache)
        ResetNameplateCastWatchers()
        currentEncounterID = nil
        RecoverTimelineEvents()
        CT:RefreshTrackingState()
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(0, function()
                if CT.RehydrateNameplateCastWatchers then
                    CT:RehydrateNameplateCastWatchers()
                end
            end)
        elseif CT.RehydrateNameplateCastWatchers then
            CT:RehydrateNameplateCastWatchers()
        end
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        -- One-shot watcher rebinding for phasing/zone transitions. No polling.
        wipe(trashCasts)
        wipe(trashRetryToken)
        ResetNameplateCastWatchers()
        UpdateLiveAlerts()
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(0, function()
                if CT.RehydrateNameplateCastWatchers then
                    CT:RehydrateNameplateCastWatchers()
                end
            end)
        elseif CT.RehydrateNameplateCastWatchers then
            CT:RehydrateNameplateCastWatchers()
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        StopTestForLiveCombat()
        CT:RefreshTrackingState()
    elseif event == "PLAYER_REGEN_ENABLED" then
        CT:RefreshTrackingState()
        if CT.RefreshAuraContainerLayout then CT:RefreshAuraContainerLayout() end
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        local unit = select(1, ...)
        if (unit == nil or unit == "player") and db and db.roleProfile == "AUTO" then
            wipe(trashCasts)
            wipe(trashRetryToken)
            UpdateLiveAlerts()
            if CT.RefreshDungeonMobPage then CT:RefreshDungeonMobPage() end
            if CT.RefreshDungeonBossPage then CT:RefreshDungeonBossPage() end
            if CT.RefreshRaidPage then CT:RefreshRaidPage() end
        end
    elseif event == "ENCOUNTER_START" then
        StopTestForLiveCombat()
        currentEncounterID = select(1, ...)
        wipe(timelineMeta)
        wipe(timelineRuntime)
        wipe(timelinePending)
        wipe(trashCasts)
        wipe(trashRetryToken)
        RecoverTimelineEvents()
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_EVENT_ADDED" then
        local eventInfo = select(1, ...)
        QueueTimelineAdded(eventInfo)
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_EVENT_STATE_CHANGED" then
        local eventID = select(1, ...)
        SyncTimelineState(eventID)
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_EVENT_BLOCK_STATE_CHANGED" then
        local eventID = SafeNumber(select(1, ...))
        if eventID then
            local blocked = false
            if C_EncounterTimeline and C_EncounterTimeline.IsEventBlocked then
                local ok, value = pcall(C_EncounterTimeline.IsEventBlocked, eventID)
                blocked = ok and not IsSecret(value) and value == true
            end
            if blocked then
                timelinePending[eventID] = nil
                timelineRuntime[eventID] = nil
            else
                SyncTimelineState(eventID)
            end
        end
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_EVENT_REMOVED" then
        local eventID = select(1, ...)
        RemoveTimelineEvent(eventID)
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_STATE_UPDATED" then
        RecoverTimelineEvents()
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_VIEW_ACTIVATED" then
        -- Blizzard fires this after the new view has completed its data/layout
        -- update, so queries can be used immediately.
        wipe(timelineMeta)
        wipe(timelineRuntime)
        wipe(timelinePending)
        RecoverTimelineEvents()
        CT:RefreshTrackingState()
    elseif event == "ENCOUNTER_TIMELINE_VIEW_DEACTIVATED" then
        -- Blizzard explicitly requires timeline consumers to discard all
        -- stored timeline event data when the current view is deactivated.
        wipe(timelineMeta)
        wipe(timelineRuntime)
        wipe(timelinePending)
        if not testMode and not next(trashCasts) then
            driver:Hide()
            for _, f in ipairs(activeSlots) do f:Hide() end
        end
        CT:RefreshTrackingState()
    elseif event == "UNIT_SPELLCAST_START"
        or event == "UNIT_SPELLCAST_CHANNEL_START"
        or event == "UNIT_SPELLCAST_DELAYED"
        or event == "UNIT_SPELLCAST_CHANNEL_UPDATE"
        or event == "UNIT_SPELLCAST_SUCCEEDED"
        or event == "UNIT_SPELLCAST_STOP"
        or event == "UNIT_SPELLCAST_CHANNEL_STOP"
        or event == "UNIT_SPELLCAST_INTERRUPTED"
        or event == "UNIT_SPELLCAST_FAILED"
        or event == "UNIT_SPELLCAST_FAILED_QUIET" then
        local rawUnit, castGUID, spellID, fourth, fifth = ...
        local castBarID
        if event == "UNIT_SPELLCAST_CHANNEL_STOP" or event == "UNIT_SPELLCAST_INTERRUPTED" then
            castBarID = fifth
        else
            castBarID = fourth
        end
        local unit

        if not IsSecret(rawUnit) and IsNameplateUnit(rawUnit) then
            unit = rawUnit
            if not nameplateCastWatchers[unit] or nameplateCastWatchers[unit].unitToken ~= unit then
                -- A cast can race NAME_PLATE_UNIT_ADDED. Own the public token
                -- immediately, but do not scan because this event is already
                -- the authoritative cast notification.
                AttachNameplateCastWatcher(unit, true)
            end
        elseif not IsSecret(castBarID) and castBarID ~= nil then
            -- Restricted hostile events can hide unitTarget/spellID, but
            -- Blizzard guarantees castBarID is public. Resolve that ID against
            -- the public nameplate tokens captured by NAME_PLATE_UNIT_ADDED.
            local isChannelEvent = event == "UNIT_SPELLCAST_CHANNEL_START"
                or event == "UNIT_SPELLCAST_CHANNEL_UPDATE"
                or event == "UNIT_SPELLCAST_CHANNEL_STOP"
            if event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_CHANNEL_START"
                or event == "UNIT_SPELLCAST_DELAYED" or event == "UNIT_SPELLCAST_CHANNEL_UPDATE" then
                unit = FindNameplateByCastBarID(castBarID, isChannelEvent)
            else
                -- At STOP/FAILED time UnitCastingInfo may already be gone, so
                -- resolve against the cast we previously armed.
                unit = FindTrackedTrashByCastBarID(castBarID)
            end
        end

        if unit then
            local watcher = nameplateCastWatchers[unit]
            if watcher then
                -- Always process the global fast path too. StartTrashCast uses
                -- castBarID to dedupe a duplicate delivery from RegisterUnitEvent.
                NameplateCastWatcher_OnEvent(watcher, event, ...)
            end
        end
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        local unit = select(1, ...)
        if IsNameplateUnit(unit) then
            AttachNameplateCastWatcher(unit)
        end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        local unit = select(1, ...)
        if IsNameplateUnit(unit) then
            DetachNameplateCastWatcher(unit)
            trashRetryToken[unit] = nil
            RemoveTrashCast(unit)
            UpdateLiveAlerts()
        end
    elseif event == "SPELL_DATA_LOAD_RESULT" then
        wipe(importantSpellCache)
        wipe(trashSpellResolutionCache)
        if CT.RefreshDungeonMobPage then CT:RefreshDungeonMobPage() end
        if CT.RefreshDungeonBossPage then CT:RefreshDungeonBossPage() end
        if CT.RefreshRaidPage then CT:RefreshRaidPage() end
        if CT.RefreshSpellLists then CT:RefreshSpellLists() end
    elseif event == "ENCOUNTER_END" or event == "CHALLENGE_MODE_COMPLETED" then
        if event == "ENCOUNTER_END" then currentEncounterID = nil end
        wipe(timelineMeta)
        wipe(timelineRuntime)
        wipe(timelinePending)
        wipe(trashCasts)
        wipe(trashRetryToken)
        if not testMode then
            driver:Hide()
            for _, f in ipairs(activeSlots) do f:Hide() end
        end
    else
        CT:RefreshTrackingState()
    end
end)


