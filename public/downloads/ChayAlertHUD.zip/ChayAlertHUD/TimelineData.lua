-- ChayAlert HUD TimelineData.lua
-- Secret-safe encounter timeline duration fingerprints for Retail Midnight 12.1.
-- Only unambiguous fingerprints used by the role-important mechanic resolver
-- are retained. Ambiguous duration signatures are deliberately omitted.

local data = {
    version = "2026-08-19-role-important-v1",
    encounters = {
        [2124] = {
            zero = {
                [1] = 1289059,
                [12] = 1311805,
                [25] = 1311805,
                [29] = 1311805,
            },
        },
        [2125] = {
            zero = {
                [27] = 1293048,
                [36] = 1293048,
                [43] = 264172,
                [49] = 264172,
            },
        },
        [2126] = {
            zero = {
                [20] = 1309525,
            },
        },
        [2127] = {
            zero = {
                [15] = 1301202,
            },
        },
        [2139] = {
            zero = {
                [5] = 265773,
                [8] = 265910,
                [14] = 265781,
                [28] = 265781,
            },
        },
        [2140] = {
            zero = {
                [2] = 1305810,
                [7] = 1305810,
                [8] = 266206,
                [14] = 266237,
                [22] = 266237,
            },
            one = {
                [14.8] = 266206,
            },
        },
        [2142] = {
            zero = {
                [20] = 1311956,
            },
        },
        [2143] = {
            zero = {
                [8] = 269230,
                [14] = 269369,
                [23] = 268586,
                [27] = 269369,
                [28] = 269230,
                [36] = 1303488,
                [38] = 268586,
            },
        },
        [2606] = {
            zero = {
                [19] = 372110,
                [20] = 372110,
                [28] = 372858,
            },
        },
        [2609] = {
            zero = {
                [5] = 1307297,
            },
        },
        [2623] = {
            zero = {
                [1] = 381525,
                [5] = 381512,
                [9] = 381862,
                [12] = 381862,
                [21] = 381516,
                [25] = 381516,
            },
            one = {
                [22.5] = 381512,
            },
        },
        [3101] = {
            zero = {
                [8] = 1253811,
                [12] = 474240,
                [25] = 474240,
            },
            one = {
                [27.5] = 1253811,
            },
        },
        [3102] = {
            zero = {
                [18] = 1214357,
                [36] = 1218347,
            },
        },
        [3103] = {
            zero = {
                [15] = 1214637,
                [30] = 1295453,
            },
        },
        [3105] = {
            zero = {
                [15] = 1218203,
                [24] = 1224478,
                [55] = 1218203,
                [59] = 1224478,
            },
        },
        [3199] = {
            zero = {
                [20] = 1234850,
            },
        },
        [3200] = {
            zero = {
                [40] = 1237090,
                [50] = 1237090,
            },
        },
        [3201] = {
            zero = {
                [5] = 1239824,
                [9] = 1240210,
                [18] = 1240098,
            },
            one = {
                [7.3] = 1239824,
                [23.3] = 1240098,
                [31.3] = 1240210,
            },
        },
        [3202] = {
            zero = {
                [32] = 1246607,
                [40] = 1246607,
            },
        },
        [3207] = {
            zero = {
                [16] = 1253268,
            },
        },
        [3208] = {
            zero = {
                [25] = 1235783,
            },
        },
        [3209] = {
            zero = {
                [13] = 1243569,
            },
        },
        [3285] = {
            zero = {
                [6] = 1222098,
                [16] = 1296963,
            },
        },
        [3286] = {
            zero = {
                [15] = 1222721,
                [30] = 1222721,
                [35] = 1262497,
            },
        },
        [3287] = {
            zero = {
                [17] = 1227264,
                [34] = 1311923,
                [43] = 1222755,
            },
        },
        [3379] = {
            -- Nymrissa Wavecaller. Current 12.1 data uses the same protected
            -- timeline durations for different tank abilities by difficulty:
            -- Iceblade Flurry on Normal/Heroic and Water Jet on Mythic. Keep
            -- those fingerprints difficulty-scoped so a secret spell identity
            -- can never be resolved to the wrong tank mechanic.
            byDifficulty = {
                [14] = { zero = { [9] = 1282937, [22] = 1282937, [27] = 1282937 } },
                [15] = { zero = { [9] = 1282937, [22] = 1282937, [27] = 1282937 } },
                [16] = { zero = { [9] = 1268562, [22] = 1268562, [27] = 1268562 } },
                [17] = { zero = { [9] = 1282937, [22] = 1282937, [27] = 1282937 } },
            },
        },
        [3420] = {
            zero = {
                [5] = 1277025,
                [6] = 1277025,
                [29] = 1305959,
                [32] = 1305959,
                [36] = 1305959,
            },
        },
        [3421] = {
            zero = {
                [9] = 1289192,
                [18] = 1288538,
                [20] = 1288538,
                [22] = 1288538,
                [23] = 1288538,
                [40] = 1290809,
                [44] = 1290809,
                [47] = 1290956,
                [50] = 1290809,
                [52] = 1290956,
                [57] = 1290516,
                [59] = 1290956,
                [63] = 1290516,
                [71] = 1290516,
            },
        },
        [3429] = {
            zero = {
                [12] = 1283832,
                [35] = 1282281,
                [66] = 1286918,
                [70] = 1286918,
                [85] = 1282487,
                [87] = 1286918,
                [91] = 1298381,
                [92] = 1298381,
            },
        },
        [3445] = {
            zero = {
                [4] = 1284458,
                [6] = 1284487,
                [12] = 1284434,
                [32] = 1284434,
            },
        },
        [3455] = {
            zero = {
                [6] = 1282525,
                [8] = 1280935,
                [11] = 1280935,
                [22] = 1280935,
                [44] = 1282525,
            },
        },
        [3456] = {
            zero = {
                [8] = 1296220,
                [13] = 1296050,
                [23] = 1307894,
                [24] = 1296220,
            },
        },
        [3457] = {
            zero = {
                [7] = 1298949,
                [16] = 1298949,
                [44] = 1299053,
                [53] = 1299053,
            },
        },
        [3458] = {
            zero = {
                [26] = 1301350,
                [30] = 1301350,
                [32] = 1301413,
            },
        },
        [3470] = {
            zero = {
                [6] = 1299673,
                [8] = 1299673,
                [48] = 1299673,
            },
        },
        [3492] = {
            -- No verified Mythic duration dispatch data is available for this entry.
            -- for Ula'tek. Never apply Easy/Heroic fingerprints on Mythic.
            difficulties = { [14] = true, [15] = true, [17] = true },
            zero = {
                -- Ula'tek. Keep only duration fingerprints that are
                -- unambiguous across the current Easy/Heroic phase handlers.
                -- Ambiguous values (for example 10, 37, 40, 50, 52, 60,
                -- 61, 62, 65, 66, and 67) stay intentionally unresolved.
                [20] = 1300530, -- Spectral Coils
                [25] = 1295905, -- Serpent's Bite
                [35] = 1296301, -- Mephitic Thrash
                [41] = 1296301, -- Mephitic Thrash
                [42] = 1292188, -- Caustic Waves
                [44] = 1292188, -- Caustic Waves
                [45] = 1300751, -- Call of the Serpent
                [51] = 1301510, -- Circling Prey
                [53] = 1292999, -- Submerge
                [55] = 1292188, -- Caustic Waves
                [57] = 1292999, -- Submerge
                [63] = 1300751, -- Call of the Serpent
                [70] = 1298559, -- Gore Rattle
                [71] = 1295905, -- Serpent's Bite
                [72] = 1300751, -- Call of the Serpent
                [75] = 1298367, -- Mother's Wrath
                [76] = 1298367, -- Mother's Wrath
                [84] = 1300530, -- Spectral Coils
                [86] = 1298367, -- Mother's Wrath
                [94] = 1300530, -- Spectral Coils
                [95] = 1300530, -- Spectral Coils
                [118] = 1286860, -- Rage of the Shackled
                [129] = 1286860, -- Rage of the Shackled
                [130] = 1286860, -- Rage of the Shackled
                [200] = 1286860, -- Rage of the Shackled
                [205] = 1286860, -- Rage of the Shackled
                [230] = 1286905, -- Fury Unleashed
                [235] = 1286905, -- Fury Unleashed
            },
        },
        [3497] = {
            zero = {
                [15] = 1291759,
                [17] = 1291759,
                [18] = 1291759,
                [30] = 1295854,
                [60] = 1292779,
            },
        },
    },
}

_G.ChayAlertHUDTimelineData = data
