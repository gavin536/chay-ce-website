-- ChayAlertHUD TrashRuntime.lua
-- Midnight 12.1 protected-trash observation/inference layer.
-- Architecture: public castBarID + nameplate runtime state + static cast model.
-- Detection stays independent from the circle and timeline presentation layers.

local CT = _G.ChayAlertHUD
local RuntimeData = _G.ChayAlertHUDTrashRuntimeData
if type(CT) ~= "table" or type(RuntimeData) ~= "table" then return end

local states = {}
local RETRY_DELAY = 0.10
local PREDICTION_WINDOW = 6.0
local PREDICTION_MARGIN = 0.75
local CAST_TO_CHANNEL_WINDOW = 0.45
local HISTORY_LIMIT = 12

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value) or false
end

local function SafeNumber(value)
    if IsSecret(value) then return nil end
    return tonumber(value)
end

local function IsNameplateUnit(unit)
    return not IsSecret(unit)
        and type(unit) == "string"
        and unit:match("^nameplate%d+$") ~= nil
end

local function SafeUnitExists(unit)
    if type(UnitExists) ~= "function" then return true end
    local ok, value = pcall(UnitExists, unit)
    if not ok or IsSecret(value) then return true end
    return value == true
end

local function SafeUnitName(unit)
    if type(UnitName) ~= "function" then return nil end
    local ok, value = pcall(UnitName, unit)
    if ok and not IsSecret(value) and type(value) == "string" and value ~= "" then
        return value
    end
    return nil
end

local function SafeUnitLevel(unit)
    if type(UnitLevel) ~= "function" then return nil end
    local ok, value = pcall(UnitLevel, unit)
    if ok and not IsSecret(value) and type(value) == "number" then
        return value
    end
    return nil
end

local function SafeUnitPowerType(unit)
    if type(UnitPowerType) ~= "function" then return nil end
    local ok, value = pcall(UnitPowerType, unit)
    if ok and not IsSecret(value) and type(value) == "number" then
        return value
    end
    return nil
end

local function SafeUnitInCombat(unit)
    if type(UnitAffectingCombat) ~= "function" then return nil end
    local ok, value = pcall(UnitAffectingCombat, unit)
    if ok and not IsSecret(value) and type(value) == "boolean" then
        return value
    end
    return nil
end

local function SafeTargetAPIExists(unit)
    if type(UnitShouldDisplaySpellTargetName) ~= "function" then return nil end
    local ok, value = pcall(UnitShouldDisplaySpellTargetName, unit)
    if ok and not IsSecret(value) and type(value) == "boolean" then
        return value
    end
    return nil
end

local function SafeCreatureID(unit)
    if type(UnitCreatureID) == "function" then
        local ok, value = pcall(UnitCreatureID, unit)
        if ok and not IsSecret(value) then
            local npcID = tonumber(value)
            if npcID and npcID > 0 then return npcID, "unit_api" end
        end
    end

    -- Independent fallback: if the unit GUID itself is public, its creature ID
    -- component is factual Blizzard unit identity data. Never parse a secret GUID.
    if type(UnitGUID) == "function" then
        local ok, guid = pcall(UnitGUID, unit)
        if ok and not IsSecret(guid) and type(guid) == "string" then
            local _, _, _, _, _, rawNPCID = strsplit("-", guid)
            local npcID = tonumber(rawNPCID)
            if npcID and npcID > 0 then return npcID, "unit_guid" end
        end
    end
    return nil
end

local function CurrentDungeonKey()
    if type(CT.GetCurrentDungeonKey) ~= "function" then return nil end
    local key = CT:GetCurrentDungeonKey()
    return type(key) == "string" and key or nil
end

local function GetDungeonModel(dungeonKey)
    return RuntimeData.GetDungeon and RuntimeData:GetDungeon(dungeonKey) or nil
end

local function GetCatalogDungeon(dungeonKey)
    local catalog = type(CT.GetDungeonData) == "function" and CT:GetDungeonData() or nil
    return catalog and catalog.dungeons and catalog.dungeons[dungeonKey] or nil
end

local function BuildCatalogPublicSpellCandidates(state, spellID)
    local dungeon = GetCatalogDungeon(state.dungeonKey)
    if not dungeon or type(dungeon.mobs) ~= "table" then return {} end

    local rows = {}
    for _, mob in ipairs(dungeon.mobs) do
        local spell
        if type(mob.spellByID) == "table" then
            spell = mob.spellByID[spellID]
        else
            for _, candidate in ipairs(mob.spells or {}) do
                if SafeNumber(candidate.id) == spellID then
                    spell = candidate
                    break
                end
            end
        end
        if spell then
            rows[#rows + 1] = {
                npcID = SafeNumber(mob.npcID),
                spellID = spellID,
                spell = spell,
                kept = true,
                evidenceScore = 100,
            }
        end
    end
    return rows
end

local function ResetCombatState(state)
    state.inCombat = false
    state.combatStartedAt = nil
    state.castCount = 0
    state.activeCastBarID = nil
    state.activeKind = nil
    state.activeSpellID = nil
    state.activeNPCID = nil
    state.activeRecord = nil
    state.previousRecord = nil
    state.castHistory = {}
    state.nextSpellStartAt = {}
    state.cdIndex = {}
end

local function GetState(unit, create)
    local state = states[unit]
    if not state and create then
        state = {
            unit = unit,
            firstSeenAt = GetTime(),
            nextSpellStartAt = {},
            cdIndex = {},
            castHistory = {},
        }
        states[unit] = state
    end
    return state
end

local function ResolveNPCByName(state, dungeon)
    if not state.name or not dungeon or type(dungeon.mobs) ~= "table" then return nil end
    local found
    for npcID, mob in pairs(dungeon.mobs) do
        if mob.name == state.name then
            if found then return nil end
            found = npcID
        end
    end
    return found
end

local function SnapshotState(state)
    if type(state) ~= "table" or not IsNameplateUnit(state.unit) or not SafeUnitExists(state.unit) then
        return
    end

    local dungeonKey = CurrentDungeonKey()
    if dungeonKey ~= state.dungeonKey then
        state.dungeonKey = dungeonKey
        state.npcID = nil
        state.npcIDSource = nil
        state.observedNPCID = nil
        state.observedNPCSource = nil
        state.name = nil
        state.level = nil
        state.power = nil
        ResetCombatState(state)
    end

    -- Capture direct public identity before consulting the compatibility model.
    -- This allows the clean recorder to learn from NPCs the current model does
    -- not know yet, without using model membership as an identity source.
    local npcID, npcSource = SafeCreatureID(state.unit)
    if npcID then
        state.observedNPCID = npcID
        state.observedNPCSource = npcSource
    end
    local name = SafeUnitName(state.unit)
    if name then state.name = name end

    local dungeon = GetDungeonModel(dungeonKey)
    if not dungeon then return end

    if npcID and dungeon.mobs and dungeon.mobs[npcID] then
        state.npcID = npcID
        state.npcIDSource = npcSource
    end
    if not state.npcID then
        local resolvedByName = ResolveNPCByName(state, dungeon)
        if resolvedByName then
            state.npcID = resolvedByName
            state.npcIDSource = "name_match"
        end
    end

    local level = SafeUnitLevel(state.unit)
    if level then state.level = level end
    local power = SafeUnitPowerType(state.unit)
    if power ~= nil then state.power = power end
end

local function InitializePredictions(state, mob)
    if type(state) ~= "table" or type(mob) ~= "table" or type(mob.spells) ~= "table" then return end
    if type(state.combatStartedAt) ~= "number" then return end
    state.nextSpellStartAt = type(state.nextSpellStartAt) == "table" and state.nextSpellStartAt or {}
    for spellID, spell in pairs(mob.spells) do
        if state.nextSpellStartAt[spellID] == nil and type(spell.first) == "number" then
            state.nextSpellStartAt[spellID] = state.combatStartedAt + spell.first
        end
    end
end

local function UpdateCombatState(state, now)
    if type(state) ~= "table" then return end
    now = tonumber(now) or GetTime()
    local inCombat = SafeUnitInCombat(state.unit)
    if inCombat == true and state.inCombat ~= true then
        state.inCombat = true
        state.combatStartedAt = now
        state.castCount = 0
        state.activeCastBarID = nil
        state.activeKind = nil
        state.activeSpellID = nil
        state.activeNPCID = nil
        state.activeRecord = nil
        state.previousRecord = nil
        state.castHistory = {}
        state.nextSpellStartAt = {}
        state.cdIndex = {}
        local dungeon = GetDungeonModel(state.dungeonKey)
        local mob = dungeon and state.npcID and dungeon.mobs and dungeon.mobs[state.npcID]
        InitializePredictions(state, mob)
    elseif inCombat == false and state.inCombat == true then
        ResetCombatState(state)
    end
end

local function SpellStartsAsKind(spell, kind)
    if type(spell) ~= "table" then return false end
    if kind == "cast" then
        return type(spell.castTime) == "number" and spell.castTime > 0
    elseif kind == "channel" then
        -- Cast-into-channel abilities begin with UNIT_SPELLCAST_START and retain
        -- their castBarID into the channel transition. Pure channels start here.
        return spell.castTime == nil and type(spell.channelTime) == "number" and spell.channelTime > 0
    end
    return false
end

local function MobMatchesObservables(state, mob, kind)
    local traits = type(mob) == "table" and mob.traits or nil
    if type(traits) ~= "table" then return true end

    if type(state.level) == "number" and type(traits.level) == "number" and state.level ~= traits.level then
        return false
    end
    if type(state.power) == "number" and type(traits.power) == "number" and state.power ~= traits.power then
        return false
    end
    if kind == "cast" and traits.hasCastSpell == false then return false end
    if kind == "channel" and traits.hasChannelSpell == false then return false end
    return true
end

local function BuildMobCandidates(state, kind)
    local dungeon = GetDungeonModel(state.dungeonKey)
    if not dungeon or type(dungeon.mobs) ~= "table" then return {} end

    if state.npcID and dungeon.mobs[state.npcID] then
        return { { npcID = state.npcID, mob = dungeon.mobs[state.npcID] } }
    end

    local candidates = {}
    for npcID, mob in pairs(dungeon.mobs) do
        if MobMatchesObservables(state, mob, kind) then
            candidates[#candidates + 1] = { npcID = npcID, mob = mob }
        end
    end
    return candidates
end

local function BuildSpellCandidates(state, kind, targetAPIExists, now)
    local rows = {}
    local ledger = {}
    local order = tonumber(state.castCount) or 0
    local mobCandidates = BuildMobCandidates(state, kind)
    now = tonumber(now) or GetTime()

    for _, mobRow in ipairs(mobCandidates) do
        local mob = mobRow.mob
        local raw = {}
        local hasOrderMatch = false

        for spellID, spell in pairs(mob.spells or {}) do
            if SpellStartsAsKind(spell, kind) then
                local row = {
                    npcID = mobRow.npcID,
                    spellID = spellID,
                    spell = spell,
                    kept = true,
                    evidenceScore = 0,
                }
                raw[#raw + 1] = row
                if type(spell.openingCastOrder) == "number" and spell.openingCastOrder == order then
                    hasOrderMatch = true
                end
            end
        end

        for _, row in ipairs(raw) do
            local spell = row.spell
            if type(spell.openingCastOrder) == "number" then
                row.orderMatch = spell.openingCastOrder == order
                if row.orderMatch then
                    row.evidenceScore = row.evidenceScore + 40
                elseif hasOrderMatch then
                    row.kept = false
                    row.eliminationReason = "opening_order"
                end
            end

            if row.kept and type(targetAPIExists) == "boolean" and type(spell.targetAPIExists) == "boolean" then
                row.targetMatch = spell.targetAPIExists == targetAPIExists
                if row.targetMatch then
                    row.evidenceScore = row.evidenceScore + 30
                else
                    row.kept = false
                    row.eliminationReason = "target_behavior"
                end
            end

            local predictedAt = state.nextSpellStartAt and state.nextSpellStartAt[row.spellID]
            if type(predictedAt) == "number" then
                row.predictedAt = predictedAt
                row.predictionDelta = math.abs(now - predictedAt)
                if row.predictionDelta <= PREDICTION_WINDOW then
                    local timingScore = math.max(0, 30 * (1 - (row.predictionDelta / PREDICTION_WINDOW)))
                    row.evidenceScore = row.evidenceScore + timingScore
                end
            end

            ledger[#ledger + 1] = row
            if row.kept then rows[#rows + 1] = row end
        end
    end

    return rows, ledger
end

local function FilterByPrediction(state, rows, now)
    if type(rows) ~= "table" or #rows <= 1 then return rows, false end
    now = tonumber(now) or GetTime()

    local bestRow, bestDelta, secondDelta
    for _, row in ipairs(rows) do
        local predictedAt = state.nextSpellStartAt and state.nextSpellStartAt[row.spellID]
        if type(predictedAt) == "number" then
            local delta = math.abs(now - predictedAt)
            row.predictedAt = predictedAt
            row.predictionDelta = delta
            if not bestDelta or delta < bestDelta then
                secondDelta = bestDelta
                bestDelta = delta
                bestRow = row
            elseif not secondDelta or delta < secondDelta then
                secondDelta = delta
            end
        end
    end

    if bestRow and bestDelta <= PREDICTION_WINDOW
        and (not secondDelta or (secondDelta - bestDelta) >= PREDICTION_MARGIN) then
        for _, row in ipairs(rows) do
            if row ~= bestRow then
                row.kept = false
                row.eliminationReason = row.eliminationReason or "prediction_margin"
            end
        end
        return { bestRow }, true
    end
    return rows, false
end

local function AllCandidatesImportant(rows, dungeonKey)
    if type(rows) ~= "table" or #rows == 0 or type(CT.IsRuntimeAbilityEnabled) ~= "function" then
        return false, nil, "OTHER", false
    end

    local oneNPCID
    local sharedMechanicType
    local allTTSEnabled = type(CT.GetAbilityEffectiveConfig) == "function"
    for _, row in ipairs(rows) do
        if CT:IsRuntimeAbilityEnabled(dungeonKey, row.npcID, row.spellID) ~= true then
            return false, nil, "OTHER", false
        end
        if oneNPCID == nil then
            oneNPCID = row.npcID
        elseif oneNPCID ~= row.npcID then
            oneNPCID = false
        end

        local cfg = type(CT.GetAbilityEffectiveConfig) == "function"
            and CT:GetAbilityEffectiveConfig(dungeonKey, row.npcID, row.spellID) or nil
        local mechanicType = cfg and type(cfg.mechanicType) == "string" and cfg.mechanicType or "OTHER"
        if sharedMechanicType == nil then
            sharedMechanicType = mechanicType
        elseif sharedMechanicType ~= mechanicType then
            sharedMechanicType = "OTHER"
        end
        if not cfg or cfg.ttsEnabled ~= true then
            allTTSEnabled = false
        end
    end
    return true, oneNPCID or nil, sharedMechanicType or "OTHER", allTTSEnabled == true
end

local function ResolveSpell(state, kind, targetAPIExists, now)
    local rows, ledger = BuildSpellCandidates(state, kind, targetAPIExists, now)
    local predictionNarrowed
    rows, predictionNarrowed = FilterByPrediction(state, rows, now)
    if #rows == 1 then
        local reason = predictionNarrowed and "prediction_margin" or "deterministic_filters"
        return rows[1], rows, ledger, reason
    end
    return nil, rows, ledger, #rows == 0 and "no_candidates" or "ambiguous"
end

local function BuildPublicSpellCandidates(state, spellID, kind)
    local dungeon = GetDungeonModel(state.dungeonKey)
    if not dungeon or type(dungeon.mobs) ~= "table" then return {} end

    if state.npcID then
        local mob = dungeon.mobs[state.npcID]
        local spell = mob and mob.spells and mob.spells[spellID]
        if spell then
            return { { npcID = state.npcID, spellID = spellID, spell = spell, kept = true, evidenceScore = 100 } }
        end
        return {}
    end

    local rows = {}
    for npcID, mob in pairs(dungeon.mobs) do
        local spell = mob.spells and mob.spells[spellID]
        if spell and MobMatchesObservables(state, mob, kind) then
            rows[#rows + 1] = { npcID = npcID, spellID = spellID, spell = spell, kept = true, evidenceScore = 100 }
        end
    end
    return rows
end

local function GetSpellModel(state, npcID, spellID)
    local dungeon = GetDungeonModel(state.dungeonKey)
    local mob = dungeon and dungeon.mobs and dungeon.mobs[npcID]
    local spell = mob and mob.spells and mob.spells[spellID]
    return mob, spell
end

local function ExpectedDurationFor(spell, kind)
    if type(spell) ~= "table" then return nil end
    if kind == "channel" then
        return type(spell.channelTime) == "number" and spell.channelTime or nil
    end
    return type(spell.castTime) == "number" and spell.castTime or nil
end

local function MarkSpellResolved(state, npcID, spellID, now, method, trusted)
    local mob, spell = GetSpellModel(state, npcID, spellID)
    if not spell then return nil end

    state.npcID = state.npcID or npcID
    state.activeNPCID = npcID
    state.activeSpellID = spellID

    if type(state.combatStartedAt) ~= "number" and type(spell.first) == "number" then
        state.combatStartedAt = now - spell.first
    end
    InitializePredictions(state, mob)

    local record = state.activeRecord
    if type(record) == "table" then
        record.resolvedNPCID = npcID
        record.resolvedSpellID = spellID
        record.resolutionMethod = method or "unknown"
        record.resolutionTrusted = trusted == true
        record.expectedDuration = ExpectedDurationFor(spell, record.kind)
    end
    return spell
end

local function AdvanceResolvedCooldown(state, record)
    if type(state) ~= "table" or type(record) ~= "table" or record.resolutionTrusted ~= true then return false end
    local npcID = tonumber(record.resolvedNPCID)
    local spellID = tonumber(record.resolvedSpellID)
    if not npcID or not spellID then return false end

    local _, spell = GetSpellModel(state, npcID, spellID)
    local cd = spell and spell.cd
    if type(cd) ~= "table" or #cd == 0 then return false end

    state.cdIndex = type(state.cdIndex) == "table" and state.cdIndex or {}
    state.nextSpellStartAt = type(state.nextSpellStartAt) == "table" and state.nextSpellStartAt or {}
    local index = (tonumber(state.cdIndex[spellID]) or 0) + 1
    local delay = tonumber(cd[math.min(index, #cd)])
    if not delay or delay <= 0 then return false end

    state.cdIndex[spellID] = index
    local anchor = tonumber(record.cooldownAnchorAt) or tonumber(record.startTime) or GetTime()
    state.nextSpellStartAt[spellID] = anchor + delay
    record.cooldownAdvanced = true
    record.nextExpectedStart = state.nextSpellStartAt[spellID]
    return true
end

local function PushHistory(state, record)
    if type(state) ~= "table" or type(record) ~= "table" then return end
    state.castHistory = type(state.castHistory) == "table" and state.castHistory or {}
    state.castHistory[#state.castHistory + 1] = record
    while #state.castHistory > HISTORY_LIMIT do
        table.remove(state.castHistory, 1)
    end
    state.previousRecord = record
end

local function FinalizeRecord(state, record, outcome, now)
    if type(state) ~= "table" or type(record) ~= "table" or record.finalized then return end
    now = tonumber(now) or GetTime()
    record.endTime = now
    record.outcome = outcome or record.outcome or "unknown"
    record.finalized = true
    if type(record.startTime) == "number" then
        record.observedLifetime = math.max(0, now - record.startTime)
    end

    local shouldAdvance = record.outcome == "channel_success" or record.outcome == "success"
    if shouldAdvance and record.outcome == "success" and record.kind == "cast"
        and record.resolvedNPCID and record.resolvedSpellID then
        local _, resolvedSpell = GetSpellModel(state, record.resolvedNPCID, record.resolvedSpellID)
        if resolvedSpell and type(resolvedSpell.channelTime) == "number" and resolvedSpell.channelTime > 0 then
            -- Cast-into-channel mechanics advance their cooldown only after the
            -- channel finishes successfully, never on the warm-up cast STOP.
            shouldAdvance = false
            record.awaitingChannel = true
        end
    end
    if shouldAdvance and record.cooldownAdvanced ~= true then
        AdvanceResolvedCooldown(state, record)
    end

    PushHistory(state, record)
end

local function GetUnitCastBarID(unit, isChannel)
    local func = isChannel and UnitChannelInfo or UnitCastingInfo
    if type(func) ~= "function" then return nil end

    -- UnitChannelInfo's castBarID is return #11; UnitCastingInfo's castBarID is
    -- return #10 (delayTimeMs follows at #11). Per Patch 12.0.0/12.0.1 API docs.
    if isChannel then
        local ok, _, _, _, _, _, _, _, _, _, _, rawCastBarID = pcall(func, unit)
        if ok and not IsSecret(rawCastBarID) then return tonumber(rawCastBarID) end
    else
        local ok, _, _, _, _, _, _, _, _, _, rawCastBarID = pcall(func, unit)
        if ok and not IsSecret(rawCastBarID) then return tonumber(rawCastBarID) end
    end
    return nil
end

local function FindUnitByLiveCastBarID(castBarID, isChannel)
    castBarID = SafeNumber(castBarID)
    if not castBarID then return nil end
    for unit, state in pairs(states) do
        if state.unit == unit and SafeUnitExists(unit) then
            if GetUnitCastBarID(unit, isChannel) == castBarID then
                return unit
            end
        end
    end
    return nil
end

local function FindUnitByActiveCastBarID(castBarID)
    castBarID = SafeNumber(castBarID)
    if not castBarID then return nil end
    for unit, state in pairs(states) do
        if state.activeCastBarID == castBarID then return unit end
    end
    return nil
end

local function ResolveEventUnit(rawUnit, castBarID, isChannel, activeOnly)
    if IsNameplateUnit(rawUnit) then return rawUnit end
    if activeOnly then return FindUnitByActiveCastBarID(castBarID) end
    return FindUnitByLiveCastBarID(castBarID, isChannel)
end

local function BuildRowsForResolvedSpell(state, npcID, spellID, kind)
    local dungeon = GetDungeonModel(state.dungeonKey)
    if not dungeon or type(dungeon.mobs) ~= "table" then return {} end

    if npcID and dungeon.mobs[npcID] and dungeon.mobs[npcID].spells
        and dungeon.mobs[npcID].spells[spellID] then
        local spell = dungeon.mobs[npcID].spells[spellID]
        return { { npcID = npcID, spellID = spellID, spell = spell } }
    end

    return BuildPublicSpellCandidates(state, spellID, kind)
end

local function NewActiveRecord(state, castBarID, kind, eventSpellID, now)
    -- Inspect secrecy before performing any comparison or coercion on the event
    -- spell identifier. IsSecret(nil) is safe and returns false.
    local spellProtected = IsSecret(eventSpellID)
    local record = {
        castBarID = castBarID,
        kind = kind,
        startTime = now,
        delayCount = 0,
        spellProtected = spellProtected,
        publicSpellID = spellProtected and nil or SafeNumber(eventSpellID),
        castOrder = tonumber(state.castCount) or 0,
        targetAPIExists = SafeTargetAPIExists(state.unit),
    }
    state.activeRecord = record
    return record
end

local function CommitResolved(state, row, castBarID, kind, now, method, ledger, resolutionReason)
    if not row then return false end
    local record = state.activeRecord
    if type(record) == "table" then
        record.candidateLedger = ledger
        record.resolutionReason = resolutionReason
    end

    -- Only static/public IDs reach this function. No protected event value is
    -- converted, compared, or used as a table key.
    MarkSpellResolved(state, row.npcID, row.spellID, now, method, true)

    local enabledForProfile = type(CT.IsRuntimeAbilityEnabled) ~= "function"
        or CT:IsRuntimeAbilityEnabled(state.dungeonKey, row.npcID, row.spellID) == true
    if not enabledForProfile then
        if record then
            record.dispatchStatus = "SUPPRESSED"
            record.dispatchReason = "user_or_profile_filter"
        end
        return true
    end

    if type(CT.CommitRuntimeTrashCast) ~= "function" then
        if record then
            record.dispatchStatus = "SUPPRESSED"
            record.dispatchReason = "core_dispatch_unavailable"
        end
        return true
    end

    local shown = CT:CommitRuntimeTrashCast(state.unit, row.spellID, castBarID, kind == "channel", row.npcID)
    if record then
        record.dispatchStatus = shown == true and "ALERT_CREATED" or "SUPPRESSED"
        record.dispatchReason = shown == true and "enabled_resolved_mechanic" or "core_rejected_dispatch"
    end
    return true
end

local function CommitGenericIfSafe(state, rows, castBarID, kind, ledger, reason)
    local record = state.activeRecord
    if record then
        record.candidateLedger = ledger or rows
        record.resolutionMethod = "generic_all_important"
        record.resolutionReason = reason or "all_remaining_candidates_important"
    end

    local allImportant, oneNPCID, mechanicType, allTTSEnabled = AllCandidatesImportant(rows, state.dungeonKey)
    if not allImportant or type(CT.CommitRuntimeGenericTrashCast) ~= "function" then
        if record then
            record.dispatchStatus = "SUPPRESSED"
            record.dispatchReason = #rows == 0 and "no_candidates" or "ambiguous_not_all_important"
        end
        return false
    end

    local shown = CT:CommitRuntimeGenericTrashCast(
        state.unit, castBarID, kind == "channel", oneNPCID, mechanicType, false
    ) == true
    if record then
        record.resolvedNPCID = oneNPCID
        record.dispatchStatus = shown and "ALERT_CREATED" or "SUPPRESSED"
        record.dispatchReason = shown and "generic_all_candidates_important" or "core_rejected_generic"
    end
    return shown
end

local function RetryProtectedInference(unit, castBarID, kind, seq)
    if not C_Timer or type(C_Timer.After) ~= "function" then return end
    C_Timer.After(RETRY_DELAY, function()
        local state = states[unit]
        if not state or state.activeCastBarID ~= castBarID or state.activeSeq ~= seq then return end
        SnapshotState(state)
        UpdateCombatState(state, GetTime())

        local targetAPIExists = SafeTargetAPIExists(unit)
        if type(targetAPIExists) == "boolean" and type(state.activeRecord) == "table" then
            state.activeRecord.targetAPIExists = targetAPIExists
        end
        local row, rows, ledger, reason = ResolveSpell(state, kind, targetAPIExists, GetTime())
        if row then
            CommitResolved(state, row, castBarID, kind, GetTime(), "local_inference_retry", ledger, reason)
        else
            CommitGenericIfSafe(state, rows, castBarID, kind, ledger, reason)
        end
    end)
end

local function CanTransitionToChannel(state, parent, newCastBarID, now)
    if type(parent) ~= "table" or parent.kind ~= "cast" or parent.interrupted or parent.failed then return false end
    local oldCastBarID = tonumber(parent.castBarID)
    newCastBarID = tonumber(newCastBarID)
    if not oldCastBarID or not newCastBarID or newCastBarID ~= (oldCastBarID + 1) then return false end
    if not parent.resolvedNPCID or not parent.resolvedSpellID then return false end

    local _, spell = GetSpellModel(state, parent.resolvedNPCID, parent.resolvedSpellID)
    if not spell or type(spell.channelTime) ~= "number" or spell.channelTime <= 0 then return false end

    if parent.finalized then
        local ended = tonumber(parent.endTime)
        return ended ~= nil and (now - ended) >= 0 and (now - ended) <= CAST_TO_CHANNEL_WINDOW
    end
    if parent.succeededAt then
        return (now - parent.succeededAt) >= 0 and (now - parent.succeededAt) <= CAST_TO_CHANNEL_WINDOW
    end
    return true
end

local function BeginChannelTransition(state, parent, eventSpellID, newCastBarID, now)
    if not CanTransitionToChannel(state, parent, newCastBarID, now) then return false end

    if not parent.finalized then
        FinalizeRecord(state, parent, "cast_to_channel", now)
    end

    state.activeSeq = (tonumber(state.activeSeq) or 0) + 1
    state.activeCastBarID = newCastBarID
    state.activeKind = "channel"
    state.activeSpellID = parent.resolvedSpellID
    state.activeNPCID = parent.resolvedNPCID

    local record = NewActiveRecord(state, newCastBarID, "channel", eventSpellID, now)
    record.parentCastBarID = parent.castBarID
    -- Cooldown data is start-to-start for the complete mechanic. Preserve the
    -- warm-up cast start as the anchor when this cast converts into a channel.
    record.cooldownAnchorAt = parent.cooldownAnchorAt or parent.startTime
    record.resolvedNPCID = parent.resolvedNPCID
    record.resolvedSpellID = parent.resolvedSpellID
    record.resolutionMethod = "cast_to_channel"
    record.resolutionReason = "sequential_castbar_and_known_channel_phase"
    record.resolutionTrusted = parent.resolutionTrusted == true
    local _, spell = GetSpellModel(state, record.resolvedNPCID, record.resolvedSpellID)
    record.expectedDuration = ExpectedDurationFor(spell, "channel")

    local enabledForProfile = type(CT.IsRuntimeAbilityEnabled) ~= "function"
        or CT:IsRuntimeAbilityEnabled(state.dungeonKey, record.resolvedNPCID, record.resolvedSpellID) == true
    if enabledForProfile and type(CT.CommitRuntimeTrashCast) == "function" then
        local shown = CT:CommitRuntimeTrashCast(state.unit, record.resolvedSpellID, newCastBarID, true, record.resolvedNPCID)
        record.dispatchStatus = shown == true and "ALERT_CREATED" or "SUPPRESSED"
        record.dispatchReason = shown == true and "cast_to_channel_refresh" or "core_rejected_dispatch"
    else
        record.dispatchStatus = "SUPPRESSED"
        record.dispatchReason = "user_or_profile_filter"
    end
    return true
end

local function BeginCast(unit, eventSpellID, castBarID, kind)
    if not IsNameplateUnit(unit) or type(CT.IsRuntimeTrashTrackingEnabled) ~= "function"
        or CT:IsRuntimeTrashTrackingEnabled() ~= true then
        return
    end

    local state = GetState(unit, true)
    SnapshotState(state)
    local now = GetTime()
    UpdateCombatState(state, now)

    local publicCastBarID = SafeNumber(castBarID)
    if not publicCastBarID then
        publicCastBarID = GetUnitCastBarID(unit, kind == "channel")
    end

    if publicCastBarID and state.activeCastBarID == publicCastBarID then return end

    if kind == "channel" then
        local parent = state.activeRecord
        if not parent or parent.kind ~= "cast" then parent = state.previousRecord end
        if BeginChannelTransition(state, parent, eventSpellID, publicCastBarID, now) then
            return
        end
    end

    if state.activeRecord and not state.activeRecord.finalized then
        FinalizeRecord(state, state.activeRecord, "replaced_by_new_cast", now)
    end

    state.castCount = (tonumber(state.castCount) or 0) + 1
    state.activeSeq = (tonumber(state.activeSeq) or 0) + 1
    state.activeCastBarID = publicCastBarID
    state.activeKind = kind
    state.activeSpellID = nil
    state.activeNPCID = nil
    local record = NewActiveRecord(state, publicCastBarID, kind, eventSpellID, now)

    local publicSpellID = SafeNumber(eventSpellID)
    if publicSpellID then
        record.spellProtected = false
        local rows = BuildCatalogPublicSpellCandidates(state, publicSpellID)
        if #rows == 0 then
            rows = BuildPublicSpellCandidates(state, publicSpellID, kind)
        end
        record.candidateLedger = rows
        if #rows == 1 then
            CommitResolved(state, rows[1], publicCastBarID, kind, now, "public_spell_id", rows, "readable_event_spell_id")
        elseif #rows > 1 then
            CommitGenericIfSafe(state, rows, publicCastBarID, kind, rows, "public_spell_shared_across_mobs")
        else
            record.dispatchStatus = "SUPPRESSED"
            record.dispatchReason = "public_spell_not_in_runtime_model"
        end
        return
    end


    local row, rows, ledger, reason = ResolveSpell(state, kind, nil, now)
    record.candidateLedger = ledger
    if row and CommitResolved(state, row, publicCastBarID, kind, now, "local_inference", ledger, reason) then
        return
    end
    if CommitGenericIfSafe(state, rows, publicCastBarID, kind, ledger, reason) then
        return
    end

    RetryProtectedInference(unit, publicCastBarID, kind, state.activeSeq)
end

local function MarkDelayed(unit, castBarID)
    if not IsNameplateUnit(unit) then return end
    local state = states[unit]
    local record = state and state.activeRecord
    local publicCastBarID = SafeNumber(castBarID)
    if not record or not publicCastBarID or record.castBarID ~= publicCastBarID then return end
    record.delayCount = (tonumber(record.delayCount) or 0) + 1
    record.lastDelayTime = GetTime()
end

local function MarkSucceeded(unit, castBarID)
    if not IsNameplateUnit(unit) then return end
    local state = states[unit]
    local record = state and state.activeRecord
    local publicCastBarID = SafeNumber(castBarID)
    -- SUCCEEDED also fires for instant spells that have no displayed cast bar.
    -- Never let a castBarID-less event mutate an unrelated active nameplate cast.
    if not record or not publicCastBarID or record.castBarID ~= publicCastBarID then return end
    record.succeeded = true
    record.succeededAt = GetTime()
end

local function ClearActiveState(state, castBarID)
    if not state then return end
    if castBarID == nil or state.activeCastBarID == castBarID then
        state.activeCastBarID = nil
        state.activeKind = nil
        state.activeSpellID = nil
        state.activeNPCID = nil
        state.activeRecord = nil
    end
end

local function EndCast(unit, event, castBarID, interruptedBy)
    if not IsNameplateUnit(unit) then return end
    local state = states[unit]
    if not state then return end

    local publicCastBarID = SafeNumber(castBarID)
    -- Outcome events without a public castBarID cannot be tied to the active
    -- hostile cast deterministically. Leave the record pending instead of
    -- mutating or clearing an unrelated cast.
    if not publicCastBarID then return end
    local record = state.activeRecord
    if record and record.castBarID and record.castBarID ~= publicCastBarID then
        return
    end

    local now = GetTime()
    if record then
        if event == "UNIT_SPELLCAST_INTERRUPTED" then
            record.interrupted = true
            record.interruptedAt = now
            FinalizeRecord(state, record, "interrupted", now)
        elseif event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_FAILED_QUIET" then
            record.failed = true
            record.failedAt = now
            FinalizeRecord(state, record, "failed", now)
        elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" then
            if record.interrupted then
                FinalizeRecord(state, record, "interrupted", now)
            elseif IsSecret(interruptedBy) then
                FinalizeRecord(state, record, "channel_stop_unknown", now)
            elseif interruptedBy ~= nil then
                record.interrupted = true
                record.interruptedAt = now
                FinalizeRecord(state, record, "interrupted", now)
            else
                record.succeeded = true
                record.succeededAt = record.succeededAt or now
                FinalizeRecord(state, record, "channel_success", now)
            end
        elseif event == "UNIT_SPELLCAST_STOP" then
            if record.interrupted then
                FinalizeRecord(state, record, "interrupted", now)
            elseif record.failed then
                FinalizeRecord(state, record, "failed", now)
            elseif record.succeeded then
                FinalizeRecord(state, record, "success", now)
            else
                FinalizeRecord(state, record, "stop_unknown", now)
            end
        end
    end

    if type(CT.RemoveRuntimeTrashCast) == "function" then
        CT:RemoveRuntimeTrashCast(unit, publicCastBarID)
    end
    ClearActiveState(state, publicCastBarID)
end

local function TrackNameplate(unit)
    if not IsNameplateUnit(unit) then return end
    local state = GetState(unit, true)
    SnapshotState(state)
    UpdateCombatState(state, GetTime())
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0.12, function()
            local current = states[unit]
            if current == state then
                SnapshotState(current)
                UpdateCombatState(current, GetTime())
            end
        end)
    end
end

local function UntrackNameplate(unit)
    if not IsNameplateUnit(unit) then return end
    local state = states[unit]
    if state and type(CT.RemoveRuntimeTrashCast) == "function" then
        CT:RemoveRuntimeTrashCast(unit, state.activeCastBarID)
    end
    states[unit] = nil
end

local function RehydrateNameplates()
    if not C_NamePlate or type(C_NamePlate.GetNamePlates) ~= "function" then return 0 end
    local ok, plates = pcall(C_NamePlate.GetNamePlates)
    if not ok or type(plates) ~= "table" then return 0 end

    local tracked = 0
    for _, plate in ipairs(plates) do
        local unit
        if type(plate) == "table" or type(plate) == "userdata" then
            unit = plate.unitToken
                or plate.namePlateUnitToken
                or (plate.UnitFrame and plate.UnitFrame.unit)
                or (plate.unitFrame and plate.unitFrame.unit)
        end
        if IsNameplateUnit(unit) then
            TrackNameplate(unit)
            tracked = tracked + 1
        end
    end
    return tracked
end

local function ScheduleRehydrate()
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0, RehydrateNameplates)
    else
        RehydrateNameplates()
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
frame:RegisterEvent("PLAYER_REGEN_DISABLED")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
frame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
frame:RegisterEvent("UNIT_SPELLCAST_START")
frame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
frame:RegisterEvent("UNIT_SPELLCAST_DELAYED")
frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
frame:RegisterEvent("UNIT_SPELLCAST_STOP")
frame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
frame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
frame:RegisterEvent("UNIT_SPELLCAST_FAILED")
frame:RegisterEvent("UNIT_SPELLCAST_FAILED_QUIET")

frame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        wipe(states)
        ScheduleRehydrate()
        return
    elseif event == "PLAYER_REGEN_DISABLED" then
        local now = GetTime()
        for _, state in pairs(states) do
            SnapshotState(state)
            UpdateCombatState(state, now)
        end
        return
    elseif event == "PLAYER_REGEN_ENABLED" then
        for _, state in pairs(states) do
            if SafeUnitInCombat(state.unit) ~= true then
                ResetCombatState(state)
            end
        end
        return
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        local unit = select(1, ...)
        if IsNameplateUnit(unit) then TrackNameplate(unit) end
        return
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        local unit = select(1, ...)
        if IsNameplateUnit(unit) then UntrackNameplate(unit) end
        return
    end

    if event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_CHANNEL_START" then
        local rawUnit, _, spellID, castBarID = ...
        local isChannel = event == "UNIT_SPELLCAST_CHANNEL_START"
        local unit = ResolveEventUnit(rawUnit, castBarID, isChannel, false)
        if unit then BeginCast(unit, spellID, castBarID, isChannel and "channel" or "cast") end
        return
    end

    if event == "UNIT_SPELLCAST_DELAYED" then
        local rawUnit, _, _, castBarID = ...
        local unit = ResolveEventUnit(rawUnit, castBarID, false, true)
        if unit then MarkDelayed(unit, castBarID) end
        return
    end

    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local rawUnit, _, _, castBarID = ...
        local unit = ResolveEventUnit(rawUnit, castBarID, false, true)
        if unit then MarkSucceeded(unit, castBarID) end
        return
    end

    local rawUnit, _, _, fourth, fifth = ...
    local castBarID
    local interruptedBy
    if event == "UNIT_SPELLCAST_CHANNEL_STOP" or event == "UNIT_SPELLCAST_INTERRUPTED" then
        interruptedBy = fourth
        castBarID = fifth
    else
        castBarID = fourth
    end
    local unit = ResolveEventUnit(rawUnit, castBarID, false, true)
    if unit then EndCast(unit, event, castBarID, interruptedBy) end
end)

_G.ChayAlertHUDTrashRuntime = {
    source = RuntimeData.source,
    states = states,
    RehydrateNameplates = RehydrateNameplates,
}
