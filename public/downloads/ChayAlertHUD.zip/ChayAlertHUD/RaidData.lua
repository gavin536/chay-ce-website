-- ChayAlert HUD Midnight Season 2 raid catalog.
-- Static encounter, Encounter Journal, and spell identifiers used by the
-- ability manager and role-aware routing.
local data = {
    order = { "the_venomous_abyss", "the_tidebound_grotto" },
    raids = {
        ["the_venomous_abyss"] = {
            name = "The Venomous Abyss",
            instanceID = 3004,
            bosses = {
                {
                    name = "The Coiled Altar",
                    encounterID = 3429, ejID = 2883,
                    spells = {
                        { id = 1282487, name = "Fangs of the Coiled Altar", aoe = true },
                        { id = 1299960, name = "Toxic Deluge" },
                        { id = 1283489, name = "Guillotine" },
                        { id = 1299680, name = "Sever", tank = true },
                        { id = 1282281, name = "Venomfang" },
                        { id = 1283832, name = "Axegrinder" },
                        { id = 1289900, name = "Dreadmarch" },
                        { id = 1285911, name = "Unnerving Fixation" },
                        { id = 1286573, name = "Soul Sever", tank = true },
                        { id = 1286918, name = "Eternal Nightfall", aoe = true },
                        { id = 1286441, name = "Spiritcackle" },
                        { id = 1286895, name = "Gloombomb" },
                        { id = 1298381, name = "Defilement of the Coiled Altar", aoe = true },
                        { id = 1299266, name = "Grim Guillotine" },
                        { id = 1307279, name = "Blighted Sever", tank = true },
                    },
                },
                {
                    name = "The Lost Explorers",
                    encounterID = 3497, ejID = 2894,
                    spells = {
                        { id = 1296535, name = "Disgusting Fish" },
                        { id = 1297022, name = "Mor'zahi's Command" },
                        { id = 1292779, name = "Final Ascension" },
                        { id = 1290711, name = "Blink Nova" },
                        { id = 1286921, name = "Icebound Flames" },
                        { id = 1295854, name = "Shredding Shards", tank = true },
                        { id = 1295886, name = "Frostfire Volley" },
                        { id = 1291390, name = "Cataclysmic Invocation" },
                        { id = 1291759, name = "Shell Spin" },
                        { id = 1296092, name = "Mighty Thud", aoe = true },
                        { id = 1291933, name = "Throw Junk" },
                        { id = 1295817, name = "Fling Fish" },
                        { id = 1292104, name = "Mushroom Toss" },
                        { id = 1296249, name = "Explosive Surprise" },
                    },
                },
                {
                    name = "Nek'zali the Soulcoiler",
                    encounterID = 3470, ejID = 2888,
                    spells = {
                        { id = 1293212, name = "Grasping Depths", mythic = true },
                        { id = 1285681, name = "Soulcoil Ignition" },
                        { id = 1287426, name = "Essence Rend" },
                        { id = 1295397, name = "Restless Amani" },
                        { id = 1287533, name = "Gravebound Advance" },
                        { id = 1292036, name = "Possession Barrage", tank = true },
                        { id = 1289696, name = "Tether of Awakening", defaultAlert = false },
                        { id = 1305421, name = "Hungering Pyre" },
                        { id = 1299673, name = "Invoke" },
                    },
                },
                {
                    name = "Entombed Sentinels",
                    encounterID = 3445, ejID = 2874,
                    spells = {
                        { id = 1284588, name = "Vitriolic Stasis" },
                        { id = 1296878, name = "Shifting Protovenom", mythic = true },
                        { id = 1284251, name = "Venom Coagulation" },
                        { id = 1284434, name = "Toxic Droplets" },
                        { id = 1284458, name = "Empowering Slam", tank = true },
                        { id = 1284483, name = "Blighted Blood" },
                        { id = 1288232, name = "Unstable Miasma" },
                        { id = 1284487, name = "Bloodvenom Injection", tank = true },
                    },
                },
                {
                    name = "Sszorak",
                    encounterID = 3420, ejID = 2871,
                    spells = {
                        { id = 1285732, name = "Howling Maelstrom" },
                        { id = 1277025, name = "Apex Predator", tank = true },
                        { id = 1305959, name = "Venomous Surge" },
                        { id = 1285425, name = "Raging Crosswinds" },
                        { id = 1296898, name = "Unbound Ferocity", mythic = true },
                    },
                },
                {
                    name = "The Twin Fangs",
                    encounterID = 3421, ejID = 2887,
                    spells = {
                        { id = 1308556, name = "Submerge" },
                        { id = 1289192, name = "Caustic Deluge", tank = true },
                        { id = 1291404, name = "Venomous Emergence" },
                        { id = 1291478, name = "Corrosive Spit" },
                        { id = 1290956, name = "Stir the Depths" },
                        { id = 1294293, name = "Vile Flood", castbar = true },
                        { id = 1303230, name = "Blood Torrent" },
                        { id = 1308356, name = "Rouse the Brood", interrupt = true },
                        { id = 1290516, name = "Ravenous Feast" },
                        { id = 1290809, name = "Coiling Ichor" },
                        { id = 1288538, name = "Stone Breaker", tank = true },
                        { id = 1306872, name = "Sanguine Storm" },
                    },
                },
                {
                    name = "Ula'tek",
                    encounterID = 3492, ejID = 2895,
                    spells = {
                        { id = 1292999, name = "Submerge" },
                        { id = 1300635, name = "Submerge", defaultAlert = false },
                        { id = 1292188, name = "Caustic Waves" },
                        { id = 1300751, name = "Call of the Serpent" },
                        { id = 1298367, name = "Mother's Wrath", tank = true },
                        { id = 1298559, name = "Gore Rattle" },
                        { id = 1296301, name = "Mephitic Thrash" },
                        { id = 1300530, name = "Spectral Coils", aoe = true },
                        { id = 1286860, name = "Rage of the Shackled", aoe = true },
                        { id = 1302982, name = "Virulent Spit" },
                        { id = 1301510, name = "Circling Prey" },
                        { id = 1295905, name = "Serpent's Bite" },
                        { id = 1310738, name = "Toxic Womb", mythic = true },
                        { id = 1310763, name = "Fester Burst", mythic = true },
                        { id = 1299757, name = "Toxic Incubation", mythic = true },
                        { id = 1286905, name = "Fury Unleashed", aoe = true },
                    },
                },
                {
                    name = "Vashnik the Malignant",
                    encounterID = 3455, ejID = 2882,
                    spells = {
                        { id = 1283164, name = "Imbibe" },
                        { id = 1282525, name = "Malignant Catalyst", aoe = true },
                        { id = 1282117, name = "Adaptive Infection" },
                        { id = 1281907, name = "Plague Froth" },
                        { id = 1280935, name = "Dripping Fangs", tank = true },
                    },
                },
            },
        },
        ["the_tidebound_grotto"] = {
            name = "The Tidebound Grotto",
            instanceID = 2987,
            bosses = {
                {
                    name = "Nymrissa Wavecaller",
                    encounterID = 3379, ejID = 2849,
                    spells = {
                        { id = 1276710, name = "Alluring Bubble" },
                        { id = 1257717, name = "Alluring Bubble" },
                        { id = 1258668, name = "Swirling Whirlpools" },
                        { id = 1260837, name = "Abyssal Rain", aoe = true },
                        { id = 1282937, name = "Iceblade Flurry", tank = true },
                        { id = 1313393, name = "Chilling Frost" },
                        { id = 1268562, name = "Water Jet", tank = true, mythic = true },
                    },
                },
            },
        },
    },
    byEncounterID = {},
}

for _, raidKey in ipairs(data.order) do
    local raid = data.raids[raidKey]
    for _, boss in ipairs(raid.bosses) do
        boss.spellByID = {}
        for _, spell in ipairs(boss.spells) do
            boss.spellByID[spell.id] = spell
        end
        data.byEncounterID[boss.encounterID] = { raidKey = raidKey, raid = raid, boss = boss }
    end
end

_G.ChayAlertHUDRaidData = data
return data
