CHAY_CE ChayMedia
Version 1.1.0

ChayMedia registers the CHAY_CE Bushido textures with LibSharedMedia-3.0 and adds a compatibility bridge for shared statusbar/background textures registered by other addons.

WHAT THE SHARED-MEDIA BRIDGE DOES

LibSharedMedia keeps different media categories separate. Some addons register a texture only as a "statusbar" while another addon may request the same kind of image as a "background".

ChayMedia now:
- Registers the four CHAY_CE Bushido textures as both statusbar and background media.
- Reads all statusbar and background textures already registered with LibSharedMedia by other addons.
- Makes statusbar textures available as backgrounds when that media name is not already registered as a background.
- Makes background textures available as statusbars when that media name is not already registered as a statusbar.
- Listens for future LibSharedMedia registrations so textures added by addons that load later are bridged automatically.
- Preserves existing media entries and never overwrites an existing media name in the target category.

This allows compatible texture files registered by addons such as ElvUI, Details, Plater, WeakAuras, BigWigs, SharedMedia packs, and other LibSharedMedia users to appear in more shared-media texture selectors when those selectors use either the statusbar or background media category.

Borders, fonts, and sounds remain in their native LibSharedMedia categories. ChayMedia does not convert border textures into bar/background textures because border artwork is not generally interchangeable with statusbar artwork.

INSTALL

1. Extract ChayMedia.zip.
2. Put the ChayMedia folder here:
   World of Warcraft\_retail_\Interface\AddOns\ChayMedia
3. Make sure this file exists:
   World of Warcraft\_retail_\Interface\AddOns\ChayMedia\ChayMedia.toc
4. Restart World of Warcraft or type /reload.
5. Make sure ChayMedia is enabled on the character-select AddOns screen.

CHAY_CE TEXTURE NAMES

- CHAY_CE - Bushido 1
- CHAY_CE - Bushido 2
- CHAY_CE - Bushido 3
- CHAY_CE - Bushido 4

NOTES

ChayMedia uses the same global LibSharedMedia-3.0 registry used by other compatible addons. If LibSharedMedia is supplied by another enabled addon, ChayMedia waits for it to become available and then registers/synchronizes the textures.

The Midnight 12.0 addon API changes primarily restrict combat-information processing. SharedMedia texture registration is UI look-and-feel customization and does not depend on restricted combat APIs.
