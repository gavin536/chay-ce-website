CHAY_CE ChayMedia

This addon registers the CHAY_CE Bushido textures with LibSharedMedia-compatible addons such as ElvUI, Details, Plater, WeakAuras, BigWigs, and other addons that use shared media dropdowns.

Install:
1. Extract ChayMedia.zip.
2. Put the ChayMedia folder here:
   World of Warcraft\_retail_\Interface\AddOns\ChayMedia
3. Make sure this file exists:
   World of Warcraft\_retail_\Interface\AddOns\ChayMedia\ChayMedia.toc
4. Restart World of Warcraft or type /reload.
5. Make sure ChayMedia is enabled on the character-select AddOns screen.

Texture names added:
- CHAY_CE - Bushido 1
- CHAY_CE - Bushido 2
- CHAY_CE - Bushido 3
- CHAY_CE - Bushido 4

ElvUI:
1. Type /ec.
2. Open the relevant UnitFrames, NamePlates, CastBar, ActionBars, or General media texture dropdown.
3. Select one of the CHAY_CE - Bushido textures.

Details:
1. Open Details options.
2. Go to Bars: General or Appearance.
3. Open the texture/statusbar dropdown.
4. Select one of the CHAY_CE - Bushido textures.

If the textures do not show, reload once after enabling ChayMedia and make sure ElvUI or Details is also enabled.
