local addonName = ...
local initialized = false
local isMirroring = false
local sharedMedia

local media = {
    { name = "CHAY_CE - Bushido 1", file = "JiberishBushido1.tga" },
    { name = "CHAY_CE - Bushido 2", file = "JiberishBushido2.tga" },
    { name = "CHAY_CE - Bushido 3", file = "JiberishBushido3.tga" },
    { name = "CHAY_CE - Bushido 4", file = "JiberishBushido4.tga" },
}

local callbackOwner = {}

local function RegisterBundledMedia(LSM)
    local basePath = "Interface\\AddOns\\ChayMedia\\Media\\StatusBars\\"

    for _, item in ipairs(media) do
        local path = basePath .. item.file
        LSM:Register("statusbar", item.name, path)
        LSM:Register("background", item.name, path)
    end
end

local function MirrorTexture(LSM, sourceType, targetType, name, path)
    if type(name) ~= "string" or name == "" then
        return
    end

    if type(path) ~= "string" or path == "" then
        return
    end

    if LSM:IsValid(targetType, name) then
        return
    end

    LSM:Register(targetType, name, path)
end

local function MirrorExistingTextures(LSM)
    local statusbars = LSM:HashTable("statusbar")
    if type(statusbars) == "table" then
        for name, path in pairs(statusbars) do
            MirrorTexture(LSM, "statusbar", "background", name, path)
        end
    end

    local backgrounds = LSM:HashTable("background")
    if type(backgrounds) == "table" then
        for name, path in pairs(backgrounds) do
            MirrorTexture(LSM, "background", "statusbar", name, path)
        end
    end
end

function callbackOwner:OnSharedMediaRegistered(_, mediaType, name)
    if isMirroring or not sharedMedia then
        return
    end

    if mediaType ~= "statusbar" and mediaType ~= "background" then
        return
    end

    local targetType = mediaType == "statusbar" and "background" or "statusbar"
    local path = sharedMedia:Fetch(mediaType, name, true)

    if type(path) ~= "string" or path == "" then
        return
    end

    isMirroring = true
    MirrorTexture(sharedMedia, mediaType, targetType, name, path)
    isMirroring = false
end

local function InitializeSharedMedia()
    if initialized then
        return true
    end

    local libStub = _G.LibStub
    if not libStub then
        return false
    end

    local LSM = libStub("LibSharedMedia-3.0", true)
    if not LSM
        or type(LSM.Register) ~= "function"
        or type(LSM.Fetch) ~= "function"
        or type(LSM.HashTable) ~= "function"
        or type(LSM.IsValid) ~= "function"
        or type(LSM.RegisterCallback) ~= "function"
    then
        return false
    end

    sharedMedia = LSM

    RegisterBundledMedia(LSM)

    isMirroring = true
    MirrorExistingTextures(LSM)
    isMirroring = false

    LSM.RegisterCallback(callbackOwner, "LibSharedMedia_Registered", "OnSharedMediaRegistered")

    initialized = true
    return true
end

if not InitializeSharedMedia() then
    local frame = CreateFrame("Frame")

    frame:RegisterEvent("ADDON_LOADED")
    frame:RegisterEvent("PLAYER_LOGIN")

    frame:SetScript("OnEvent", function(self)
        if InitializeSharedMedia() then
            self:UnregisterAllEvents()
            self:SetScript("OnEvent", nil)
        end
    end)
end
