local addonName = ...
local registered = false

local media = {
    { name = "CHAY_CE - Bushido 1", file = "JiberishBushido1.tga" },
    { name = "CHAY_CE - Bushido 2", file = "JiberishBushido2.tga" },
    { name = "CHAY_CE - Bushido 3", file = "JiberishBushido3.tga" },
    { name = "CHAY_CE - Bushido 4", file = "JiberishBushido4.tga" },
}

local function RegisterMedia()
    if registered then
        return true
    end

    local libStub = _G.LibStub
    if not libStub then
        return false
    end

    local LSM = libStub("LibSharedMedia-3.0", true)
    if not LSM or type(LSM.Register) ~= "function" then
        return false
    end

    local basePath = "Interface\\AddOns\\ChayMedia\\Media\\StatusBars\\"

    for _, item in ipairs(media) do
        LSM:Register("statusbar", item.name, basePath .. item.file)
        LSM:Register("background", item.name, basePath .. item.file)
    end

    registered = true
    return true
end

if not RegisterMedia() then
    local frame = CreateFrame("Frame")

    frame:RegisterEvent("ADDON_LOADED")
    frame:RegisterEvent("PLAYER_LOGIN")

    frame:SetScript("OnEvent", function(self)
        if RegisterMedia() then
            self:UnregisterAllEvents()
            self:SetScript("OnEvent", nil)
        end
    end)
end
