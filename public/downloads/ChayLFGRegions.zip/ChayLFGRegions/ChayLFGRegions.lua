local ADDON_NAME = ...

local addon = CreateFrame("Frame")
local db
local installed = false
local warned = false

local REGION_ORDER = { "US", "OCE", "LATAM", "BR", "OTHER" }
local SETTING_FOR_REGION = {
    US = "showUS",
    OCE = "showOCE",
    LATAM = "showLATAM",
    BR = "showBR",
    OTHER = "showOther",
}

local DEFAULTS = {
    showUS = true,
    showOCE = true,
    showLATAM = true,
    showBR = true,
    showOther = true,
    sortByRegion = true,
}

-- Independent realm classification table.
-- This addon does not read or modify GroupfinderFlags saved variables or runtime tables.
local REALM_REGION = {
    ["Aegwynn"] = "US",
    ["AeriePeak"] = "US",
    ["Agamaggan"] = "US",
    ["Aggramar"] = "US",
    ["Akama"] = "US",
    ["Alexstrasza"] = "US",
    ["Alleria"] = "US",
    ["AltarofStorms"] = "US",
    ["AlteracMountains"] = "US",
    ["Aman'Thul"] = "OCE",
    ["Andorhal"] = "US",
    ["Anetheron"] = "US",
    ["Antonidas"] = "US",
    ["Anub'arak"] = "US",
    ["Anvilmar"] = "US",
    ["Arathor"] = "US",
    ["Archimonde"] = "US",
    ["Area52"] = "US",
    ["ArgentDawn"] = "US",
    ["Arthas"] = "US",
    ["Arygos"] = "US",
    ["Auchindoun"] = "US",
    ["Azgalor"] = "US",
    ["Azjol-Nerub"] = "US",
    ["Azralon"] = "BR",
    ["Azshara"] = "US",
    ["Azuremyst"] = "US",
    ["Baelgun"] = "US",
    ["Balnazzar"] = "US",
    ["Barthilas"] = "OCE",
    ["BlackDragonflight"] = "US",
    ["Blackhand"] = "US",
    ["Blackrock"] = "US",
    ["BlackwaterRaiders"] = "US",
    ["BlackwingLair"] = "US",
    ["Blade'sEdge"] = "US",
    ["Bladefist"] = "US",
    ["BleedingHollow"] = "US",
    ["BloodFurnace"] = "US",
    ["Bloodhoof"] = "US",
    ["Bloodscalp"] = "US",
    ["Bonechewer"] = "US",
    ["BoreanTundra"] = "US",
    ["Boulderfist"] = "US",
    ["Bronzebeard"] = "US",
    ["BurningBlade"] = "US",
    ["BurningLegion"] = "US",
    ["Caelestrasz"] = "OCE",
    ["Cairne"] = "US",
    ["CenarionCircle"] = "US",
    ["Cenarius"] = "US",
    ["Cho'gall"] = "US",
    ["Chromaggus"] = "US",
    ["Coilfang"] = "US",
    ["Crushridge"] = "US",
    ["Daggerspine"] = "US",
    ["Dalaran"] = "US",
    ["Dalvengyr"] = "US",
    ["DarkIron"] = "US",
    ["Darkspear"] = "US",
    ["Darrowmere"] = "US",
    ["Dath'Remar"] = "OCE",
    ["Dawnbringer"] = "US",
    ["Deathwing"] = "US",
    ["DemonSoul"] = "US",
    ["Dentarg"] = "US",
    ["Destromath"] = "US",
    ["Dethecus"] = "US",
    ["Detheroc"] = "US",
    ["Doomhammer"] = "US",
    ["Draenor"] = "US",
    ["Dragonblight"] = "US",
    ["Dragonmaw"] = "US",
    ["Drak'Tharon"] = "US",
    ["Drak'thul"] = "US",
    ["Draka"] = "US",
    ["Drakkari"] = "LATAM",
    ["Dreadmaul"] = "OCE",
    ["Drenden"] = "US",
    ["Dunemaul"] = "US",
    ["Durotan"] = "US",
    ["Duskwood"] = "US",
    ["EarthenRing"] = "US",
    ["EchoIsles"] = "US",
    ["Eitrigg"] = "US",
    ["Eldre'Thalas"] = "US",
    ["Elune"] = "US",
    ["EmeraldDream"] = "US",
    ["Eonar"] = "US",
    ["Eredar"] = "US",
    ["Executus"] = "US",
    ["Exodar"] = "US",
    ["Farstriders"] = "US",
    ["Feathermoon"] = "US",
    ["Fenris"] = "US",
    ["Firetree"] = "US",
    ["Fizzcrank"] = "US",
    ["Frostmane"] = "US",
    ["Frostmourne"] = "OCE",
    ["Frostwolf"] = "US",
    ["Galakrond"] = "US",
    ["Gallywix"] = "BR",
    ["Garithos"] = "US",
    ["Garona"] = "US",
    ["Garrosh"] = "US",
    ["Ghostlands"] = "US",
    ["Gilneas"] = "US",
    ["Gnomeregan"] = "US",
    ["Goldrinn"] = "BR",
    ["Gorefiend"] = "US",
    ["Gorgonnash"] = "US",
    ["Greymane"] = "US",
    ["GrizzlyHills"] = "US",
    ["Gul'dan"] = "US",
    ["Gundrak"] = "OCE",
    ["Gurubashi"] = "US",
    ["Hakkar"] = "US",
    ["Haomarush"] = "US",
    ["Hellscream"] = "US",
    ["Hydraxis"] = "US",
    ["Hyjal"] = "US",
    ["Icecrown"] = "US",
    ["Illidan"] = "US",
    ["Jaedenar"] = "US",
    ["Jubei'Thos"] = "OCE",
    ["Kael'thas"] = "US",
    ["Kalecgos"] = "US",
    ["Kargath"] = "US",
    ["Kel'Thuzad"] = "US",
    ["Khadgar"] = "US",
    ["Khaz'goroth"] = "OCE",
    ["KhazModan"] = "US",
    ["Kil'jaeden"] = "US",
    ["Kilrogg"] = "US",
    ["KirinTor"] = "US",
    ["Korgath"] = "US",
    ["Korialstrasz"] = "US",
    ["KulTiras"] = "US",
    ["LaughingSkull"] = "US",
    ["Lethon"] = "US",
    ["Lightbringer"] = "US",
    ["Lightning'sBlade"] = "US",
    ["Lightninghoof"] = "US",
    ["Llane"] = "US",
    ["Lothar"] = "US",
    ["Madoran"] = "US",
    ["Maelstrom"] = "US",
    ["Magtheridon"] = "US",
    ["Maiev"] = "US",
    ["Mal'Ganis"] = "US",
    ["Malfurion"] = "US",
    ["Malorne"] = "US",
    ["Malygos"] = "US",
    ["Mannoroth"] = "US",
    ["Medivh"] = "US",
    ["Misha"] = "US",
    ["Mok'Nathal"] = "US",
    ["MoonGuard"] = "US",
    ["Moonrunner"] = "US",
    ["Mug'thol"] = "US",
    ["Muradin"] = "US",
    ["Nagrand"] = "OCE",
    ["Nathrezim"] = "US",
    ["Nazgrel"] = "US",
    ["Nazjatar"] = "US",
    ["Nemesis"] = "BR",
    ["Ner'zhul"] = "US",
    ["Nesingwary"] = "US",
    ["Nordrassil"] = "US",
    ["Norgannon"] = "US",
    ["Onyxia"] = "US",
    ["Perenolde"] = "US",
    ["Proudmoore"] = "US",
    ["Quel'dorei"] = "US",
    ["Quel'Thalas"] = "LATAM",
    ["Ragnaros"] = "LATAM",
    ["Ravencrest"] = "US",
    ["Ravenholdt"] = "US",
    ["Rexxar"] = "US",
    ["Rivendare"] = "US",
    ["Runetotem"] = "US",
    ["Sargeras"] = "US",
    ["Saurfang"] = "OCE",
    ["ScarletCrusade"] = "US",
    ["Scilla"] = "US",
    ["Sen'jin"] = "US",
    ["Sentinels"] = "US",
    ["ShadowCouncil"] = "US",
    ["Shadowmoon"] = "US",
    ["Shadowsong"] = "US",
    ["Shandris"] = "US",
    ["ShatteredHalls"] = "US",
    ["ShatteredHand"] = "US",
    ["Shu'halo"] = "US",
    ["SilverHand"] = "US",
    ["Silvermoon"] = "US",
    ["SistersofElune"] = "US",
    ["Skullcrusher"] = "US",
    ["Skywall"] = "US",
    ["Smolderthorn"] = "US",
    ["Spinebreaker"] = "US",
    ["Spirestone"] = "US",
    ["Staghelm"] = "US",
    ["SteamwheedleCartel"] = "US",
    ["Stonemaul"] = "US",
    ["Stormrage"] = "US",
    ["Stormreaver"] = "US",
    ["Stormscale"] = "US",
    ["Suramar"] = "US",
    ["Tanaris"] = "US",
    ["Terenas"] = "US",
    ["Terokkar"] = "US",
    ["Thaurissan"] = "OCE",
    ["TheForgottenCoast"] = "US",
    ["TheScryers"] = "US",
    ["TheUnderbog"] = "US",
    ["TheVentureCo"] = "US",
    ["ThoriumBrotherhood"] = "US",
    ["Thrall"] = "US",
    ["Thunderhorn"] = "US",
    ["Thunderlord"] = "US",
    ["Tichondrius"] = "US",
    ["TolBarad"] = "BR",
    ["Tortheldrin"] = "US",
    ["Trollbane"] = "US",
    ["Turalyon"] = "US",
    ["TwistingNether"] = "US",
    ["Uldaman"] = "US",
    ["Uldum"] = "US",
    ["Undermine"] = "US",
    ["Ursin"] = "US",
    ["Uther"] = "US",
    ["Vashj"] = "US",
    ["Vek'nilash"] = "US",
    ["Velen"] = "US",
    ["Warsong"] = "US",
    ["Whisperwind"] = "US",
    ["Wildhammer"] = "US",
    ["Windrunner"] = "US",
    ["Winterhoof"] = "US",
    ["WyrmrestAccord"] = "US",
    ["Ysera"] = "US",
    ["Ysondre"] = "US",
    ["Zangarmarsh"] = "US",
    ["Zul'jin"] = "US",
    ["Zuluhed"] = "US",
}

local function NormalizeRealmName(realmName)
    if not realmName or realmName == "" then
        return nil
    end

    return realmName:gsub("[%s%-]", "")
end

local function InitializeDB()
    if type(ChayLFGRegionsDB) ~= "table" then
        ChayLFGRegionsDB = {}
    end

    for key, value in pairs(DEFAULTS) do
        if ChayLFGRegionsDB[key] == nil then
            ChayLFGRegionsDB[key] = value
        end
    end

    db = ChayLFGRegionsDB
end

local function GetResultRegion(resultID)
    if not canaccessvalue(resultID) then
        return "OTHER"
    end

    local info = C_LFGList.GetSearchResultInfo(resultID)
    if not canaccessvalue(info) or info == nil then
        return "OTHER"
    end

    local leaderName = info.leaderName
    if not canaccessvalue(leaderName) or leaderName == nil or leaderName == "" then
        return "OTHER"
    end

    local shortName = Ambiguate(leaderName, "short")
    local fullName = Ambiguate(leaderName, "mail")

    if not canaccessvalue(shortName) or not canaccessvalue(fullName) then
        return "OTHER"
    end

    if shortName == nil or fullName == nil or shortName == "" or fullName == "" then
        return "OTHER"
    end

    local realmName
    if shortName == fullName then
        realmName = GetRealmName()
    else
        local startIndex = string.len(shortName) + 2
        realmName = string.sub(fullName, startIndex)
    end

    realmName = NormalizeRealmName(realmName)
    if not realmName then
        return "OTHER"
    end

    return REALM_REGION[realmName] or "OTHER"
end

local function BuildFilteredResults(results)
    local buckets
    local filtered = {}

    if db.sortByRegion then
        buckets = {
            US = {},
            OCE = {},
            LATAM = {},
            BR = {},
            OTHER = {},
        }
    end

    for index = 1, #results do
        local resultID = results[index]
        local region = GetResultRegion(resultID)
        local settingKey = SETTING_FOR_REGION[region]

        if settingKey and db[settingKey] then
            if buckets then
                local bucket = buckets[region]
                bucket[#bucket + 1] = resultID
            else
                filtered[#filtered + 1] = resultID
            end
        end
    end

    if buckets then
        for orderIndex = 1, #REGION_ORDER do
            local region = REGION_ORDER[orderIndex]
            local bucket = buckets[region]
            for resultIndex = 1, #bucket do
                filtered[#filtered + 1] = bucket[resultIndex]
            end
        end
    end

    return filtered
end

local function ApplyRegionFilterAndSort(panel)
    if not db or not panel or type(panel.results) ~= "table" then
        return
    end

    local ok, filtered = pcall(BuildFilteredResults, panel.results)
    if not ok then
        if not warned then
            warned = true
            print("|cffff5555ChayLFGRegions:|r Region filtering was skipped because the current LFG data could not be safely read.")
        end
        return
    end

    local results = panel.results
    wipe(results)

    for index = 1, #filtered do
        results[index] = filtered[index]
    end
end

local function RefreshResults()
    local frame = _G.LFGListFrame
    local panel = frame and frame.SearchPanel

    if not panel or not panel:IsShown() then
        return
    end

    if type(_G.LFGListSearchPanel_UpdateResultList) == "function" then
        _G.LFGListSearchPanel_UpdateResultList(panel)
    end
end

local function SetCheckboxTooltip(checkButton, text)
    checkButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(text, 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)

    checkButton:SetScript("OnLeave", GameTooltip_Hide)
end

local function CreateCheckbox(parent, labelText, settingKey, tooltipText)
    local checkButton = CreateFrame("CheckButton", nil, parent)
    checkButton:SetSize(18, 18)
    checkButton:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
    checkButton:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
    checkButton:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
    checkButton:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
    checkButton:SetDisabledCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check-Disabled")

    local label = checkButton:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    label:SetPoint("LEFT", checkButton, "RIGHT", 1, 0)
    label:SetText(labelText)

    local labelWidth = math.ceil(label:GetStringWidth())
    checkButton:SetHitRectInsets(0, -(labelWidth + 4), 0, 0)
    checkButton:SetChecked(db[settingKey])

    checkButton:SetScript("OnClick", function(self)
        local checked = self:GetChecked() and true or false
        db[settingKey] = checked

        if checked then
            PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        else
            PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF)
        end

        RefreshResults()
    end)

    SetCheckboxTooltip(checkButton, tooltipText)

    checkButton.Label = label
    checkButton.TotalWidth = 18 + labelWidth + 9
    return checkButton
end

local function LayoutSearchPanel(panel, bar)
    if not panel or not panel.SearchBox or not panel.FilterButton or not panel.ResultsInset then
        return
    end

    bar:ClearAllPoints()
    bar:SetPoint("TOPLEFT", panel.SearchBox, "BOTTOMLEFT", -4, -4)
    bar:SetPoint("TOPRIGHT", panel.FilterButton, "BOTTOMRIGHT", 0, -4)
    bar:SetHeight(20)

    panel.ResultsInset:ClearAllPoints()
    panel.ResultsInset:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", -1, -2)
    panel.ResultsInset:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -25, 26)
end

local function CreateRegionControls()
    local frame = _G.LFGListFrame
    local panel = frame and frame.SearchPanel

    if not panel or panel.ChayLFGRegionsBar then
        return
    end

    if not panel.SearchBox or not panel.FilterButton or not panel.ResultsInset then
        return
    end

    local bar = CreateFrame("Frame", nil, panel)
    bar:SetFrameLevel(math.max(panel:GetFrameLevel(), panel.ResultsInset:GetFrameLevel()) + 2)

    local controls = {
        { "US", "showUS", "Show North American English-realm listings." },
        { "OCE", "showOCE", "Show Oceanic listings." },
        { "LATAM", "showLATAM", "Show Latin American listings." },
        { "BR", "showBR", "Show Brazilian listings." },
        { "Other", "showOther", "Show unclassified listings. Keep this enabled if you want listings to remain visible when Midnight restrictions make leader realm data inaccessible." },
        { "Sort", "sortByRegion", "Group visible listings by region while preserving Blizzard's order inside each region." },
    }

    local previous
    for index = 1, #controls do
        local control = controls[index]
        local checkButton = CreateCheckbox(bar, control[1], control[2], control[3])

        if previous then
            checkButton:SetPoint("LEFT", previous.Label, "RIGHT", 9, 0)
        else
            checkButton:SetPoint("LEFT", bar, "LEFT", 0, 0)
        end

        previous = checkButton
    end

    panel.ChayLFGRegionsBar = bar
    LayoutSearchPanel(panel, bar)

    panel:HookScript("OnShow", function()
        LayoutSearchPanel(panel, bar)
    end)
end

local function Install()
    if installed or not db then
        return
    end

    if GetCurrentRegionName and GetCurrentRegionName() ~= "US" then
        return
    end

    if type(_G.LFGListUtil_SortSearchResults) ~= "function" or not _G.LFGListFrame then
        return
    end

    hooksecurefunc("LFGListUtil_SortSearchResults", function(panel)
        ApplyRegionFilterAndSort(panel)
    end)

    hooksecurefunc("LFGListSearchPanel_UpdateResults", function(panel)
        if not db or panel.searching or type(panel.results) ~= "table" then
            return
        end

        local applications = panel.applications
        local hasApplications = type(applications) == "table" and #applications > 0

        if #panel.results == 0 and not hasApplications and panel.totalResults and panel.totalResults > 0 then
            panel.ScrollBox.NoResultsFound:SetText("No groups match the selected regions.")
            panel.ScrollBox.NoResultsFound:Show()
            panel.ScrollBox.StartGroupButton:Hide()
        end
    end)

    CreateRegionControls()
    installed = true
end

addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("PLAYER_LOGIN")
addon:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == ADDON_NAME then
            InitializeDB()
            Install()
        elseif arg1 == "Blizzard_GroupFinder" then
            Install()
        end
    elseif event == "PLAYER_LOGIN" then
        Install()
        self:UnregisterEvent("PLAYER_LOGIN")
    end
end)
