local ADDON_NAME = ...

local CAP = {}
_G.ChayAddonProfiles = CAP

local MEDIA_LOGO = "Interface\\AddOns\\ChayAddonProfiles\\Media\\Logo"
local MEDIA_LOGO_SQUARE = "Interface\\AddOns\\ChayAddonProfiles\\Media\\LogoSquare"
local MEDIA_BACKGROUND = "Interface\\AddOns\\ChayAddonProfiles\\Media\\Background"
local MEDIA_DRAGON = "Interface\\AddOns\\ChayAddonProfiles\\Media\\Dragon"
local MEDIA_HEADER_ART = "Interface\\AddOns\\ChayAddonProfiles\\Media\\HeaderArt"

local PROFILE_ORDER = { "raid", "mplus", "dungeon", "delve", "world", "city", "pvp" }
local PROFILE_LABELS = {
    raid = "Raid",
    mplus = "M+",
    dungeon = "Dungeon",
    delve = "Delve",
    world = "World",
    city = "City",
    pvp = "PvP",
}

local PROFILE_SHORT_LABELS = {
    raid = "Raid",
    mplus = "M+",
    dungeon = "Dung",
    delve = "Delv",
    world = "World",
    city = "City",
    pvp = "PvP",
}

local PROFILE_COLORS = {
    raid = { r = 0.95, g = 0.28, b = 0.28 },
    mplus = { r = 0.96, g = 0.52, b = 0.20 },
    dungeon = { r = 0.96, g = 0.76, b = 0.22 },
    delve = { r = 0.38, g = 0.95, b = 0.70 },
    world = { r = 0.30, g = 0.86, b = 0.38 },
    city = { r = 0.28, g = 0.78, b = 0.96 },
    pvp = { r = 0.80, g = 0.44, b = 0.95 },
}

local function GetColumnShade(index, isHeader)
    if index % 2 == 1 then
        if isHeader then
            return 0.11, 0.11, 0.11, 0.22
        end
        return 0.10, 0.10, 0.10, 0.07
    end
    if isHeader then
        return 0.05, 0.05, 0.05, 0.16
    end
    return 0.04, 0.04, 0.04, 0.05
end

local DEFAULT_DB = {
    version = 167,
    knownAddOns = {},
    rulesBackup = nil,
    rulesBackupInfo = nil,
    addonRules = {},
    addonNotes = {},
    protectedAddonDisabled = {},
    settings = {
        autoPrompt = true,
        dontShowPrompts = false,
        detectNewAddOns = true,
        newAddOnDefault = true,
        perCharacter = true,
        linkDungeonMPlus = true,
        linkWorldCity = true,
        showMinimapButton = true,
        darkenPanels = false,
        minimapAngle = 225,
        textSize = 13,
        sortMode = "name",
        sortMemDesc = true,
        groupDependencies = false,
        protectCoreAddons = true,
        framePoint = { point = "CENTER", relativePoint = "CENTER", x = 0, y = 0 },
        frameSize = { width = 1220, height = 760 },
        promptPoint = { point = "CENTER", relativePoint = "CENTER", x = 0, y = 170 },
    },
}

local DEFAULT_CHAR_DB = {
    lastEffectiveProfile = nil,
    loadedProfile = nil,
    pendingProfile = nil,
}

local MIN_WIDTH = 760
local MIN_HEIGHT = 520
local MAX_WIDTH = 1900
local MAX_HEIGHT = 1100

local frame = CreateFrame("Frame")
local mainFrame, sidePanel, mainPanel, scrollFrame, scrollChild, statusText, profileText, searchBox, searchClearButton, minimapButton
local resizeGrip, titleLogo, sideLogo, watermarkLogo, applyPromptFrame, previewFrame, notesFrame
local filterButton, headerSquareLogo
local headerArtPanel
local reviewButton
local rows = {}
local addonList = {}
local visibleAddons = {}
local currentProfile = "world"
local currentEffectiveProfile = "world"
local pendingEffectiveProfile = nil
local loginComplete = false
local suppressPromptsUntil = 0
local queuedProfileCheck = false
local lastPromptProfile = nil
local updateUsageButton
local optionControls = {}
local columnButtons = {}
local quickProfileButtons = {}
local lastScanReport = { new = {}, removed = {}, incompatible = {}, noRules = {} }

local function CopyDefaults(src, dst)
    if type(dst) ~= "table" then
        dst = {}
    end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
    return dst
end

local function DB()
    ChayAddonProfilesDB = CopyDefaults(DEFAULT_DB, ChayAddonProfilesDB)
    return ChayAddonProfilesDB
end

local function CDB()
    ChayAddonProfilesCharDB = CopyDefaults(DEFAULT_CHAR_DB, ChayAddonProfilesCharDB)
    return ChayAddonProfilesCharDB
end

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cffff3030Chay Addon Profiles:|r " .. tostring(msg))
end

local function AddOnsAPI(name, ...)
    if C_AddOns and C_AddOns[name] then
        return C_AddOns[name](...)
    end
    return nil
end

local function ReloadNow()
    ReloadUI()
end

local function Clamp(value, minValue, maxValue)
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function GetEffectiveTextSize()
    return Clamp(DB().settings.textSize or 13, 10, 30)
end

local function GetTimeSafe()
    return GetTime and GetTime() or 0
end

local function EffectiveProfile(profile)
    local db = DB()
    if db.settings.linkDungeonMPlus and (profile == "mplus" or profile == "dungeon") then
        return "dungeon"
    end
    if db.settings.linkWorldCity and (profile == "world" or profile == "city") then
        return "world"
    end
    return profile
end

local function GetProfileDisplay(profile)
    local effective = EffectiveProfile(profile)
    if effective == "dungeon" and DB().settings.linkDungeonMPlus then
        return "Dungeon / M+"
    end
    if effective == "world" and DB().settings.linkWorldCity then
        return "World / City"
    end
    return PROFILE_LABELS[effective] or effective
end

local function GetNumAddOnsSafe()
    return AddOnsAPI("GetNumAddOns") or 0
end

local function GetAddOnInfoSafe(index)
    return AddOnsAPI("GetAddOnInfo", index)
end

local function GetAddOnMetadataSafe(name, key)
    return AddOnsAPI("GetAddOnMetadata", name, key)
end

local function GetEnableState(name)
    local character = DB().settings.perCharacter and UnitName("player") or nil
    local state
    if character then
        state = AddOnsAPI("GetAddOnEnableState", name, character)
    end
    if state == nil then
        state = AddOnsAPI("GetAddOnEnableState", name)
    end
    return tonumber(state) or 0
end

local function IsEnabled(name)
    return GetEnableState(name) > 0
end

local function IsLibraryLike(name, title)
    local n = tostring(name or "")
    local t = tostring(title or "")
    if n == "LibStub" or n == "CallbackHandler-1.0" then return true end
    if n:match("^Ace3") or n:match("^Lib") or n:match("^AceGUI") or n:match("^AceConfig") then return true end
    if t:match("^Lib") or t:match("Library") then return true end
    return false
end

local CORE_PROTECTED_ADDONS = {
    ChayAddonProfiles = true,
    ElvUI = true,
    BigWigs = true,
    LittleWigs = true,
    WeakAuras = true,
    WeakAurasOptions = true,
    Details = true,
    Details_EncounterDetails = true,
    Details_RaidCheck = true,
    Details_DataStorage = true,
    DBM_Core = true,
    ["DBM-Core"] = true,
    ["DBM-GUI"] = true,
    ["DBM-StatusBarTimers"] = true,
}

local function IsCoreProtectedAddon(name, title)
    if not DB().settings.protectCoreAddons then return false end
    local n = tostring(name or "")
    local t = tostring(title or "")
    if CORE_PROTECTED_ADDONS[n] then return true end
    if n == "BigWigs_Core" or n == "BigWigs_Options" or n == "BigWigs_Plugins" then return true end
    if n == "LittleWigs_Core" or n == "LittleWigs_Options" then return true end
    if n:match("^ElvUI_[Cc]ore") or n:match("^ElvUI_Libraries") then return true end
    if t == "BigWigs" or t == "LittleWigs" or t == "ElvUI" or t == "WeakAuras" or t == "Details! Damage Meter" then return true end
    return false
end

local function IsProtectedOverrideDisabled(name)
    local db = DB()
    return db.protectedAddonDisabled and db.protectedAddonDisabled[name] and true or false
end

local function SetProtectedOverrideDisabled(name, disabled)
    local db = DB()
    db.protectedAddonDisabled = db.protectedAddonDisabled or {}
    if disabled then
        db.protectedAddonDisabled[name] = true
    else
        db.protectedAddonDisabled[name] = nil
    end
end

local function IsProtectedAddon(name, title)
    if not name or name == "" then return true end
    if name == ADDON_NAME then return true end
    if name:match("^Blizzard_") then return true end
    if IsLibraryLike(name, title) then return true end
    if IsCoreProtectedAddon(name, title) then return true end
    return false
end

local function IsIncompatible(reason)
    if reason == "INTERFACE_VERSION" or reason == "TOO_NEW" then
        return true
    end
    return false
end

local function FormatMemory(kb)
    kb = tonumber(kb) or 0
    if kb >= 1024 then
        return string.format("%.1f MB", kb / 1024)
    end
    return string.format("%d KB", kb)
end

local function SafeAddonKey(name)
    return tostring(name or ""):gsub("[^%w_]", "_")
end

local function SetAddonEnabledForNextLoad(name, enabled)
    local character = DB().settings.perCharacter and UnitName("player") or nil
    if enabled then
        if character then
            pcall(AddOnsAPI, "EnableAddOn", name, character)
        else
            pcall(AddOnsAPI, "EnableAddOn", name)
        end
    else
        if character then
            pcall(AddOnsAPI, "DisableAddOn", name, character)
        else
            pcall(AddOnsAPI, "DisableAddOn", name)
        end
    end
end

local function EnsureRulesForAddon(name, title, incompatible)
    local db = DB()
    db.addonRules[name] = db.addonRules[name] or {}
    local protected = IsProtectedAddon(name, title)

    for _, key in ipairs(PROFILE_ORDER) do
        if db.addonRules[name][key] == nil then
            db.addonRules[name][key] = db.settings.newAddOnDefault and true or false
        end
    end

    if protected and not IsProtectedOverrideDisabled(name) then
        for _, key in ipairs(PROFILE_ORDER) do
            db.addonRules[name][key] = true
        end
    end

    if incompatible then
        for _, key in ipairs(PROFILE_ORDER) do
            db.addonRules[name][key] = false
        end
        SetAddonEnabledForNextLoad(name, false)
    end
end

local function DesiredEnabled(name, profile)
    local db = DB()
    local rules = db.addonRules[name]
    if not rules then return true end
    local effective = EffectiveProfile(profile)
    return rules[effective] and true or false
end

local function SetRule(name, profile, value)
    local db = DB()
    local rules = db.addonRules[name]
    if not rules then return end

    rules[profile] = value and true or false

    if db.settings.linkDungeonMPlus and (profile == "dungeon" or profile == "mplus") then
        rules.dungeon = value and true or false
        rules.mplus = value and true or false
    end
    if db.settings.linkWorldCity and (profile == "world" or profile == "city") then
        rules.world = value and true or false
        rules.city = value and true or false
    end
end

local function SetAllProfilesForAddon(addon, value)
    if addon.protected and not IsProtectedOverrideDisabled(addon.name) and not value then return end
    if addon.incompatible then value = false end
    if addon.protected and value then
        SetProtectedOverrideDisabled(addon.name, false)
    end
    for _, key in ipairs(PROFILE_ORDER) do
        SetRule(addon.name, key, value)
    end
end

local function ScanAddOns(showMessages)
    local db = DB()
    local current = {}
    local newAddons = {}
    local removed = {}
    local incompatibleAddons = {}
    local noRuleAddons = {}

    wipe(addonList)

    for i = 1, GetNumAddOnsSafe() do
        local name, title, notes, loadable, reason, security, newVersion = GetAddOnInfoSafe(i)
        if name and name ~= "" then
            title = title and title ~= "" and title or name
            local hadRules = db.addonRules[name] ~= nil
            local incompatible = IsIncompatible(reason)
            local protected = IsProtectedAddon(name, title)
            local mem = 0
            if GetAddOnMemoryUsage then
                mem = tonumber(GetAddOnMemoryUsage(name)) or 0
            end

            current[name] = true
            EnsureRulesForAddon(name, title, incompatible)

            addonList[#addonList + 1] = {
                index = i,
                name = name,
                key = SafeAddonKey(name),
                title = title,
                notes = notes or "",
                loadable = loadable,
                reason = reason,
                security = security,
                newVersion = newVersion,
                protected = protected,
                incompatible = incompatible,
                memory = mem,
            }

            if db.settings.detectNewAddOns and not db.knownAddOns[name] then
                newAddons[#newAddons + 1] = title
            end
            if not hadRules then
                noRuleAddons[#noRuleAddons + 1] = title
            end
            if incompatible then
                incompatibleAddons[#incompatibleAddons + 1] = title
            end
            db.knownAddOns[name] = true
        end
    end

    for knownName in pairs(db.knownAddOns) do
        if not current[knownName] then
            removed[#removed + 1] = knownName
            db.knownAddOns[knownName] = nil
            db.addonRules[knownName] = nil
        end
    end

    lastScanReport = {
        new = newAddons,
        removed = removed,
        incompatible = incompatibleAddons,
        noRules = noRuleAddons,
    }

    if showMessages then
        if #newAddons > 0 then
            Print(#newAddons .. " new addon(s) detected.")
        end
        if #removed > 0 then
            Print(#removed .. " removed addon(s) cleaned from rules.")
        end
    end

    return newAddons, removed
end

local function TrimText(value)
    value = tostring(value or "")
    value = value:gsub("^%s+", ""):gsub("%s+$", "")
    return value
end

local GROUP_PREFIXES = {
    "BigWigs", "LittleWigs", "WeakAuras", "Raider.IO", "RaiderIO", "ElvUI", "Exwind", "EXwind",
    "ExBoss", "EXBoss", "Details", "HandyNotes", "Method Raid Tools", "Mythic Dungeon Tools",
    "Plater", "DBM", "Deadly Boss Mods", "RCLootCouncil", "Simulationcraft", "SimulationCraft",
}

local function GetAddonGroupKey(addon)
    local title = TrimText(addon and addon.title or addon and addon.name or "")
    local name = TrimText(addon and addon.name or title)
    local combined = title .. " " .. name

    for _, prefix in ipairs(GROUP_PREFIXES) do
        if combined:lower():find(prefix:lower(), 1, true) then
            return prefix:lower(), prefix
        end
    end

    local base = title
    base = base:gsub("%s*%b[]", "")
    base = base:gsub("%s*%b()", "")
    base = base:match("^([^:]+):") or base
    base = base:match("^([^%-]+)%s+%-") or base
    base = base:match("^([^_]+)_") or base
    base = TrimText(base)
    if base == "" then base = title ~= "" and title or name end
    return strlower(base), base
end

local function IsLikelyGroupParent(addon, display)
    local title = TrimText(addon.title or addon.name)
    local name = TrimText(addon.name or title)
    local d = TrimText(display)
    return strlower(title) == strlower(d) or strlower(name) == strlower(d)
end

local function SortAddons()
    local db = DB()
    if db.settings.sortMode == "memory" then
        table.sort(addonList, function(a, b)
            if a.memory == b.memory then
                return strlower(a.title or a.name) < strlower(b.title or b.name)
            end
            if db.settings.sortMemDesc then
                return a.memory > b.memory
            end
            return a.memory < b.memory
        end)
    elseif db.settings.sortMode == "group" or db.settings.groupDependencies then
        table.sort(addonList, function(a, b)
            local ag, ad = GetAddonGroupKey(a)
            local bg, bd = GetAddonGroupKey(b)
            if ag ~= bg then return ag < bg end
            local ap = IsLikelyGroupParent(a, ad) and 0 or 1
            local bp = IsLikelyGroupParent(b, bd) and 0 or 1
            if ap ~= bp then return ap < bp end
            return strlower(a.title or a.name) < strlower(b.title or b.name)
        end)
    else
        table.sort(addonList, function(a, b)
            return strlower(a.title or a.name) < strlower(b.title or b.name)
        end)
    end
end

local function DetectProfile()
    local inInstance, instanceType, difficultyID = IsInInstance()
    if inInstance then
        if instanceType == "raid" then
            return "raid"
        elseif instanceType == "party" then
            if difficultyID == 8 then
                return "mplus"
            end
            return "dungeon"
        elseif instanceType == "scenario" then
            return "delve"
        elseif instanceType == "arena" or instanceType == "pvp" then
            return "pvp"
        end
    end
    if IsResting() then
        return "city"
    end
    return "world"
end

local function GetProfileDiff(profile)
    local enableList, disableList = {}, {}
    local effective = EffectiveProfile(profile)
    for _, addon in ipairs(addonList) do
        local enabled = IsEnabled(addon.name)
        if addon.incompatible then
            if enabled then
                disableList[#disableList + 1] = addon.name
            end
        elseif addon.protected and not IsProtectedOverrideDisabled(addon.name) then
            if not enabled then
                enableList[#enableList + 1] = addon.name
            end
        else
            local desired = DesiredEnabled(addon.name, effective)
            if desired and not enabled then
                enableList[#enableList + 1] = addon.name
            elseif not desired and enabled then
                disableList[#disableList + 1] = addon.name
            end
        end
    end
    return enableList, disableList
end

local function NeedsProfileApply(profile)
    local enableList, disableList = GetProfileDiff(profile)
    return (#enableList + #disableList) > 0, enableList, disableList
end

local function GetAddOnDisplayName(addonName)
    for _, addon in ipairs(addonList) do
        if addon.name == addonName then
            return addon.title or addon.name
        end
    end
    return addonName or "Unknown"
end

local function BuildCompactChangeSummary(enableList, disableList)
    local lines = {}

    local function AppendCompact(title, list)
        list = list or {}
        lines[#lines + 1] = title .. ":"
        if #list == 0 then
            lines[#lines + 1] = "  None"
            return
        end

        table.sort(list, function(a, b)
            return strlower(GetAddOnDisplayName(a)) < strlower(GetAddOnDisplayName(b))
        end)

        local limit = math.min(#list, 6)
        for i = 1, limit do
            lines[#lines + 1] = "  - " .. GetAddOnDisplayName(list[i])
        end
        if #list > limit then
            lines[#lines + 1] = "  +" .. tostring(#list - limit) .. " more"
        end
    end

    AppendCompact("Will Enable", enableList)
    lines[#lines + 1] = ""
    AppendCompact("Will Disable", disableList)

    return table.concat(lines, "\n")
end

local function BuildReloadBody(total, enableList, disableList)
    return tostring(total) .. " addon setting(s) changed.\n\n" .. BuildCompactChangeSummary(enableList, disableList)
end

local function SetStatusField(field, label, value, color)
    if not field then return end
    if field.label then
        field.label:SetText(label)
    end
    if field.value then
        field.value:SetText(value)
        field.value:SetTextColor(color.r, color.g, color.b, color.a or 1)
    end
end

local function UpdateProfileStatusText()
    local detected = currentEffectiveProfile or EffectiveProfile(DetectProfile())
    local loaded = CDB().loadedProfile or CDB().lastEffectiveProfile or detected
    local pending = CDB().pendingProfile or pendingEffectiveProfile

    if mainFrame and mainFrame.statusFields then
        SetStatusField(mainFrame.statusFields.current, "Current:", GetProfileDisplay(detected), { r = 1.00, g = 0.86, b = 0.12 })
        SetStatusField(mainFrame.statusFields.loaded, "Loaded:", GetProfileDisplay(loaded), { r = 0.20, g = 1.00, b = 0.32 })
        SetStatusField(mainFrame.statusFields.pending, "Pending:", pending and GetProfileDisplay(pending) or "None", pending and { r = 1.00, g = 0.18, b = 0.18 } or { r = 0.62, g = 0.62, b = 0.62 })
        SetStatusField(mainFrame.statusFields.combat, "Combat queued:", queuedProfileCheck and "Yes" or "No", queuedProfileCheck and { r = 1.00, g = 0.86, b = 0.12 } or { r = 0.94, g = 0.94, b = 0.94 })
    end

    if profileText then
        local text = "Current: |cffffdb1f" .. GetProfileDisplay(detected) .. "|r   Loaded: |cff30ff55" .. GetProfileDisplay(loaded) .. "|r"
        if pending then
            text = text .. "   Pending: |cffff3030" .. GetProfileDisplay(pending) .. "|r"
        else
            text = text .. "   Pending: |cff888888None|r"
        end
        text = text .. "   Combat queued: " .. (queuedProfileCheck and "|cffffdb1fYes|r" or "|cffffffffNo|r")
        profileText:SetText(text)
    end
end

local function HideApplyPopup()
    StaticPopup_Hide("CHAY_ADDON_PROFILES_APPLY")
    if applyPromptFrame then
        applyPromptFrame:Hide()
        applyPromptFrame:SetScript("OnUpdate", nil)
    end
end

StaticPopupDialogs["CHAY_ADDON_PROFILES_RELOAD"] = {
    text = "Chay Addon Profiles applied %s.\n\n%s\n\nReload UI now?",
    button1 = RELOADUI,
    button2 = CANCEL,
    OnAccept = function() ReloadNow() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["CHAY_ADDON_PROFILES_APPLY"] = {
    text = "%s profile differs from your current addon state.\n\nApply and reload?",
    button1 = "Apply",
    button2 = CANCEL,
    OnAccept = function(_, profile)
        CAP:ApplyProfile(profile)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["CHAY_ADDON_PROFILES_NEW"] = {
    text = "New addon(s) detected. Open Chay Addon Profiles to choose where they should load?",
    button1 = "Open",
    button2 = "Later",
    OnAccept = function() CAP:Show() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["CHAY_ADDON_PROFILES_CAPTURE"] = {
    text = "Capture your currently loaded addons into the %s profile?\n\nThis updates that profile's checkboxes to match what is enabled right now. It does not reload and it does not change addon load state until you apply a profile.",
    button1 = "Capture",
    button2 = CANCEL,
    OnAccept = function(_, profile)
        CAP:CaptureLoadedProfile(profile)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}


StaticPopupDialogs["CHAY_ADDON_PROFILES_PROTECTED_DISABLE"] = {
    text = "Disable protected addon %s for Chay Addon Profiles?\n\nThis can break UI packages or dependencies. The addon will stay disabled for selected profiles until you turn it back ON here.",
    button1 = "Disable",
    button2 = CANCEL,
    OnAccept = function(_, addon)
        if addon and addon.name then
            SetProtectedOverrideDisabled(addon.name, true)
            for _, key in ipairs(PROFILE_ORDER) do
                SetRule(addon.name, key, false)
            end
            SetAddonEnabledForNextLoad(addon.name, false)
            ScanAddOns(false)
            if CAP.RefreshRows then CAP:RefreshRows(true) end
            UpdateProfileStatusText()
            Print((addon.title or addon.name) .. " is protected but was manually set OFF. Apply profile and reload to finish.")
        end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["CHAY_ADDON_PROFILES_RESTORE_BACKUP"] = {
    text = "Restore the last saved checkbox backup?\n\nThis only restores saved profile checkboxes. It does not enable or disable addons until you apply a profile and reload.",
    button1 = "Restore",
    button2 = CANCEL,
    OnAccept = function()
        CAP:RestoreRulesBackup()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

local function DeepCopyTable(src)
    local dst = {}
    if type(src) ~= "table" then return dst end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = DeepCopyTable(v)
        else
            dst[k] = v
        end
    end
    return dst
end

function CAP:BackupRules(reason)
    local db = DB()
    db.rulesBackup = DeepCopyTable(db.addonRules or {})
    db.rulesBackupInfo = tostring(reason or "Manual backup") .. " - " .. date("%Y-%m-%d %H:%M:%S")
    Print("Profile checkbox backup saved.")
    if statusText then
        statusText:SetText("|cffff3030Backup saved.|r " .. db.rulesBackupInfo)
    end
end

function CAP:RestoreRulesBackup()
    local db = DB()
    if type(db.rulesBackup) ~= "table" then
        Print("No profile checkbox backup exists yet.")
        return
    end
    db.addonRules = DeepCopyTable(db.rulesBackup)
    ScanAddOns(false)
    if CAP.RefreshRows then CAP:RefreshRows(true) end
    UpdateProfileStatusText()
    Print("Restored profile checkboxes from backup. Apply a profile and reload when ready.")
end

local function ConfirmRestoreBackup()
    if type(DB().rulesBackup) ~= "table" then
        Print("No profile checkbox backup exists yet.")
        return
    end
    StaticPopup_Show("CHAY_ADDON_PROFILES_RESTORE_BACKUP")
end

function CAP:ApplyProfile(profile)
    local effective = EffectiveProfile(profile or DetectProfile())

    if InCombatLockdown() then
        queuedProfileCheck = true
        pendingEffectiveProfile = effective
        CDB().pendingProfile = effective
        UpdateProfileStatusText()
        Print("Profile check queued until combat ends.")
        return
    end

    ScanAddOns(false)
    effective = EffectiveProfile(profile or DetectProfile())
    local enableList, disableList = GetProfileDiff(effective)
    local total = #enableList + #disableList

    for _, name in ipairs(enableList) do
        SetAddonEnabledForNextLoad(name, true)
    end
    for _, name in ipairs(disableList) do
        SetAddonEnabledForNextLoad(name, false)
    end

    CDB().lastEffectiveProfile = effective
    if total > 0 then
        pendingEffectiveProfile = effective
        CDB().pendingProfile = effective
        StaticPopup_Show("CHAY_ADDON_PROFILES_RELOAD", GetProfileDisplay(effective), BuildReloadBody(total, enableList, disableList))
    else
        pendingEffectiveProfile = nil
        CDB().pendingProfile = nil
        CDB().loadedProfile = effective
        Print(GetProfileDisplay(effective) .. " already matches current addon state.")
    end
    UpdateProfileStatusText()
end

function CAP:CaptureLoadedProfile(profile)
    local effective = EffectiveProfile(profile or currentProfile or DetectProfile())
    CAP:BackupRules("Before capture " .. GetProfileDisplay(effective))
    ScanAddOns(false)

    local captured = 0
    local forcedOn = 0
    local forcedOff = 0

    for _, addon in ipairs(addonList) do
        if addon.incompatible then
            for _, key in ipairs(PROFILE_ORDER) do
                SetRule(addon.name, key, false)
            end
            forcedOff = forcedOff + 1
        elseif addon.protected and not IsProtectedOverrideDisabled(addon.name) then
            for _, key in ipairs(PROFILE_ORDER) do
                SetRule(addon.name, key, true)
            end
            forcedOn = forcedOn + 1
        else
            SetRule(addon.name, effective, IsEnabled(addon.name))
            captured = captured + 1
        end
    end

    currentProfile = effective
    currentEffectiveProfile = effective
    pendingEffectiveProfile = nil
    CDB().pendingProfile = nil
    CDB().lastEffectiveProfile = effective
    CDB().loadedProfile = effective

    CAP:RefreshRows(true)
    UpdateProfileStatusText()
    Print("Captured loaded addon state into " .. GetProfileDisplay(effective) .. ". " .. tostring(captured) .. " addon rule(s) updated, " .. tostring(forcedOn) .. " protected kept on, " .. tostring(forcedOff) .. " incompatible kept off.")
end

local function ConfirmCaptureLoaded(profile)
    local effective = EffectiveProfile(profile or currentProfile or DetectProfile())
    StaticPopup_Show("CHAY_ADDON_PROFILES_CAPTURE", GetProfileDisplay(effective), nil, effective)
end

local function MakeFontString(parent, template, size, color)
    local fs = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormal")
    fs:SetFont(STANDARD_TEXT_FONT, size or DB().settings.textSize, "OUTLINE")
    if color then
        fs:SetTextColor(color.r, color.g, color.b, color.a or 1)
    end
    return fs
end

local function SetButtonFont(button, size)
    if not button or not button.GetFontString then return end
    local fs = button:GetFontString()
    if fs then
        fs:SetFont(STANDARD_TEXT_FONT, math.max(9, size), "OUTLINE")
    end
end

local function ApplyTextSize()
    local size = GetEffectiveTextSize()
    if mainFrame and mainFrame.title then mainFrame.title:SetFont(STANDARD_TEXT_FONT, size + 9, "OUTLINE") end
    if mainFrame and mainFrame.subtitle then mainFrame.subtitle:SetFont(STANDARD_TEXT_FONT, size + 1, "OUTLINE") end
    if mainFrame and mainFrame.headerLine then mainFrame.headerLine:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end

    if mainPanel then
        if mainPanel.panelTitle then mainPanel.panelTitle:SetFont(STANDARD_TEXT_FONT, size + 5, "OUTLINE") end
        if mainPanel.panelSubtitle then mainPanel.panelSubtitle:SetFont(STANDARD_TEXT_FONT, math.max(10, size - 1), "OUTLINE") end
        if mainPanel.searchLabel then mainPanel.searchLabel:SetFont(STANDARD_TEXT_FONT, math.max(10, size - 1), "OUTLINE") end
        if mainPanel.header then
            local header = mainPanel.header
            if header.addonHeader and header.addonHeader.text then header.addonHeader.text:SetFont(STANDARD_TEXT_FONT, size + 1, "OUTLINE") end
            if header.allHeader then header.allHeader:SetFont(STANDARD_TEXT_FONT, size + 1, "OUTLINE") end
            if header.stateHeader then header.stateHeader:SetFont(STANDARD_TEXT_FONT, size + 1, "OUTLINE") end
            if header.memHeader and header.memHeader.text then header.memHeader.text:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end
            if header.azHeader then SetButtonFont(header.azHeader, math.max(9, size - 4)) end
            if header.groupHeader then SetButtonFont(header.groupHeader, math.max(9, size - 4)) end
        end
        for _, key in ipairs(PROFILE_ORDER) do
            local group = columnButtons[key]
            if group then
                if group.label then group.label:SetFont(STANDARD_TEXT_FONT, math.max(10, size - 1), "OUTLINE") end
                SetButtonFont(group.on, math.max(9, size - 4))
                SetButtonFont(group.off, math.max(9, size - 4))
            end
        end
    end


    if mainFrame and mainFrame.statusFields then
        for _, field in pairs(mainFrame.statusFields) do
            if field.label then
                local labelSize = field.dynamicLabelSize or math.max(9, size - 2)
                field.label:SetFont(STANDARD_TEXT_FONT, labelSize, "OUTLINE")
            end
            if field.value then
                local valueSize = field.dynamicValueSize or math.max(11, size + 1)
                field.value:SetFont(STANDARD_TEXT_FONT, valueSize, "OUTLINE")
            end
        end
    end
    if filterButton then SetButtonFont(filterButton, math.max(10, size - 1)) end
    if profileText then profileText:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end
    if statusText then statusText:SetFont(STANDARD_TEXT_FONT, math.max(10, size - 2), "OUTLINE") end
    if searchBox then searchBox:SetFont(STANDARD_TEXT_FONT, math.max(10, size - 1), "OUTLINE") end
    if searchClearButton then SetButtonFont(searchClearButton, math.max(10, size - 2)) end

    if sidePanel then
        for _, fs in ipairs(sidePanel.fontStrings or {}) do
            local extra = fs.capExtra or 0
            fs:SetFont(STANDARD_TEXT_FONT, math.max(10, size + extra), "OUTLINE")
        end
        for _, cb in pairs(optionControls) do
            if cb and cb.Text then
                cb.Text:SetFont(STANDARD_TEXT_FONT, math.max(11, size - 1), "OUTLINE")
            end
        end
        for _, button in ipairs(quickProfileButtons) do
            SetButtonFont(button, math.max(10, size - 2))
        end
        if reviewButton then SetButtonFont(reviewButton, math.max(10, size - 2)) end
    end
    for _, row in ipairs(rows) do
        if row.nameText then row.nameText:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end
        if row.stateText then row.stateText:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end
        if row.memText then row.memText:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end
        if row.profileToggles then
            for _, button in pairs(row.profileToggles) do
                SetButtonFont(button, math.max(10, size - 2))
            end
        end
    end
end

local function StylePanel(panel, r, g, b, a)
    panel:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    panel:SetBackdropColor(r or 0.01, g or 0.01, b or 0.01, a or 0.94)
    panel:SetBackdropBorderColor(0.62, 0.02, 0.02, 1)
end


local function ApplyBackgroundDarkness()
    if not mainFrame then return end
    local dark = DB().settings.darkenPanels and true or false
    local mainAlpha = dark and 0.88 or 0.82
    local panelAlpha = dark and 0.28 or 0.16
    local sideAlpha = dark and 0.30 or 0.18
    local headerAlpha = dark and 0.28 or 0.18
    local footerAlpha = dark and 0.52 or 0.42

    if mainFrame.SetBackdropColor then
        mainFrame:SetBackdropColor(0, 0, 0, mainAlpha)
    end
    if sidePanel and sidePanel.SetBackdropColor then
        sidePanel:SetBackdropColor(0.005, 0.005, 0.005, sideAlpha)
    end
    if mainPanel and mainPanel.SetBackdropColor then
        mainPanel:SetBackdropColor(0.005, 0.005, 0.005, panelAlpha)
    end
    if mainPanel and mainPanel.header and mainPanel.header.SetBackdropColor then
        mainPanel.header:SetBackdropColor(0.12, 0.01, 0.01, headerAlpha)
    end
    if mainPanel and mainPanel.footerMask and mainPanel.footerMask.SetBackdropColor then
        mainPanel.footerMask:SetBackdropColor(0, 0, 0, footerAlpha)
    end
    if watermarkLogo then
        watermarkLogo:SetAlpha(dark and 0.68 or 0.82)
    end
    if sidePanel and sidePanel.bgDragon then
        sidePanel.bgDragon:SetAlpha(dark and 0.30 or 0.40)
    end
    if mainFrame.dragonBackground then
        mainFrame.dragonBackground:SetAlpha(0)
    end
    if headerArtPanel and headerArtPanel.dragon then
        headerArtPanel.dragon:SetAlpha(dark and 0.78 or 0.92)
    end
end

local function StyleActionButton(button, text, w, h)
    button:SetSize(w or 120, h or 28)
    button:SetText(text)
    button:SetNormalFontObject(GameFontNormal)
    button:SetHighlightFontObject(GameFontHighlight)
    button:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    button:SetBackdropColor(0.035, 0.035, 0.035, 0.98)
    button:SetBackdropBorderColor(0.20, 0.20, 0.20, 1)
    button:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.16, 0.02, 0.02, 1)
        self:SetBackdropBorderColor(0.82, 0.04, 0.04, 1)
    end)
    button:SetScript("OnLeave", function(self)
        if self.profileKey and EffectiveProfile(currentProfile or DetectProfile()) == EffectiveProfile(self.profileKey) then
            self:SetBackdropColor(0.20, 0.02, 0.02, 0.98)
            self:SetBackdropBorderColor(0.95, 0.04, 0.04, 1)
        else
            self:SetBackdropColor(0.035, 0.035, 0.035, 0.98)
            self:SetBackdropBorderColor(0.20, 0.20, 0.20, 1)
        end
    end)
end

local function StyleToggleButton(button, label, isOn)
    button:SetSize(label == "OFF" and 36 or 32, 22)
    button:SetText(label)
    button:SetNormalFontObject(GameFontNormalSmall)
    button:SetHighlightFontObject(GameFontNormalSmall)

    local fs = button:GetFontString()
    if fs then
        fs:SetFont(STANDARD_TEXT_FONT, math.max(9, GetEffectiveTextSize() - 4), "OUTLINE")
        if isOn then
            fs:SetTextColor(0.25, 1.00, 0.32, 1)
        else
            fs:SetTextColor(1.00, 0.18, 0.18, 1)
        end
    end

    button:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    button:SetBackdropColor(0.005, 0.005, 0.005, 0.22)
    button:SetBackdropBorderColor(0.16, 0.16, 0.16, 0.34)

    button:SetScript("OnEnter", nil)
    button:SetScript("OnLeave", nil)
    button:SetScript("OnMouseDown", nil)
    button:SetScript("OnMouseUp", nil)
end



local function GetAddonNote(addonName)
    if not addonName then return "" end
    local notes = DB().addonNotes
    return notes and notes[addonName] or ""
end

local function SetAddonNote(addonName, note)
    if not addonName then return end
    DB().addonNotes = DB().addonNotes or {}
    note = strtrim(tostring(note or ""))
    if note == "" then
        DB().addonNotes[addonName] = nil
    else
        DB().addonNotes[addonName] = note
    end
end

local function CreateNotesFrame()
    if notesFrame then return end

    notesFrame = CreateFrame("Frame", "ChayAddonProfilesNotesFrame", UIParent, "BackdropTemplate")
    notesFrame:SetSize(430, 286)
    notesFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    notesFrame:SetClampedToScreen(true)
    notesFrame:SetMovable(true)
    notesFrame:EnableMouse(true)
    notesFrame:RegisterForDrag("LeftButton")
    notesFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    notesFrame:SetBackdropColor(0.012, 0.004, 0.004, 0.96)
    notesFrame:SetBackdropBorderColor(0.62, 0.02, 0.02, 1)
    notesFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    notesFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    notesFrame.title = MakeFontString(notesFrame, nil, 16, { r = 1, g = 0.18, b = 0.18 })
    notesFrame.title:SetPoint("TOPLEFT", 16, -14)
    notesFrame.title:SetText("Addon Note / Tag")

    notesFrame.addonText = MakeFontString(notesFrame, nil, 12, { r = 0.94, g = 0.94, b = 0.94 })
    notesFrame.addonText:SetPoint("TOPLEFT", 16, -42)
    notesFrame.addonText:SetPoint("TOPRIGHT", -42, -42)
    notesFrame.addonText:SetJustifyH("LEFT")
    notesFrame.addonText:SetWordWrap(false)
    notesFrame.addonText:SetNonSpaceWrap(false)

    local close = CreateFrame("Button", nil, notesFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    local editBg = CreateFrame("Frame", nil, notesFrame, "BackdropTemplate")
    editBg:SetPoint("TOPLEFT", 16, -68)
    editBg:SetPoint("BOTTOMRIGHT", -16, 102)
    editBg:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    editBg:SetBackdropColor(0, 0, 0, 0.72)
    editBg:SetBackdropBorderColor(0.35, 0.02, 0.02, 1)

    notesFrame.editBox = CreateFrame("EditBox", nil, editBg)
    notesFrame.editBox:SetPoint("TOPLEFT", 8, -8)
    notesFrame.editBox:SetPoint("BOTTOMRIGHT", -8, 8)
    notesFrame.editBox:SetFont(STANDARD_TEXT_FONT, 13, "OUTLINE")
    notesFrame.editBox:SetTextColor(0.94, 0.94, 0.94, 1)
    notesFrame.editBox:SetMultiLine(true)
    notesFrame.editBox:SetAutoFocus(false)
    notesFrame.editBox:SetMaxLetters(160)
    notesFrame.editBox:SetJustifyH("LEFT")
    notesFrame.editBox:SetJustifyV("TOP")
    notesFrame.editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)

    local tagLabel = MakeFontString(notesFrame, nil, 11, { r = 1, g = 0.86, b = 0.25 })
    tagLabel:SetPoint("BOTTOMLEFT", 16, 78)
    tagLabel:SetText("Quick tags:")

    local tags = {
        { label = "Raid only", w = 76, x = 82, y = 74 },
        { label = "World only", w = 82, x = 164, y = 74 },
        { label = "High memory", w = 90, x = 252, y = 74 },
        { label = "Do not disable", w = 108, x = 82, y = 48 },
        { label = "Dependency", w = 88, x = 196, y = 48 },
    }
    for _, tag in ipairs(tags) do
        local label = tag.label
        local buttonWidth = tag.w
        local x = tag.x
        local y = tag.y
        local btn = CreateFrame("Button", nil, notesFrame, "BackdropTemplate")
        StyleActionButton(btn, label, buttonWidth, 22)
        SetButtonFont(btn, 10)
        btn:SetPoint("BOTTOMLEFT", notesFrame, "BOTTOMLEFT", x, y)
        btn:SetScript("OnClick", function()
            local current = notesFrame.editBox:GetText() or ""
            if current ~= "" then current = current .. "; " end
            notesFrame.editBox:SetText(current .. label)
            notesFrame.editBox:SetCursorPosition(string.len(notesFrame.editBox:GetText() or ""))
        end)
    end

    notesFrame.saveButton = CreateFrame("Button", nil, notesFrame, "BackdropTemplate")
    StyleActionButton(notesFrame.saveButton, "Save", 82, 26)
    notesFrame.saveButton:SetPoint("BOTTOMRIGHT", notesFrame, "BOTTOMRIGHT", -16, 16)
    notesFrame.saveButton:SetScript("OnClick", function()
        SetAddonNote(notesFrame.addonName, notesFrame.editBox:GetText())
        notesFrame:Hide()
        CAP:RefreshRows(true)
    end)

    notesFrame.clearButton = CreateFrame("Button", nil, notesFrame, "BackdropTemplate")
    StyleActionButton(notesFrame.clearButton, "Clear", 82, 26)
    notesFrame.clearButton:SetPoint("RIGHT", notesFrame.saveButton, "LEFT", -8, 0)
    notesFrame.clearButton:SetScript("OnClick", function()
        notesFrame.editBox:SetText("")
        SetAddonNote(notesFrame.addonName, "")
        notesFrame:Hide()
        CAP:RefreshRows(true)
    end)

    notesFrame.closeButton = CreateFrame("Button", nil, notesFrame, "BackdropTemplate")
    StyleActionButton(notesFrame.closeButton, "Close", 82, 26)
    notesFrame.closeButton:SetPoint("RIGHT", notesFrame.clearButton, "LEFT", -8, 0)
    notesFrame.closeButton:SetScript("OnClick", function()
        notesFrame:Hide()
    end)

    notesFrame:Hide()
end

local function OpenAddonNoteEditor(addon)
    if not addon then return end
    CreateNotesFrame()
    notesFrame.addonName = addon.name
    notesFrame.addonText:SetText(addon.title or addon.name or "Addon")
    notesFrame.editBox:SetText(GetAddonNote(addon.name))
    notesFrame.editBox:SetCursorPosition(string.len(notesFrame.editBox:GetText() or ""))
    notesFrame:ClearAllPoints()
    notesFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
    notesFrame:SetAlpha(1)
    notesFrame:Show()
end

local function SaveApplyPromptPoint()
    if not applyPromptFrame then return end
    local point, _, relativePoint, x, y = applyPromptFrame:GetPoint(1)
    DB().settings.promptPoint = {
        point = point or "CENTER",
        relativePoint = relativePoint or "CENTER",
        x = math.floor((x or 0) + 0.5),
        y = math.floor((y or 0) + 0.5),
    }
end

local function FadeApplyPromptAfter(delay)
    if not applyPromptFrame then return end
    applyPromptFrame.fadeElapsed = 0
    applyPromptFrame.fadeDelay = delay or 8
    applyPromptFrame:SetScript("OnUpdate", function(self, elapsed)
        self.fadeElapsed = (self.fadeElapsed or 0) + elapsed
        if self.fadeElapsed <= self.fadeDelay then
            return
        end
        local fadeElapsed = self.fadeElapsed - self.fadeDelay
        local alpha = 1 - Clamp(fadeElapsed / 0.7, 0, 1)
        self:SetAlpha(alpha)
        if alpha <= 0 then
            self:SetScript("OnUpdate", nil)
            self:Hide()
            self:SetAlpha(1)
        end
    end)
end

local function CreateApplyPromptFrame()
    if applyPromptFrame then return end

    applyPromptFrame = CreateFrame("Frame", "ChayAddonProfilesApplyPrompt", UIParent, "BackdropTemplate")
    applyPromptFrame:SetSize(420, 112)
    applyPromptFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    applyPromptFrame:SetClampedToScreen(true)
    applyPromptFrame:SetMovable(true)
    applyPromptFrame:EnableMouse(true)
    applyPromptFrame:RegisterForDrag("LeftButton")
    applyPromptFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    applyPromptFrame:SetBackdropColor(0.015, 0.005, 0.005, 0.94)
    applyPromptFrame:SetBackdropBorderColor(0.55, 0.03, 0.03, 1)
    applyPromptFrame:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", nil)
        self:SetAlpha(1)
        self:StartMoving()
    end)
    applyPromptFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SaveApplyPromptPoint()
        FadeApplyPromptAfter(8)
    end)
    applyPromptFrame:SetScript("OnEnter", function(self)
        self:SetScript("OnUpdate", nil)
        self:SetAlpha(1)
    end)
    applyPromptFrame:SetScript("OnLeave", function()
        FadeApplyPromptAfter(8)
    end)

    applyPromptFrame.title = MakeFontString(applyPromptFrame, nil, 15, { r = 1, g = 0.18, b = 0.18 })
    applyPromptFrame.title:SetPoint("TOPLEFT", 14, -12)
    applyPromptFrame.title:SetText("Chay Addon Profiles")

    applyPromptFrame.text = MakeFontString(applyPromptFrame, nil, 12, { r = 0.94, g = 0.94, b = 0.94 })
    applyPromptFrame.text:SetPoint("TOPLEFT", 14, -36)
    applyPromptFrame.text:SetPoint("TOPRIGHT", -14, -36)
    applyPromptFrame.text:SetJustifyH("LEFT")
    applyPromptFrame.text:SetText("Profile differs from your current addon state.")

    applyPromptFrame.applyButton = CreateFrame("Button", nil, applyPromptFrame, "BackdropTemplate")
    StyleActionButton(applyPromptFrame.applyButton, "Apply + Reload", 122, 26)
    applyPromptFrame.applyButton:SetPoint("BOTTOMRIGHT", applyPromptFrame, "BOTTOMRIGHT", -14, 12)
    applyPromptFrame.applyButton:SetScript("OnClick", function()
        local profile = applyPromptFrame.profile or DetectProfile()
        HideApplyPopup()
        CAP:ApplyProfile(profile)
    end)

    applyPromptFrame.laterButton = CreateFrame("Button", nil, applyPromptFrame, "BackdropTemplate")
    StyleActionButton(applyPromptFrame.laterButton, "Later", 76, 26)
    applyPromptFrame.laterButton:SetPoint("RIGHT", applyPromptFrame.applyButton, "LEFT", -8, 0)
    applyPromptFrame.laterButton:SetScript("OnClick", function()
        HideApplyPopup()
    end)

    applyPromptFrame:Hide()
end

local function ShowApplyPrompt(profile)
    if DB().settings.dontShowPrompts then return end
    CreateApplyPromptFrame()
    applyPromptFrame.profile = profile
    applyPromptFrame:SetScript("OnUpdate", nil)
    applyPromptFrame:SetAlpha(1)
    applyPromptFrame:ClearAllPoints()
    local p = DB().settings.promptPoint or DEFAULT_DB.settings.promptPoint
    applyPromptFrame:SetPoint(p.point or "CENTER", UIParent, p.relativePoint or "CENTER", p.x or 0, p.y or 170)
    applyPromptFrame.text:SetText(GetProfileDisplay(profile) .. " profile differs from your current addon state.")
    applyPromptFrame:Show()
    FadeApplyPromptAfter(8)
end


local function AppendPreviewList(lines, title, list)
    lines[#lines + 1] = title .. " (" .. tostring(#list) .. ")"
    if #list == 0 then
        lines[#lines + 1] = "  None"
    else
        table.sort(list, function(a, b)
            return strlower(GetAddOnDisplayName(a)) < strlower(GetAddOnDisplayName(b))
        end)
        for _, addonName in ipairs(list) do
            lines[#lines + 1] = "  - " .. GetAddOnDisplayName(addonName)
        end
    end
    lines[#lines + 1] = ""
end

local function CreatePreviewFrame()
    if previewFrame then return end

    previewFrame = CreateFrame("Frame", "ChayAddonProfilesPreviewFrame", UIParent, "BackdropTemplate")
    previewFrame:SetSize(520, 430)
    previewFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    previewFrame:SetClampedToScreen(true)
    previewFrame:SetMovable(true)
    previewFrame:EnableMouse(true)
    previewFrame:RegisterForDrag("LeftButton")
    previewFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    previewFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    previewFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    previewFrame:SetBackdropColor(0.01, 0.005, 0.005, 0.96)
    previewFrame:SetBackdropBorderColor(0.62, 0.02, 0.02, 1)
    previewFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 30)

    previewFrame.title = MakeFontString(previewFrame, nil, 17, { r = 1, g = 0.18, b = 0.18 })
    previewFrame.title:SetPoint("TOPLEFT", 16, -14)
    previewFrame.title:SetText("Preview Changes")

    local close = CreateFrame("Button", nil, previewFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    previewFrame.summary = MakeFontString(previewFrame, nil, 12, { r = 0.92, g = 0.92, b = 0.92 })
    previewFrame.summary:SetPoint("TOPLEFT", previewFrame.title, "BOTTOMLEFT", 0, -8)
    previewFrame.summary:SetPoint("TOPRIGHT", previewFrame, "TOPRIGHT", -38, -38)
    previewFrame.summary:SetJustifyH("LEFT")
    previewFrame.summary:SetText("Current profile changes before reload.")

    local scroll = CreateFrame("ScrollFrame", nil, previewFrame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 16, -72)
    scroll:SetPoint("BOTTOMRIGHT", -34, 58)
    scroll:EnableMouseWheel(true)

    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(450, 1)
    scroll:SetScrollChild(child)

    previewFrame.text = child:CreateFontString(nil, "OVERLAY")
    previewFrame.text:SetFont(STANDARD_TEXT_FONT, math.max(11, GetEffectiveTextSize() - 1), "OUTLINE")
    previewFrame.text:SetTextColor(0.94, 0.94, 0.94, 1)
    previewFrame.text:SetPoint("TOPLEFT", child, "TOPLEFT", 0, 0)
    previewFrame.text:SetJustifyH("LEFT")
    previewFrame.text:SetJustifyV("TOP")
    previewFrame.text:SetWidth(440)
    previewFrame.scrollChild = child

    previewFrame.applyButton = CreateFrame("Button", nil, previewFrame, "BackdropTemplate")
    StyleActionButton(previewFrame.applyButton, "Apply + Reload", 132, 28)
    previewFrame.applyButton:SetPoint("BOTTOMRIGHT", previewFrame, "BOTTOMRIGHT", -16, 16)
    previewFrame.applyButton:SetScript("OnClick", function()
        local profile = previewFrame.profile or DetectProfile()
        previewFrame:Hide()
        CAP:ApplyProfile(profile)
    end)

    previewFrame.closeButton = CreateFrame("Button", nil, previewFrame, "BackdropTemplate")
    StyleActionButton(previewFrame.closeButton, "Close", 84, 28)
    previewFrame.closeButton:SetPoint("RIGHT", previewFrame.applyButton, "LEFT", -10, 0)
    previewFrame.closeButton:SetScript("OnClick", function()
        previewFrame:Hide()
    end)

    previewFrame:Hide()
end

local function ShowPreviewChanges(profile)
    CreatePreviewFrame()
    ScanAddOns(false)

    local effective = EffectiveProfile(profile or DetectProfile())
    local enableList, disableList = GetProfileDiff(effective)
    local total = #enableList + #disableList
    local lines = {}

    lines[#lines + 1] = GetProfileDisplay(effective) .. " profile"
    lines[#lines + 1] = tostring(total) .. " addon setting(s) would change on apply."
    lines[#lines + 1] = ""
    AppendPreviewList(lines, "Will Enable", enableList)
    AppendPreviewList(lines, "Will Disable", disableList)

    previewFrame.profile = effective
    previewFrame.title:SetText("Preview Changes")
    previewFrame.summary:SetText("Review what will change before applying this profile.")
    previewFrame.applyButton:Show()
    previewFrame.closeButton:ClearAllPoints()
    previewFrame.closeButton:SetPoint("RIGHT", previewFrame.applyButton, "LEFT", -10, 0)
    previewFrame.text:SetFont(STANDARD_TEXT_FONT, math.max(11, GetEffectiveTextSize() - 1), "OUTLINE")
    previewFrame.text:SetText(table.concat(lines, "\n"))
    previewFrame.scrollChild:SetHeight(math.max(1, previewFrame.text:GetStringHeight() + 10))
    previewFrame:ClearAllPoints()
    previewFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
    previewFrame:Show()
end


local function AddReviewSection(lines, title, list)
    list = list or {}
    lines[#lines + 1] = "|cffff3030" .. title .. "|r"
    if #list == 0 then
        lines[#lines + 1] = "  None"
    else
        table.sort(list, function(a, b) return strlower(tostring(a)) < strlower(tostring(b)) end)
        for i, name in ipairs(list) do
            if i <= 18 then
                lines[#lines + 1] = "  - " .. tostring(name)
            end
        end
        if #list > 18 then
            lines[#lines + 1] = "  +" .. tostring(#list - 18) .. " more"
        end
    end
    lines[#lines + 1] = ""
end

local function GetNotedAddonsList()
    local result = {}
    local notes = DB().addonNotes or {}
    for _, addon in ipairs(addonList) do
        if notes[addon.name] and notes[addon.name] ~= "" then
            result[#result + 1] = addon.title .. " - " .. notes[addon.name]
        end
    end
    table.sort(result, function(a, b) return strlower(tostring(a)) < strlower(tostring(b)) end)
    return result
end

local function GetProtectedAddonsList()
    local result = {}
    for _, addon in ipairs(addonList) do
        if addon.protected and not addon.incompatible then
            result[#result + 1] = addon.title or addon.name
        end
    end
    table.sort(result, function(a, b) return strlower(tostring(a)) < strlower(tostring(b)) end)
    return result
end

local function ShowAddonReview()
    CreatePreviewFrame()
    ScanAddOns(false)

    local report = lastScanReport or { new = {}, removed = {}, incompatible = {}, noRules = {} }
    local lines = {}
    lines[#lines + 1] = "Addon review / safety log"
    lines[#lines + 1] = "This is informational only. It does not apply or reload anything."
    lines[#lines + 1] = ""
    AddReviewSection(lines, "New addons detected", report.new)
    AddReviewSection(lines, "Deleted addons cleaned up", report.removed)
    AddReviewSection(lines, "Incompatible addons ignored", report.incompatible)
    AddReviewSection(lines, "Addons with no saved rules yet", report.noRules)
    AddReviewSection(lines, "Addons with notes/tags", GetNotedAddonsList())
    AddReviewSection(lines, "Protected addons never disabled", GetProtectedAddonsList())

    previewFrame.profile = nil
    previewFrame.title:SetText("Addon Review")
    previewFrame.summary:SetText("Recent addon scan results and safety status.")
    previewFrame.text:SetFont(STANDARD_TEXT_FONT, math.max(11, GetEffectiveTextSize() - 1), "OUTLINE")
    previewFrame.text:SetText(table.concat(lines, "\n"))
    previewFrame.scrollChild:SetHeight(math.max(1, previewFrame.text:GetStringHeight() + 10))
    previewFrame.applyButton:Hide()
    previewFrame.closeButton:ClearAllPoints()
    previewFrame.closeButton:SetPoint("BOTTOMRIGHT", previewFrame, "BOTTOMRIGHT", -16, 16)
    previewFrame:ClearAllPoints()
    previewFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
    previewFrame:Show()
end


local function CountTableEntries(tbl)
    local count = 0
    if type(tbl) ~= "table" then return 0 end
    for _ in pairs(tbl) do
        count = count + 1
    end
    return count
end

local function ShowCommandHelp()
    CreatePreviewFrame()

    local lines = {
        "Chay Addon Profiles Commands",
        "",
        "/cap - Open or close the main GUI",
        "/cap apply - Apply the detected profile and reload prompt",
        "/cap preview - Preview detected profile changes",
        "/cap review - Open addon review / safety log",
        "/cap status - Print current/loaded/pending profile status",
        "/cap check - Open full addon safety check",
        "/cap scan - Rescan installed addons",
        "/cap capture - Save currently loaded addon state into the current profile",
        "/cap backup - Save a backup of all profile checkboxes",
        "/cap restore - Restore the last saved checkbox backup",
        "/cap usage - Refresh memory usage",
        "/cap prompts on - Enable prompts",
        "/cap prompts off - Disable prompts",
        "/cap raid / mplus / dungeon / delve / world / city / pvp - Manual profile preview",
        "/cap group - Sort by addon/dependencies",
        "/cap a-z - Sort alphabetically",
        "/cap text bigger - Increase text size",
        "/cap text smaller - Decrease text size",
        "/cap resetprompt - Reset movable prompt position",
        "/cap reset - Reset main GUI size/position",
        "/cap minimap - Toggle minimap button",
        "/cap minimapreset - Reset minimap button position",
        "",
        "Mouse:",
        "Ctrl + mouse wheel over the main GUI resizes the window.",
        "Mouse wheel over the addon list scrolls the list.",
        "Right-click an addon row to edit its note/tag.",
    }

    previewFrame.title:SetText("Help / Commands")
    previewFrame.summary:SetText("Reference only. Nothing is applied from this window.")
    previewFrame.text:SetText(table.concat(lines, "\n"))
    previewFrame.scrollChild:SetHeight(math.max(1, previewFrame.text:GetStringHeight() + 10))
    previewFrame.applyButton:Hide()
    previewFrame:Show()
end

local function ShowSafetyCheck()
    CreatePreviewFrame()
    if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
    ScanAddOns(false)

    local detected = EffectiveProfile(DetectProfile())
    local loaded = CDB().loadedProfile or CDB().lastEffectiveProfile or "none"
    local pending = CDB().pendingProfile or pendingEffectiveProfile or "none"
    local enableList, disableList = GetProfileDiff(detected)

    local protectedCount = 0
    local incompatibleCount = 0
    local notedCount = 0
    local totalMemory = 0
    for _, addon in ipairs(addonList) do
        if addon.protected then protectedCount = protectedCount + 1 end
        if addon.incompatible then incompatibleCount = incompatibleCount + 1 end
        if DB().addonNotes[addon.name] and DB().addonNotes[addon.name] ~= "" then notedCount = notedCount + 1 end
        totalMemory = totalMemory + (tonumber(addon.memory) or 0)
    end

    local lines = {
        "Full Addon Safety Check",
        "",
        "Profile State:",
        "  Current: " .. GetProfileDisplay(detected),
        "  Loaded: " .. GetProfileDisplay(loaded),
        "  Pending: " .. GetProfileDisplay(pending),
        "  Combat locked: " .. (InCombatLockdown() and "Yes" or "No"),
        "  Queued profile check: " .. (queuedProfileCheck and "Yes" or "No"),
        "",
        "Addon State:",
        "  Installed addons scanned: " .. tostring(#addonList),
        "  Saved rules: " .. tostring(CountTableEntries(DB().addonRules)),
        "  Known addons: " .. tostring(CountTableEntries(DB().knownAddOns)),
        "  Protected addons: " .. tostring(protectedCount),
        "  Incompatible ignored: " .. tostring(incompatibleCount),
        "  Addons with notes/tags: " .. tostring(notedCount),
        "  Current addon memory: " .. FormatMemory(totalMemory),
        "  Last checkbox backup: " .. tostring(DB().rulesBackupInfo or "None"),
        "",
        "Prompt / Profile Settings:",
        "  Auto prompts: " .. (DB().settings.autoPrompt and "On" or "Off"),
        "  Don't show prompts: " .. (DB().settings.dontShowPrompts and "On" or "Off"),
        "  Per character: " .. (DB().settings.perCharacter and "On" or "Off"),
        "  Link Dungeon/M+: " .. (DB().settings.linkDungeonMPlus and "On" or "Off"),
        "  Link World/City: " .. (DB().settings.linkWorldCity and "On" or "Off"),
        "  Protect core addons: " .. (DB().settings.protectCoreAddons and "On" or "Off"),
        "",
        "Pending Detected Profile Changes:",
        "  Will enable: " .. tostring(#enableList),
        "  Will disable: " .. tostring(#disableList),
        "",
        BuildCompactChangeSummary(enableList, disableList),
    }

    previewFrame.title:SetText("Safety Check")
    previewFrame.summary:SetText("Read-only diagnostic. No addon settings are changed.")
    previewFrame.text:SetText(table.concat(lines, "\n"))
    previewFrame.scrollChild:SetHeight(math.max(1, previewFrame.text:GetStringHeight() + 10))
    previewFrame.applyButton:Hide()
    previewFrame:Show()
end

local function ResetPromptPosition()
    DB().settings.promptPoint = CopyDefaults(DEFAULT_DB.settings.promptPoint, {})
    if applyPromptFrame then
        applyPromptFrame:ClearAllPoints()
        applyPromptFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 170)
    end
    Print("Prompt position reset.")
end

local function OpenQuickProfile(profile)
    currentProfile = profile or DetectProfile()
    currentEffectiveProfile = EffectiveProfile(currentProfile)
    UpdateProfileStatusText()
    ShowPreviewChanges(currentProfile)
end

local function RefreshOptionChecks()
    local db = DB()
    for key, cb in pairs(optionControls) do
        if db.settings[key] ~= nil then
            cb:SetChecked(db.settings[key])
        end
    end
end

local function ResizeWindow(delta)
    if not mainFrame then return end
    local db = DB()
    local w, h = mainFrame:GetSize()
    local step = IsShiftKeyDown() and 50 or 25
    local nw = Clamp(w + (delta * step), MIN_WIDTH, MAX_WIDTH)
    local nh = Clamp(h + (delta * step), MIN_HEIGHT, MAX_HEIGHT)
    mainFrame:SetSize(nw, nh)
    db.settings.frameSize.width = nw
    db.settings.frameSize.height = nh
    if CAP.UpdateLayout then CAP:UpdateLayout() end
end


local function ScrollList(delta)
    if not scrollFrame then return end
    if IsControlKeyDown() then
        ResizeWindow(delta)
        return
    end
    local current = scrollFrame:GetVerticalScroll()
    local maxScroll = scrollFrame:GetVerticalScrollRange()
    scrollFrame:SetVerticalScroll(Clamp(current - (delta * 48), 0, maxScroll))
end

local function AddListWheel(widget)
    if not widget then return end
    widget:EnableMouseWheel(true)
    widget:SetScript("OnMouseWheel", function(_, delta)
        ScrollList(delta)
    end)
end

function CAP:UpdateLayout(skipRowRefresh)
    if not mainFrame or not mainPanel then return end

    local w, h = mainFrame:GetSize()
    local sideW = Clamp(math.floor(w * 0.17), 176, 236)
    local rightPreviewW = 0
    local margin = 12
    local textSize = GetEffectiveTextSize()
    local layoutTextSize = Clamp(textSize, 10, 24)
    local textBump = math.max(0, layoutTextSize - 13)
    local titleW = Clamp(math.floor(w * 0.43), 360, 560)
    local titleH = Clamp(math.floor(titleW * 0.19), 66, 106)
    local statusW = Clamp(math.floor(w * 0.42), 390, 620)
    local statusSegW = math.floor(statusW / 4)
    local statusLabelSize = Clamp(math.floor(math.min(layoutTextSize - 2, (statusSegW / 10))), 8, math.max(9, layoutTextSize - 1))
    local statusValueSize = Clamp(math.floor(math.min(layoutTextSize, (statusSegW / 7.4))), 10, math.max(11, layoutTextSize))
    local statusH = Clamp(38 + statusLabelSize + statusValueSize, 54, 70)
    local statusTopOffset = Clamp(104 + math.floor(textBump * 0.35), 96, 126)
    local topH = Clamp(statusTopOffset + statusH + 18 + math.floor(textBump * 0.25), 174, 212)
    local bottomH = 52

    ApplyTextSize()

    sidePanel:ClearAllPoints()
    sidePanel:SetPoint("TOPLEFT", margin, -topH - 8)
    sidePanel:SetPoint("BOTTOMLEFT", margin, margin)
    sidePanel:SetWidth(sideW)

    if sidePanel.scrollFrame then
        sidePanel.scrollFrame:ClearAllPoints()
        sidePanel.scrollFrame:SetPoint("TOPLEFT", sidePanel, "TOPLEFT", 4, -4)
        sidePanel.scrollFrame:SetPoint("BOTTOMRIGHT", sidePanel, "BOTTOMRIGHT", -4, 4)
    end

    if sidePanel.content then
        sidePanel.content:SetWidth(math.max(1, sideW - 18))
        sidePanel.content:SetHeight(sidePanel.contentHeight or 720)
    end

    mainPanel:ClearAllPoints()
    mainPanel:SetPoint("TOPLEFT", sidePanel, "TOPRIGHT", margin, 0)
    mainPanel:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -(margin + rightPreviewW), margin)

    local panelW = w - sideW - rightPreviewW - (margin * 4)
    local panelH = h - topH - margin
    local leftPad = 10
    local rowW = math.max(1, panelW - 20)

    if headerSquareLogo then
        headerSquareLogo:SetSize(1, 1)
        headerSquareLogo:Hide()
    end
    if headerArtPanel then
        headerArtPanel:ClearAllPoints()
        headerArtPanel:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", margin, -margin)
        headerArtPanel:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -margin, -margin)
        headerArtPanel:SetHeight(math.max(112, topH - 22))
        if headerArtPanel.dragon then
            headerArtPanel.dragon:ClearAllPoints()
            headerArtPanel.dragon:SetPoint("TOPLEFT", headerArtPanel, "TOPLEFT", 2, -2)
            headerArtPanel.dragon:SetPoint("BOTTOMRIGHT", headerArtPanel, "BOTTOMRIGHT", -2, 2)
        end
        if headerArtPanel.topTrim then
            headerArtPanel.topTrim:ClearAllPoints()
            headerArtPanel.topTrim:SetPoint("TOPLEFT", headerArtPanel, "TOPLEFT", 4, -4)
            headerArtPanel.topTrim:SetPoint("TOPRIGHT", headerArtPanel, "TOPRIGHT", -4, -4)
        end
        if headerArtPanel.bottomTrim then
            headerArtPanel.bottomTrim:ClearAllPoints()
            headerArtPanel.bottomTrim:SetPoint("BOTTOMLEFT", headerArtPanel, "BOTTOMLEFT", 4, 4)
            headerArtPanel.bottomTrim:SetPoint("BOTTOMRIGHT", headerArtPanel, "BOTTOMRIGHT", -4, 4)
        end
        if headerArtPanel.centerGem then
            headerArtPanel.centerGem:ClearAllPoints()
            headerArtPanel.centerGem:SetPoint("TOP", headerArtPanel, "TOP", 0, -4)
            headerArtPanel.centerGem:SetSize(1, 1)
            headerArtPanel.centerGem:SetAlpha(0)
            headerArtPanel.centerGem:Hide()
        end
        if headerArtPanel.leftWing then
            headerArtPanel.leftWing:ClearAllPoints()
            headerArtPanel.leftWing:SetPoint("TOP", headerArtPanel, "TOP", -120, -18)
            headerArtPanel.leftWing:SetSize(math.max(190, math.floor(w * 0.20)), 2)
        end
        if headerArtPanel.rightWing then
            headerArtPanel.rightWing:ClearAllPoints()
            headerArtPanel.rightWing:SetPoint("TOP", headerArtPanel, "TOP", 120, -18)
            headerArtPanel.rightWing:SetSize(math.max(190, math.floor(w * 0.20)), 2)
        end
    end
    if titleLogo then
        titleLogo:ClearAllPoints()
        titleLogo:SetPoint("TOP", mainFrame, "TOP", 0, -28)
        titleLogo:SetSize(titleW, titleH)
        titleLogo:SetAlpha(0.92)
        titleLogo:SetBlendMode("BLEND")
        titleLogo:Show()
    end
    if mainFrame.statusBox then
        mainFrame.statusBox:ClearAllPoints()
        mainFrame.statusBox:SetSize(statusW, statusH)
        if mainFrame.statusBox.topGlow then
            mainFrame.statusBox.topGlow:SetHeight(2)
        end
        if mainFrame.statusBox.bottomGlow then
            mainFrame.statusBox.bottomGlow:SetHeight(2)
        end
        mainFrame.statusBox:SetPoint("TOP", mainFrame, "TOP", 0, -statusTopOffset)
    end
    if mainPanel and mainPanel.searchLabel and searchBox then
        mainPanel.searchLabel:ClearAllPoints()
        searchBox:ClearAllPoints()
        mainPanel.searchLabel:SetPoint("TOPLEFT", mainPanel, "TOPLEFT", 16, -18)
        searchBox:SetPoint("TOPLEFT", mainPanel, "TOPLEFT", 16, -12)
        searchBox:SetPoint("TOPRIGHT", mainPanel, "TOPRIGHT", -14, -12)
        if filterButton then
            filterButton:ClearAllPoints()
            filterButton:SetSize(112, 30)
            filterButton:SetPoint("TOPRIGHT", mainPanel, "TOPRIGHT", -14, -12)
        end
        if searchClearButton then
            searchClearButton:ClearAllPoints()
            searchClearButton:SetPoint("RIGHT", searchBox, "RIGHT", -3, 0)
        end
    end
    if sideLogo then
        sideLogo:SetSize(1, 1)
        sideLogo:Hide()
    end
    if profileText then
        profileText:SetWidth(math.max(260, (mainFrame.statusBox and mainFrame.statusBox:GetWidth() or 470) - 28))
        profileText:SetHeight(math.max(18, statusH - 18))
    end
    if mainFrame.statusFields and mainFrame.statusBox then
        local sbw = mainFrame.statusBox:GetWidth()
        local segW = math.floor(sbw / 4)
        for idx, key in ipairs({ "current", "loaded", "pending", "combat" }) do
            local field = mainFrame.statusFields[key]
            if field then
                field.dynamicLabelSize = statusLabelSize
                field.dynamicValueSize = statusValueSize
                field:ClearAllPoints()
                field:SetPoint("TOPLEFT", mainFrame.statusBox, "TOPLEFT", (idx - 1) * segW, -1)
                field:SetSize(idx == 4 and (sbw - ((idx - 1) * segW)) or segW, statusH - 2)
                if field.label then
                    field.label:SetFont(STANDARD_TEXT_FONT, statusLabelSize, "OUTLINE")
                    field.label:SetWordWrap(false)
                    field.label:SetNonSpaceWrap(false)
                    field.label:ClearAllPoints()
                    field.label:SetPoint("TOP", field, "TOP", 0, -10)
                    field.label:SetWidth(math.max(40, field:GetWidth() - 10))
                end
                if field.value then
                    field.value:SetFont(STANDARD_TEXT_FONT, statusValueSize, "OUTLINE")
                    field.value:SetWordWrap(false)
                    field.value:SetNonSpaceWrap(false)
                    field.value:ClearAllPoints()
                    field.value:SetPoint("TOP", field.label or field, "BOTTOM", 0, -4)
                    field.value:SetWidth(math.max(40, field:GetWidth() - 10))
                end
                if field.divider then
                    field.divider:ClearAllPoints()
                    field.divider:SetPoint("TOPRIGHT", field, "TOPRIGHT", 0, -10)
                    field.divider:SetSize(1, math.max(34, statusH - 20))
                    field.divider:SetShown(idx < 4)
                end
            end
        end
    end

    if watermarkLogo then
        watermarkLogo:ClearAllPoints()
        watermarkLogo:SetPoint("TOPLEFT", mainPanel, "TOPLEFT", 2, -2)
        watermarkLogo:SetPoint("BOTTOMRIGHT", mainPanel, "BOTTOMRIGHT", -2, 2)
    end

    if mainPanel.header then
        mainPanel.header:ClearAllPoints()
        mainPanel.header:SetPoint("TOPLEFT", leftPad, -50)
        mainPanel.header:SetSize(rowW, Clamp(GetEffectiveTextSize() + 48, 64, 84))
    end

    if mainPanel.footerMask then
        mainPanel.footerMask:ClearAllPoints()
        mainPanel.footerMask:SetPoint("BOTTOMLEFT", mainPanel, "BOTTOMLEFT", 1, 1)
        mainPanel.footerMask:SetPoint("BOTTOMRIGHT", mainPanel, "BOTTOMRIGHT", -1, 1)
        mainPanel.footerMask:SetHeight(bottomH + 3)
    end

    if scrollFrame then
        scrollFrame:ClearAllPoints()
        scrollFrame:SetPoint("TOPLEFT", mainPanel.header, "BOTTOMLEFT", 0, -4)
        scrollFrame:SetPoint("BOTTOMRIGHT", mainPanel, "BOTTOMRIGHT", -24, bottomH + 12)
        if scrollFrame.SetClipsChildren then
            scrollFrame:SetClipsChildren(true)
        end
    end

    local profileCount = #PROFILE_ORDER
    local compact = rowW < (980 + (textBump * 24))
    local ultraCompact = rowW < 760
    local profileGap = ultraCompact and 1 or (compact and 2 or 8)
    local allW = ultraCompact and 34 or (compact and math.max(40, layoutTextSize + 20) or math.max(56, layoutTextSize + 32))
    local stateW = ultraCompact and 78 or (compact and math.max(82, (layoutTextSize * 4) + 8) or math.max(104, (layoutTextSize * 5) + 8))
    local memW = ultraCompact and 66 or (compact and math.max(70, (layoutTextSize * 3) + 10) or math.max(84, (layoutTextSize * 3) + 18))
    local desiredNameW = ultraCompact and math.floor(rowW * 0.24) or (compact and math.floor(rowW * 0.25) or math.floor(rowW * 0.30))
    local nameW = Clamp(desiredNameW, ultraCompact and 74 or (compact and 92 or 160), ultraCompact and 120 or (compact and 170 or 420))
    local remainingForProfiles = rowW - nameW - allW - stateW - memW - (profileGap * (profileCount - 1)) - 18
    local profileW = Clamp(math.floor(remainingForProfiles / profileCount), ultraCompact and 26 or (compact and 34 or 58), ultraCompact and 48 or (compact and 64 or 104))
    local totalNeeded = nameW + allW + stateW + memW + (profileW * profileCount) + (profileGap * (profileCount - 1)) + 42
    if totalNeeded > rowW then
        local overflow = totalNeeded - rowW
        nameW = math.max(96, nameW - overflow)
        totalNeeded = nameW + allW + stateW + memW + (profileW * profileCount) + (profileGap * (profileCount - 1)) + 42
        if totalNeeded > rowW then
            profileGap = math.max(1, profileGap - 2)
            profileW = math.max(28, profileW - 2)
        end
    end

    local x = 14
    mainPanel.profileGap = profileGap
    mainPanel.colX = { name = x }
    x = x + nameW
    mainPanel.colX.all = x
    x = x + allW
    mainPanel.colX.state = x
    x = x + stateW
    mainPanel.colX.mem = x
    x = x + memW + 12
    for _, key in ipairs(PROFILE_ORDER) do
        mainPanel.colX[key] = x
        x = x + profileW + profileGap
    end
    mainPanel.nameW = nameW
    mainPanel.allW = allW
    mainPanel.stateW = stateW
    mainPanel.memW = memW
    mainPanel.profileW = profileW
    mainPanel.rowW = rowW

    if mainPanel.header then
        mainPanel.header.addonHeader:ClearAllPoints()
        if mainPanel.header.azHeader then mainPanel.header.azHeader:ClearAllPoints() end
        if mainPanel.header.groupHeader then mainPanel.header.groupHeader:ClearAllPoints() end
        mainPanel.header.allHeader:ClearAllPoints()
        mainPanel.header.stateHeader:ClearAllPoints()
        mainPanel.header.memHeader:ClearAllPoints()
        mainPanel.header.addonHeader:SetPoint("TOPLEFT", mainPanel.header, "TOPLEFT", mainPanel.colX.name, -12)
        if mainPanel.header.azHeader then
            mainPanel.header.azHeader:SetSize(40, 18)
            mainPanel.header.azHeader:SetPoint("LEFT", mainPanel.header.addonHeader, "RIGHT", 8, 0)
        end
        if mainPanel.header.groupHeader then
            mainPanel.header.groupHeader:SetSize(56, 18)
            mainPanel.header.groupHeader:SetPoint("LEFT", mainPanel.header.azHeader or mainPanel.header.addonHeader, "RIGHT", 5, 0)
        end
        mainPanel.header.allHeader:SetPoint("TOPLEFT", mainPanel.header, "TOPLEFT", mainPanel.colX.all + 4, -30)
        mainPanel.header.allHeader:SetWidth(math.max(26, allW - 8))
        mainPanel.header.allHeader:SetJustifyH("CENTER")
        mainPanel.header.allHeader:SetText(allW < 52 and "All" or "All")
        mainPanel.header.stateHeader:SetPoint("TOPLEFT", mainPanel.header, "TOPLEFT", mainPanel.colX.state + 4, -30)
        mainPanel.header.stateHeader:SetWidth(math.max(46, stateW - 8))
        mainPanel.header.stateHeader:SetJustifyH("CENTER")
        mainPanel.header.stateHeader:SetText(stateW < 94 and "State" or "State")
        mainPanel.header.memHeader:SetPoint("TOPLEFT", mainPanel.header, "TOPLEFT", mainPanel.colX.mem + 2, -25)
        for _, key in ipairs(PROFILE_ORDER) do
            local group = columnButtons[key]
            if group then
                local headerLabel = (profileW < 58 and PROFILE_SHORT_LABELS[key]) or PROFILE_LABELS[key]
                if key == "world" then
                    headerLabel = "World"
                end
                local headerFont = Clamp(math.floor(math.min(GetEffectiveTextSize() + 2, (profileW / 1.80))), 14, math.max(14, GetEffectiveTextSize() + 2))
                group.label:SetText(headerLabel)
                group.label:SetFont(STANDARD_TEXT_FONT, headerFont, "OUTLINE")
                group.label:SetWidth(math.max(24, profileW - 2))
                group.label:SetJustifyH("CENTER")
                group.label:SetWordWrap(false)
                group.label:SetNonSpaceWrap(false)
                group.label:ClearAllPoints()
                group.on:ClearAllPoints()
                group.off:ClearAllPoints()
                group.bg:ClearAllPoints()
                group.bg:SetPoint("TOPLEFT", mainPanel.header, "TOPLEFT", mainPanel.colX[key], -2)
                group.bg:SetPoint("BOTTOMLEFT", mainPanel.header, "BOTTOMLEFT", mainPanel.colX[key], 2)
                group.bg:SetWidth(profileW)
                group.label:SetPoint("TOP", mainPanel.header, "TOPLEFT", mainPanel.colX[key] + (profileW * 0.5), -10)
                group.on:Hide()
                group.off:Hide()
            end
        end
    end


    if mainPanel.applyButton and mainPanel.scanButton and mainPanel.reloadButton and updateUsageButton and mainPanel.previewButton then
        local buttonY = 12
        local bw = rowW < 820 and 92 or 116
        mainPanel.applyButton:ClearAllPoints()
        mainPanel.applyButton:SetSize(bw, 28)
        mainPanel.applyButton:SetPoint("BOTTOMLEFT", mainPanel, "BOTTOMLEFT", 12, buttonY)
        mainPanel.scanButton:ClearAllPoints()
        mainPanel.scanButton:SetSize(bw, 28)
        mainPanel.scanButton:SetPoint("LEFT", mainPanel.applyButton, "RIGHT", 8, 0)
        mainPanel.reloadButton:ClearAllPoints()
        mainPanel.reloadButton:SetSize(rowW < 820 and 82 or 104, 28)
        mainPanel.reloadButton:SetPoint("LEFT", mainPanel.scanButton, "RIGHT", 8, 0)
        updateUsageButton:ClearAllPoints()
        updateUsageButton:SetSize(rowW < 980 and 1 or 116, 28)
        updateUsageButton:SetPoint("LEFT", mainPanel.reloadButton, "RIGHT", 8, 0)
        updateUsageButton:SetShown(rowW >= 980)
        mainPanel.previewButton:ClearAllPoints()
        mainPanel.previewButton:SetSize(1, 1)
        mainPanel.previewButton:SetPoint("LEFT", updateUsageButton:IsShown() and updateUsageButton or mainPanel.reloadButton, "RIGHT", 8, 0)
        mainPanel.previewButton:SetShown(false)
    end

    if statusText then
        statusText:ClearAllPoints()
        statusText:SetPoint("BOTTOMRIGHT", mainPanel, "BOTTOMRIGHT", -14, 18)
        statusText:SetWidth(math.max(160, math.floor(rowW * 0.38)))
    end

    for _, button in ipairs(quickProfileButtons) do
        if button.profileKey then
            button:SetBackdropColor(0.025, 0.025, 0.025, 0.96)
            button:SetBackdropBorderColor(0.28, 0.28, 0.28, 0.75)
            if button.label then
                button.label:SetFont(STANDARD_TEXT_FONT, math.max(11, GetEffectiveTextSize()), "OUTLINE")
            end
        end
    end

    ApplyBackgroundDarkness()

    if resizeGrip then
        resizeGrip:ClearAllPoints()
        resizeGrip:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -5, 5)
    end

    if CAP.RefreshRows and not skipRowRefresh then CAP:RefreshRows(true) end
end

local function CreateSidePanel()
    sidePanel = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    sidePanel:SetClipsChildren(true)
    StylePanel(sidePanel, 0.005, 0.005, 0.005, 0.18)
    sidePanel.fontStrings = {}
    sidePanel.contentHeight = 660

    sidePanel.scrollFrame = CreateFrame("ScrollFrame", nil, sidePanel)
    sidePanel.scrollFrame:SetClipsChildren(true)
    sidePanel.scrollFrame:EnableMouse(true)
    sidePanel.scrollFrame:EnableMouseWheel(true)
    sidePanel.scrollFrame:SetScript("OnMouseWheel", function(self, delta)
        local current = self:GetVerticalScroll()
        local maxScroll = self:GetVerticalScrollRange()
        self:SetVerticalScroll(Clamp(current - (delta * 34), 0, maxScroll))
    end)

    sidePanel.content = CreateFrame("Frame", nil, sidePanel.scrollFrame)
    sidePanel.content:SetSize(190, sidePanel.contentHeight)
    sidePanel.scrollFrame:SetScrollChild(sidePanel.content)

    sidePanel.bgDragon = sidePanel:CreateTexture(nil, "BACKGROUND")
    sidePanel.bgDragon:SetPoint("TOPLEFT", sidePanel, "TOPLEFT", 2, -2)
    sidePanel.bgDragon:SetPoint("BOTTOMRIGHT", sidePanel, "BOTTOMRIGHT", -2, 2)
    sidePanel.bgDragon:SetTexture(MEDIA_BACKGROUND)
    sidePanel.bgDragon:SetTexCoord(0.02, 0.98, 0.02, 0.98)
    sidePanel.bgDragon:SetBlendMode("BLEND")
    sidePanel.bgDragon:SetAlpha(0.40)

    local function SideText(text, x, y, size, color, extra)
        local fs = sidePanel.content:CreateFontString(nil, "OVERLAY")
        fs.capExtra = extra or 0
        fs:SetFont(STANDARD_TEXT_FONT, size or GetEffectiveTextSize(), "OUTLINE")
        fs:SetTextColor(color and color.r or 0.92, color and color.g or 0.92, color and color.b or 0.92, 1)
        fs:SetPoint("TOPLEFT", x, y)
        fs:SetText(text)
        fs:SetWordWrap(false)
        fs:SetNonSpaceWrap(false)
        sidePanel.fontStrings[#sidePanel.fontStrings + 1] = fs
        return fs
    end

    local function NavButton(label, iconPath, profile, y)
        local btn = CreateFrame("Button", nil, sidePanel.content, "BackdropTemplate")
        StyleActionButton(btn, "", 170, 34)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", sidePanel.content, "TOPLEFT", 8, y)
        btn:SetPoint("TOPRIGHT", sidePanel.content, "TOPRIGHT", -8, y)
        btn:SetHeight(34)
        btn.profileKey = profile

        btn.icon = btn:CreateTexture(nil, "ARTWORK")
        btn.icon:SetSize(20, 20)
        btn.icon:SetPoint("LEFT", btn, "LEFT", 12, 0)
        btn.icon:SetTexture(iconPath)

        btn.label = btn:CreateFontString(nil, "OVERLAY")
        btn.label:SetFont(STANDARD_TEXT_FONT, math.max(11, GetEffectiveTextSize()), "OUTLINE")
        btn.label:SetTextColor(0.94, 0.94, 0.94, 1)
        btn.label:SetPoint("LEFT", btn.icon, "RIGHT", 12, 0)
        btn.label:SetPoint("RIGHT", btn, "RIGHT", -10, 0)
        btn.label:SetJustifyH("LEFT")
        btn.label:SetWordWrap(false)
        btn.label:SetNonSpaceWrap(false)
        btn.label:SetText(label)

        btn:SetScript("OnClick", function()
            if profile then
                OpenQuickProfile(profile)
            end
        end)
        btn:SetScript("OnEnter", nil)
        btn:SetScript("OnLeave", nil)
        btn:SetScript("OnMouseDown", nil)
        btn:SetScript("OnMouseUp", nil)
        btn:SetBackdropColor(0.025, 0.025, 0.025, 0.96)
        btn:SetBackdropBorderColor(0.28, 0.28, 0.28, 0.75)
        quickProfileButtons[#quickProfileButtons + 1] = btn
        return btn
    end

    sideLogo = sidePanel.content:CreateTexture(nil, "ARTWORK")
    sideLogo:SetPoint("TOP", sidePanel.content, "TOP", 0, -10)
    sideLogo:SetTexture(MEDIA_LOGO_SQUARE)
    sideLogo:SetSize(1, 1)
    sideLogo:SetAlpha(0)
    sideLogo:Hide()

    local manualHeader = SideText("MANUAL LOAD", 12, -18, 12, { r = 1, g = 0.82, b = 0.32 }, 0)
    manualHeader:SetWidth(170)
    manualHeader:SetJustifyH("CENTER")

    NavButton("Raid", "Interface\\Icons\\Achievement_Boss_Ragnaros", "raid", -46)
    NavButton("M+", "Interface\\Icons\\Achievement_Dungeon_Heroic_GloryoftheRaider", "mplus", -84)
    NavButton("Dungeon", "Interface\\Icons\\Achievement_Dungeon_Heroic_GloryoftheRaider", "dungeon", -122)
    NavButton("Delve", "Interface\\Icons\\INV_Misc_Map_01", "delve", -160)
    NavButton("World", "Interface\\Icons\\INV_Misc_Map_01", "world", -198)
    NavButton("City", "Interface\\Icons\\INV_Misc_GroupLooking", "city", -236)
    NavButton("PvP", "Interface\\Icons\\Achievement_BG_winWSG", "pvp", -274)

    local divider = sidePanel.content:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(0.55, 0.03, 0.03, 0.75)
    divider:SetPoint("TOPLEFT", sidePanel.content, "TOPLEFT", 10, -318)
    divider:SetPoint("TOPRIGHT", sidePanel.content, "TOPRIGHT", -10, -318)
    divider:SetHeight(1)

    local optionHeader = SideText("OPTIONS", 12, -334, 12, { r = 1, g = 0.82, b = 0.32 }, 0)
    optionHeader:SetWidth(170)
    optionHeader:SetJustifyH("CENTER")

    local function OptionCheck(key, label, y, onChange)
        local cb = CreateFrame("CheckButton", nil, sidePanel.content, "UICheckButtonTemplate")
        cb:SetSize(22, 22)
        cb:SetPoint("TOPLEFT", sidePanel.content, "TOPLEFT", 10, y)
        cb.Text:SetText(label)
        cb.Text:SetFont(STANDARD_TEXT_FONT, math.max(10, GetEffectiveTextSize() - 2), "OUTLINE")
        cb.Text:SetTextColor(0.94, 0.94, 0.94, 1)
        cb.Text:SetPoint("LEFT", cb, "RIGHT", 3, 0)
        cb.Text:SetWidth(145)
        cb.Text:SetJustifyH("LEFT")
        cb.Text:SetWordWrap(false)
        cb.Text:SetNonSpaceWrap(false)
        cb:SetHitRectInsets(0, 0, 0, 0)
        cb:SetScript("OnClick", function(self)
            DB().settings[key] = self:GetChecked() and true or false
            if onChange then onChange(self) end
            RefreshOptionChecks()
            if CAP.UpdateLayout then CAP:UpdateLayout() end
        end)
        optionControls[key] = cb
        return cb
    end

    OptionCheck("linkDungeonMPlus", "Combine M+ / Dungeon", -360, function()
        ScanAddOns(false)
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    end)
    OptionCheck("linkWorldCity", "Combine World / City", -405, function()
        ScanAddOns(false)
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    end)
    OptionCheck("protectCoreAddons", "Lock Protected Addons", -450, function()
        ScanAddOns(false)
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    end)
    OptionCheck("perCharacter", "Per Character", -495, function()
        ScanAddOns(false)
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    end)
    OptionCheck("darkenPanels", "Darker Panels", -540, function()
        ApplyBackgroundDarkness()
    end)
    OptionCheck("dontShowPrompts", "Disable Zone Prompt", -585, function()
        if DB().settings.dontShowPrompts then
            HideApplyPopup()
        end
    end)

    local textLabel = SideText("TEXT SIZE", 12, -645, 11, { r = 1, g = 0.82, b = 0.32 })
    textLabel:SetWidth(100)

    local textValue = SideText(tostring(GetEffectiveTextSize()), 148, -645, 11, { r = 0.94, g = 0.94, b = 0.94 })
    textValue:SetWidth(28)
    textValue:SetJustifyH("RIGHT")

    local textSlider = CreateFrame("Slider", "ChayAddonProfilesTextSizeSlider", sidePanel.content, "OptionsSliderTemplate")
    textSlider:SetPoint("TOPLEFT", sidePanel.content, "TOPLEFT", 10, -671)
    textSlider:SetPoint("TOPRIGHT", sidePanel.content, "TOPRIGHT", -10, -671)
    textSlider:SetHeight(18)
    textSlider:SetMinMaxValues(10, 30)
    textSlider:SetValueStep(1)
    if textSlider.SetObeyStepOnDrag then textSlider:SetObeyStepOnDrag(true) end
    textSlider:SetValue(GetEffectiveTextSize())
    if textSlider.Low then textSlider.Low:SetText("10") end
    if textSlider.High then textSlider.High:SetText("30") end
    if textSlider.Text then textSlider.Text:SetText("") end
    textSlider:SetScript("OnValueChanged", function(self, value)
        local newSize = Clamp(math.floor((tonumber(value) or 13) + 0.5), 10, 30)
        if DB().settings.textSize ~= newSize then
            DB().settings.textSize = newSize
            textValue:SetText(tostring(newSize))
            ApplyTextSize()
            if CAP.UpdateLayout then CAP:UpdateLayout() end
        end
    end)
    sidePanel.textSlider = textSlider
    sidePanel.textValue = textValue

    -- Hidden controls retained only for settings not shown in the left panel.
    for _, key in ipairs({ "detectNewAddOns", "showMinimapButton", "groupDependencies" }) do
        if not optionControls[key] then
            local cb = CreateFrame("CheckButton", nil, sidePanel.content, "UICheckButtonTemplate")
            cb:SetSize(1, 1)
            cb:SetPoint("TOPLEFT", -200, 0)
            cb:Hide()
            optionControls[key] = cb
        end
    end
end

local function CreateHeader()
    -- Custom frameless header. No Blizzard title bar is used.
    mainFrame.headerDrag = CreateFrame("Frame", nil, mainFrame)
    mainFrame.headerDrag:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 8, -6)
    mainFrame.headerDrag:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -48, -6)
    mainFrame.headerDrag:SetHeight(126)
    mainFrame.headerDrag:EnableMouse(true)
    mainFrame.headerDrag:RegisterForDrag("LeftButton")
    mainFrame.headerDrag:SetScript("OnDragStart", function() mainFrame:StartMoving() end)
    mainFrame.headerDrag:SetScript("OnDragStop", function()
        mainFrame:StopMovingOrSizing()
        local point, _, relativePoint, x, y = mainFrame:GetPoint(1)
        DB().settings.framePoint = { point = point, relativePoint = relativePoint, x = x, y = y }
    end)

    headerArtPanel = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    headerArtPanel:SetFrameLevel(mainFrame:GetFrameLevel() + 1)
    headerArtPanel:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    headerArtPanel:SetBackdropColor(0.010, 0.004, 0.004, 0.56)
    headerArtPanel:SetBackdropBorderColor(0.70, 0.035, 0.035, 0.98)

    headerArtPanel.dragon = headerArtPanel:CreateTexture(nil, "BACKGROUND")
    headerArtPanel.dragon:SetTexture(MEDIA_HEADER_ART)
    headerArtPanel.dragon:SetTexCoord(0, 1, 0, 1)
    headerArtPanel.dragon:SetAlpha(0.92)

    headerArtPanel.shade = headerArtPanel:CreateTexture(nil, "BORDER")
    headerArtPanel.shade:SetPoint("TOPLEFT", 2, -2)
    headerArtPanel.shade:SetPoint("BOTTOMRIGHT", -2, 2)
    headerArtPanel.shade:SetColorTexture(0, 0, 0, 0.12)

    headerArtPanel.topTrim = headerArtPanel:CreateTexture(nil, "ARTWORK")
    headerArtPanel.topTrim:SetHeight(2)
    headerArtPanel.topTrim:SetColorTexture(0.95, 0.10, 0.05, 0.88)

    headerArtPanel.bottomTrim = headerArtPanel:CreateTexture(nil, "ARTWORK")
    headerArtPanel.bottomTrim:SetHeight(2)
    headerArtPanel.bottomTrim:SetColorTexture(0.95, 0.10, 0.05, 0.82)

    headerArtPanel.centerGem = headerArtPanel:CreateTexture(nil, "ARTWORK")
    headerArtPanel.centerGem:SetTexture(MEDIA_LOGO_SQUARE)
    headerArtPanel.centerGem:SetAlpha(0.36)
    headerArtPanel.centerGem:SetBlendMode("ADD")

    headerArtPanel.leftWing = headerArtPanel:CreateTexture(nil, "ARTWORK")
    headerArtPanel.leftWing:SetColorTexture(0.95, 0.15, 0.07, 0.48)
    headerArtPanel.rightWing = headerArtPanel:CreateTexture(nil, "ARTWORK")
    headerArtPanel.rightWing:SetColorTexture(0.95, 0.15, 0.07, 0.48)

    headerSquareLogo = mainFrame:CreateTexture(nil, "ARTWORK")
    headerSquareLogo:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 18, -10)
    headerSquareLogo:SetTexture(MEDIA_LOGO_SQUARE)
    headerSquareLogo:SetTexCoord(0, 1, 0, 1)
    headerSquareLogo:SetSize(1, 1)
    headerSquareLogo:Hide()

    titleLogo = headerArtPanel:CreateTexture(nil, "OVERLAY")
    titleLogo:SetPoint("TOP", mainFrame, "TOP", 0, -28)
    titleLogo:SetTexture(MEDIA_LOGO)
    titleLogo:SetTexCoord(0, 1, 0, 1)
    titleLogo:SetSize(520, 96)
    titleLogo:SetAlpha(0.92)
    titleLogo:SetBlendMode("BLEND")

    local statusBox = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    mainFrame.statusBox = statusBox
    statusBox:SetFrameLevel((headerArtPanel and headerArtPanel:GetFrameLevel() or mainFrame:GetFrameLevel()) + 2)
    statusBox:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    statusBox:SetBackdropColor(0.015, 0, 0, 0.90)
    statusBox:SetBackdropBorderColor(0.90, 0.10, 0.10, 1)
    statusBox:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -44, -42)
    statusBox:SetSize(470, 72)
    statusBox.innerShade = statusBox:CreateTexture(nil, "BACKGROUND")
    statusBox.innerShade:SetPoint("TOPLEFT", 1, -1)
    statusBox.innerShade:SetPoint("BOTTOMRIGHT", -1, 1)
    statusBox.innerShade:SetColorTexture(0.05, 0.01, 0.01, 0.34)
    statusBox.topGlow = statusBox:CreateTexture(nil, "ARTWORK")
    statusBox.topGlow:SetPoint("TOPLEFT", 1, -1)
    statusBox.topGlow:SetPoint("TOPRIGHT", -1, -1)
    statusBox.topGlow:SetHeight(2)
    statusBox.topGlow:SetColorTexture(1.00, 0.24, 0.24, 0.92)
    statusBox.bottomGlow = statusBox:CreateTexture(nil, "ARTWORK")
    statusBox.bottomGlow:SetPoint("BOTTOMLEFT", 1, 1)
    statusBox.bottomGlow:SetPoint("BOTTOMRIGHT", -1, 1)
    statusBox.bottomGlow:SetHeight(2)
    statusBox.bottomGlow:SetColorTexture(1.00, 0.70, 0.16, 0.55)
    statusBox.leftGlow = statusBox:CreateTexture(nil, "ARTWORK")
    statusBox.leftGlow:SetPoint("TOPLEFT", 1, -1)
    statusBox.leftGlow:SetPoint("BOTTOMLEFT", 1, 1)
    statusBox.leftGlow:SetWidth(2)
    statusBox.leftGlow:SetColorTexture(1.00, 0.18, 0.08, 0.72)
    statusBox.rightGlow = statusBox:CreateTexture(nil, "ARTWORK")
    statusBox.rightGlow:SetPoint("TOPRIGHT", -1, -1)
    statusBox.rightGlow:SetPoint("BOTTOMRIGHT", -1, 1)
    statusBox.rightGlow:SetWidth(2)
    statusBox.rightGlow:SetColorTexture(1.00, 0.18, 0.08, 0.72)

    mainFrame.statusFields = {}
    for _, key in ipairs({ "current", "loaded", "pending", "combat" }) do
        local field = CreateFrame("Frame", nil, statusBox)
        field.label = MakeFontString(field, nil, math.max(9, GetEffectiveTextSize() - 2), { r = 0.78, g = 0.78, b = 0.78 })
        field.label:SetJustifyH("CENTER")
        field.value = MakeFontString(field, nil, GetEffectiveTextSize() + 1, { r = 0.94, g = 0.94, b = 0.94 })
        field.value:SetJustifyH("CENTER")
        field.divider = field:CreateTexture(nil, "ARTWORK")
        field.divider:SetColorTexture(0.42, 0.16, 0.16, 0.55)
        mainFrame.statusFields[key] = field
    end

    profileText = MakeFontString(statusBox, nil, GetEffectiveTextSize(), { r = 0.94, g = 0.94, b = 0.94 })
    profileText:Hide()

    mainFrame.title = mainFrame:CreateFontString(nil, "OVERLAY")
    mainFrame.title:Hide()
    mainFrame.subtitle = mainFrame:CreateFontString(nil, "OVERLAY")
    mainFrame.subtitle:Hide()
    mainFrame.headerLine = mainFrame:CreateFontString(nil, "OVERLAY")
    mainFrame.headerLine:Hide()
end

local function CreateMainPanel()
    mainPanel = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    mainPanel:SetClipsChildren(true)
    StylePanel(mainPanel, 0.005, 0.005, 0.005, 0.16)

    watermarkLogo = mainPanel:CreateTexture(nil, "BACKGROUND", nil, 1)
    watermarkLogo:SetTexture(MEDIA_BACKGROUND)
    watermarkLogo:SetTexCoord(0.02, 0.98, 0.02, 0.98)
    watermarkLogo:SetBlendMode("BLEND")
    watermarkLogo:SetAlpha(0.82)

    mainPanel.panelTitle = mainPanel:CreateFontString(nil, "OVERLAY")
    mainPanel.panelTitle:Hide()
    mainPanel.panelSubtitle = mainPanel:CreateFontString(nil, "OVERLAY")
    mainPanel.panelSubtitle:Hide()

    local searchLabel = MakeFontString(mainPanel, nil, GetEffectiveTextSize() - 1, { r = 0.90, g = 0.90, b = 0.90 })
    mainPanel.searchLabel = searchLabel
    searchLabel:SetDrawLayer("OVERLAY", 7)
    searchLabel:SetPoint("TOPRIGHT", mainPanel, "TOPRIGHT", -54, -28)
    searchLabel:SetText("")
    searchLabel:Hide()

    searchBox = CreateFrame("EditBox", nil, mainPanel, "InputBoxTemplate")
    searchBox:SetSize(270, 28)
    searchBox:SetPoint("TOPRIGHT", mainPanel, "TOPRIGHT", -24, -46)
    searchBox:SetFrameStrata("DIALOG")
    searchBox:SetFrameLevel((mainFrame:GetFrameLevel() or 1) + 20)
    searchBox:SetAutoFocus(false)
    searchBox:SetScript("OnTextChanged", function(self)
        if searchClearButton then
            searchClearButton:SetShown((self:GetText() or "") ~= "")
        end
        CAP:RefreshRows(true)
    end)
    searchBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

    searchClearButton = CreateFrame("Button", nil, mainPanel, "BackdropTemplate")
    StyleActionButton(searchClearButton, "X", 22, 22)
    searchClearButton:SetPoint("RIGHT", searchBox, "RIGHT", -3, 0)
    searchClearButton:SetFrameLevel(searchBox:GetFrameLevel() + 3)
    searchClearButton:SetScript("OnClick", function()
        searchBox:SetText("")
        searchBox:ClearFocus()
        searchClearButton:Hide()
        CAP:RefreshRows(true)
    end)
    searchClearButton:Hide()

    filterButton = nil

    local header = CreateFrame("Frame", nil, mainPanel, "BackdropTemplate")
    StylePanel(header, 0.12, 0.01, 0.01, 0.42)
    mainPanel.header = header

    header.addonHeader = CreateFrame("Button", nil, header, "BackdropTemplate")
    header.addonHeader:SetSize(120, 24)
    header.addonHeader.text = MakeFontString(header.addonHeader, nil, DB().settings.textSize, { r = 1, g = 0.22, b = 0.22 })
    header.addonHeader.text:SetPoint("LEFT")
    header.addonHeader.text:SetText("Addon")
    header.addonHeader:SetScript("OnClick", function()
        local db = DB()
        if db.settings.sortMode == "group" then
            db.settings.sortMode = "name"
            db.settings.groupDependencies = false
        else
            db.settings.sortMode = "group"
            db.settings.groupDependencies = true
        end
        RefreshOptionChecks()
        CAP:RefreshRows(true)
    end)
    header.azHeader = CreateFrame("Button", nil, header, "BackdropTemplate")
    StyleToggleButton(header.azHeader, "A-Z", true)
    header.azHeader:SetScript("OnClick", function()
        DB().settings.sortMode = "name"
        DB().settings.groupDependencies = false
        RefreshOptionChecks()
        CAP:RefreshRows(true)
    end)

    header.groupHeader = CreateFrame("Button", nil, header, "BackdropTemplate")
    StyleToggleButton(header.groupHeader, "Group", true)
    header.groupHeader:SetScript("OnClick", function()
        DB().settings.sortMode = "group"
        DB().settings.groupDependencies = true
        RefreshOptionChecks()
        CAP:RefreshRows(true)
    end)
    header.allHeader = MakeFontString(header, nil, DB().settings.textSize, { r = 1, g = 0.22, b = 0.22 })
    header.allHeader:SetText("All")
    header.stateHeader = MakeFontString(header, nil, DB().settings.textSize, { r = 1, g = 0.22, b = 0.22 })
    header.stateHeader:SetText("State")

    header.memHeader = CreateFrame("Button", nil, header, "BackdropTemplate")
    header.memHeader:SetSize(54, 22)
    header.memHeader.text = MakeFontString(header.memHeader, nil, GetEffectiveTextSize(), { r = 1, g = 0.76, b = 0.22 })
    header.memHeader.text:SetPoint("CENTER")
    header.memHeader.text:SetText("Mem")
    StylePanel(header.memHeader, 0.05, 0.01, 0.01, 0.64)
    header.memHeader:SetScript("OnClick", function()
        local db = DB()
        if db.settings.sortMode == "memory" then
            db.settings.sortMemDesc = not db.settings.sortMemDesc
        else
            db.settings.sortMode = "memory"
            db.settings.sortMemDesc = true
        end
        CAP:RefreshRows(true)
    end)

    for index, key in ipairs(PROFILE_ORDER) do
        local profileKey = key
        local group = {}
        local r, g, b, a = GetColumnShade(index, true)
        group.bg = header:CreateTexture(nil, "BACKGROUND")
        group.bg:SetColorTexture(r, g, b, a)
        group.label = MakeFontString(header, nil, GetEffectiveTextSize() - 1, { r = 0.90, g = 0.90, b = 0.90 })
        group.label:SetText(PROFILE_LABELS[key])
        group.on = CreateFrame("Button", nil, header, "BackdropTemplate")
        StyleToggleButton(group.on, "ON", true)
        group.off = CreateFrame("Button", nil, header, "BackdropTemplate")
        StyleToggleButton(group.off, "OFF", false)
        group.on:SetScript("OnClick", function()
            for _, addon in ipairs(addonList) do
                if not addon.protected and not addon.incompatible then
                    SetRule(addon.name, profileKey, true)
                end
            end
            CAP:RefreshRows(true)
        end)
        group.off:SetScript("OnClick", function()
            for _, addon in ipairs(addonList) do
                if not addon.protected then
                    SetRule(addon.name, profileKey, false)
                end
            end
            CAP:RefreshRows(true)
        end)
        columnButtons[key] = group
    end

    scrollFrame = CreateFrame("ScrollFrame", nil, mainPanel, "UIPanelScrollFrameTemplate")
    scrollFrame:EnableMouse(true)
    scrollFrame:EnableMouseWheel(true)
    scrollFrame:SetScript("OnMouseWheel", function(_, delta)
        ScrollList(delta)
    end)

    scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(1, 1)
    scrollChild:EnableMouse(true)
    AddListWheel(scrollChild)
    scrollFrame:SetScrollChild(scrollChild)
    if scrollChild.SetClipsChildren then
        scrollChild:SetClipsChildren(true)
    end

    mainPanel.footerMask = CreateFrame("Frame", nil, mainPanel, "BackdropTemplate")
    mainPanel.footerMask:SetFrameLevel(mainPanel:GetFrameLevel() + 7)
    mainPanel.footerMask:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    mainPanel.footerMask:SetBackdropColor(0, 0, 0, 0.42)

    local apply = CreateFrame("Button", nil, mainPanel, "BackdropTemplate")
    mainPanel.applyButton = apply
    StyleActionButton(apply, "Apply Profile", 128, 30)
    apply:SetFrameLevel(mainPanel:GetFrameLevel() + 10)
    apply:SetPoint("BOTTOMLEFT", 20, 16)
    apply:SetScript("OnClick", function() CAP:ApplyProfile(currentProfile) end)

    local scan = CreateFrame("Button", nil, mainPanel, "BackdropTemplate")
    mainPanel.scanButton = scan
    StyleActionButton(scan, "Scan Addons", 128, 30)
    scan:SetFrameLevel(mainPanel:GetFrameLevel() + 10)
    scan:SetPoint("LEFT", apply, "RIGHT", 12, 0)
    scan:SetScript("OnClick", function()
        ScanAddOns(true)
        CAP:RefreshRows(true)
    end)

    local reload = CreateFrame("Button", nil, mainPanel, "BackdropTemplate")
    mainPanel.reloadButton = reload
    StyleActionButton(reload, "Reload UI", 116, 30)
    reload:SetFrameLevel(mainPanel:GetFrameLevel() + 10)
    reload:SetPoint("LEFT", scan, "RIGHT", 12, 0)
    reload:SetScript("OnClick", ReloadNow)

    updateUsageButton = CreateFrame("Button", nil, mainPanel, "BackdropTemplate")
    StyleActionButton(updateUsageButton, "Update Usage", 128, 30)
    updateUsageButton:SetFrameLevel(mainPanel:GetFrameLevel() + 10)
    updateUsageButton:SetPoint("LEFT", reload, "RIGHT", 12, 0)
    updateUsageButton:SetScript("OnClick", function()
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        ScanAddOns(false)
        CAP:RefreshRows(true)
    end)

    local preview = CreateFrame("Button", nil, mainPanel, "BackdropTemplate")
    mainPanel.previewButton = preview
    StyleActionButton(preview, "Preview", 104, 30)
    preview:SetFrameLevel(mainPanel:GetFrameLevel() + 10)
    preview:SetPoint("LEFT", updateUsageButton, "RIGHT", 12, 0)
    preview:SetScript("OnClick", function()
        ShowPreviewChanges(currentProfile)
    end)
    preview:Hide()

    statusText = MakeFontString(mainPanel.footerMask or mainPanel, nil, DB().settings.textSize - 1, { r = 1, g = 0.20, b = 0.20 })
    statusText:SetDrawLayer("OVERLAY", 7)
    statusText:SetPoint("BOTTOMRIGHT", -72, 26)
    statusText:SetWidth(430)
    statusText:SetJustifyH("RIGHT")
end

local function SaveMainFrameSize()
    if not mainFrame then return end
    local w, h = mainFrame:GetSize()
    w = Clamp(w, MIN_WIDTH, MAX_WIDTH)
    h = Clamp(h, MIN_HEIGHT, MAX_HEIGHT)
    mainFrame:SetSize(w, h)
    DB().settings.frameSize.width = w
    DB().settings.frameSize.height = h
end

local function CreateResizeGrip()
    resizeGrip = CreateFrame("Button", nil, mainFrame, "BackdropTemplate")
    resizeGrip:SetSize(32, 32)
    resizeGrip:SetFrameLevel(mainFrame:GetFrameLevel() + 30)
    resizeGrip:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    resizeGrip:SetBackdropColor(0.05, 0.01, 0.01, 0.74)
    resizeGrip:SetBackdropBorderColor(0.70, 0.03, 0.03, 1)

    local l1 = resizeGrip:CreateTexture(nil, "ARTWORK")
    l1:SetColorTexture(0.95, 0.04, 0.04, 0.95)
    l1:SetSize(2, 24)
    l1:SetPoint("BOTTOMRIGHT", -6, 5)
    l1:SetRotation(0.785)

    local l2 = resizeGrip:CreateTexture(nil, "ARTWORK")
    l2:SetColorTexture(0.95, 0.04, 0.04, 0.75)
    l2:SetSize(2, 17)
    l2:SetPoint("BOTTOMRIGHT", -12, 5)
    l2:SetRotation(0.785)

    local l3 = resizeGrip:CreateTexture(nil, "ARTWORK")
    l3:SetColorTexture(0.95, 0.04, 0.04, 0.55)
    l3:SetSize(2, 10)
    l3:SetPoint("BOTTOMRIGHT", -18, 5)
    l3:SetRotation(0.785)

    resizeGrip:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" or not mainFrame then return end
        local scale = UIParent:GetEffectiveScale() or 1
        local cx, cy = GetCursorPosition()
        self.startX = (cx or 0) / scale
        self.startY = (cy or 0) / scale
        self.startW, self.startH = mainFrame:GetSize()
        self.elapsed = 0
        self.didResize = false
        self:SetScript("OnUpdate", function(grip, elapsed)
            grip.elapsed = (grip.elapsed or 0) + elapsed
            if grip.elapsed < 0.010 then return end
            grip.elapsed = 0

            local currentScale = UIParent:GetEffectiveScale() or 1
            local mx, my = GetCursorPosition()
            mx = (mx or 0) / currentScale
            my = (my or 0) / currentScale
            local dx = mx - (grip.startX or mx)
            local dy = my - (grip.startY or my)

            if not grip.didResize and math.abs(dx) < 3 and math.abs(dy) < 3 then
                return
            end

            grip.didResize = true
            local newW = Clamp((grip.startW or mainFrame:GetWidth()) + dx, MIN_WIDTH, MAX_WIDTH)
            local newH = Clamp((grip.startH or mainFrame:GetHeight()) - dy, MIN_HEIGHT, MAX_HEIGHT)
            mainFrame:SetSize(newW, newH)
            DB().settings.frameSize.width = newW
            DB().settings.frameSize.height = newH
            if CAP.UpdateLayout then CAP:UpdateLayout(true) end
        end)
    end)
    resizeGrip:SetScript("OnMouseUp", function(self)
        self:SetScript("OnUpdate", nil)
        if mainFrame then
            SaveMainFrameSize()
        end
        self.startX, self.startY, self.startW, self.startH = nil, nil, nil, nil
        self.didResize = false
        if CAP.UpdateLayout then CAP:UpdateLayout() end
    end)
    resizeGrip:SetScript("OnHide", function(self)
        self:SetScript("OnUpdate", nil)
        self.startX, self.startY, self.startW, self.startH = nil, nil, nil, nil
        self.didResize = false
    end)
end

local function CreateMainFrame()
    if mainFrame then return end

    local db = DB()
    mainFrame = CreateFrame("Frame", "ChayAddonProfilesFrame", UIParent, "BackdropTemplate")
    mainFrame:SetFrameStrata("DIALOG")
    mainFrame:SetMovable(true)
    mainFrame:SetResizable(true)
    mainFrame:SetResizeBounds(MIN_WIDTH, MIN_HEIGHT, MAX_WIDTH, MAX_HEIGHT)
    mainFrame:EnableMouse(true)
    mainFrame:SetClampedToScreen(true)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    mainFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relativePoint, x, y = self:GetPoint(1)
        DB().settings.framePoint = { point = point, relativePoint = relativePoint, x = x, y = y }
    end)
    mainFrame:EnableMouseWheel(true)
    mainFrame:SetScript("OnMouseWheel", function(_, delta)
        if IsControlKeyDown() then
            ResizeWindow(delta)
            SaveMainFrameSize()
        end
    end)
    StylePanel(mainFrame, 0, 0, 0, 0.30)

    mainFrame.dragonBackground = mainFrame:CreateTexture(nil, "BACKGROUND")
    mainFrame.dragonBackground:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 8, -8)
    mainFrame.dragonBackground:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -8, 8)
    mainFrame.dragonBackground:SetTexture(MEDIA_BACKGROUND)
    mainFrame.dragonBackground:SetTexCoord(0.03, 0.97, 0.06, 0.94)
    mainFrame.dragonBackground:SetAlpha(0)

    local width = Clamp(db.settings.frameSize.width or 1220, MIN_WIDTH, MAX_WIDTH)
    local height = Clamp(db.settings.frameSize.height or 760, MIN_HEIGHT, MAX_HEIGHT)
    mainFrame:SetSize(width, height)
    local p = db.settings.framePoint or DEFAULT_DB.settings.framePoint
    mainFrame:SetPoint(p.point or "CENTER", UIParent, p.relativePoint or "CENTER", p.x or 0, p.y or 0)

    local close = CreateFrame("Button", nil, mainFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)
    close:SetFrameLevel(mainFrame:GetFrameLevel() + 30)

    CreateHeader()
    CreateSidePanel()
    RefreshOptionChecks()
    CreateMainPanel()

    CreateResizeGrip()
    CAP:UpdateLayout()
    mainFrame:Hide()
end

local function SearchMatches(addon)
    if not searchBox then return true end
    local q = strlower(searchBox:GetText() or "")
    if q == "" then return true end
    return strfind(strlower(addon.name or ""), q, 1, true) or strfind(strlower(addon.title or ""), q, 1, true)
end

local function CreateRow(index)
    local row = CreateFrame("Frame", nil, scrollChild, "BackdropTemplate")
    row:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    row:EnableMouse(true)
    AddListWheel(row)
    row:SetScript("OnMouseUp", function(self, button)
        if button == "RightButton" and self.addon then
            OpenAddonNoteEditor(self.addon)
        end
    end)
    row:SetScript("OnEnter", function(self)
        if not self.addon then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.addon.title or self.addon.name or "Addon", 1, 0.25, 0.25)
        GameTooltip:AddLine("Right-click to edit note/tag.", 0.90, 0.90, 0.90)
        if self.addon.incompatible then
            GameTooltip:AddLine("Incompatible addons are forced OFF and ignored.", 1, 0.20, 0.20, true)
        elseif self.addon.protected then
            GameTooltip:AddLine("Protected addons are locked ON only while Lock Protected Addons is checked.", 1, 0.76, 0.42, true)
        end
        local note = GetAddonNote(self.addon.name)
        if note ~= "" then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Note: " .. note, 1, 0.86, 0.25, true)
        end
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    row.nameText = MakeFontString(row, nil, DB().settings.textSize, { r = 0.94, g = 0.94, b = 0.94 })
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)
    row.nameText:SetNonSpaceWrap(false)
    row.stateText = MakeFontString(row, nil, DB().settings.textSize, { r = 0.94, g = 0.94, b = 0.94 })
    row.stateText:SetWordWrap(false)
    row.stateText:SetNonSpaceWrap(false)
    row.memText = MakeFontString(row, nil, DB().settings.textSize, { r = 0.86, g = 0.86, b = 0.86 })
    row.memText:SetWordWrap(false)
    row.memText:SetNonSpaceWrap(false)
    row.allCheck = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
    row.allCheck:SetSize(24, 24)
    AddListWheel(row.allCheck)
    row.allCheck:SetScript("OnClick", function(self)
        local addon = self.addon
        if not addon then return end
        if addon.protected and not IsProtectedOverrideDisabled(addon.name) and not self:GetChecked() then
            self:SetChecked(true)
            StaticPopup_Show("CHAY_ADDON_PROFILES_PROTECTED_DISABLE", addon.title or addon.name, nil, addon)
            return
        elseif addon.protected and self:GetChecked() then
            SetProtectedOverrideDisabled(addon.name, false)
        end
        SetAllProfilesForAddon(addon, self:GetChecked() and true or false)
        CAP:RefreshRows(true)
    end)

    row.columnBGs = {}
    row.profileToggles = {}
    for _, key in ipairs(PROFILE_ORDER) do
        local profileKey = key
        local bg = row:CreateTexture(nil, "BACKGROUND")
        row.columnBGs[key] = bg
        local button = CreateFrame("Button", nil, row, "BackdropTemplate")
        button:SetSize(42, 22)
        AddListWheel(button)
        button:SetScript("OnClick", function(self)
            local addon = self.addon
            if not addon then return end
            if addon.protected and not IsProtectedOverrideDisabled(addon.name) and DesiredEnabled(addon.name, profileKey) then
                StaticPopup_Show("CHAY_ADDON_PROFILES_PROTECTED_DISABLE", addon.title or addon.name, nil, addon)
                return
            elseif addon.protected and IsProtectedOverrideDisabled(addon.name) and not DesiredEnabled(addon.name, profileKey) then
                SetProtectedOverrideDisabled(addon.name, false)
            end
            if addon.incompatible then
                SetRule(addon.name, profileKey, false)
                CAP:RefreshRows(true)
                return
            end
            SetRule(addon.name, profileKey, not DesiredEnabled(addon.name, profileKey))
            CAP:RefreshRows(true)
        end)
        row.profileToggles[profileKey] = button
    end
    rows[index] = row
    return row
end

function CAP:RefreshRows(noScan)
    if not scrollChild then return end
    if not noScan then
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        ScanAddOns(false)
    end
    SortAddons()

    wipe(visibleAddons)
    for _, addon in ipairs(addonList) do
        if SearchMatches(addon) then
            visibleAddons[#visibleAddons + 1] = addon
        end
    end

    local rowH = Clamp(GetEffectiveTextSize() + 21, 30, 64)
    local width = mainPanel.rowW or 900
    local colX = mainPanel.colX or {}

    for i, addon in ipairs(visibleAddons) do
        local row = rows[i] or CreateRow(i)
        row.addon = addon
        row:SetSize(width, rowH)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -((i - 1) * rowH))
        row:SetBackdropColor(i % 2 == 0 and 0.010 or 0.040, 0, 0, DB().settings.darkenPanels and 0.42 or 0.26)

        row.nameText:ClearAllPoints()
        row.nameText:SetPoint("LEFT", row, "LEFT", colX.name or 14, 0)
        row.nameText:SetWidth(math.max(54, (mainPanel.nameW or 300) - 14))
        local note = GetAddonNote(addon.name)
        row.nameText:SetText((note ~= "" and "* " or "") .. addon.title)
        if addon.incompatible then
            row.nameText:SetTextColor(1, 0.25, 0.25, 1)
        elseif addon.protected then
            row.nameText:SetTextColor(1, 0.76, 0.42, 1)
        else
            row.nameText:SetTextColor(0.94, 0.94, 0.94, 1)
        end

        row.allCheck:ClearAllPoints()
        row.allCheck:SetPoint("CENTER", row, "LEFT", (colX.all or 0) + math.floor((mainPanel.allW or 48) * 0.5), 0)
        row.allCheck.addon = addon
        local allEnabled = true
        for _, profileKey in ipairs(PROFILE_ORDER) do
            if not DesiredEnabled(addon.name, profileKey) then
                allEnabled = false
                break
            end
        end
        row.allCheck:SetChecked(allEnabled)
        row.allCheck:SetEnabled(not addon.incompatible)
        row.allCheck:SetAlpha(addon.incompatible and 0.35 or 1)

        row.stateText:ClearAllPoints()
        row.stateText:SetPoint("LEFT", row, "LEFT", (colX.state or 0) + 4, 0)
        row.stateText:SetWidth(math.max(44, (mainPanel.stateW or 118) - 6))
        row.stateText:SetJustifyH("LEFT")
        local tightState = (mainPanel.stateW or 118) < 92
        if addon.incompatible then
            row.stateText:SetText(tightState and "Ignore" or "Ignored")
            row.stateText:SetTextColor(1, 0.18, 0.18, 1)
        elseif addon.protected and IsProtectedOverrideDisabled(addon.name) then
            row.stateText:SetText(tightState and "Manual" or "Manual OFF")
            row.stateText:SetTextColor(1, 0.22, 0.22, 1)
        elseif addon.protected then
            row.stateText:SetText(IsEnabled(addon.name) and (tightState and "Prot" or "Protected") or (tightState and "Will" or "Will Enable"))
            row.stateText:SetTextColor(1, 0.76, 0.42, 1)
        elseif IsEnabled(addon.name) then
            row.stateText:SetText(tightState and "On" or "Enabled")
            row.stateText:SetTextColor(0.20, 1, 0.35, 1)
        else
            row.stateText:SetText(tightState and "Off" or "Disabled")
            row.stateText:SetTextColor(1, 0.25, 0.48, 1)
        end

        row.memText:ClearAllPoints()
        row.memText:SetPoint("LEFT", row, "LEFT", (colX.mem or 0) + 2, 0)
        row.memText:SetWidth(math.max(42, (mainPanel.memW or 100) - 4))
        row.memText:SetJustifyH("LEFT")
        row.memText:SetText(FormatMemory(addon.memory))

        for index, key in ipairs(PROFILE_ORDER) do
            local bg = row.columnBGs and row.columnBGs[key]
            if bg then
                local r, g, b, a = GetColumnShade(index, false)
                bg:ClearAllPoints()
                bg:SetPoint("TOPLEFT", row, "TOPLEFT", (colX[key] or 0), -1)
                bg:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", (colX[key] or 0), 1)
                bg:SetWidth(math.max(24, (mainPanel.profileW or 64)))
                bg:SetColorTexture(r, g, b, a)
                bg:Show()
            end
            local toggle = row.profileToggles[key]
            local enabled = DesiredEnabled(addon.name, key)
            toggle:ClearAllPoints()
            toggle:SetPoint("CENTER", row, "LEFT", (colX[key] or 0) + ((mainPanel.profileW or 64) * 0.5), 0)
            toggle:SetSize(math.max(30, math.min(48, (mainPanel.profileW or 64) - 6)), math.max(20, rowH - 8))
            toggle.addon = addon
            toggle:SetText(enabled and "ON" or "OFF")
            toggle:SetEnabled(not addon.incompatible)
            toggle:SetAlpha(addon.incompatible and 0.40 or 1)
            toggle:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
            toggle:SetBackdropColor(0, 0, 0, 0.05)
            toggle:SetBackdropBorderColor(enabled and 0.10 or 0.26, enabled and 0.35 or 0.04, enabled and 0.12 or 0.04, 0.18)
            local fs = toggle:GetFontString()
            if fs then
                local toggleFont = Clamp(math.floor(math.min(GetEffectiveTextSize(), ((mainPanel.profileW or 64) * 0.58))), 12, math.max(12, GetEffectiveTextSize()))
                fs:SetFont(STANDARD_TEXT_FONT, toggleFont, "OUTLINE")
                if enabled then
                    fs:SetTextColor(0.20, 1.00, 0.32, 1)
                else
                    fs:SetTextColor(1.00, 0.16, 0.12, 1)
                end
            end
        end
        row:Show()
    end

    for i = #visibleAddons + 1, #rows do
        rows[i]:Hide()
    end

    scrollChild:SetSize(width, math.max(1, #visibleAddons * rowH))
    if statusText then
        local sortText
        if DB().settings.sortMode == "memory" then
            sortText = DB().settings.sortMemDesc and "Memory high to low" or "Memory low to high"
        elseif DB().settings.sortMode == "group" or DB().settings.groupDependencies then
            sortText = "Grouped addon/dependency sort"
        else
            sortText = "Alphabetical sort"
        end
        statusText:SetText("|cffff3030" .. #visibleAddons .. " addons shown.|r " .. sortText .. ".")
    end
    UpdateProfileStatusText()
end

local function GetCursorAngle(cx, cy, px, py)
    local dy = py - cy
    local dx = px - cx
    if math.atan2 then
        return math.deg(math.atan2(dy, dx))
    end
    if atan2 then
        return math.deg(atan2(dy, dx))
    end
    if dx == 0 then
        return dy >= 0 and 90 or -90
    end
    local angle = math.deg(math.atan(dy / dx))
    if dx < 0 then
        angle = angle + 180
    end
    return angle
end

local function UpdateMinimapButtonPosition()
    if not minimapButton or not Minimap then return end
    local angle = math.rad(DB().settings.minimapAngle or 225)
    local radius = 82
    local x = math.cos(angle) * radius
    local y = math.sin(angle) * radius
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function CreateMinimapButton()
    if minimapButton then return end
    minimapButton = CreateFrame("Button", "ChayAddonProfilesMinimapButton", Minimap, "BackdropTemplate")
    minimapButton:SetSize(34, 34)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 8)
    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    minimapButton:RegisterForDrag("LeftButton")
    minimapButton:SetMovable(false)

    local icon = minimapButton:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture(MEDIA_LOGO_SQUARE)

    local border = minimapButton:CreateTexture(nil, "OVERLAY")
    border:SetPoint("TOPLEFT", -4, 4)
    border:SetPoint("BOTTOMRIGHT", 4, -4)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    minimapButton:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            CAP:ApplyProfile(DetectProfile())
        else
            CAP:Toggle()
        end
    end)

    minimapButton:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local px, py = GetCursorPosition()
            local scale = UIParent:GetEffectiveScale()
            px, py = px / scale, py / scale
            local angle = GetCursorAngle(mx, my, px, py)
            DB().settings.minimapAngle = angle
            UpdateMinimapButtonPosition()
        end)
    end)

    minimapButton:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)

    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("|cffff3030Chay_CE|r Addon Profiles")
        GameTooltip:AddLine("Left Click: Open GUI", 1, 1, 1)
        GameTooltip:AddLine("Right Click: Apply current profile", 1, 1, 1)
        GameTooltip:AddLine("Drag: Move around minimap", 0.75, 0.75, 0.75)
        GameTooltip:Show()
    end)
    minimapButton:SetScript("OnLeave", GameTooltip_Hide)

    UpdateMinimapButtonPosition()
    minimapButton:SetShown(DB().settings.showMinimapButton)
end

local function PromptIfNeeded(force)
    if not loginComplete then return end
    if GetTimeSafe() < suppressPromptsUntil then return end
    if DB().settings.dontShowPrompts and not force then return end

    currentProfile = DetectProfile()
    currentEffectiveProfile = EffectiveProfile(currentProfile)

    if InCombatLockdown() then
        queuedProfileCheck = true
        pendingEffectiveProfile = currentEffectiveProfile
        CDB().pendingProfile = currentEffectiveProfile
        UpdateProfileStatusText()
        return
    end

    if not force and CDB().lastEffectiveProfile == currentEffectiveProfile then
        return
    end

    ScanAddOns(false)
    local needs = NeedsProfileApply(currentEffectiveProfile)
    CDB().lastEffectiveProfile = currentEffectiveProfile

    if needs then
        pendingEffectiveProfile = currentEffectiveProfile
        CDB().pendingProfile = currentEffectiveProfile
        if lastPromptProfile ~= currentEffectiveProfile or force then
            lastPromptProfile = currentEffectiveProfile
            ShowApplyPrompt(currentEffectiveProfile)
        end
    else
        pendingEffectiveProfile = nil
        CDB().pendingProfile = nil
        CDB().loadedProfile = currentEffectiveProfile
        HideApplyPopup()
    end

    UpdateProfileStatusText()
end

function CAP:Show()
    CreateMainFrame()
    mainFrame:Show()
    currentProfile = DetectProfile()
    currentEffectiveProfile = EffectiveProfile(currentProfile)
    ScanAddOns(false)
    UpdateProfileStatusText()
    self:UpdateLayout()
    self:RefreshRows(true)
end


local function PrintProfileStatus()
    local detected = EffectiveProfile(DetectProfile())
    local loaded = CDB().loadedProfile or "none"
    local pending = CDB().pendingProfile or pendingEffectiveProfile or "none"
    local last = CDB().lastEffectiveProfile or "none"
    local enableList, disableList = GetProfileDiff(detected)
    local total = #enableList + #disableList

    Print("Detected: " .. GetProfileDisplay(detected) .. " | Loaded: " .. GetProfileDisplay(loaded) .. " | Pending: " .. GetProfileDisplay(pending) .. " | Last: " .. GetProfileDisplay(last))
    if InCombatLockdown() then
        Print("Combat locked: any profile prompt is queued until combat ends.")
    end
    if total > 0 then
        Print("Current detected profile has " .. total .. " pending addon change(s). Use /cap preview to review before applying.")
    else
        Print("Current detected profile already matches the next-load addon state.")
    end
end

function CAP:Hide()
    if mainFrame then mainFrame:Hide() end
end

function CAP:Toggle()
    CreateMainFrame()
    if mainFrame:IsShown() then
        CAP:Hide()
    else
        CAP:Show()
    end
end

SLASH_CHAYADDONPROFILES1 = "/cap"
SLASH_CHAYADDONPROFILES2 = "/chayaddons"
SlashCmdList.CHAYADDONPROFILES = function(msg)
    msg = strlower(strtrim(msg or ""))
    if msg == "help" or msg == "commands" then
        ShowCommandHelp()
    elseif msg == "check" or msg == "diagnose" or msg == "doctor" then
        ShowSafetyCheck()
    elseif msg == "resetprompt" or msg == "promptreset" then
        ResetPromptPosition()
    elseif msg == "apply" then
        CAP:ApplyProfile(DetectProfile())
    elseif msg == "preview" then
        ShowPreviewChanges(DetectProfile())
    elseif msg == "review" or msg == "changes" or msg == "log" then
        ShowAddonReview()
    elseif msg == "status" then
        PrintProfileStatus()
    elseif msg == "reload" then
        ReloadNow()
    elseif msg == "scan" then
        ScanAddOns(true)
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    elseif msg == "capture" or msg == "capture loaded" or msg == "snapshot" then
        ConfirmCaptureLoaded(currentProfile or DetectProfile())
    elseif msg == "backup" or msg == "backup rules" then
        CAP:BackupRules("Manual backup")
    elseif msg == "restore" or msg == "restore backup" then
        ConfirmRestoreBackup()
    elseif msg == "sort name" or msg == "az" or msg == "a-z" then
        DB().settings.sortMode = "name"
        DB().settings.groupDependencies = false
        RefreshOptionChecks()
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    elseif msg == "sort group" or msg == "group" then
        DB().settings.sortMode = "group"
        DB().settings.groupDependencies = true
        RefreshOptionChecks()
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    elseif msg == "usage" or msg == "mem" then
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        ScanAddOns(false)
        if CAP.RefreshRows then CAP:RefreshRows(true) end
    elseif msg == "prompts off" or msg == "noprompts" then
        DB().settings.dontShowPrompts = true
        HideApplyPopup()
        RefreshOptionChecks()
        Print("Prompts disabled. Use /cap prompts on to enable them again.")
    elseif msg == "prompts on" then
        DB().settings.dontShowPrompts = false
        RefreshOptionChecks()
        Print("Prompts enabled.")
    elseif msg == "raid" or msg == "profile raid" then
        OpenQuickProfile("raid")
    elseif msg == "mplus" or msg == "m+" or msg == "mythic" or msg == "profile mplus" then
        OpenQuickProfile("mplus")
    elseif msg == "dungeon" or msg == "profile dungeon" then
        OpenQuickProfile("dungeon")
    elseif msg == "delve" or msg == "delves" or msg == "profile delve" then
        OpenQuickProfile("delve")
    elseif msg == "world" or msg == "profile world" then
        OpenQuickProfile("world")
    elseif msg == "city" or msg == "profile city" then
        OpenQuickProfile("city")
    elseif msg == "pvp" or msg == "profile pvp" then
        OpenQuickProfile("pvp")
    elseif msg == "minimap" then
        DB().settings.showMinimapButton = not DB().settings.showMinimapButton
        if minimapButton then minimapButton:SetShown(DB().settings.showMinimapButton) end
        RefreshOptionChecks()
    elseif msg == "minimapreset" then
        DB().settings.minimapAngle = 225
        DB().settings.showMinimapButton = true
        if minimapButton then minimapButton:Show() end
        UpdateMinimapButtonPosition()
        RefreshOptionChecks()
    elseif msg == "text bigger" or msg == "bigger" then
        DB().settings.textSize = Clamp(DB().settings.textSize + 1, 10, 30)
        if CAP.UpdateLayout then CAP:UpdateLayout() end
    elseif msg == "text smaller" or msg == "smaller" then
        DB().settings.textSize = Clamp(DB().settings.textSize - 1, 10, 30)
        if CAP.UpdateLayout then CAP:UpdateLayout() end
    elseif msg == "reset" or msg == "resetui" then
        DB().settings.frameSize.width = DEFAULT_DB.settings.frameSize.width
        DB().settings.frameSize.height = DEFAULT_DB.settings.frameSize.height
        DB().settings.framePoint = CopyDefaults(DEFAULT_DB.settings.framePoint, {})
        if mainFrame then
            mainFrame:ClearAllPoints()
            mainFrame:SetPoint("CENTER")
            mainFrame:SetSize(DB().settings.frameSize.width, DB().settings.frameSize.height)
            CAP:UpdateLayout()
        end
    else
        CAP:Toggle()
    end
end

frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
frame:RegisterEvent("CHALLENGE_MODE_START")
frame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")

frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        DB()
        CDB()
    elseif event == "PLAYER_LOGIN" then
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        local newAddons = ScanAddOns(false)
        CreateMinimapButton()
        currentProfile = DetectProfile()
        currentEffectiveProfile = EffectiveProfile(currentProfile)
        pendingEffectiveProfile = nil
        CDB().loadedProfile = currentEffectiveProfile
        CDB().pendingProfile = nil
        CDB().lastEffectiveProfile = currentEffectiveProfile
        suppressPromptsUntil = GetTimeSafe() + 6
        loginComplete = true
        if DB().settings.detectNewAddOns and not DB().settings.dontShowPrompts and newAddons and #newAddons > 0 then
            StaticPopup_Show("CHAY_ADDON_PROFILES_NEW")
        end
        Print("Loaded. Use /cap to open.")
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" or event == "CHALLENGE_MODE_START" then
        if loginComplete then
            C_Timer.After(1.0, function()
                PromptIfNeeded(false)
            end)
        end
    elseif event == "CHALLENGE_MODE_COMPLETED" then
        suppressPromptsUntil = GetTimeSafe() + 30
        HideApplyPopup()
        if loginComplete then
            C_Timer.After(2.0, function()
                currentProfile = DetectProfile()
                currentEffectiveProfile = EffectiveProfile(currentProfile)
                pendingEffectiveProfile = nil
                CDB().pendingProfile = nil
                CDB().loadedProfile = currentEffectiveProfile
                CDB().lastEffectiveProfile = currentEffectiveProfile
                UpdateProfileStatusText()
            end)
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if queuedProfileCheck then
            queuedProfileCheck = false
            UpdateProfileStatusText()
            C_Timer.After(0.5, function()
                PromptIfNeeded(false)
            end)
        end
    end
end)
