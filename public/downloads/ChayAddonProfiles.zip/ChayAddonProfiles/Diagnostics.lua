local ADDON_NAME = ...
local CAP = _G.ChayAddonProfiles
if not CAP then return end

local floor = math.floor
local max = math.max
local min = math.min
local tonumber = tonumber
local tostring = tostring
local type = type
local pairs = pairs
local ipairs = ipairs
local format = string.format
local lower = string.lower
local match = string.match
local time = time
local date = date
local wipe = wipe
local table_sort = table.sort
local table_insert = table.insert

local MAX_ERRORS = 100
local MAX_PERF_ROWS = 40
local MAX_ERROR_ROWS = 40
local MAX_VISIBLE_ROWS = 20

local diagFrame
local openButton
local tabs = {}
local pages = {}
local currentTab = "Health"
local perfRows = {}
local errorRows = {}
local selectedError
local selectedAddon
local lastPerf = {}
local installedErrorHandler = false
local errorCaptureMode
local previousErrorHandler
local bugGrabberCallbackOwner = {}
local reportFrame
local healthSummary
local healthAdvice
local perfSummary
local errorSummary
local detailEdit
local detailMeasure
local detailScroll
local copyDetailButton
local perfScroll
local perfChild
local errorsScroll
local errorsChild
local perfTopIndex = 1
local errorTopIndex = 1
local DEEP_TEST_SECONDS = 30
local deepTestRunning = false
local deepTestTicker
local deepTestTimer
local deepFpsSamples = {}
local deepTestStartedAt
local deepTestButton
local disableProfileButton
local deepStatusText
local errorRefreshPending = false
local cachedProfilerAvailable = false

local RED = { 0.92, 0.035, 0.025 }
local RED_BRIGHT = { 1.00, 0.14, 0.08 }
local RED_DARK = { 0.20, 0.008, 0.008 }
local GOLD = { 1.00, 0.76, 0.22 }
local WHITE = { 0.95, 0.95, 0.95 }
local MUTED = { 0.68, 0.68, 0.68 }

local function CharDB()
    ChayAddonProfilesCharDB = ChayAddonProfilesCharDB or {}
    ChayAddonProfilesCharDB.diagnostics = ChayAddonProfilesCharDB.diagnostics or {
        errors = {},
        pendingDeepScan = false,
        deepResults = {},
        lastDeepScan = nil,
    }
    ChayAddonProfilesCharDB.diagnostics.errors = ChayAddonProfilesCharDB.diagnostics.errors or {}
    ChayAddonProfilesCharDB.diagnostics.deepResults = ChayAddonProfilesCharDB.diagnostics.deepResults or {}
    return ChayAddonProfilesCharDB.diagnostics
end

local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff3028ChayAddonProfiles:|r " .. tostring(msg))
    end
end

local function IsCPUProfilingEnabled()
    if C_CVar and C_CVar.GetCVar then
        return C_CVar.GetCVar("scriptProfile") == "1"
    end
    if GetCVarBool then
        return GetCVarBool("scriptProfile") == true
    end
    return false
end

local function SetCPUProfiling(enabled)
    local value = enabled and "1" or "0"
    if C_CVar and C_CVar.SetCVar then
        C_CVar.SetCVar("scriptProfile", value)
        return true
    end
    if SetCVar then
        SetCVar("scriptProfile", value)
        return true
    end
    return false
end

local function AddRedBorder(target, alpha)
    local a = alpha or 0.9
    local t = target:CreateTexture(nil, "BORDER")
    t:SetPoint("TOPLEFT"); t:SetPoint("TOPRIGHT"); t:SetHeight(1)
    t:SetColorTexture(RED[1], RED[2], RED[3], a)
    local b = target:CreateTexture(nil, "BORDER")
    b:SetPoint("BOTTOMLEFT"); b:SetPoint("BOTTOMRIGHT"); b:SetHeight(1)
    b:SetColorTexture(RED[1], RED[2], RED[3], a)
    local l = target:CreateTexture(nil, "BORDER")
    l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(1)
    l:SetColorTexture(RED[1], RED[2], RED[3], a)
    local r = target:CreateTexture(nil, "BORDER")
    r:SetPoint("TOPRIGHT"); r:SetPoint("BOTTOMRIGHT"); r:SetWidth(1)
    r:SetColorTexture(RED[1], RED[2], RED[3], a)
end

local function StylePanel(target, alpha)
    target:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    target:SetBackdropColor(0.008, 0.006, 0.007, alpha or 0.92)
    target:SetBackdropBorderColor(0.55, 0.02, 0.02, 0.92)
end

local function MakeButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
    button:SetSize(width or 130, height or 28)
    StylePanel(button, 0.94)
    button:SetBackdropColor(RED_DARK[1], RED_DARK[2], RED_DARK[3], 0.96)
    button:SetBackdropBorderColor(0.72, 0.02, 0.02, 1)
    local fs = button:CreateFontString(nil, "OVERLAY")
    fs:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
    fs:SetPoint("CENTER")
    fs:SetText(text)
    fs:SetTextColor(1, 0.86, 0.82, 1)
    button.label = fs
    button:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.33, 0.015, 0.012, 0.98)
        self:SetBackdropBorderColor(1, 0.08, 0.04, 1)
    end)
    button:SetScript("OnLeave", function(self)
        self:SetBackdropColor(RED_DARK[1], RED_DARK[2], RED_DARK[3], 0.96)
        self:SetBackdropBorderColor(0.72, 0.02, 0.02, 1)
    end)
    return button
end

local function SetButtonText(button, text)
    if button and button.label then button.label:SetText(text) end
end

local function SetButtonEnabled(button, enabled)
    if not button then return end
    button:EnableMouse(enabled and true or false)
    button:SetAlpha(enabled and 1 or 0.38)
end

local addonNameLookup
local addonNameLookupLower

local function IsBlizzardSource(name)
    return type(name) == "string" and (name:match("^Blizzard_") ~= nil or name == "FrameXML" or name == "SharedXML")
end

local function BuildAddonNameLookup()
    if addonNameLookup then return addonNameLookup, addonNameLookupLower end
    addonNameLookup = {}
    addonNameLookupLower = {}
    if C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetAddOnInfo then
        local count = C_AddOns.GetNumAddOns()
        for i = 1, count do
            local name = C_AddOns.GetAddOnInfo(i)
            if type(name) == "string" and name ~= "" then
                addonNameLookup[name] = true
                addonNameLookupLower[lower(name)] = name
            end
        end
    end
    return addonNameLookup, addonNameLookupLower
end

local function ResolveKnownAddonName(candidate)
    if type(candidate) ~= "string" or candidate == "" or IsBlizzardSource(candidate) then return nil end
    local known, knownLower = BuildAddonNameLookup()
    if known[candidate] then return candidate end
    return knownLower[lower(candidate)]
end

local function AddonFromText(text)
    if type(text) ~= "string" then return nil end

    -- Prefer canonical Interface/AddOns paths when BugGrabber kept the full path.
    for candidate in text:gmatch("[Ii]nterface[\\/]AddOns[\\/]([^\\/%]%s:]+)") do
        local resolved = ResolveKnownAddonName(candidate)
        if resolved then return resolved end
    end

    -- BugSack/BugGrabber often strips Interface/AddOns and stores frames as
    -- [AddonFolder/path/file.lua]:line. Walk every frame in order and skip
    -- Blizzard-owned frames until the first installed addon folder is found.
    for candidate in text:gmatch("%[([^%]/\\]+)[\\/][^%]]+%]") do
        local resolved = ResolveKnownAddonName(candidate)
        if resolved then return resolved end
    end

    -- Fallback for unbracketed stripped paths such as AddonFolder/file.lua:123.
    for candidate in text:gmatch("([!%w_%-%.]+)[\\/][^%s%]]+") do
        local resolved = ResolveKnownAddonName(candidate)
        if resolved then return resolved end
    end
    return nil
end

local function ReattributeStoredErrors()
    local d = CharDB()
    if not d.errors or #d.errors == 0 then return end

    local rebuilt = {}
    local byKey = {}
    for _, err in ipairs(d.errors) do
        if type(err) == "table" then
            local combined = tostring(err.message or "") .. "\n" .. tostring(err.stack or "")
            local detected = AddonFromText(combined)
            if detected then
                err.addon = detected
            elseif err.addon and IsBlizzardSource(err.addon) then
                err.addon = nil
            end

            local firstLine = match(tostring(err.message or "Unknown error"), "([^\n]+)") or tostring(err.message or "Unknown error")
            err.key = tostring(err.kind or "Lua Error") .. "\031" .. firstLine .. "\031" .. tostring(err.addon or "")

            local existing = byKey[err.key]
            if existing then
                -- Existing unknown + newly attributed records may represent the
                -- same BugGrabber object imported by two ChayAddonProfiles builds.
                -- Use the larger counter rather than double-counting that object.
                existing.count = max(tonumber(existing.count) or 1, tonumber(err.count) or 1)
                existing.firstSeen = min(tonumber(existing.firstSeen) or time(), tonumber(err.firstSeen) or time())
                existing.lastSeen = max(tonumber(existing.lastSeen) or 0, tonumber(err.lastSeen) or 0)
                if (not existing.stack or existing.stack == "") and err.stack and err.stack ~= "" then existing.stack = err.stack end
                if (not existing.locals or existing.locals == "") and err.locals and err.locals ~= "" then existing.locals = err.locals end
            else
                byKey[err.key] = err
                rebuilt[#rebuilt + 1] = err
            end
        end
    end

    d.errors = rebuilt
end

local function QueueErrorRefresh()
    if diagFrame and diagFrame:IsShown() and currentTab == "Errors" and not errorRefreshPending then
        errorRefreshPending = true
        C_Timer.After(0.50, function()
            errorRefreshPending = false
            if diagFrame and diagFrame:IsShown() and currentTab == "Errors" then
                CAP:RefreshDiagnostics(false)
            end
        end)
    end
end

local function SaveError(kind, message, stack, addon, localsText, sourceCount, firstSeen, lastSeen, syncOnly)
    local d = CharDB()
    message = tostring(message or "Unknown error")
    stack = tostring(stack or "")
    localsText = tostring(localsText or "")
    addon = addon or AddonFromText(message) or AddonFromText(stack)
    local firstLine = match(message, "([^\n]+)") or message
    local key = tostring(kind or "Lua Error") .. "\031" .. firstLine .. "\031" .. tostring(addon or "")
    local incomingCount = max(1, tonumber(sourceCount) or 1)

    for _, err in ipairs(d.errors) do
        if err.key == key then
            if syncOnly then
                err.count = max(err.count or 1, incomingCount)
            else
                err.count = (err.count or 1) + incomingCount
            end
            err.lastSeen = max(err.lastSeen or 0, tonumber(lastSeen) or time())
            if stack ~= "" then err.stack = stack end
            if localsText ~= "" then err.locals = localsText end
            if addon and addon ~= "" then err.addon = addon end
            QueueErrorRefresh()
            return
        end
    end

    table_insert(d.errors, 1, {
        key = key,
        kind = kind or "Lua Error",
        message = message,
        stack = stack,
        locals = localsText ~= "" and localsText or nil,
        addon = addon,
        count = incomingCount,
        firstSeen = tonumber(firstSeen) or time(),
        lastSeen = tonumber(lastSeen) or time(),
    })
    while #d.errors > MAX_ERRORS do
        table.remove(d.errors)
    end
    QueueErrorRefresh()
end

local function CaptureLuaError(message)
    local stack = ""
    if debugstack then
        local ok, result = pcall(debugstack, 3, 20, 20)
        if ok and result then stack = result end
    end
    SaveError("Lua Error", message, stack)
end

local function SaveBugGrabberErrorObject(bug, syncOnly)
    if type(bug) ~= "table" or not bug.message then return false end
    SaveError(
        bug.type or "Lua Error",
        bug.message or bug.error or bug[1],
        bug.stack or bug.traceback,
        nil,
        bug.locals,
        syncOnly and (bug.counter or 1) or 1,
        bug.time or bug.firstSeen,
        bug.time or bug.lastSeen,
        syncOnly
    )
    return true
end

local function SyncCurrentBugGrabberSession()
    if not _G.BugGrabber or type(BugGrabber.GetDB) ~= "function" then return end
    local okDB, bugDB = pcall(BugGrabber.GetDB, BugGrabber)
    if not okDB or type(bugDB) ~= "table" then return end

    local sessionID
    if type(BugGrabber.GetSessionId) == "function" then
        local okSession, result = pcall(BugGrabber.GetSessionId, BugGrabber)
        if okSession then sessionID = result end
    end

    for _, bug in pairs(bugDB) do
        if type(bug) == "table" and (not sessionID or bug.session == sessionID) then
            SaveBugGrabberErrorObject(bug, true)
        end
    end
end

local function OnBugGrabbed(_, fromBugGrabber)
    local bug = type(fromBugGrabber) == "table" and fromBugGrabber or nil
    if not bug and type(fromBugGrabber) == "string" and BugGrabber and type(BugGrabber.GetErrorByID) == "function" then
        local ok, result = pcall(BugGrabber.GetErrorByID, BugGrabber, fromBugGrabber)
        if ok and type(result) == "table" then bug = result end
    end
    if bug then
        SaveBugGrabberErrorObject(bug, false)
    elseif type(fromBugGrabber) == "string" then
        SaveError("Lua Error", fromBugGrabber, "")
    end
end

local function InstallBugGrabberCapture()
    if installedErrorHandler and errorCaptureMode == "BugGrabber" then return true end
    if not _G.BugGrabber then return false end

    if not BugGrabber.RegisterCallback and type(BugGrabber.setupCallbacks) == "function" then
        pcall(BugGrabber.setupCallbacks)
    end

    local installed = false
    if not BugGrabber.RegisterCallback and EventRegistry and EventRegistry.RegisterCallback then
        installed = pcall(function()
            EventRegistry:RegisterCallback("BugGrabber.BugGrabbed", OnBugGrabbed, bugGrabberCallbackOwner)
            if EventRegistry.TriggerEvent then
                EventRegistry:TriggerEvent("BugGrabber.DisplayRegistered")
            end
        end)
    elseif type(BugGrabber.RegisterCallback) == "function" then
        installed = pcall(BugGrabber.RegisterCallback, bugGrabberCallbackOwner, "BugGrabber_BugGrabbed", OnBugGrabbed)
    end

    if installed then
        installedErrorHandler = true
        errorCaptureMode = "BugGrabber"
        SyncCurrentBugGrabberSession()
        return true
    end
    return false
end

local function InstallFallbackErrorCapture()
    if installedErrorHandler then return true end

    if _G.AddLuaErrorHandler then
        local ok = pcall(AddLuaErrorHandler, CaptureLuaError)
        if ok then
            installedErrorHandler = true
            errorCaptureMode = "AddLuaErrorHandler"
            return true
        end
    end

    if seterrorhandler and geterrorhandler then
        previousErrorHandler = geterrorhandler()
        local ok = pcall(seterrorhandler, function(message)
            CaptureLuaError(message)
            if previousErrorHandler then return previousErrorHandler(message) end
        end)
        if ok then
            installedErrorHandler = true
            errorCaptureMode = "ErrorHandler"
            return true
        end
        previousErrorHandler = nil
    end
    return false
end

local function InstallErrorCapture(allowFallback)
    if InstallBugGrabberCapture() then return true end
    if allowFallback then return InstallFallbackErrorCapture() end
    return false
end

local function GetDiagnosis(err)
    local count = tonumber(err and err.count) or 1
    local kind = lower(tostring(err and err.kind or ""))
    local message = lower(tostring(err and err.message or ""))
    local severity, rank = "LOW", 1
    if kind == "protected action" or message:find("addon_action_forbidden", 1, true) then
        severity, rank = "CRITICAL", 4
    elseif message:find("auras cannot be accessed when secret", 1, true) or count >= 100 then
        severity, rank = "HIGH", 3
    elseif count >= 10 or message:find("attempt to index", 1, true) or message:find("attempt to perform", 1, true) then
        severity, rank = "MEDIUM", 2
    end

    local issue = "Lua/runtime issue"
    if message:find("auras cannot be accessed when secret", 1, true) then
        issue = "Midnight restricted aura access / tainted execution path"
    elseif kind == "protected action" then
        issue = "Protected action blocked or forbidden"
    elseif message:find("attempt to index", 1, true) and message:find("nil value", 1, true) then
        issue = "Nil reference"
    elseif message:find("attempt to perform boolean test", 1, true) then
        issue = "Invalid boolean/event payload assumption"
    elseif kind == "lua warning" then
        issue = "Lua warning"
    end

    local color = "|cff9fd3ff"
    if severity == "CRITICAL" then color = "|cffff3030"
    elseif severity == "HIGH" then color = "|cffff6b3d"
    elseif severity == "MEDIUM" then color = "|cffffc247" end
    return severity, rank, color, issue
end

local function GetFixGuidance(err)
    local kind = lower(tostring(err and err.kind or ""))
    local message = lower(tostring(err and err.message or ""))
    if message:find("auras cannot be accessed when secret", 1, true) then
        return table.concat({
            "1. Open the first addon-owned file/line in the stack and trace every call that reaches the aura API.",
            "2. Verify the exact Retail 12.1+ aura/event contract. Do not inspect, compare, index, convert, or branch on secret aura values from an insecure path.",
            "3. Remove legacy UNIT_AURA/AuraData assumptions only where the recorded stack proves they are wrong; preserve unrelated behavior.",
            "4. Fix the originating execution path instead of wrapping the failing API call in pcall or suppressing the error.",
            "5. Retest in the same combat/content state and verify this issue's counter stops increasing."
        }, "\n")
    elseif kind == "protected action" or message:find("addon_action_forbidden", 1, true) or message:find("addon_action_blocked", 1, true) then
        return table.concat({
            "1. Trace the stack to the first addon-owned function before the protected Blizzard action.",
            "2. Determine whether the addon calls a protected action in combat or taints a secure execution path.",
            "3. Move the protected change to a permitted out-of-combat path or remove the taint source; do not hide the fault.",
            "4. Verify the replacement against current Retail 12.1+ secure-execution rules.",
            "5. Reproduce the same action in and out of combat and confirm the protected-action event does not return."
        }, "\n")
    elseif message:find("attempt to index", 1, true) and message:find("nil value", 1, true) then
        return table.concat({
            "1. Open the exact file and line and identify which lookup or API result can be nil.",
            "2. Trace the caller to determine whether nil is a valid current state or an outdated API/data assumption.",
            "3. If nil is valid, add the narrowest guard that preserves behavior. If not, correct the upstream lookup/API use.",
            "4. Audit nearby code for the same assumption so the failure is not moved to another line.",
            "5. Retest the exact UI/quest/combat state that triggered it."
        }, "\n")
    end
    return table.concat({
        "1. Open the exact file/line and trace the stack to the first addon-owned caller.",
        "2. Verify every Blizzard API/event involved against current Retail 12.1+ documentation before changing code.",
        "3. Correct the root condition while preserving unrelated working logic; do not suppress the symptom.",
        "4. Audit adjacent code for the same outdated assumption.",
        "5. Reproduce the same gameplay state and verify the error counter remains unchanged."
    }, "\n")
end

local function GetAddOnCount()
    return C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns() or 0
end

local function GetAddOnInfo(index)
    if not C_AddOns or not C_AddOns.GetAddOnInfo then return nil end
    return C_AddOns.GetAddOnInfo(index)
end

local function IsLoaded(name)
    return C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded(name) == true
end

local function FormatMemory(kb)
    kb = tonumber(kb) or 0
    if kb >= 1024 then return format("%.1f MB", kb / 1024) end
    return format("%.0f KB", kb)
end

local function GetMetric(name, metric)
    if not C_AddOnProfiler or not C_AddOnProfiler.GetAddOnMetric or metric == nil then return nil end
    local ok, value = pcall(C_AddOnProfiler.GetAddOnMetric, name, metric)
    if ok and type(value) == "number" then return value end
    return nil
end

local function ErrorCountForAddon(name)
    local total = 0
    for _, err in ipairs(CharDB().errors) do
        if err.addon == name then total = total + (err.count or 1) end
    end
    return total
end

local function RefreshPerformanceData()
    local recentMetric = Enum and Enum.AddOnProfilerMetric and Enum.AddOnProfilerMetric.RecentAverageTime
    local peakMetric = Enum and Enum.AddOnProfilerMetric and Enum.AddOnProfilerMetric.PeakTime
    local over1Metric = Enum and Enum.AddOnProfilerMetric and Enum.AddOnProfilerMetric.CountTimeOver1Ms
    local profilerAvailable = C_AddOnProfiler and C_AddOnProfiler.GetAddOnMetric and recentMetric ~= nil
    if profilerAvailable and C_AddOnProfiler.IsEnabled then
        local ok, enabled = pcall(C_AddOnProfiler.IsEnabled)
        if ok and enabled == false then profilerAvailable = false end
    end

    if UpdateAddOnMemoryUsage then pcall(UpdateAddOnMemoryUsage) end
    local deepResults = CharDB().deepResults or {}
    wipe(lastPerf)
    local count = GetAddOnCount()
    for i = 1, count do
        local name, title = GetAddOnInfo(i)
        if name and IsLoaded(name) then
            local memory = 0
            if GetAddOnMemoryUsage then
                local ok, value = pcall(GetAddOnMemoryUsage, name)
                if ok and type(value) == "number" then memory = value end
            end
            local deep = deepResults[name]
            lastPerf[#lastPerf + 1] = {
                name = name,
                title = tostring(title or name):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""),
                recent = profilerAvailable and GetMetric(name, recentMetric) or nil,
                peak = profilerAvailable and GetMetric(name, peakMetric) or nil,
                over1 = profilerAvailable and GetMetric(name, over1Metric) or nil,
                memory = memory,
                errors = ErrorCountForAddon(name),
                deepCPU = deep and deep.cpuPerSec or nil,
                deepShare = deep and deep.share or nil,
            }
        end
    end
    table_sort(lastPerf, function(a, b)
        local ad, bd = a.deepCPU, b.deepCPU
        if ad ~= nil or bd ~= nil then
            ad, bd = ad or -1, bd or -1
            if ad ~= bd then return ad > bd end
        end
        local ar, br = a.recent or -1, b.recent or -1
        if ar ~= br then return ar > br end
        local ae, be = a.errors or 0, b.errors or 0
        if ae ~= be then return ae > be end
        return (a.memory or 0) > (b.memory or 0)
    end)
    return profilerAvailable
end

local function BuildReport(err)
    if not err then return nil end
    local severity, _, _, issue = GetDiagnosis(err)
    local perf
    for _, item in ipairs(lastPerf) do if item.name == err.addon then perf = item break end end
    local lines = {
        "CHAY ADDON PROFILES - CHATGPT FIX REPORT",
        "Retail WoW Midnight 12.1+ diagnostic export",
        "",
        "I will attach the complete ZIP of the addon named below. Inspect the entire ZIP before changing anything.",
        "",
        "SOURCE ADDON: " .. tostring(err.addon or "Could not attribute safely"),
        "SEVERITY: " .. severity,
        "ERROR TYPE: " .. tostring(err.kind or "Lua Error"),
        "OCCURRENCES: " .. tostring(err.count or 1),
        "DETECTED PATTERN: " .. issue,
        "LAST SEEN: " .. date("%Y-%m-%d %H:%M:%S", err.lastSeen or time()),
        "",
        "DETAILED REPAIR DIRECTION",
        GetFixGuidance(err),
    }
    if perf then
        lines[#lines + 1] = ""
        lines[#lines + 1] = "CURRENT ADDON PERFORMANCE METRICS"
        lines[#lines + 1] = "30-second measured CPU: " .. (perf.deepCPU and format("%.2f ms/sec (%.1f%% share)", perf.deepCPU, perf.deepShare or 0) or "not tested")
        lines[#lines + 1] = "Recent average execution time: " .. (perf.recent and format("%.3f ms/tick", perf.recent) or "n/a")
        lines[#lines + 1] = "Peak execution time: " .. (perf.peak and format("%.3f ms", perf.peak) or "n/a")
        lines[#lines + 1] = "Ticks over 1 ms: " .. tostring(perf.over1 or "n/a")
        lines[#lines + 1] = "Memory: " .. FormatMemory(perf.memory)
        lines[#lines + 1] = "Captured errors: " .. tostring(perf.errors or 0)
    end
    lines[#lines + 1] = ""
    lines[#lines + 1] = "EXACT ERROR MESSAGE"
    lines[#lines + 1] = tostring(err.message or "")
    if err.stack and err.stack ~= "" then
        lines[#lines + 1] = ""
        lines[#lines + 1] = "STACK TRACE"
        lines[#lines + 1] = tostring(err.stack)
    end

    if err.locals and err.locals ~= "" then
        lines[#lines + 1] = ""
        lines[#lines + 1] = "LOCALS"
        lines[#lines + 1] = tostring(err.locals)
    end
    lines[#lines + 1] = ""
    lines[#lines + 1] = "REQUIREMENTS FOR CHATGPT"
    lines[#lines + 1] = "- Read all relevant files in the uploaded ZIP before editing."
    lines[#lines + 1] = "- Target current Retail WoW Midnight 12.1 and forward."
    lines[#lines + 1] = "- Verify affected Blizzard APIs/events against current authoritative documentation, including Warcraft Wiki Patch 12.0.0 API changes and later 12.1 changes."
    lines[#lines + 1] = "- Do not invent APIs, guess payload behavior, or suppress the symptom instead of fixing the root cause."
    lines[#lines + 1] = "- Preserve all unrelated working logic and addon scope."
    lines[#lines + 1] = "- Check the completed fix for Lua errors, secret-value misuse, taint, protected-action problems, bad events, and performance regressions."
    lines[#lines + 1] = "- Return complete copy-paste-ready files and a corrected ZIP, not snippets or diffs."
    lines[#lines + 1] = "- Explain the verified cause and why the final change fixes this exact recorded failure."
    return table.concat(lines, "\n")
end

local function ShowReport(err)
    local report = BuildReport(err)
    if not report then return end
    if not reportFrame then
        reportFrame = CreateFrame("Frame", "ChayAddonProfilesDiagnosticReport", UIParent, "BackdropTemplate")
        reportFrame:SetSize(800, 620)
        reportFrame:SetPoint("CENTER")
        reportFrame:SetFrameStrata("FULLSCREEN_DIALOG")
        reportFrame:SetClampedToScreen(true)
        reportFrame:SetMovable(true)
        reportFrame:EnableMouse(true)
        reportFrame:RegisterForDrag("LeftButton")
        reportFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
        reportFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        StylePanel(reportFrame, 0.98)

        local title = reportFrame:CreateFontString(nil, "OVERLAY")
        title:SetFont(STANDARD_TEXT_FONT, 18, "OUTLINE")
        title:SetPoint("TOPLEFT", 16, -14)
        title:SetTextColor(RED_BRIGHT[1], RED_BRIGHT[2], RED_BRIGHT[3])
        title:SetText("ChatGPT Fix Report")

        local help = reportFrame:CreateFontString(nil, "OVERLAY")
        help:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
        help:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -7)
        help:SetPoint("RIGHT", reportFrame, "RIGHT", -42, 0)
        help:SetJustifyH("LEFT")
        help:SetText("Upload the broken addon ZIP to ChatGPT, click inside this report, press Ctrl+A then Ctrl+C, and paste it with the ZIP.")

        local close = MakeButton(reportFrame, "X", 28, 26)
        close:SetPoint("TOPRIGHT", -10, -10)
        close:SetScript("OnClick", function() reportFrame:Hide() end)

        local panel = CreateFrame("Frame", nil, reportFrame, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 14, -70)
        panel:SetPoint("BOTTOMRIGHT", -14, 54)
        StylePanel(panel, 0.91)

        local scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 10, -10)
        scroll:SetPoint("BOTTOMRIGHT", -30, 10)
        local edit = CreateFrame("EditBox", nil, scroll)
        edit:SetMultiLine(true)
        edit:SetAutoFocus(false)
        edit:SetFontObject(ChatFontNormal)
        edit:SetWidth(730)
        edit:SetHeight(3200)
        edit:SetTextInsets(4, 4, 4, 4)
        edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        edit:SetScript("OnMouseUp", function(self) self:SetFocus() end)
        scroll:SetScrollChild(edit)
        reportFrame.edit = edit

        local selectAll = MakeButton(reportFrame, "Select All", 118, 28)
        selectAll:SetPoint("BOTTOMLEFT", 14, 14)
        selectAll:SetScript("OnClick", function()
            reportFrame.edit:SetFocus()
            reportFrame.edit:HighlightText()
        end)
        local closeBottom = MakeButton(reportFrame, "Close", 92, 28)
        closeBottom:SetPoint("LEFT", selectAll, "RIGHT", 8, 0)
        closeBottom:SetScript("OnClick", function() reportFrame:Hide() end)

        local hint = reportFrame:CreateFontString(nil, "OVERLAY")
        hint:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
        hint:SetPoint("BOTTOMRIGHT", -14, 20)
        hint:SetTextColor(MUTED[1], MUTED[2], MUTED[3])
        hint:SetText("WoW cannot write directly to the Windows clipboard; Select All + Ctrl+C is the safe copy path.")
    end
    reportFrame.edit:SetText(report)
    reportFrame.edit:SetCursorPosition(0)
    reportFrame.edit:ClearFocus()
    reportFrame:Show()
end

local function SetTab(name)
    currentTab = name
    for tabName, button in pairs(tabs) do
        button:SetBackdropColor(tabName == name and 0.42 or RED_DARK[1], tabName == name and 0.02 or RED_DARK[2], tabName == name and 0.015 or RED_DARK[3], 0.98)
        if button.label then button.label:SetTextColor(tabName == name and 1 or 0.94, tabName == name and 1 or 0.78, tabName == name and 1 or 0.74, 1) end
    end
    for pageName, page in pairs(pages) do page:SetShown(pageName == name) end
    CAP:RefreshDiagnostics(false)
end

local function CreateHealthPage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetPoint("TOPLEFT", 14, -58)
    page:SetPoint("BOTTOMRIGHT", -14, 14)
    pages.Health = page

    local title = page:CreateFontString(nil, "OVERLAY")
    title:SetFont(STANDARD_TEXT_FONT, 18, "OUTLINE")
    title:SetPoint("TOPLEFT", 0, -2)
    title:SetTextColor(RED_BRIGHT[1], RED_BRIGHT[2], RED_BRIGHT[3])
    title:SetText("Addon Health")

    local summaryPanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    summaryPanel:SetPoint("TOPLEFT", 0, -34)
    summaryPanel:SetPoint("TOPRIGHT", 0, -34)
    summaryPanel:SetHeight(152)
    StylePanel(summaryPanel, 0.78)

    healthSummary = summaryPanel:CreateFontString(nil, "OVERLAY")
    healthSummary:SetFont(STANDARD_TEXT_FONT, 13, "OUTLINE")
    healthSummary:SetPoint("TOPLEFT", 14, -14)
    healthSummary:SetPoint("BOTTOMRIGHT", -14, 14)
    healthSummary:SetJustifyH("LEFT")
    healthSummary:SetJustifyV("TOP")
    healthSummary:SetWordWrap(true)

    local advicePanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    advicePanel:SetPoint("TOPLEFT", summaryPanel, "BOTTOMLEFT", 0, -12)
    advicePanel:SetPoint("BOTTOMRIGHT", page, "BOTTOMRIGHT", 0, 46)
    StylePanel(advicePanel, 0.72)

    healthAdvice = advicePanel:CreateFontString(nil, "OVERLAY")
    healthAdvice:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
    healthAdvice:SetPoint("TOPLEFT", 14, -14)
    healthAdvice:SetPoint("BOTTOMRIGHT", -14, 14)
    healthAdvice:SetJustifyH("LEFT")
    healthAdvice:SetJustifyV("TOP")
    healthAdvice:SetWordWrap(true)

    local refresh = MakeButton(page, "Refresh Health", 138, 28)
    refresh:SetPoint("BOTTOMLEFT", 0, 8)
    refresh:SetScript("OnClick", function() CAP:RefreshDiagnostics(true) end)
end

local function GetTestCharacter()
    if ChayAddonProfilesDB and ChayAddonProfilesDB.settings and ChayAddonProfilesDB.settings.perCharacter then
        local name = UnitName("player")
        if name and name ~= "" and name ~= UNKNOWNOBJECT then return name end
    end
    return nil
end

local function SetTestAddonEnabled(name, enabled)
    if not name or name == "" or not C_AddOns then return false end
    local fn = enabled and C_AddOns.EnableAddOn or C_AddOns.DisableAddOn
    if not fn then return false end
    local character = GetTestCharacter()
    local ok
    if character then ok = pcall(fn, name, character) else ok = pcall(fn, name) end
    return ok and true or false
end

local function CreatePerformancePage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetPoint("TOPLEFT", 14, -58)
    page:SetPoint("BOTTOMRIGHT", -14, 14)
    pages.Performance = page
    page:Hide()

    local title = page:CreateFontString(nil, "OVERLAY")
    title:SetFont(STANDARD_TEXT_FONT, 18, "OUTLINE")
    title:SetPoint("TOPLEFT", 0, -2)
    title:SetTextColor(RED_BRIGHT[1], RED_BRIGHT[2], RED_BRIGHT[3])
    title:SetText("Performance")

    perfSummary = page:CreateFontString(nil, "OVERLAY")
    perfSummary:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
    perfSummary:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    perfSummary:SetPoint("TOPRIGHT", page, "TOPRIGHT", -2, -30)
    perfSummary:SetJustifyH("LEFT")
    perfSummary:SetJustifyV("TOP")
    perfSummary:SetWordWrap(true)

    deepStatusText = page:CreateFontString(nil, "OVERLAY")
    deepStatusText:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
    deepStatusText:SetPoint("TOPRIGHT", page, "TOPRIGHT", -2, -2)
    deepStatusText:SetJustifyH("RIGHT")
    deepStatusText:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
    deepStatusText:SetText("")

    local header = CreateFrame("Frame", nil, page, "BackdropTemplate")
    header:SetPoint("TOPLEFT", 0, -72)
    header:SetPoint("TOPRIGHT", -18, -72)
    header:SetHeight(28)
    StylePanel(header, 0.88)
    page.perfHeader = header
    page.perfHeaders = {}
    for _, label in ipairs({ "Addon", "30s CPU", "Recent", "Peak", "Memory", "Errors" }) do
        local fs = header:CreateFontString(nil, "OVERLAY")
        fs:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
        fs:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
        fs:SetText(label)
        fs:SetJustifyH(label == "Addon" and "LEFT" or "RIGHT")
        page.perfHeaders[#page.perfHeaders + 1] = fs
    end

    perfScroll = CreateFrame("ScrollFrame", nil, page, "UIPanelScrollFrameTemplate")
    perfScroll:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -4)
    perfScroll:SetPoint("BOTTOMRIGHT", page, "BOTTOMRIGHT", -24, 86)
    perfScroll:EnableMouseWheel(true)
    perfScroll:SetScript("OnMouseWheel", function(_, delta)
        perfTopIndex = max(1, min(max(1, #lastPerf - MAX_VISIBLE_ROWS + 1), perfTopIndex - delta * 3))
        CAP:RefreshDiagnostics()
    end)
    perfChild = CreateFrame("Frame", nil, perfScroll)
    perfChild:SetSize(1, 1)
    perfScroll:SetScrollChild(perfChild)

    for i = 1, MAX_VISIBLE_ROWS do
        local row = CreateFrame("Button", nil, perfChild, "BackdropTemplate")
        row:SetHeight(26)
        row:SetPoint("TOPLEFT", 0, -(i - 1) * 27)
        row:SetPoint("RIGHT", perfChild, "RIGHT", 0, 0)
        row:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
        row:SetBackdropColor(i % 2 == 0 and 0.025 or 0.045, 0.01, 0.01, 0.62)
        row.name = row:CreateFontString(nil, "OVERLAY"); row.name:SetJustifyH("LEFT"); row.name:SetWordWrap(false)
        row.deep = row:CreateFontString(nil, "OVERLAY"); row.deep:SetJustifyH("RIGHT"); row.deep:SetWordWrap(false)
        row.recent = row:CreateFontString(nil, "OVERLAY"); row.recent:SetJustifyH("RIGHT"); row.recent:SetWordWrap(false)
        row.peak = row:CreateFontString(nil, "OVERLAY"); row.peak:SetJustifyH("RIGHT"); row.peak:SetWordWrap(false)
        row.memory = row:CreateFontString(nil, "OVERLAY"); row.memory:SetJustifyH("RIGHT"); row.memory:SetWordWrap(false)
        row.errors = row:CreateFontString(nil, "OVERLAY"); row.errors:SetJustifyH("RIGHT"); row.errors:SetWordWrap(false)
        row:SetScript("OnClick", function(self)
            selectedAddon = self.addonName
            CAP:RefreshDiagnostics()
        end)
        row:SetScript("OnEnter", function(self)
            local item = self.perfItem
            if not item then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(item.title or item.name, 1, 0.82, 0.72)
            GameTooltip:AddLine("30s CPU: " .. (item.deepCPU and format("%.2f ms/s (%.1f%% share)", item.deepCPU, item.deepShare or 0) or "not tested"), 1, 1, 1)
            GameTooltip:AddLine("Recent profiler: " .. (item.recent and format("%.3f ms", item.recent) or "n/a"), 1, 1, 1)
            GameTooltip:AddLine("Peak profiler: " .. (item.peak and format("%.3f ms", item.peak) or "n/a"), 1, 1, 1)
            GameTooltip:AddLine("Ticks >1ms: " .. tostring(item.over1 ~= nil and item.over1 or "n/a"), 1, 1, 1)
            GameTooltip:AddLine("Memory: " .. FormatMemory(item.memory), 1, 1, 1)
            GameTooltip:AddLine("Captured errors: " .. tostring(item.errors or 0), 1, 1, 1)
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        perfRows[i] = row
    end

    deepTestButton = MakeButton(page, "30s Deep Test", 138, 28)
    deepTestButton:SetPoint("BOTTOMLEFT", 0, 44)
    deepTestButton:SetScript("OnClick", function() CAP:RequestDeepPerformanceTest() end)

    local refresh = MakeButton(page, "Refresh Metrics", 138, 28)
    refresh:SetPoint("LEFT", deepTestButton, "RIGHT", 8, 0)
    refresh:SetScript("OnClick", function() CAP:RefreshDiagnostics(true) end)

    disableProfileButton = MakeButton(page, "Disable CPU Profiling", 166, 28)
    disableProfileButton:SetPoint("LEFT", refresh, "RIGHT", 8, 0)
    disableProfileButton:SetScript("OnClick", function()
        if IsCPUProfilingEnabled() then
            StaticPopup_Show("CHAYADDONPROFILES_DISABLE_PROFILE")
        end
    end)

    local test = MakeButton(page, "Disable Selected + Reload", 190, 28)
    test:SetPoint("BOTTOMLEFT", 0, 8)
    test:SetScript("OnClick", function()
        if not selectedAddon or selectedAddon == ADDON_NAME then
            Print("Select a non-profile-manager addon first.")
            return
        end
        if SetTestAddonEnabled(selectedAddon, false) then
            CharDB().testAddon = selectedAddon
            ReloadUI()
        else
            Print("The client did not accept the addon disable request.")
        end
    end)
    page.testButton = test

    local restore = MakeButton(page, "Restore Tested Addon", 170, 28)
    restore:SetPoint("LEFT", test, "RIGHT", 8, 0)
    restore:SetScript("OnClick", function()
        local addon = CharDB().testAddon
        if not addon then return end
        if SetTestAddonEnabled(addon, true) then
            CharDB().testAddon = nil
            ReloadUI()
        else
            Print("The client did not accept the addon enable request.")
        end
    end)
    page.restoreButton = restore
end

local function CreateErrorsPage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetPoint("TOPLEFT", 14, -58)
    page:SetPoint("BOTTOMRIGHT", -14, 14)
    pages.Errors = page
    page:Hide()

    local title = page:CreateFontString(nil, "OVERLAY")
    title:SetFont(STANDARD_TEXT_FONT, 18, "OUTLINE")
    title:SetPoint("TOPLEFT", 0, -2)
    title:SetTextColor(RED_BRIGHT[1], RED_BRIGHT[2], RED_BRIGHT[3])
    title:SetText("Errors & Taint")

    errorSummary = page:CreateFontString(nil, "OVERLAY")
    errorSummary:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
    errorSummary:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -7)
    errorSummary:SetPoint("TOPRIGHT", -2, -31)
    errorSummary:SetJustifyH("LEFT")

    local listPanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    listPanel:SetPoint("TOPLEFT", 0, -62)
    listPanel:SetPoint("TOPRIGHT", 0, -62)
    listPanel:SetHeight(154)
    StylePanel(listPanel, 0.76)

    errorsScroll = CreateFrame("ScrollFrame", nil, listPanel, "UIPanelScrollFrameTemplate")
    errorsScroll:SetPoint("TOPLEFT", 6, -6)
    errorsScroll:SetPoint("BOTTOMRIGHT", -26, 6)
    errorsScroll:EnableMouseWheel(true)
    errorsScroll:SetScript("OnMouseWheel", function(_, delta)
        local count = #CharDB().errors
        errorTopIndex = max(1, min(max(1, count - 4 + 1), errorTopIndex - delta * 2))
        CAP:RefreshDiagnostics()
    end)
    errorsChild = CreateFrame("Frame", nil, errorsScroll)
    errorsChild:SetSize(1, 1)
    errorsScroll:SetScrollChild(errorsChild)

    for i = 1, 5 do
        local row = CreateFrame("Button", nil, errorsChild, "BackdropTemplate")
        row:SetHeight(26)
        row:SetPoint("TOPLEFT", 0, -(i - 1) * 27)
        row:SetPoint("RIGHT", errorsChild, "RIGHT", 0, 0)
        row:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
        row:SetBackdropColor(i % 2 == 0 and 0.025 or 0.045, 0.01, 0.01, 0.72)
        row.text = row:CreateFontString(nil, "OVERLAY")
        row.text:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
        row.text:SetPoint("LEFT", 7, 0)
        row.text:SetPoint("RIGHT", -7, 0)
        row.text:SetJustifyH("LEFT")
        row.text:SetWordWrap(false)
        row:SetScript("OnClick", function(self)
            selectedError = self.errorIndex
            CAP:RefreshDiagnostics()
        end)
        errorRows[i] = row
    end

    local detailPanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    detailPanel:SetPoint("TOPLEFT", listPanel, "BOTTOMLEFT", 0, -10)
    detailPanel:SetPoint("BOTTOMRIGHT", page, "BOTTOMRIGHT", 0, 48)
    StylePanel(detailPanel, 0.82)

    detailScroll = CreateFrame("ScrollFrame", nil, detailPanel, "UIPanelScrollFrameTemplate")
    detailScroll:SetPoint("TOPLEFT", 8, -8)
    detailScroll:SetPoint("BOTTOMRIGHT", -26, 8)
    local child = CreateFrame("Frame", nil, detailScroll)
    child:SetSize(1, 240)
    detailScroll:SetScrollChild(child)

    detailMeasure = child:CreateFontString(nil, "ARTWORK")
    detailMeasure:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
    detailMeasure:SetPoint("TOPLEFT", 0, 0)
    detailMeasure:SetJustifyH("LEFT")
    detailMeasure:SetJustifyV("TOP")
    detailMeasure:SetWordWrap(true)
    detailMeasure:Hide()

    detailEdit = CreateFrame("EditBox", nil, child)
    detailEdit:SetMultiLine(true)
    detailEdit:SetAutoFocus(false)
    detailEdit:SetFontObject(ChatFontNormal)
    detailEdit:SetPoint("TOPLEFT", 0, 0)
    detailEdit:SetHeight(240)
    detailEdit:SetTextInsets(2, 2, 2, 2)
    detailEdit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    detailEdit:SetScript("OnMouseUp", function(self) self:SetFocus() end)

    local clear = MakeButton(page, "Clear Errors", 116, 28)
    clear:SetPoint("BOTTOMLEFT", 0, 8)
    clear:SetScript("OnClick", function()
        wipe(CharDB().errors)
        selectedError = nil
        errorTopIndex = 1
        CAP:RefreshDiagnostics()
    end)
    local selectAll = MakeButton(page, "Select Detail Text", 148, 28)
    selectAll:SetPoint("LEFT", clear, "RIGHT", 8, 0)
    selectAll:SetScript("OnClick", function()
        detailEdit:SetFocus()
        detailEdit:HighlightText()
    end)

    copyDetailButton = MakeButton(page, "Copy Detail Text", 140, 28)
    copyDetailButton:SetPoint("LEFT", selectAll, "RIGHT", 8, 0)
    copyDetailButton:SetScript("OnClick", function()
        if not detailEdit then return end
        detailEdit:SetFocus()
        detailEdit:HighlightText()
        Print("Detail text selected. Press Ctrl+C to copy it.")
    end)
    copyDetailButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Copy Detail Text", 1, 0.25, 0.20)
        GameTooltip:AddLine("Selects the complete diagnostic detail so it is ready for Ctrl+C.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    copyDetailButton:SetScript("OnLeave", GameTooltip_Hide)

    local report = MakeButton(page, "ChatGPT Fix Report", 158, 28)
    report:SetPoint("LEFT", copyDetailButton, "RIGHT", 8, 0)
    report:SetScript("OnClick", function()
        local err = selectedError and CharDB().errors[selectedError]
        if err then ShowReport(err) end
    end)
    page.reportButton = report
end

function CAP:AttachDiagnostics(mainFrame)
    if diagFrame or not mainFrame then return end

    local buttonParent = mainFrame.sidePanel and mainFrame.sidePanel.content or mainFrame
    openButton = MakeButton(buttonParent, "DEV DIAGNOSTICS", 170, 20)
    openButton:SetFrameLevel((buttonParent:GetFrameLevel() or mainFrame:GetFrameLevel()) + 35)
    if mainFrame.sidePanel and mainFrame.sidePanel.content then
        openButton:SetPoint("TOPLEFT", mainFrame.sidePanel.content, "TOPLEFT", 8, 0)
        openButton:SetPoint("TOPRIGHT", mainFrame.sidePanel.content, "TOPRIGHT", -8, 0)
    else
        openButton:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 18, -140)
    end
    if openButton.SetBackdropColor then
        openButton:SetBackdropColor(0.32, 0.005, 0.005, 0.98)
        openButton:SetBackdropBorderColor(1.0, 0.08, 0.04, 1.0)
    end
    local glow = openButton:CreateTexture(nil, "BACKGROUND", nil, -1)
    glow:SetPoint("TOPLEFT", -3, 3)
    glow:SetPoint("BOTTOMRIGHT", 3, -3)
    glow:SetColorTexture(0.80, 0.02, 0.01, 0.28)
    openButton.devGlow = glow
    openButton:SetScript("OnClick", function() CAP:ShowDiagnostics() end)
    openButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Developer Diagnostics", 1, 0.18, 0.12)
        GameTooltip:AddLine("For addon development, bug fixing, Lua errors, taint checks, and performance testing.", 1, 1, 1, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Use at your own risk", 1, 0.82, 0.20)
        GameTooltip:AddLine("Deep CPU tests add profiling overhead. Disable/reload testing temporarily turns off the selected addon.", 0.92, 0.92, 0.92, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("AI repair workflow", 0.45, 0.80, 1.0)
        GameTooltip:AddLine("Select an error, create the ChatGPT Fix Report, then upload the problem addon ZIP and report to ChatGPT or Google Gemini for code review and repair.", 0.92, 0.92, 0.92, true)
        GameTooltip:Show()
    end)
    openButton:SetScript("OnLeave", GameTooltip_Hide)

    diagFrame = CreateFrame("Frame", "ChayAddonProfilesDiagnostics", mainFrame, "BackdropTemplate")
    diagFrame:SetFrameLevel(mainFrame:GetFrameLevel() + 25)
    diagFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 12, -112)
    diagFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -12, 12)
    StylePanel(diagFrame, 0.96)
    diagFrame:Hide()

    local bg = diagFrame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\AddOns\\ChayAddonProfiles\\Media\\Background")
    bg:SetTexCoord(0.03, 0.97, 0.04, 0.96)
    bg:SetAlpha(0.42)
    local veil = diagFrame:CreateTexture(nil, "BACKGROUND", nil, 1)
    veil:SetAllPoints()
    veil:SetColorTexture(0, 0, 0, 0.46)

    local title = diagFrame:CreateFontString(nil, "OVERLAY")
    title:SetFont(STANDARD_TEXT_FONT, 20, "OUTLINE")
    title:SetPoint("TOPLEFT", 14, -14)
    title:SetTextColor(RED_BRIGHT[1], RED_BRIGHT[2], RED_BRIGHT[3])
    title:SetText("Chay Diagnostics")

    local back = MakeButton(diagFrame, "Back to Profiles", 128, 26)
    back:SetPoint("TOPRIGHT", -12, -12)
    back:SetScript("OnClick", function() diagFrame:Hide() end)

    local names = { "Health", "Performance", "Errors" }
    local previous
    for _, name in ipairs(names) do
        local tab = MakeButton(diagFrame, name, name == "Performance" and 116 or 92, 26)
        if previous then tab:SetPoint("LEFT", previous, "RIGHT", 7, 0)
        else tab:SetPoint("TOPLEFT", 14, -46) end
        tab:SetScript("OnClick", function() SetTab(name) end)
        tabs[name] = tab
        previous = tab
    end

    CreateHealthPage(diagFrame)
    CreatePerformancePage(diagFrame)
    CreateErrorsPage(diagFrame)
    SetTab("Health")
    CAP:UpdateDiagnosticsLayout()

    if mainFrame.HookScript then
        local resizePending = false
        mainFrame:HookScript("OnSizeChanged", function()
            if resizePending then return end
            resizePending = true
            C_Timer.After(0, function()
                resizePending = false
                if diagFrame then CAP:UpdateDiagnosticsLayout() end
            end)
        end)
    end
end

function CAP:UpdateDiagnosticsLayout()
    if not diagFrame then return end
    local w = diagFrame:GetWidth()
    local h = diagFrame:GetHeight()
    local compact = w < 900
    local fontSize = compact and 9 or 10

    if pages.Performance and perfChild and pages.Performance.perfHeader then
        local usableW = max(520, pages.Performance:GetWidth() - 30)
        perfChild:SetWidth(usableW)

        local widths
        if usableW < 700 then
            widths = { 0.38, 0.14, 0.12, 0.11, 0.16, 0.09 }
        else
            widths = { 0.44, 0.13, 0.11, 0.10, 0.14, 0.08 }
        end
        local pad = 6
        local function PlaceColumns(columns, isHeader)
            local left = 0
            for i, fs in ipairs(columns) do
                local cw = floor(usableW * widths[i])
                fs:ClearAllPoints()
                fs:SetWidth(max(38, cw - pad * 2))
                fs:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
                if i == 1 then
                    fs:SetPoint("LEFT", isHeader and pages.Performance.perfHeader or fs:GetParent(), "LEFT", left + pad, 0)
                    fs:SetJustifyH("LEFT")
                else
                    fs:SetPoint("LEFT", isHeader and pages.Performance.perfHeader or fs:GetParent(), "LEFT", left + pad, 0)
                    fs:SetJustifyH("RIGHT")
                end
                left = left + cw
            end
        end
        PlaceColumns(pages.Performance.perfHeaders, true)
        for _, row in ipairs(perfRows) do
            PlaceColumns({ row.name, row.deep, row.recent, row.peak, row.memory, row.errors }, false)
        end

        if h < 500 then
            pages.Performance.perfHeader:SetPoint("TOPLEFT", 0, -68)
            pages.Performance.perfHeader:SetPoint("TOPRIGHT", -18, -68)
        end
    end

    if pages.Errors and errorsChild and detailEdit and detailMeasure then
        local usableW = max(480, pages.Errors:GetWidth() - 36)
        errorsChild:SetWidth(usableW)
        detailEdit:SetWidth(max(460, usableW - 4))
        detailMeasure:SetWidth(max(460, usableW - 4))
        detailEdit:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
        detailMeasure:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
        for _, row in ipairs(errorRows) do
            row.text:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
        end
    end

    if perfSummary then perfSummary:SetFont(STANDARD_TEXT_FONT, compact and 9 or 10, "OUTLINE") end
    if errorSummary then errorSummary:SetFont(STANDARD_TEXT_FONT, compact and 9 or 10, "OUTLINE") end
    if healthSummary then healthSummary:SetFont(STANDARD_TEXT_FONT, compact and 11 or 13, "OUTLINE") end
    if healthAdvice then healthAdvice:SetFont(STANDARD_TEXT_FONT, compact and 10 or 12, "OUTLINE") end
end

function CAP:RequestDeepPerformanceTest()
    if deepTestRunning then
        Print("A 30-second deep performance test is already running.")
        return
    end
    if IsCPUProfilingEnabled() then
        self:StartDeepPerformanceTest()
    else
        CharDB().pendingDeepScan = true
        StaticPopup_Show("CHAYADDONPROFILES_ENABLE_PROFILE")
    end
end

function CAP:StartDeepPerformanceTest()
    if deepTestRunning then return end
    if not IsCPUProfilingEnabled() then
        CharDB().pendingDeepScan = true
        StaticPopup_Show("CHAYADDONPROFILES_ENABLE_PROFILE")
        return
    end
    if not ResetCPUUsage or not UpdateAddOnCPUUsage or not GetAddOnCPUUsage then
        CharDB().pendingDeepScan = false
        Print("The legacy CPU interval profiler API is unavailable on this client; the deep test was not started.")
        return
    end

    local d = CharDB()
    d.pendingDeepScan = false
    deepTestRunning = true
    wipe(deepFpsSamples)
    deepTestStartedAt = GetTime()
    pcall(ResetCPUUsage)
    pcall(UpdateAddOnCPUUsage)

    if deepTestButton then SetButtonEnabled(deepTestButton, false) end
    if deepStatusText then deepStatusText:SetText("30s test running…") end
    if perfSummary then perfSummary:SetText("30-second deep CPU test is running. Reproduce the FPS problem now and play normally; avoid opening unrelated menus unless they are part of the problem.") end

    deepTestTicker = C_Timer.NewTicker(0.25, function()
        if GetFramerate then deepFpsSamples[#deepFpsSamples + 1] = GetFramerate() end
        local left = max(0, DEEP_TEST_SECONDS - (GetTime() - deepTestStartedAt))
        if deepStatusText then deepStatusText:SetText(format("Deep Test: %.1fs", left)) end
    end)
    deepTestTimer = C_Timer.NewTimer(DEEP_TEST_SECONDS, function()
        CAP:FinishDeepPerformanceTest()
    end)
end

function CAP:FinishDeepPerformanceTest()
    if not deepTestRunning then return end
    deepTestRunning = false
    if deepTestTicker then deepTestTicker:Cancel(); deepTestTicker = nil end
    if deepTestTimer then deepTestTimer = nil end

    local elapsed = max(0.001, GetTime() - (deepTestStartedAt or GetTime()))
    pcall(UpdateAddOnCPUUsage)
    if UpdateAddOnMemoryUsage then pcall(UpdateAddOnMemoryUsage) end

    local d = CharDB()
    d.deepResults = {}
    local totalCPU = 0
    local raw = {}
    local count = GetAddOnCount()
    for i = 1, count do
        local name = GetAddOnInfo(i)
        if name and IsLoaded(name) then
            local ok, cpu = pcall(GetAddOnCPUUsage, name)
            cpu = ok and type(cpu) == "number" and cpu or 0
            totalCPU = totalCPU + cpu
            raw[name] = cpu
        end
    end
    for name, cpu in pairs(raw) do
        d.deepResults[name] = {
            cpuMs = cpu,
            cpuPerSec = cpu / elapsed,
            share = totalCPU > 0 and (cpu / totalCPU * 100) or 0,
        }
    end

    local fpsMin, fpsTotal = nil, 0
    for _, value in ipairs(deepFpsSamples) do
        fpsMin = fpsMin and min(fpsMin, value) or value
        fpsTotal = fpsTotal + value
    end
    local fpsAvg = #deepFpsSamples > 0 and (fpsTotal / #deepFpsSamples) or (GetFramerate and GetFramerate() or 0)
    fpsMin = fpsMin or fpsAvg
    d.lastDeepScan = {
        completedAt = time(),
        duration = elapsed,
        fpsAvg = fpsAvg,
        fpsMin = fpsMin,
        totalCPU = totalCPU,
    }

    if deepStatusText then deepStatusText:SetText("30s test complete") end
    if deepTestButton then SetButtonEnabled(deepTestButton, true) end
    self:RefreshDiagnostics(true)
    Print("30-second deep performance test complete. CPU profiling is still enabled; disable it when you are finished testing.")
end


function CAP:ShowDiagnostics(tab)
    local main = _G.ChayAddonProfilesFrame
    if not main then
        CAP:Toggle()
        main = _G.ChayAddonProfilesFrame
    elseif not main:IsShown() then
        main:Show()
    end
    if main and not diagFrame then CAP:AttachDiagnostics(main) end
    if diagFrame then
        diagFrame:Show()
        SetTab(tab or currentTab or "Health")
        CAP:RefreshDiagnostics(false)
    end
end

function CAP:RefreshDiagnostics(force)
    if not diagFrame then return end
    local d = CharDB()
    if force then
        cachedProfilerAvailable = RefreshPerformanceData() and true or false
    elseif #lastPerf == 0 then
        cachedProfilerAvailable = C_AddOnProfiler and C_AddOnProfiler.GetAddOnMetric and Enum and Enum.AddOnProfilerMetric and Enum.AddOnProfilerMetric.RecentAverageTime ~= nil and true or false
    end
    local profilerAvailable = cachedProfilerAvailable

    local totalErrors, unique = 0, #d.errors
    local high = 0
    for _, err in ipairs(d.errors) do
        totalErrors = totalErrors + (err.count or 1)
        local _, rank = GetDiagnosis(err)
        if rank >= 3 then high = high + 1 end
    end

    local fps = GetFramerate and GetFramerate() or 0
    local home, world = 0, 0
    if GetNetStats then
        local _, _, h, w = GetNetStats()
        home, world = h or 0, w or 0
    end
    local totalMemory = 0
    for _, item in ipairs(lastPerf) do totalMemory = totalMemory + (item.memory or 0) end

    if healthSummary then
        healthSummary:SetText(table.concat({
            "|cffff3028Current game health|r",
            format("FPS: %.0f     Home latency: %d ms     World latency: %d ms", fps, home, world),
            format("Loaded addon memory: %s     Errors: %d occurrences / %d unique", FormatMemory(totalMemory), totalErrors, unique),
            format("High/Critical unique issues: %d     Modern addon profiler: %s", high, profilerAvailable and "|cff62e86bAvailable|r" or "|cffffc247Unavailable|r"),
            format("Error capture: %s", errorCaptureMode == "BugGrabber" and "|cff62e86bBugGrabber live + current-session sync|r" or errorCaptureMode == "AddLuaErrorHandler" and "|cff62e86bBlizzard Lua error callback|r" or errorCaptureMode == "ErrorHandler" and "|cffffc247Fallback error handler|r" or "|cffff5c5cNot installed|r"),
        }, "\n"))
    end

    if healthAdvice then
        local lines = { "|cffffc247What to do next|r" }
        if totalErrors > 0 then
            lines[#lines + 1] = "• Open Errors first. Repeating Lua/taint failures are concrete bugs and should be fixed before blaming memory usage."
        else
            lines[#lines + 1] = "• No captured errors yet. Reproduce the problem, then return here."
        end
        if profilerAvailable then
            lines[#lines + 1] = "• Performance uses Blizzard's addon profiler for live Recent/Peak metrics. Use 30s Deep Test when you need a controlled interval CPU measurement while reproducing an FPS drop."
        else
            lines[#lines + 1] = "• This client did not expose the modern addon profiler API. ChayAddonProfiles will not invent CPU numbers."
        end
        lines[#lines + 1] = "• High memory alone is not treated as an FPS problem. Use measured execution time, repeated errors, and a disable/reload A/B test together."
        lines[#lines + 1] = "• For a code fix: select the error → ChatGPT Fix Report → Select All → Ctrl+C, then upload the broken addon's ZIP with that report."
        healthAdvice:SetText(table.concat(lines, "\n\n"))
    end

    if perfSummary and not deepTestRunning then
        local deep = d.lastDeepScan
        if deep then
            perfSummary:SetText(format("30s Deep Test: %.1fs sample, avg %.0f FPS, min %.0f FPS. Table sorts by measured 30s CPU first; Recent/Peak remain Blizzard profiler metrics.", deep.duration or 0, deep.fpsAvg or 0, deep.fpsMin or 0))
        elseif profilerAvailable then
            perfSummary:SetText("Recent/Peak use Blizzard's addon profiler. Run 30s Deep Test for a controlled interval CPU measurement while reproducing the FPS problem.")
        else
            perfSummary:SetText("Modern profiler metrics are unavailable. Run 30s Deep Test for measured addon CPU, or use memory/error data without guessed CPU values.")
        end
    end

    local visiblePerf = min(MAX_VISIBLE_ROWS, #lastPerf)
    for i, row in ipairs(perfRows) do
        local item = lastPerf[perfTopIndex + i - 1]
        if item and i <= visiblePerf then
            row.addonName = item.name
            row.name:SetText((selectedAddon == item.name and "|cffff3028> |r" or "") .. item.title)
            row.deep:SetText(item.deepCPU and format("%.2f", item.deepCPU) or "—")
            row.recent:SetText(item.recent and format("%.3f", item.recent) or "—")
            row.peak:SetText(item.peak and format("%.3f", item.peak) or "—")
            row.memory:SetText(FormatMemory(item.memory))
            row.errors:SetText(tostring(item.errors or 0))
            row.perfItem = item
            row:Show()
        else
            row.addonName = nil
            row.perfItem = nil
            row:Hide()
        end
    end
    if pages.Performance and pages.Performance.testButton then
        SetButtonEnabled(pages.Performance.testButton, selectedAddon ~= nil and selectedAddon ~= ADDON_NAME)
    end
    if pages.Performance and pages.Performance.restoreButton then
        SetButtonEnabled(pages.Performance.restoreButton, CharDB().testAddon ~= nil)
        SetButtonText(pages.Performance.restoreButton, CharDB().testAddon and "Restore Tested Addon" or "No A/B Test Active")
    end
    if deepTestButton then
        SetButtonEnabled(deepTestButton, not deepTestRunning)
        SetButtonText(deepTestButton, deepTestRunning and "Test Running…" or "30s Deep Test")
    end
    if disableProfileButton then
        disableProfileButton:SetShown(IsCPUProfilingEnabled())
    end
    if deepStatusText and not deepTestRunning then
        local last = d.lastDeepScan
        deepStatusText:SetText(last and ("Last deep test: " .. date("%H:%M:%S", last.completedAt or time())) or "")
    end

    if errorSummary then
        errorSummary:SetText(format("%d occurrences across %d unique issues. Click an issue for selectable detail text and a ChatGPT repair report.", totalErrors, unique))
    end

    local ranked = {}
    for index, err in ipairs(d.errors) do
        local severity, rank, color = GetDiagnosis(err)
        ranked[#ranked + 1] = { index = index, err = err, severity = severity, rank = rank, color = color }
    end
    table_sort(ranked, function(a, b)
        if a.rank ~= b.rank then return a.rank > b.rank end
        local ac, bc = a.err.count or 1, b.err.count or 1
        if ac ~= bc then return ac > bc end
        return (a.err.lastSeen or 0) > (b.err.lastSeen or 0)
    end)

    for i, row in ipairs(errorRows) do
        local entry = ranked[errorTopIndex + i - 1]
        if entry then
            local err = entry.err
            row.errorIndex = entry.index
            local first = match(tostring(err.message or ""), "([^\n]+)") or ""
            if #first > 110 then first = first:sub(1, 107) .. "..." end
            row.text:SetText(format("%s[%s]|r [%dx] %s — %s", entry.color, entry.severity, err.count or 1, err.addon or "unknown source", first))
            row:Show()
        else
            row.errorIndex = nil
            row:Hide()
        end
    end

    local err = selectedError and d.errors[selectedError]
    local detailText
    if err then
        local severity, _, color, issue = GetDiagnosis(err)
        detailText = table.concat({
            format("%sSeverity: %s|r", color, severity),
            "Type: " .. tostring(err.kind or "Lua Error"),
            "Addon/source: " .. tostring(err.addon or "Could not attribute safely"),
            "Occurrences: " .. tostring(err.count or 1),
            "Last seen: " .. date("%Y-%m-%d %H:%M:%S", err.lastSeen or time()),
            "",
            "Detected pattern: " .. issue,
            "",
            "Recommended repair path:",
            GetFixGuidance(err),
            "",
            "Message:",
            tostring(err.message or ""),
            err.stack and err.stack ~= "" and ("\nStack:\n" .. err.stack) or "",
            err.locals and err.locals ~= "" and ("\nLocals:\n" .. err.locals) or "",
        }, "\n")
        if pages.Errors and pages.Errors.reportButton then SetButtonEnabled(pages.Errors.reportButton, true) end
    else
        detailText = "Select an error above. This box is directly selectable: click inside it, then use Ctrl+A and Ctrl+C. ChayAddonProfiles only attributes a source when the error text/stack identifies it; it does not guess."
        if pages.Errors and pages.Errors.reportButton then SetButtonEnabled(pages.Errors.reportButton, false) end
    end
    if detailEdit and detailMeasure and detailScroll then
        detailMeasure:SetText(detailText)
        detailEdit:SetText(detailText)
        detailEdit:SetCursorPosition(0)
        detailEdit:ClearFocus()
        local child = detailScroll:GetScrollChild()
        local h = max(detailScroll:GetHeight(), detailMeasure:GetStringHeight() + 18)
        child:SetHeight(h)
        detailEdit:SetHeight(h)
    end

    if force then CAP:UpdateDiagnosticsLayout() end
end

StaticPopupDialogs["CHAYADDONPROFILES_ENABLE_PROFILE"] = {
    text = "The 30-second Deep Test needs WoW's scriptProfile CVar. CPU profiling has overhead and requires a UI reload. Enable it, reload, and automatically start the test?",
    button1 = "Enable + Reload",
    button2 = "Cancel",
    OnAccept = function()
        CharDB().pendingDeepScan = true
        if SetCPUProfiling(true) then ReloadUI() end
    end,
    OnCancel = function() CharDB().pendingDeepScan = false end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["CHAYADDONPROFILES_DISABLE_PROFILE"] = {
    text = "Disable WoW CPU profiling and reload the UI? This is recommended after deep performance testing because scriptProfile adds overhead.",
    button1 = "Disable + Reload",
    button2 = "Cancel",
    OnAccept = function()
        CharDB().pendingDeepScan = false
        if SetCPUProfiling(false) then ReloadUI() end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}


-- Keep the original profile manager core untouched. Diagnostics attaches externally
-- after the original UI creates its main frame.
local originalToggle = CAP.Toggle
if type(originalToggle) == "function" then
    CAP.Toggle = function(self, ...)
        local result = originalToggle(self, ...)
        local main = _G.ChayAddonProfilesFrame
        if main and not diagFrame then
            CAP:AttachDiagnostics(main)
        end
        return result
    end
end

local originalShow = CAP.Show
if type(originalShow) == "function" then
    CAP.Show = function(self, ...)
        local result = originalShow(self, ...)
        local main = _G.ChayAddonProfilesFrame
        if main and not diagFrame then
            CAP:AttachDiagnostics(main)
        end
        return result
    end
end

local originalSlash = SlashCmdList and SlashCmdList.CHAYADDONPROFILES
if type(originalSlash) == "function" then
    SlashCmdList.CHAYADDONPROFILES = function(msg)
        local cmd = lower((msg or ""):match("^%s*(.-)%s*$") or "")
        if cmd == "diagnostics" or cmd == "diag" then
            CAP:ShowDiagnostics("Health")
        elseif cmd == "performance" or cmd == "perf" then
            CAP:ShowDiagnostics("Performance")
        elseif cmd == "errors" or cmd == "error" then
            CAP:ShowDiagnostics("Errors")
        else
            originalSlash(msg)
        end
    end
end

ReattributeStoredErrors()
InstallErrorCapture(false)
SyncCurrentBugGrabberSession()

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("LUA_WARNING")
eventFrame:RegisterEvent("ADDON_ACTION_BLOCKED")
eventFrame:RegisterEvent("ADDON_ACTION_FORBIDDEN")
eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == "!BugGrabber" or loadedAddon == "BugSack" then
            InstallErrorCapture(false)
            SyncCurrentBugGrabberSession()
        end
    elseif event == "PLAYER_LOGIN" then
        CharDB()
        InstallErrorCapture(true)
        SyncCurrentBugGrabberSession()
        C_Timer.After(1, function()
            local d = CharDB()
            if d.pendingDeepScan and IsCPUProfilingEnabled() then
                CAP:ShowDiagnostics("Performance")
                CAP:StartDeepPerformanceTest()
            elseif d.testAddon then
                Print("A/B test active: " .. tostring(d.testAddon) .. " is disabled. Reproduce the issue, then restore it from Diagnostics when finished.")
            end
        end)
    elseif event == "LUA_WARNING" then
        local a, b = ...
        SaveError("Lua Warning", b or a or "LUA_WARNING", "")
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        local a, b = ...
        local addon = type(a) == "string" and a or nil
        SaveError("Protected Action", format("%s: %s | %s", event, tostring(a), tostring(b)), "", addon)
    end
end)
