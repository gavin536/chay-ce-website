ChayAddonProfiles

Install:
1. Extract this folder into World of Warcraft/_retail_/Interface/AddOns/
2. Final path must be: Interface/AddOns/ChayAddonProfiles/ChayAddonProfiles.toc
3. Restart WoW or reload the addon list.

Commands:
/cap - Open manager
/cap apply - Apply detected profile
/cap scan - Scan for new/deleted addons
/cap clearnew - Clear NEW highlights
/cap copytoon - Copy the selected saved toon setup into this toon
/cap toons - List saved toon setups
/cap reload - Reload UI

Notes:
- New addons are enabled for the current toon when detected. Opening from the NEW-addon prompt shows only the newly detected addon(s) while leaving the Search box blank. NEW highlighting is session-only and clears after reload.
- Addon enable/disable changes require Reload UI before they fully apply.
- Per Character stores each toon separately in ChayAddonProfilesDB.characterProfiles so other toons can be copied from the dropdown.
- Toon setups appear in the copy dropdown after that character has logged in once with this version loaded.
- The addon will never disable itself.
- Blizzard_* addons are treated as protected and kept enabled.

Diagnostics (1.8.2)
- Open ChayAddonProfiles and click Diagnostics.
- Errors are captured continuously but do not trigger performance scans.
- Performance metrics refresh only when requested.
- 30s Deep Test is an explicit controlled CPU test.
- Error details and ChatGPT Fix Report are selectable with Ctrl+A / Ctrl+C.
