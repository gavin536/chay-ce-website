ChayAddonProfiles

Install:
1. Extract this folder into World of Warcraft/_retail_/Interface/AddOns/
2. Final path must be: Interface/AddOns/ChayAddonProfiles/ChayAddonProfiles.toc
3. Restart WoW or reload the addon list.

Commands:
/cap - Open manager
/cap apply - Apply detected profile
/cap scan - Scan for new/deleted addons
/cap reload - Reload UI

Notes:
- Addon enable/disable changes require Reload UI before they fully apply.
- The addon will never disable itself.
- Blizzard_* addons are treated as protected and kept enabled.
